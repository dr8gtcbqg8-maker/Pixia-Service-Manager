# Pixia Service Manager deployen op Cloudflare Pages

## Optie 1: direct uploaden als zip
Gebruik de zip `pixia-service-manager-12-05-cloudflare-drag-drop.zip`.

1. Ga naar Cloudflare Dashboard > Workers & Pages > Pages.
2. Kies **Upload assets** of **Direct Upload**.
3. Upload de drag-and-drop zip.
4. Publiceer de site.

Let op: bij direct upload is de app al gebouwd. Build-time environment variables zoals `VITE_GEMINI_API_KEY` moeten vóór het bouwen aanwezig zijn. Als je AI-functies direct wilt laten werken, bouw dan lokaal met een `.env.local` met je key of gebruik optie 2.

## Optie 2: source zip / GitHub deploy
Gebruik de zip `pixia-service-manager-12-05-cloudflare-source.zip` of zet deze source op GitHub.

Cloudflare Pages instellingen:

- Framework preset: **Vite**
- Build command: `npm run build`
- Build output directory: `dist`
- Node.js version: `22`

Environment variables:

```txt
VITE_GEMINI_API_KEY=je_gemini_api_key
```

## Firebase controle
Voeg je Cloudflare Pages domein toe aan Firebase:

Firebase Console > Authentication > Settings > Authorized domains

Voeg toe:

```txt
jouw-project.pages.dev
```

## Wat is toegevoegd

- `wrangler.toml` voor Cloudflare Pages.
- `public/_redirects` voor React Router / SPA fallback.
- `public/_headers` voor security- en cache headers.
- Vite build-output ingesteld op `dist`.
- `VITE_GEMINI_API_KEY` ondersteuning toegevoegd.
