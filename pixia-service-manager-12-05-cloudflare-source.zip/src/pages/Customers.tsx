import React, { useEffect, useState, useMemo } from 'react';
import { Customer, Intervention, WorkOrder } from '../types';
import { Plus, MapPin, Phone, Mail, Edit3, Trash2, ExternalLink, User, Printer, Wrench, FileText, X, Navigation } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ConfirmDialog from '../components/ConfirmDialog';
import DocumentSection from '../components/DocumentSection';
import { useCustomers } from '../hooks/useCustomers';
import { customerService } from '../services/customerService';
import CustomerTable from '../components/customers/CustomerTable';
import CustomerFilters from '../components/customers/CustomerFilters';
import { cn } from '../lib/utils';
import { format, parseISO } from 'date-fns';
import { nl } from 'date-fns/locale';

const Customers: React.FC = () => {
  const { customers, loading, refreshData } = useCustomers();
  const [search, setSearch] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<{ isOpen: boolean; id: string | null }>({ isOpen: false, id: null });
  const [newCustomer, setNewCustomer] = useState({
    name: '',
    contactPerson: '',
    email: '',
    phone: '',
    address: '',
    billingAddress: '',
    status: 'active' as Customer['status'],
    notes: '',
    internalNotes: '',
    locations: [] as string[]
  });

  const handleOpenAddModal = () => {
    setSelectedCustomer(null);
    setNewCustomer({ 
      name: '', 
      contactPerson: '', 
      email: '', 
      phone: '', 
      address: '', 
      billingAddress: '',
      status: 'active',
      notes: '',
      internalNotes: '',
      locations: []
    });
    setIsAddModalOpen(true);
  };

  const handleOpenEditModal = (customer: Customer) => {
    setSelectedCustomer(customer);
    setNewCustomer({
      name: customer.name,
      contactPerson: customer.contactPerson || '',
      email: customer.email || '',
      phone: customer.phone || '',
      address: customer.address || '',
      billingAddress: customer.billingAddress || '',
      status: customer.status,
      notes: customer.notes || '',
      internalNotes: customer.internalNotes || '',
      locations: customer.locations || []
    });
    setIsAddModalOpen(true);
  };

  const handleSaveCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    const resultId = await customerService.save(newCustomer, selectedCustomer);
    if (resultId) {
      setIsAddModalOpen(false);
      setNewCustomer({ 
        name: '', 
        contactPerson: '', 
        email: '', 
        phone: '', 
        address: '', 
        billingAddress: '',
        status: 'active',
        notes: '',
        internalNotes: '',
        locations: []
      });
      refreshData();
    }
  };

  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [selectedTab, setSelectedTab] = useState('gegevens');
  const [customerMachines, setCustomerMachines] = useState<any[]>([]);
  const [customerInterventions, setCustomerInterventions] = useState<Intervention[]>([]);
  const [customerWorkOrders, setCustomerWorkOrders] = useState<WorkOrder[]>([]);

  const handleOpenDetails = async (customer: Customer) => {
    setSelectedCustomer(customer);
    setSelectedTab('gegevens');
    const { machines, interventions, workOrders } = await customerService.getRelatedData(customer.id);
    setCustomerMachines(machines);
    setCustomerInterventions(interventions as Intervention[]);
    setCustomerWorkOrders(workOrders as WorkOrder[]);
    setIsDetailsModalOpen(true);
  };

  const handleDeleteClick = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setDeleteConfirm({ isOpen: true, id });
  };

  const confirmDelete = async () => {
    if (!deleteConfirm.id) return;
    const success = await customerService.delete(deleteConfirm.id);
    if (success) {
      setDeleteConfirm({ isOpen: false, id: null });
      refreshData();
    }
  };

  const filteredCustomers = useMemo(() => customers.filter(c => 
    c.name.toLowerCase().includes(search.toLowerCase()) || 
    c.contactPerson?.toLowerCase().includes(search.toLowerCase()) ||
    c.email?.toLowerCase().includes(search.toLowerCase()) ||
    c.phone?.toLowerCase().includes(search.toLowerCase()) ||
    c.address?.toLowerCase().includes(search.toLowerCase()) ||
    c.locations?.some(loc => loc.toLowerCase().includes(search.toLowerCase()))
  ), [customers, search]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Klantenbeheer</h1>
          <p className="text-sm text-slate-500 mt-1">Beheer uw relaties en machineparken.</p>
        </div>
        <button 
          onClick={handleOpenAddModal}
          className="btn-primary"
        >
          <Plus className="w-4 h-4" />
          <span>Nieuwe Klant</span>
        </button>
      </div>

      <CustomerFilters search={search} setSearch={setSearch} />

      {loading ? (
        <div className="flex justify-center p-20">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-600"></div>
        </div>
      ) : (
        <CustomerTable 
          customers={filteredCustomers}
          onSelect={handleOpenDetails}
          onEdit={handleOpenEditModal}
          onDelete={handleDeleteClick}
        />
      )}

      <ConfirmDialog
        isOpen={deleteConfirm.isOpen}
        title="Klant Verwijderen"
        message="LET OP: Weet u zeker dat u deze klant wilt verwijderen? Hiermee worden ook alle historische gegevens, machines en interventierapporten van deze klant onbereikbaar of verwijderd uit de context. Deze actie is definitief."
        onConfirm={confirmDelete}
        onCancel={() => setDeleteConfirm({ isOpen: false, id: null })}
      />

      {/* Add/Edit Modal */}
      <AnimatePresence>
        {isAddModalOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
              onClick={() => setIsAddModalOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative bg-white w-full max-w-2xl rounded-2xl shadow-xl p-8 max-h-[90vh] overflow-y-auto custom-scrollbar"
            >
              <div className="flex items-center justify-between mb-8 pb-4 border-b border-slate-100">
                <h2 className="text-xl font-bold text-slate-900">
                  {selectedCustomer ? 'Klant bewerken' : 'Nieuwe klant toevoegen'}
                </h2>
                <button onClick={() => setIsAddModalOpen(false)} className="p-2 hover:bg-slate-100 rounded-lg text-slate-400 transition-all">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveCustomer} className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-4">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Basis informatie</h3>
                    <div className="space-y-3">
                      <div>
                        <label className="label">Bedrijfsnaam *</label>
                        <input 
                          required 
                          type="text" 
                          placeholder="Bijv. Pixia Service"
                          className="input-field" 
                          value={newCustomer.name}
                          onChange={(e) => setNewCustomer({...newCustomer, name: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="label">Contactpersoon</label>
                        <input 
                          type="text" 
                          placeholder="Naam hoofdcontact"
                          className="input-field" 
                          value={newCustomer.contactPerson}
                          onChange={(e) => setNewCustomer({...newCustomer, contactPerson: e.target.value})}
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="label">Telefoon</label>
                          <input 
                            type="text" 
                            className="input-field" 
                            value={newCustomer.phone}
                            onChange={(e) => setNewCustomer({...newCustomer, phone: e.target.value})}
                          />
                        </div>
                        <div>
                          <label className="label">Status</label>
                          <select 
                            className="input-field"
                            value={newCustomer.status}
                            onChange={(e) => setNewCustomer({...newCustomer, status: e.target.value as Customer['status']})}
                          >
                            <option value="active">Actief</option>
                            <option value="inactive">Inactief</option>
                            <option value="lead">Lead</option>
                            <option value="prospect">Prospect</option>
                          </select>
                        </div>
                      </div>
                      <div>
                        <label className="label">Email adres</label>
                        <input 
                          type="email" 
                          placeholder="klant@bedrijf.nl"
                          className="input-field" 
                          value={newCustomer.email}
                          onChange={(e) => setNewCustomer({...newCustomer, email: e.target.value})}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Locaties & Adres</h3>
                    <div className="space-y-3">
                      <div>
                        <label className="label">Bezoekadres</label>
                        <textarea 
                          rows={2}
                          placeholder="Straat en nummer, Postcode, Stad"
                          className="input-field resize-none min-h-[80px]" 
                          value={newCustomer.address}
                          onChange={(e) => setNewCustomer({...newCustomer, address: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="label">Factuuradres</label>
                        <textarea 
                          rows={2}
                          placeholder="Laat leeg indien hetzelfde als bezoekadres"
                          className="input-field resize-none min-h-[80px]" 
                          value={newCustomer.billingAddress}
                          onChange={(e) => setNewCustomer({...newCustomer, billingAddress: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="label">Extra Locaties (één per regel)</label>
                        <textarea 
                          rows={2}
                          placeholder="Magazijn A, Tweede Vestiging..."
                          className="input-field resize-none min-h-[80px]" 
                          value={newCustomer.locations.join('\n')}
                          onChange={(e) => setNewCustomer({...newCustomer, locations: e.target.value.split('\n').filter(l => l.trim() !== '')})}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-100 space-y-4">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Notities</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="label">Algemeen</label>
                      <textarea 
                        rows={3}
                        placeholder="Algemene klantinformatie..."
                        className="input-field resize-none" 
                        value={newCustomer.notes}
                        onChange={(e) => setNewCustomer({...newCustomer, notes: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="label text-rose-500 font-bold">Interne opmerkingen (geheim)</label>
                      <textarea 
                        rows={3}
                        placeholder="Zichtbaar alleen voor admins en technici..."
                        className="input-field bg-rose-50/20 border-rose-100 focus:ring-rose-500 resize-none font-medium text-rose-900" 
                        value={newCustomer.internalNotes}
                        onChange={(e) => setNewCustomer({...newCustomer, internalNotes: e.target.value})}
                      />
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-end gap-3 pt-6 border-t border-slate-100">
                  <button 
                    type="button" 
                    onClick={() => setIsAddModalOpen(false)}
                    className="btn-ghost"
                  >
                    Annuleren
                  </button>
                  <button 
                    type="submit" 
                    className="btn-primary min-w-[160px]"
                  >
                    {selectedCustomer ? 'Wijzigingen opslaan' : 'Klant aanmaken'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Details Modal / Dossier */}
      <AnimatePresence>
        {isDetailsModalOpen && selectedCustomer && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
              onClick={() => setIsDetailsModalOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative bg-white w-full max-w-5xl rounded-2xl shadow-xl overflow-hidden flex flex-col max-h-[90vh]"
            >
              {/* Header */}
              <div className="px-8 py-6 border-b border-slate-100 flex items-center justify-between bg-slate-50">
                <div className="flex items-center gap-5">
                  <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center text-white text-2xl font-bold shadow-lg shadow-blue-500/20 uppercase">
                    {selectedCustomer.name.charAt(0)}
                  </div>
                  <div>
                    <div className="flex items-center gap-3">
                      <h2 className="text-2xl font-bold text-slate-900 leading-tight">{selectedCustomer.name}</h2>
                      <span className={cn(
                        "px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border",
                        selectedCustomer.status === 'active' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 'bg-slate-100 text-slate-600 border-slate-200'
                      )}>
                        {selectedCustomer.status}
                      </span>
                    </div>
                    <p className="text-sm font-medium text-slate-500 mt-1 flex items-center gap-2">
                       #{selectedCustomer.id.slice(-6).toUpperCase()}
                       <span className="w-1 h-1 bg-slate-300 rounded-full" />
                       {customerMachines.length} machines in park
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => handleOpenEditModal(selectedCustomer)}
                    className="btn-ghost !p-2 text-slate-400 hover:text-blue-600 transition-all"
                    title="Bewerken"
                  >
                    <Edit3 className="w-5 h-5" />
                  </button>
                  <button onClick={() => setIsDetailsModalOpen(false)} className="p-2 hover:bg-slate-100 rounded-lg text-slate-400 transition-all">
                    <X className="w-6 h-6" />
                  </button>
                </div>
              </div>

              <div className="flex flex-1 overflow-hidden">
                {/* Stats Sidebar */}
                <div className="w-72 border-r border-slate-100 bg-slate-50/50 p-6 space-y-8 hidden md:block overflow-y-auto custom-scrollbar">
                  <div className="space-y-4">
                    <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Contactinformatie</h3>
                    <div className="space-y-4">
                      <div className="flex items-start gap-3">
                         <div className="p-2 bg-white rounded-xl border border-slate-200 text-slate-400 shrink-0 shadow-sm">
                           <User className="w-4 h-4" />
                         </div>
                         <div className="min-w-0">
                           <p className="text-xs font-bold text-slate-900 truncate">{selectedCustomer.contactPerson || 'Geen contactpersoon'}</p>
                           <p className="text-[10px] text-slate-500 mt-0.5">Focuspersoon</p>
                         </div>
                      </div>
                      <div className="flex items-start gap-3">
                         <div className="p-2 bg-white rounded-xl border border-slate-200 text-slate-400 shrink-0 shadow-sm">
                           <Phone className="w-4 h-4" />
                         </div>
                         <div className="min-w-0">
                           <p className="text-xs font-bold text-slate-900">{selectedCustomer.phone || '-'}</p>
                           <p className="text-[10px] text-slate-500 mt-0.5">Direct nummer</p>
                         </div>
                      </div>
                      <div className="flex items-start gap-3">
                         <div className="p-2 bg-white rounded-xl border border-slate-200 text-slate-400 shrink-0 shadow-sm">
                           <Mail className="w-4 h-4" />
                         </div>
                         <div className="min-w-0">
                           <p className="text-xs font-bold text-slate-900 truncate" title={selectedCustomer.email}>{selectedCustomer.email || '-'}</p>
                           <p className="text-[10px] text-slate-500 mt-0.5">E-mail adres</p>
                         </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4 pt-8 border-t border-slate-200">
                    <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Operationele Stats</h3>
                    <div className="grid grid-cols-2 gap-3">
                       <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-sm text-center">
                          <p className="text-xl font-bold text-slate-900 leading-tight">{customerMachines.length}</p>
                          <p className="text-[9px] font-bold text-slate-500 uppercase mt-0.5 tracking-tighter">Machines</p>
                       </div>
                       <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-sm text-center">
                          <p className="text-xl font-bold text-blue-600 leading-tight">{customerInterventions.filter(i => i.status !== 'completed').length}</p>
                          <p className="text-[9px] font-bold text-slate-500 uppercase mt-0.5 tracking-tighter">Open Interv.</p>
                       </div>
                    </div>
                  </div>

                  <div className="pt-8 border-t border-slate-200">
                    <button 
                      onClick={() => window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(selectedCustomer.address || '')}`, '_blank')}
                      className="w-full btn-secondary text-[10px] h-10 flex items-center justify-center gap-2 group"
                    >
                      <Navigation className="w-3.5 h-3.5 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" /> 
                      Maps Navigatie
                    </button>
                  </div>
                </div>

                <div className="flex-1 flex flex-col min-w-0 bg-white">
                  {/* Tabs */}
                  <div className="flex px-8 bg-white border-b border-slate-100 overflow-x-auto scrollbar-hide">
                    {[
                      { id: 'gegevens', label: 'Dossier' },
                      { id: 'machines', label: 'Machinepark' },
                      { id: 'interventies', label: 'Interventies' },
                      { id: 'werkbonnen', label: 'Werkbonnen' },
                      { id: 'documenten', label: 'Documentatie' }
                    ].map((tab) => (
                      <button
                        key={tab.id}
                        onClick={() => setSelectedTab(tab.id)}
                        className={cn(
                          "px-6 py-5 text-sm font-bold transition-all relative whitespace-nowrap",
                          selectedTab === tab.id 
                            ? "text-blue-600" 
                            : "text-slate-400 hover:text-slate-600"
                        )}
                      >
                        {tab.label}
                        {selectedTab === tab.id && (
                          <motion.div 
                            layoutId="customer-tab-active"
                            className="absolute bottom-0 left-0 right-0 h-1 bg-blue-600 rounded-t-full" 
                          />
                        )}
                      </button>
                    ))}
                  </div>

                  {/* Tab Content */}
                  <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
                    <AnimatePresence mode="wait">
                      {selectedTab === 'gegevens' && (
                        <motion.div
                          key="tab-gegevens"
                          initial={{ opacity: 0, x: 10 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: -10 }}
                          className="space-y-8"
                        >
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <div className="space-y-6">
                              <section>
                                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">Bezoekadres</h4>
                                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-700 leading-relaxed">
                                  {selectedCustomer.address || <span className="text-slate-400 font-normal italic">Geen adres ingesteld</span>}
                                </div>
                              </section>
                              <section>
                                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">Facturatie</h4>
                                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-700 leading-relaxed">
                                  {selectedCustomer.billingAddress || selectedCustomer.address || <span className="text-slate-400 font-normal italic">Zelfde als bezoekadres</span>}
                                </div>
                              </section>
                            </div>
                            <div className="space-y-6">
                              <section>
                                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">Extra locaties</h4>
                                <div className="space-y-2">
                                  {selectedCustomer.locations && selectedCustomer.locations.length > 0 ? (
                                    selectedCustomer.locations.map((loc, i) => (
                                      <div key={i} className="flex items-center gap-3 p-3 bg-white border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 shadow-sm">
                                        <MapPin className="w-4 h-4 text-slate-400" />
                                        {loc}
                                      </div>
                                    ))
                                  ) : (
                                    <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-400 italic">Geen bijkomende locaties</div>
                                  )}
                                </div>
                              </section>
                            </div>
                          </div>

                          <div className="pt-8 border-t border-slate-100">
                             <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Interne geschiedenis & Notities</h4>
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                               <div className="space-y-2">
                                 <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider ml-1">Klantnotities</p>
                                 <div className="p-5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-normal text-slate-600 leading-relaxed min-h-[120px] whitespace-pre-wrap">
                                   {selectedCustomer.notes || 'Geen notities geplaatst.'}
                                 </div>
                               </div>
                               <div className="space-y-2">
                                 <p className="text-[10px] font-bold text-rose-500 uppercase tracking-wider ml-1">Interne meldingen</p>
                                 <div className="p-5 bg-rose-50/20 border border-rose-100 rounded-xl text-sm font-normal text-rose-900 leading-relaxed min-h-[120px] whitespace-pre-wrap">
                                   {selectedCustomer.internalNotes || 'Geen interne opmerkingen beschikbaar.'}
                                 </div>
                               </div>
                             </div>
                          </div>
                        </motion.div>
                      )}

                      {selectedTab === 'machines' && (
                        <motion.div
                          key="tab-machines"
                          initial={{ opacity: 0, x: 10 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="space-y-6"
                        >
                          <div className="flex items-center justify-between">
                            <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Actieve vloot ({customerMachines.length})</h4>
                            <button className="text-xs font-bold text-blue-600 hover:underline">Machine toevoegen</button>
                          </div>
                          
                          {customerMachines.length > 0 ? (
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                              {customerMachines.map(m => (
                                <div key={m.id} className="p-5 bg-white border border-slate-200 rounded-2xl shadow-sm hover:ring-2 hover:ring-blue-100 transition-all group relative">
                                  <div className="flex items-start justify-between mb-4">
                                     <div className="p-2.5 bg-blue-50 text-blue-600 rounded-lg group-hover:bg-blue-600 group-hover:text-white transition-colors">
                                       <Printer className="w-5 h-5" />
                                     </div>
                                     <span className={cn(
                                       "px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider",
                                       m.status === 'active' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'
                                     )}>
                                       {m.status}
                                     </span>
                                  </div>
                                  <div>
                                    <p className="text-base font-bold text-slate-900">{m.brand} {m.model}</p>
                                    <p className="text-[11px] font-medium text-slate-500 mt-0.5">S/N: {m.serialNumber}</p>
                                  </div>
                                  <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 font-medium">
                                     <span className="flex items-center gap-1.5"><MapPin className="w-3 h-3" /> {m.location || 'Geen locatie'}</span>
                                     <button className="text-blue-600 font-bold hover:underline">Beheer</button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <div className="p-16 border-2 border-dashed border-slate-200 rounded-3xl text-center">
                               <Printer className="w-10 h-10 text-slate-300 mx-auto mb-4" />
                               <p className="text-base font-bold text-slate-900">Geen machines gevonden</p>
                               <p className="text-sm text-slate-500 mt-1 max-w-xs mx-auto">Er zijn momenteel geen machines gekoppeld aan deze klant.</p>
                            </div>
                          )}
                        </motion.div>
                      )}

                      {selectedTab === 'interventies' && (
                        <motion.div
                          key="tab-interventies"
                          initial={{ opacity: 0, x: 10 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="space-y-6"
                        >
                          <div className="flex items-center justify-between">
                            <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Interventie geschiedenis</h4>
                            <button className="text-xs font-bold text-blue-600 hover:underline">Nieuwe aanvraag</button>
                          </div>
                          
                          {customerInterventions.length > 0 ? (
                            <div className="space-y-3">
                              {customerInterventions.map(int => (
                                <div key={int.id} className="p-4 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors flex items-center gap-4 group cursor-pointer">
                                  <div className={cn(
                                    "w-10 h-10 rounded-lg flex items-center justify-center shrink-0 border",
                                    int.status === 'completed' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-blue-50 text-blue-600 border-blue-100'
                                  )}>
                                    <Wrench className="w-4 h-4" />
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <div className="flex items-center justify-between mb-0.5">
                                      <p className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors capitalize">{int.type}</p>
                                      <span className="text-[10px] font-bold text-slate-500">{format(parseISO(int.date), 'd MMM yyyy', { locale: nl })}</span>
                                    </div>
                                    <p className="text-xs text-slate-500 truncate font-medium">
                                      {customerMachines.find(m => m.id === int.machineId)?.model} — {int.problemDescription}
                                    </p>
                                  </div>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <div className="p-16 border-2 border-dashed border-slate-200 rounded-3xl text-center">
                               <Wrench className="w-10 h-10 text-slate-300 mx-auto mb-4" />
                               <p className="text-base font-bold text-slate-900">Nog geen interventies</p>
                               <p className="text-sm text-slate-500 mt-1 max-w-xs mx-auto">Er is nog geen onderhoud of reparatie uitgevoerd bij deze klant.</p>
                            </div>
                          )}
                        </motion.div>
                      )}

                      {/* Other tabs follow similar clean professional scale... */}
                      {selectedTab === 'werkbonnen' && (
                        <motion.div
                          key="tab-werkbonnen"
                          initial={{ opacity: 0, x: 10 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="space-y-4"
                        >
                           {/* Simplified placeholder for brevity, actual logic remains */}
                           <div className="grid grid-cols-1 gap-3">
                             {customerWorkOrders.map(wo => (
                               <div key={wo.id} className="p-4 bg-white border border-slate-200 rounded-xl flex items-center justify-between hover:bg-slate-50 transition-colors cursor-pointer group">
                                 <div className="flex items-center gap-4">
                                   <div className="w-10 h-10 bg-slate-100 text-slate-500 rounded-lg flex items-center justify-center">
                                     <FileText className="w-5 h-5" />
                                   </div>
                                   <div>
                                     <p className="text-sm font-bold text-slate-900">Werkbon #{wo.orderNumber}</p>
                                     <p className="text-[11px] text-slate-500 font-medium">{wo.date} · {wo.status}</p>
                                   </div>
                                 </div>
                                 <ExternalLink className="w-4 h-4 text-slate-300 group-hover:text-blue-600 transition-colors" />
                               </div>
                             ))}
                           </div>
                        </motion.div>
                      )}

                      {selectedTab === 'documenten' && (
                         <motion.div
                            key="tab-documenten"
                            initial={{ opacity: 0, x: 10 }}
                            animate={{ opacity: 1, x: 0 }}
                         >
                            <DocumentSection customerId={selectedCustomer.id} />
                         </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
              </div>

              <div className="px-8 py-5 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
                <p className="text-xs font-medium text-slate-500 italic">Laatst bijgewerkt: {new Date(selectedCustomer.updatedAt || '').toLocaleDateString('nl-NL')}</p>
                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => setIsDetailsModalOpen(false)}
                    className="btn-ghost !text-slate-600"
                  >
                    Sluiten
                  </button>
                  <button 
                    onClick={() => {
                        // Action to export or print
                    }}
                    className="btn-secondary h-10"
                  >
                    <Printer className="w-4 h-4" /> Dossier downloaden
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Customers;
