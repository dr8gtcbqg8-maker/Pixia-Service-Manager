import { collection, addDoc, query, where, getDocs, doc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { emailService } from '../lib/emailService';
import { Customer, Intervention, Appointment, UserProfile } from '../types';
import { COLLECTIONS } from '../constants/collections';

export type NotificationType = 'new_task' | 'update' | 'reminder' | 'alert' | 'system';

export const notificationService = {
  /**
   * Stuurt een in-app notificatie naar een technicus
   */
  async notifyTechnician(params: {
    technicianId: string;
    title: string;
    message: string;
    type: NotificationType;
    relatedId?: string;
  }) {
    try {
      await addDoc(collection(db, COLLECTIONS.NOTIFICATIONS), {
        userId: params.technicianId,
        title: params.title,
        message: params.message,
        type: params.type,
        read: false,
        relatedId: params.relatedId,
        createdAt: new Date().toISOString()
      });
      return true;
    } catch (err) {
      console.error('Fout bij maken notificatie:', err);
      return false;
    }
  },

  /**
   * Automatiseert de communicatie bij een nieuwe afspraak
   */
  async handleNewAppointment(appointment: Appointment, customer: Customer) {
    // 1. Stuur bevestigingsmail naar klant
    await emailService.triggerAutomation('appointment_confirmation', {
      customer,
      appointment
    });

    // 2. Notificeer technicus als toegewezen
    if (appointment.technicianId) {
      await this.notifyTechnician({
        technicianId: appointment.technicianId,
        title: 'Nieuwe afspraak toegewezen',
        message: `Je bent ingepland voor "${appointment.title}" op ${appointment.date}.`,
        type: 'new_task',
        relatedId: appointment.id
      });
    }
  },

  /**
   * Herinnering 24u / 2u voor afspraak
   */
  async sendAppointmentReminder(appointment: Appointment, customer: Customer, timing: '24h' | '2h') {
    const templateType = timing === '24h' ? 'appointment_reminder_24h' : 'appointment_confirmation'; // fallback or specific 2h if added
    await emailService.triggerAutomation(templateType, {
      customer,
      appointment,
      timing
    });
  }
};
