import React from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell, AreaChart, Area
} from 'recharts';
import { TrendingUp, PieChart as PieChartIcon, Activity } from 'lucide-react';

interface DashboardChartsProps {
  trendsData: any[];
  typeData: any[];
  statusData: any[];
}

const DashboardCharts: React.FC<DashboardChartsProps> = ({ trendsData, typeData, statusData }) => {
  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-3">
      <section className="xl:col-span-2 bg-surface-900 rounded-md border border-white/5 p-5 shadow-sm">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h3 className="text-base font-display font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-accent-400" />
              Servicetrends
            </h3>
            <p className="text-xs text-surface-400 mt-1">Aantal interventies over de laatste 6 maanden</p>
          </div>
        </div>

        <div className="h-[350px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={trendsData}>
              <defs>
                <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#852ffb" stopOpacity={0.15}/>
                  <stop offset="95%" stopColor="#852ffb" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1f2430" />
              <XAxis 
                dataKey="name" 
                axisLine={false} 
                tickLine={false} 
                tick={{fontSize: 11, fontWeight: 500, fill: '#9a9b9b'}}
                dy={10}
              />
              <YAxis 
                axisLine={false} 
                tickLine={false} 
                tick={{fontSize: 11, fontWeight: 500, fill: '#9a9b9b'}}
              />
              <Tooltip 
                contentStyle={{ 
                  borderRadius: '0.375rem', 
                  backgroundColor: '#00040c',
                  border: '1px solid rgba(255,255,255,0.1)', 
                  boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                  padding: '0.75rem',
                  color: '#fff'
                }}
                itemStyle={{ fontSize: '13px', fontWeight: '600', color: '#fff' }}
              />
              <Area 
                type="monotone" 
                dataKey="count" 
                name="Interventies"
                stroke="#852ffb" 
                strokeWidth={3} 
                fillOpacity={1} 
                fill="url(#colorCount)" 
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section className="bg-surface-900 rounded-md border border-white/5 p-5 shadow-sm">
        <div className="mb-8">
          <h3 className="text-base font-display font-bold text-white flex items-center gap-2">
            <PieChartIcon className="w-5 h-5 text-brand-400" />
            Distributie
          </h3>
          <p className="text-xs text-surface-400 mt-1">Interventietypes en statusverdeling</p>
        </div>

        <div className="space-y-3">
          <div className="h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={typeData}
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={8}
                  dataKey="value"
                  stroke="none"
                >
                  {typeData.map((entry, index) => (
                     // Override standard colors to give brand feel
                    <Cell key={`cell-${index}`} fill={index === 0 ? '#852ffb' : index === 1 ? '#56e5a1' : '#41336b'} />
                  ))}
                </Pie>
                <Tooltip 
                   contentStyle={{ 
                    borderRadius: '0.375rem', 
                    backgroundColor: '#00040c',
                    border: '1px solid rgba(255,255,255,0.1)', 
                    boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                    color: '#fff'
                  }}
                  itemStyle={{ color: '#fff' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-2">
             {[...typeData, ...statusData.slice(0, 2)].map((item, i) => (
               <div key={i} className="flex items-center justify-between p-3 bg-surface-800 rounded-md hover:bg-surface-700 transition-colors">
                 <div className="flex items-center gap-3">
                   <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: i === 0 ? '#852ffb' : i === 1 ? '#56e5a1' : '#41336b' }}></div>
                   <span className="text-xs font-semibold text-surface-100">{item.name}</span>
                 </div>
                 <span className="text-xs font-bold text-white">{item.value}</span>
               </div>
             ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default DashboardCharts;
