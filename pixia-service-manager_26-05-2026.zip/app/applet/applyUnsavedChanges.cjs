const fs = require('fs');
const path = require('path');

function processFile(file, objectName) {
  let content = fs.readFileSync(file, 'utf8');
  let original = content;

  // 1. Add states if not present
  if (!content.includes('const [isDirty, setIsDirty] = useState(false);')) {
    content = content.replace(
      'const [formData, setFormData] = useState({',
      'const [isDirty, setIsDirty] = useState(false);\n  const [isCancelConfirmOpen, setIsCancelConfirmOpen] = useState(false);\n  const [formData, setFormData] = useState({'
    );
  }

  // 2. Add updateFormData & handleCloseModal
  if (!content.includes('const updateFormData =')) {
    let updateFormDataCode = `
  const updateFormData = (updates: any) => {
    setFormData((prev: any) => ({ ...prev, ...updates }));
    setIsDirty(true);
  };

  const handleCloseModal = () => {
    if (isDirty && !isDetailView) {
      setIsCancelConfirmOpen(true);
    } else {
      closeModal();
    }
  };

  const closeModal = () => {
    setIsCancelConfirmOpen(false);
    setIsAddModalOpen(false);
    setIsDirty(false);
  };
`;
    if (file.includes('Customers.tsx') || file.includes('Machines.tsx') || file.includes('Inventory.tsx') || file.includes('WorkOrders.tsx')) {
       // These might not have isDetailView or might use setIsModalOpen. Let's adapt.
       let closeFn = content.includes('setIsAddModalOpen') ? 'setIsAddModalOpen(false)' : 'setIsModalOpen(false)';
       let viewCheck = content.includes('isDetailView') ? '&& !isDetailView' : '';
       updateFormDataCode = `
  const updateFormData = (updates: any) => {
    setFormData((prev: any) => ({ ...prev, ...updates }));
    setIsDirty(true);
  };

  const handleCloseModal = () => {
    if (isDirty ${viewCheck}) {
      setIsCancelConfirmOpen(true);
    } else {
      closeModal();
    }
  };

  const closeModal = () => {
    setIsCancelConfirmOpen(false);
    ${closeFn};
    setIsDirty(false);
  };
`;
    }

    content = content.replace(
      /const (handleOpenAddModal|handleOpenModal|handleCreate) = \(\) => \{/,
      updateFormDataCode + '\n  const $1 = () => {'
    );
    // fallback if function not found
    if (original === content) {
      content = content.replace(
        /const (fetch.*?) = async \(\) => \{/,
        updateFormDataCode + '\n  const $1 = async () => {'
      );
    }
  }

  // 3. Replace all setFormData({ ...formData, xxx }) with updateFormData({ xxx })
  content = content.replace(/setFormData\(\{.*?\.\.\.formData,\s*([^:]+):\s*([^}]+)\}\)/g, 'updateFormData({ $1: $2 })');
  
  // 4. Update the reset in open modal / submit to also clear isDirty
  content = content.replace(/setIsAddModalOpen\(true\)/g, 'setIsAddModalOpen(true); setIsDirty(false)');
  content = content.replace(/setIsModalOpen\(true\)/g, 'setIsModalOpen(true); setIsDirty(false)');

  // Ensure saving clears isDirty
  content = content.replace(/setIsAddModalOpen\(false\)/g, 'handleCloseModal()');
  // NOTE: above might be too aggressive if used elsewhere like in successful save. 
  // Let's revert and only replace onClick={() => setIsAddModalOpen(false)}
  
  content = original; // Wait, start over with precise replacements

  if (!content.includes('const [isDirty, setIsDirty] = useState(false);')) {
    content = content.replace(
      'const [formData, setFormData] = useState',
      'const [isDirty, setIsDirty] = useState(false);\n  const [isCancelConfirmOpen, setIsCancelConfirmOpen] = useState(false);\n  const [formData, setFormData] = useState'
    );
  }

  let closeFn = content.includes('setIsAddModalOpen') ? 'setIsAddModalOpen' : 'setIsModalOpen';
  let viewCheck = content.includes('isDetailView') ? '&& !isDetailView' : '';
  
  if (!content.includes('const updateFormData =')) {
    const fnCode = `
  const updateFormData = (updates: any) => {
    setFormData((prev: any) => ({ ...prev, ...updates }));
    setIsDirty(true);
  };

  const handleCloseModal = () => {
    if (isDirty ${viewCheck}) {
      setIsCancelConfirmOpen(true);
    } else {
      closeModal();
    }
  };

  const closeModal = () => {
    setIsCancelConfirmOpen(false);
    ${closeFn}(false);
    setIsDirty(false);
  };
`;
    // inject before typical functions
    let injected = false;
    ['const handleOpen', 'const fetch', 'const handle'].forEach(anchor => {
      if (!injected && content.includes(anchor)) {
        content = content.replace(anchor, fnCode + '\n  ' + anchor);
        injected = true;
      }
    });
  }

  // replace setFormData with updateFormData
  content = content.replace(/setFormData\(\{[\s\n]*\.\.\.formData,[\s\n]*([^:]+):/g, 'updateFormData({ $1:');

  // For buttons that cancel:
  content = content.replace(/onClick=\{.*?setIsAddModalOpen\(false\).*?\}/g, 'onClick={handleCloseModal}');
  content = content.replace(/onClick=\{.*?setIsModalOpen\(false\).*?\}/g, 'onClick={handleCloseModal}');
  
  // Replace the successful save close to bypass confirmation
  // "closeModal()" doesn't prompt.
  
  // Also we need to make sure we append the ConfirmDialog at the end of the return statement
  if (!content.includes('isCancelConfirmOpen}')) {
    const confirmDialogCode = `
      <ConfirmDialog
        isOpen={isCancelConfirmOpen}
        title="Onopgeslagen Wijzigingen"
        message="Je hebt onopgeslagen wijzigingen. Weet je zeker dat je wilt annuleren? Al je werk gaat verloren."
        onConfirm={closeModal}
        onCancel={() => setIsCancelConfirmOpen(false)}
        variant="danger"
        confirmText="Ja, werk weggooien"
        cancelText="Terug"
      />
    </div>
  );
};`;
    content = content.replace(/    <\/div>\s*?\);\s*?};\s*?$/g, confirmDialogCode);
  }

  fs.writeFileSync(file, content);
  console.log('Processed ' + file);
}

processFile('src/pages/Interventions.tsx', 'Intervention');
processFile('src/pages/WorkOrders.tsx', 'WorkOrder');
processFile('src/pages/Customers.tsx', 'Customer');
processFile('src/pages/Machines.tsx', 'Machine');
processFile('src/pages/Inventory.tsx', 'InventoryItem');
