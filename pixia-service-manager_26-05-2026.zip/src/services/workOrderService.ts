import { collection, addDoc, doc, updateDoc, deleteDoc, getDoc, getDocs, query, where, limit } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { WorkOrder } from '../types';
import { handleFirestoreError, OperationType } from '../lib/utils';
import { logAction } from '../lib/audit';
import { COLLECTIONS } from '../constants/collections';

export const workOrderService = {
  /**
   * Finds existing work order for an intervention to prevent duplicates
   */
  async findExistingWorkOrderForIntervention(interventionId: string): Promise<WorkOrder | null> {
    if (!interventionId) return null;
    try {
      const q = query(
        collection(db, COLLECTIONS.WORK_ORDERS),
        where('interventionId', '==', interventionId),
        limit(1)
      );
      const snap = await getDocs(q);
      if (!snap.empty) {
        return { id: snap.docs[0].id, ...snap.docs[0].data() } as WorkOrder;
      }
      return null;
    } catch (err) {
      console.error('Error finding work order for intervention:', err);
      return null;
    }
  },

  /**
   * Checks if a work order number already exists
   */
  async checkDuplicateOrderNumber(orderNumber: string, excludeId?: string): Promise<boolean> {
    try {
      const q = query(collection(db, COLLECTIONS.WORK_ORDERS), where('orderNumber', '==', orderNumber), limit(1));
      const snap = await getDocs(q);
      if (snap.empty) return false;
      if (excludeId && snap.docs[0].id === excludeId) return false;
      return true;
    } catch (err) {
      return false;
    }
  },

  async save(formData: any, selectedOrder: WorkOrder | null) {
    try {
      const data = {
        ...formData,
        updatedAt: new Date().toISOString()
      };

      // Remove undefined values since Firestore does not support them
      Object.keys(data).forEach(key => {
        if (data[key] === undefined) {
          delete data[key];
        }
      });

      if (selectedOrder) {
        await updateDoc(doc(db, COLLECTIONS.WORK_ORDERS, selectedOrder.id), data);
        await logAction('Werkbon aangepast', 'work_order', selectedOrder.id, `Status: ${data.status}`);
        return selectedOrder.id;
      } else {
        let visitNumber = formData.visitNumber || 1;
        if (formData.interventionId) {
          try {
            const q = query(
              collection(db, COLLECTIONS.WORK_ORDERS),
              where('interventionId', '==', formData.interventionId)
            );
            const snap = await getDocs(q);
            visitNumber = snap.size + 1;
            
            // Logically update parent intervention's workOrderCount
            const intRef = doc(db, COLLECTIONS.INTERVENTIONS, formData.interventionId);
            const intSnap = await getDoc(intRef);
            if (intSnap.exists()) {
              await updateDoc(intRef, {
                workOrderCount: visitNumber,
                updatedAt: new Date().toISOString()
              });
            }
          } catch (e) {
            console.error('Error calculating visitNumber:', e);
          }
        }
        
        const docRef = await addDoc(collection(db, COLLECTIONS.WORK_ORDERS), {
          ...data,
          visitNumber,
          createdAt: new Date().toISOString()
        });
        await logAction('Werkbon aangemaakt', 'work_order', docRef.id, `Nummer: ${data.orderNumber}`);
        return docRef.id;
      }
    } catch (err) {
      handleFirestoreError(err, selectedOrder ? OperationType.UPDATE : OperationType.CREATE, COLLECTIONS.WORK_ORDERS);
      return null;
    }
  },

  async delete(id: string, orderNumber: string) {
    try {
      const orderRef = doc(db, COLLECTIONS.WORK_ORDERS, id);
      await deleteDoc(orderRef);
      await logAction('Werkbon verwijderd', 'work_order', id, `Nummer: ${orderNumber}`);
      return true;
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `${COLLECTIONS.WORK_ORDERS}/${id}`);
      return false;
    }
  },

  async sign(orderId: string, entity: 'client' | 'technician', signatureData: string, clientName?: string) {
    try {
      const orderRef = doc(db, COLLECTIONS.WORK_ORDERS, orderId);
      const updateData: any = {
        updatedAt: new Date().toISOString()
      };

      if (entity === 'client') {
        updateData.clientSignature = signatureData;
        updateData.signedAt = new Date().toISOString();
        updateData.status = 'completed';
      } else {
        updateData.technicianSignature = signatureData;
      }

      await updateDoc(orderRef, updateData);
      
      if (entity === 'client') {
        await logAction('Werkbon ondertekend', 'work_order', orderId, `Door: ${clientName}`);
      } else {
        await logAction('Werkbon getekend door technicus', 'work_order', orderId);
      }
      return true;
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `${COLLECTIONS.WORK_ORDERS}/${orderId}`);
      return false;
    }
  },

  async processStock(workOrder: WorkOrder) {
    try {
      if (workOrder.stockProcessed || !workOrder.partsUsed || workOrder.partsUsed.length === 0) return true;

      // Check if linked intervention hasn't already processed stock
      if (workOrder.interventionId) {
        const intDoc = await getDoc(doc(db, COLLECTIONS.INTERVENTIONS, workOrder.interventionId));
        if (intDoc.exists() && intDoc.data().stockProcessed) {
          return true;
        }
      }

      for (const part of workOrder.partsUsed) {
        if (!part.itemId) continue;
        const itemRef = doc(db, COLLECTIONS.INVENTORY, part.itemId);
        const itemDoc = await getDoc(itemRef);
        if (itemDoc.exists()) {
          const currentStock = itemDoc.data().stockCount || 0;
          await updateDoc(itemRef, {
            stockCount: currentStock - part.quantity,
            updatedAt: new Date().toISOString()
          });
          
          await addDoc(collection(db, COLLECTIONS.INVENTORY_MUTATIONS), {
            itemId: part.itemId,
            type: 'intervention',
            quantity: part.quantity,
            interventionId: workOrder.interventionId || 'none',
            reason: `Gebruikt via werkbon ${workOrder.orderNumber}`,
            technicianName: workOrder.technicianName,
            timestamp: new Date().toISOString()
          });
        }
      }

      await updateDoc(doc(db, COLLECTIONS.WORK_ORDERS, workOrder.id), { stockProcessed: true });
      if (workOrder.interventionId) {
        await updateDoc(doc(db, COLLECTIONS.INTERVENTIONS, workOrder.interventionId), { stockProcessed: true });
      }
      return true;
    } catch (err) {
      console.error('Error processing stock for work order:', err);
      return false;
    }
  }
};
