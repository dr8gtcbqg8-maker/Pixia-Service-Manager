import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Calendar, Activity } from 'lucide-react';
import { cn } from '../../lib/utils';
import { Period, Customer } from '../../types';

interface DashboardFiltersProps {
  period: Period;
  setPeriod: (period: Period) => void;
  selectedCustomerId: string;
  setSelectedCustomerId: (id: string) => void;
  selectedMachineType: string;
  setSelectedMachineType: (type: string) => void;
  customers: Customer[];
  machineTypes: string[];
}

const DashboardFilters: React.FC<DashboardFiltersProps> = ({
  period, setPeriod,
  selectedCustomerId, setSelectedCustomerId,
  selectedMachineType, setSelectedMachineType,
  customers, machineTypes
}) => {
  const navigate = useNavigate();
  const periodLabels = {
    week: 'Deze Week',
    month: 'Deze Maand',
    year: 'Dit Jaar'
  };

  return (
    <div className="flex flex-col lg:items-start gap-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between w-full gap-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 flex items-center gap-3">
            Dashboard
            <Activity className="w-8 h-8 text-blue-500" />
          </h1>
          <p className="text-slate-500 font-medium text-sm mt-1">Real-time overzicht van operationele status</p>
        </div>
        
        <div className="flex flex-wrap items-center gap-3">
          <div className="bg-white p-1 rounded-xl flex items-center border border-slate-200 shadow-sm">
            {(['week', 'month', 'year'] as Period[]).map((p) => (
              <button
                key={p}
                onClick={() => setPeriod(p)}
                className={cn(
                  "px-4 py-1.5 rounded-lg text-xs font-semibold transition-all",
                  period === p 
                    ? "bg-slate-900 text-white shadow-sm" 
                    : "text-slate-500 hover:text-slate-700 hover:bg-slate-50"
                )}
              >
                {periodLabels[p]}
              </button>
            ))}
          </div>
          <button 
            onClick={() => navigate('/calendar')}
            className="btn-primary"
          >
            <Calendar className="w-4 h-4" />
            <span>Planning bekijken</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
         <div className="space-y-1.5">
           <label className="text-xs font-semibold text-slate-600 block">Klant</label>
           <select 
             value={selectedCustomerId}
             onChange={(e) => setSelectedCustomerId(e.target.value)}
             className="input-field"
           >
              <option value="all">Alle Klanten</option>
              {customers.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
           </select>
         </div>
         <div className="space-y-1.5">
           <label className="text-xs font-semibold text-slate-600 block">Machine Type</label>
           <select 
             value={selectedMachineType}
             onChange={(e) => setSelectedMachineType(e.target.value)}
             className="input-field"
           >
              <option value="all">Alle Typen</option>
              {machineTypes.map(t => (
                <option key={t} value={t}>{t}</option>
              ))}
           </select>
         </div>
      </div>
    </div>
  );
};

export default DashboardFilters;
