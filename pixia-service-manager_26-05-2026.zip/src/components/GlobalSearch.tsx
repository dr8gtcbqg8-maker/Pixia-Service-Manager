import React, { useState, useEffect, useRef } from 'react';
import { Search, Loader2, User, Printer, Wrench } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { collection, getDocs, limit, orderBy, query } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Customer, Machine, Intervention } from '../types';
import { COLLECTIONS } from '../constants/collections';

export const GlobalSearch: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<{
    customers: Customer[];
    machines: Machine[];
    interventions: Intervention[];
  }>({ customers: [], machines: [], interventions: [] });
  
  const [allData, setAllData] = useState<{
    customers: Customer[];
    machines: Machine[];
    interventions: Intervention[];
  } | null>(null);

  const wrapperRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (!isOpen) return;
    if (allData) return;
    
    // Fetch all data for client-side search indexing
    const fetchAllData = async () => {
      setLoading(true);
      try {
        const [cSnap, mSnap, iSnap] = await Promise.all([
          getDocs(query(collection(db, COLLECTIONS.CUSTOMERS))),
          getDocs(query(collection(db, COLLECTIONS.MACHINES))),
          getDocs(query(collection(db, COLLECTIONS.INTERVENTIONS), orderBy('date', 'desc'), limit(100)))
        ]);
        setAllData({
          customers: cSnap.docs.map(d => ({ id: d.id, ...d.data() } as Customer)),
          machines: mSnap.docs.map(d => ({ id: d.id, ...d.data() } as Machine)),
          interventions: iSnap.docs.map(d => ({ id: d.id, ...d.data() } as Intervention))
        });
      } catch (err) {
        console.error("Error fetching data for search", err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchAllData();
  }, [isOpen, allData]);

  useEffect(() => {
    if (!searchQuery.trim() || !allData) {
      setResults({ customers: [], machines: [], interventions: [] });
      return;
    }
    
    const lowerQuery = searchQuery.toLowerCase();
    
    const matchingCustomers = allData.customers.filter(c => 
      c.name.toLowerCase().includes(lowerQuery) ||
      (c.contactPerson && c.contactPerson.toLowerCase().includes(lowerQuery)) ||
      (c.email && c.email.toLowerCase().includes(lowerQuery))
    ).slice(0, 5);
    
    const matchingMachines = allData.machines.filter(m => 
      m.serialNumber.toLowerCase().includes(lowerQuery) ||
      m.brand.toLowerCase().includes(lowerQuery) ||
      m.model.toLowerCase().includes(lowerQuery) || 
      (m.location && m.location.toLowerCase().includes(lowerQuery))
    ).slice(0, 5);
    
    const matchingInterventions = allData.interventions.filter(i => 
      (i.interventionNumber && i.interventionNumber.toLowerCase().includes(lowerQuery)) ||
      (i.problemDescription && i.problemDescription.toLowerCase().includes(lowerQuery)) ||
      (i.workPerformed && i.workPerformed.toLowerCase().includes(lowerQuery))
    ).slice(0, 5);
    
    setResults({
      customers: matchingCustomers,
      machines: matchingMachines,
      interventions: matchingInterventions
    });
  }, [searchQuery, allData]);

  const handleAction = (path: string) => {
    setIsOpen(false);
    setSearchQuery('');
    navigate(path);
  };

  return (
    <div className="relative w-full max-w-md hidden sm:block" ref={wrapperRef}>
      <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-surface-400 pointer-events-none">
        <Search className="w-4 h-4" />
      </span>
      <input 
        type="text" 
        value={searchQuery}
        onChange={(e) => {
          setSearchQuery(e.target.value);
          if (!isOpen && e.target.value.trim().length > 0) setIsOpen(true);
        }}
        onFocus={() => {
          if (searchQuery.trim().length > 0 || !allData) {
            setIsOpen(true);
          }
        }}
        placeholder="Zoek klant, machine of serienummer..." 
        className="block w-full pl-10 pr-3 py-2 border border-surface-200 rounded-lg text-sm bg-surface-50 focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:border-blue-500 transition-all placeholder:text-surface-400"
      />
      
      {isOpen && (searchQuery.trim().length > 0 || loading) && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-md shadow-xl border border-surface-200 overflow-hidden z-50">
          <div className="max-h-[400px] overflow-y-auto custom-scrollbar">
            {loading ? (
              <div className="p-4 flex items-center justify-center text-surface-400">
                <Loader2 className="w-5 h-5 animate-spin mr-2" />
                <span className="text-sm">Zoeken in systeem...</span>
              </div>
            ) : (
              <>
                {results.customers.length === 0 && results.machines.length === 0 && results.interventions.length === 0 ? (
                  <div className="p-4 text-center text-sm text-surface-500">
                    Geen resultaten gevonden voor "{searchQuery}"
                  </div>
                ) : (
                  <div className="py-2">
                    {results.customers.length > 0 && (
                      <div className="mb-2">
                        <div className="px-4 py-1 text-[10px] font-bold uppercase tracking-widest text-surface-400 bg-surface-50">
                          Klanten
                        </div>
                        {results.customers.map(c => (
                          <div 
                            key={c.id} 
                            onClick={() => handleAction(`/customers?id=${c.id}`)}
                            className="px-4 py-2 hover:bg-brand-50 cursor-pointer flex items-center gap-3 transition-colors"
                          >
                            <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center shrink-0">
                              <User className="w-4 h-4 text-brand-500" />
                            </div>
                            <div className="min-w-0">
                              <div className="text-sm font-bold text-surface-900 truncate tracking-tight">{c.name}</div>
                              {c.contactPerson && <div className="text-xs font-medium text-surface-500 truncate">{c.contactPerson}</div>}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                    
                    {results.machines.length > 0 && (
                      <div className="mb-2 border-t border-surface-100">
                        <div className="px-4 py-1 text-[10px] font-bold uppercase tracking-widest text-surface-400 bg-surface-50">
                          Machines
                        </div>
                        {results.machines.map(m => {
                          const customer = allData?.customers.find(c => c.id === m.customerId);
                          return (
                            <div 
                              key={m.id} 
                              onClick={() => handleAction(`/machines?id=${m.id}`)}
                              className="px-4 py-2 hover:bg-brand-50 cursor-pointer flex items-center gap-3 transition-colors"
                            >
                              <div className="w-8 h-8 rounded-lg bg-indigo-100 flex items-center justify-center shrink-0">
                                <Printer className="w-4 h-4 text-brand-600" />
                              </div>
                              <div className="min-w-0">
                                <div className="text-sm font-bold text-surface-900 truncate tracking-tight">{m.brand} {m.model}</div>
                                <div className="text-[11px] font-medium text-surface-500 truncate">
                                  SN: {m.serialNumber} {customer && `• Klant: ${customer.name}`}
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {results.interventions.length > 0 && (
                      <div className="border-t border-surface-100">
                        <div className="px-4 py-1 text-[10px] font-bold uppercase tracking-widest text-surface-400 bg-surface-50">
                          Interventies
                        </div>
                        {results.interventions.map(i => {
                          const customer = allData?.customers.find(c => c.id === i.customerId);
                          return (
                            <div 
                              key={i.id} 
                              onClick={() => handleAction(`/interventions?id=${i.id}`)}
                              className="px-4 py-2 hover:bg-orange-50 cursor-pointer flex items-center gap-3 transition-colors"
                            >
                              <div className="w-8 h-8 rounded-lg bg-orange-100 flex items-center justify-center shrink-0">
                                <Wrench className="w-4 h-4 text-orange-600" />
                              </div>
                              <div className="min-w-0">
                                <div className="text-sm font-bold text-surface-900 truncate tracking-tight">
                                  {i.interventionNumber} • {new Date(i.date).toLocaleDateString('nl-NL')}
                                </div>
                                {customer && <div className="text-[11px] font-medium text-surface-500 truncate">{customer.name}</div>}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
