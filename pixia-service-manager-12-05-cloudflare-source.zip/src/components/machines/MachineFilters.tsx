import React from 'react';
import { Search, Filter } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Customer } from '../../types';
import { cn } from '../../lib/utils';

interface MachineFiltersProps {
  search: string;
  setSearch: (s: string) => void;
  showFilters: boolean;
  setShowFilters: (b: boolean) => void;
  filterCustomer: string;
  setFilterCustomer: (s: string) => void;
  filterType: string;
  setFilterType: (s: string) => void;
  filterStatus: string;
  setFilterStatus: (s: string) => void;
  filterInstallDate: string;
  setFilterInstallDate: (s: string) => void;
  filterWarrantyDate: string;
  setFilterWarrantyDate: (s: string) => void;
  customers: Customer[];
}

const MachineFilters: React.FC<MachineFiltersProps> = ({
  search, setSearch,
  showFilters, setShowFilters,
  filterCustomer, setFilterCustomer,
  filterType, setFilterType,
  filterStatus, setFilterStatus,
  filterInstallDate, setFilterInstallDate,
  filterWarrantyDate, setFilterWarrantyDate,
  customers
}) => {
  return (
    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Zoek op merk, model, serienummer of klant..." 
            className="input-field pl-12"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <button 
          onClick={() => setShowFilters(!showFilters)}
          className={cn(
            "flex items-center justify-center gap-2 px-6 py-3 rounded-xl border text-sm font-bold transition-all min-w-[140px]",
            showFilters 
              ? "bg-slate-900 text-white border-slate-900 shadow-lg shadow-slate-200" 
              : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50 hover:border-slate-300"
          )}
        >
          <Filter className="w-4 h-4" />
          <span>Filters</span>
          {(filterCustomer || filterType || filterStatus) && (
            <span className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
          )}
        </button>
      </div>

      <AnimatePresence>
        {showFilters && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 pt-4 border-t border-slate-100">
              <div className="space-y-1">
                <label className="label !text-[10px] !mb-1">Klant</label>
                <select 
                  className="input-field !py-2 !text-xs"
                  value={filterCustomer}
                  onChange={(e) => setFilterCustomer(e.target.value)}
                >
                  <option value="">Alle Klanten</option>
                  {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div className="space-y-1">
                <label className="label !text-[10px] !mb-1">Type</label>
                <select 
                  className="input-field !py-2 !text-xs"
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value)}
                >
                  <option value="">Alle Types</option>
                  <option value="printer">Printer</option>
                  <option value="laminator">Laminator</option>
                  <option value="other">Anders</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="label !text-[10px] !mb-1">Status</label>
                <select 
                  className="input-field !py-2 !text-xs"
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                >
                  <option value="">Alle Status</option>
                  <option value="active">Actief</option>
                  <option value="maintenance-needed">Onderhoud nodig</option>
                  <option value="faulty">Storing</option>
                  <option value="out-of-service">Buiten gebruik</option>
                  <option value="replaced">Vervangen</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="label !text-[10px] !mb-1">Instal. Datum</label>
                <input 
                  type="date"
                  className="input-field !py-2 !text-xs"
                  value={filterInstallDate}
                  onChange={(e) => setFilterInstallDate(e.target.value)}
                />
              </div>
              <div className="space-y-1">
                <label className="label !text-[10px] !mb-1">Garantie Eind</label>
                <input 
                  type="date"
                  className="input-field !py-2 !text-xs"
                  value={filterWarrantyDate}
                  onChange={(e) => setFilterWarrantyDate(e.target.value)}
                />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default MachineFilters;
