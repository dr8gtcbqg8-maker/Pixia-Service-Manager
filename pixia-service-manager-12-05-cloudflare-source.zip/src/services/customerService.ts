import { collection, addDoc, doc, updateDoc, deleteDoc, getDocs, query, where, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Customer } from '../types';
import { handleFirestoreError, OperationType } from '../lib/utils';
import { logAction } from '../lib/audit';
import { COLLECTIONS } from '../constants/collections';

export const customerService = {
  async getAll() {
    try {
      const q = query(collection(db, COLLECTIONS.CUSTOMERS), orderBy('name', 'asc'));
      const snap = await getDocs(q);
      return snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Customer));
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, COLLECTIONS.CUSTOMERS);
      return [];
    }
  },

  async save(customerData: any, selectedCustomer: Customer | null) {
    try {
      if (selectedCustomer) {
        const docRef = doc(db, COLLECTIONS.CUSTOMERS, selectedCustomer.id);
        await updateDoc(docRef, { ...customerData, updatedAt: new Date().toISOString() });
        await logAction('Klant aangepast', 'customer', selectedCustomer.id, `Naam: ${customerData.name}`);
        return selectedCustomer.id;
      } else {
        const docRef = await addDoc(collection(db, COLLECTIONS.CUSTOMERS), {
          ...customerData,
          createdAt: new Date().toISOString(),
        });
        await logAction('Klant aangemaakt', 'customer', docRef.id, `Naam: ${customerData.name}`);
        return docRef.id;
      }
    } catch (err) {
      handleFirestoreError(err, selectedCustomer ? OperationType.UPDATE : OperationType.CREATE, `${COLLECTIONS.CUSTOMERS}/${selectedCustomer?.id || 'new'}`);
      return null;
    }
  },

  async delete(id: string) {
    try {
      await deleteDoc(doc(db, COLLECTIONS.CUSTOMERS, id));
      await logAction('Klant verwijderd', 'customer', id);
      return true;
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `${COLLECTIONS.CUSTOMERS}/${id}`);
      return false;
    }
  },

  async getRelatedData(customerId: string) {
    try {
      const [machinesSnap, interventionsSnap, workOrdersSnap] = await Promise.all([
        getDocs(query(collection(db, COLLECTIONS.MACHINES), where('customerId', '==', customerId))),
        getDocs(query(collection(db, COLLECTIONS.INTERVENTIONS), where('customerId', '==', customerId), orderBy('date', 'desc'))),
        getDocs(query(collection(db, COLLECTIONS.WORK_ORDERS), where('customerId', '==', customerId), orderBy('createdAt', 'desc')))
      ]);

      return {
        machines: machinesSnap.docs.map(d => ({ id: d.id, ...d.data() })),
        interventions: interventionsSnap.docs.map(d => ({ id: d.id, ...d.data() })),
        workOrders: workOrdersSnap.docs.map(d => ({ id: d.id, ...d.data() }))
      };
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'related-data');
      return { machines: [], interventions: [], workOrders: [] };
    }
  }
};
