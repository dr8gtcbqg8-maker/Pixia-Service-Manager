const fs = require('fs');

function extractKey(lines, idx) {
  let prevCode = lines.slice(Math.max(0, idx - 10), idx + 1).join(' ');
  let key = null;
  
  // if it's partsUsed related
  if (lines[idx].includes('partsUsed') || lines[idx].includes('newParts')) {
    return 'partsUsed';
  }
  
  // if it involves customerId and machineId
  if (lines[idx].includes('machineId: ')) {
    return 'customerId';
  }
  
  for (let i = idx; i >= Math.max(0, idx - 3); i--) {
    let line = lines[i];
    let m = line.match(/value=\{[a-zA-Z0-9_]+\.([a-zA-Z0-9_]+)/);
    if (m) return m[1];
    
    m = line.match(/checked=\{[a-zA-Z0-9_]+\.([a-zA-Z0-9_]+)/);
    if (m) return m[1];
    
    m = line.match(/id=\{?['"]([a-zA-Z0-9_]+)['"]\}?/);
    if (m) return m[1];
  }
  
  return null;
}

const files = [
  'src/pages/Customers.tsx',
  'src/pages/Interventions.tsx',
  'src/pages/Inventory.tsx',
  'src/pages/Machines.tsx',
  'src/pages/WorkOrders.tsx'
];

files.forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  let lines = content.split('\n');
  let changed = false;
  
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].includes('updateFormData({ :')) {
      let key = extractKey(lines, i);
      if (key) {
        lines[i] = lines[i].replace('updateFormData({ :', `updateFormData({ ${key}:`);
        changed = true;
      } else {
        console.log("COULD NOT FIND KEY FOR:", file, ":", i + 1, lines[i]);
      }
    }
  }
  
  if (changed) {
    fs.writeFileSync(file, lines.join('\n'));
    console.log("Fixed", file);
  }
});
