import { 
  collection, query, where, getDocs, addDoc, updateDoc, doc, 
  Timestamp, serverTimestamp, getDoc, limit, orderBy 
} from 'firebase/firestore';
import { db, auth } from './firebase';
import { 
  CommunicationTemplate, EmailLog, Customer, Machine, 
  Intervention, WorkOrder, Appointment, UserProfile,
  CommunicationTemplateType
} from '../types';
import { SUPPORTED_PLACEHOLDERS } from '../constants/emailTemplates';
import { COLLECTIONS } from '../constants/collections';

export const emailService = {
  /**
   * Replaces placeholders in a string using provided data objects.
   */
  replacePlaceholders(template: string, data: {
    customer?: Partial<Customer>;
    machine?: Partial<Machine>;
    intervention?: Partial<Intervention>;
    workOrder?: Partial<WorkOrder>;
    appointment?: Partial<Appointment>;
    technician?: Partial<UserProfile>;
    timing?: string;
  }) {
    let content = template;
    
    // Build context with fallback values
    const context: Record<string, string> = {
      customer_name: data.customer?.name || data.customer?.contactPerson || 'Klant',
      contact_person: data.customer?.contactPerson || 'Contactpersoon',
      customer_email: data.customer?.email || '',
      customer_phone: data.customer?.phone || '',
      machine_brand: data.machine?.brand || 'Machine',
      machine_model: data.machine?.model || 'Model',
      serial_number: data.machine?.serialNumber || 'Onbekend',
      appointment_date: data.appointment?.date || data.intervention?.date || 'Nader te bepalen',
      appointment_time: data.appointment?.startTime || data.intervention?.time || data.intervention?.startTime || '--:--',
      appointment_location: data.appointment?.location || data.intervention?.location || data.customer?.address || 'Locatie onbekend',
      technician_name: data.technician?.displayName || data.appointment?.technicianName || data.intervention?.technicianName || 'Technicus',
      intervention_type: data.intervention?.type || 'Service',
      intervention_status: data.intervention?.status || 'In behandeling',
      work_order_number: data.workOrder?.orderNumber || 'Concept',
      company_name: 'Pixia Service Manager',
      company_phone: '030-1234567',
      company_email: 'service@pixia.nl'
    };

    // Replace based on defined placeholders
    SUPPORTED_PLACEHOLDERS.forEach(p => {
      const value = context[p.key] || '';
      const regex = new RegExp(`{{${p.key}}}`, 'g');
      content = content.replace(regex, value);
    });

    // Fallback for old templates that might still use {{date}} or {{time}}
    content = content.replace(/{{date}}/g, context.appointment_date);
    content = content.replace(/{{time}}/g, context.appointment_time);
    content = content.replace(/{{location}}/g, context.appointment_location);

    return content;
  },

  async logEmail(log: Omit<EmailLog, 'id'>) {
    await addDoc(collection(db, COLLECTIONS.EMAIL_LOGS), {
      ...log,
      timestamp: log.timestamp || new Date().toISOString()
    });
  },

  async sendEmail(params: {
    recipient: string,
    subject: string,
    body: string,
    customerId?: string,
    machineId?: string,
    interventionId?: string,
    workOrderId?: string
  }) {
    if (!params.recipient) {
      console.warn('Cannot send email: No recipient provided.');
      return false;
    }

    console.log('Sending email:', params);
    // Simulation
    await new Promise(resolve => setTimeout(resolve, 800));
    
    await this.logEmail({
      timestamp: new Date().toISOString(),
      recipient: params.recipient,
      subject: params.subject,
      customerId: params.customerId,
      machineId: params.machineId,
      interventionId: params.interventionId,
      workOrderId: params.workOrderId,
      status: 'sent'
    });

    return true;
  },

  /**
   * Triggers email automation based on a template type or ID.
   * Now with robust rule-based logic.
   */
  async triggerAutomation(type: CommunicationTemplateType | string, data: any) {
    try {
      // 1. Check for active automation rules for this trigger type
      const ruleQuery = query(
        collection(db, COLLECTIONS.AUTOMATION_RULES),
        where('type', '==', type),
        where('active', '==', true),
        limit(1)
      );
      const ruleSnap = await getDocs(ruleQuery);
      
      let templateSelector: string = type; // Default to the type itself as the ID (new system)
      
      if (!ruleSnap.empty) {
        const ruleData = ruleSnap.docs[0].data();
        // If the rule points to a specific template ID or type, use it
        templateSelector = ruleData.templateType || ruleData.templateId || templateSelector;
      } else {
        // Fallback for system triggers that ignore automation_rules table (safety)
        console.log(`No active automation rule for ${type}, attempting direct system trigger.`);
      }

      let template: CommunicationTemplate | null = null;

      // 2. Fetch the template
      const docRef = doc(db, COLLECTIONS.COMMUNICATION_TEMPLATES, templateSelector);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        template = { id: docSnap.id, ...docSnap.data() } as CommunicationTemplate;
      } else {
        // Search by type field if ID lookup failed
        const q = query(
          collection(db, COLLECTIONS.COMMUNICATION_TEMPLATES),
          where('type', '==', templateSelector),
          where('active', '==', true),
          limit(1)
        );
        const snap = await getDocs(q);
        if (!snap.empty) {
          template = { id: snap.docs[0].id, ...snap.docs[0].data() } as CommunicationTemplate;
        }
      }

      if (!template || !template.active) {
        console.warn(`No active template found for selector: ${templateSelector}`);
        return;
      }

      const subject = this.replacePlaceholders(template.subject, data);
      const body = this.replacePlaceholders(template.body, data);
      const recipient = data.customer?.email || '';
      
      if (recipient) {
        await this.sendEmail({
          recipient,
          subject,
          body,
          customerId: data.customer?.id,
          machineId: data.machine?.id,
          interventionId: data.intervention?.id,
          workOrderId: data.workOrder?.id
        });
      }
    } catch (err) {
      console.error('Error triggering email automation:', err);
    }
  }
};
