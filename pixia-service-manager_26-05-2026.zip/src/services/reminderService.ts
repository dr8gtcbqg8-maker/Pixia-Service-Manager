import { collection, addDoc, doc, updateDoc, deleteDoc, getDocs, query, where, limit, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Reminder, ReminderStatus, ReminderHistoryEntry } from '../types';
import { handleFirestoreError, OperationType } from '../lib/utils';
import { logAction } from '../lib/audit';
import { COLLECTIONS } from '../constants/collections';
import { normalizeText } from '../lib/normalization';

export const reminderService = {
  /**
   * Generates a unique key for a reminder to prevent duplicates
   */
  generateKey(type: string, customerId?: string, machineId?: string): string {
    return `${type}_${customerId || 'no-cust'}_${machineId || 'no-mach'}`;
  },

  /**
   * Finds potential duplicate reminders
   */
  async findPotentialDuplicates(reminderData: any, excludeId?: string): Promise<Reminder[]> {
    try {
      const normalizedTitle = normalizeText(reminderData.title);
      const matches: Reminder[] = [];
      
      const q = query(
        collection(db, COLLECTIONS.REMINDERS),
        where('customerId', '==', reminderData.customerId || 'none'),
        where('status', 'in', ['open', 'planned', 'postponed'])
      );
      
      const snap = await getDocs(q);
      
      snap.forEach(doc => {
        if (excludeId && doc.id === excludeId) return;
        const d = doc.data() as Reminder;
        
        // Key match
        if (reminderData.uniqueReminderKey && d.uniqueReminderKey === reminderData.uniqueReminderKey) {
          matches.push({ id: doc.id, ...d });
          return;
        }

        // Exact match fallback: check machine, type, date and title
        const isSameMachine = d.machineId === reminderData.machineId;
        const isSameType = d.type === reminderData.type;
        const isSameDate = d.dueDate === reminderData.dueDate;
        const isSameTitle = normalizeText(d.title) === normalizedTitle;
        
        if (isSameMachine && isSameType && isSameDate && isSameTitle) {
          matches.push({ id: doc.id, ...d });
          return;
        }
        
        // Soft match: already an open reminder for this machine and type
        if (isSameMachine && isSameType) {
          matches.push({ id: doc.id, ...d });
        }
      });
      
      return matches;
    } catch (err) {
      console.error('Error finding duplicate reminders:', err);
      return [];
    }
  },

  /**
   * Creates a new reminder or updates an existing active one with the same context
   */
  async upsert(reminderData: Partial<Reminder>, triggerUser?: string) {
    try {
      const now = new Date().toISOString();
      const type = reminderData.type || 'other';
      const customerId = reminderData.customerId;
      const machineId = reminderData.machineId;
      
      const key = reminderData.uniqueReminderKey || this.generateKey(type, customerId, machineId);
      
      // Search for active reminders with same key
      const q = query(
        collection(db, COLLECTIONS.REMINDERS),
        where('uniqueReminderKey', '==', key),
        where('status', 'in', ['open', 'planned', 'postponed']),
        limit(1)
      );
      
      const snap = await getDocs(q);
      
      if (!snap.empty) {
        // Reuse/Update existing reminder
        const existingDoc = snap.docs[0];
        const existingData = existingDoc.data() as Reminder;
        
        const history: ReminderHistoryEntry[] = existingData.history || [];
        history.push({
          status: existingData.status,
          date: now,
          reason: `Hergebruik/Update getriggerd door nieuwe melding: ${reminderData.title || 'Geen titel'}`,
          userName: triggerUser || 'Systeem'
        });

        const updateData = {
          ...reminderData,
          uniqueReminderKey: key,
          history,
          count: (existingData.count || 1) + 1,
          lastTriggeredAt: now,
          updatedAt: now
        };

        await updateDoc(doc(db, COLLECTIONS.REMINDERS, existingDoc.id), updateData);
        await logAction('Bestaande herinnering bijgewerkt (Smart)', 'reminder', existingDoc.id, `Titel: ${reminderData.title}`);
        return existingDoc.id;
      } else {
        // Create new reminder
        const newReminder = {
          ...reminderData,
          uniqueReminderKey: key,
          status: reminderData.status || 'open',
          count: 1,
          history: [{
            status: reminderData.status || 'open' as ReminderStatus,
            date: now,
            reason: 'Initiële aanmaak',
            userName: triggerUser || 'Systeem'
          }],
          createdAt: now,
          updatedAt: now
        };

        const docRef = await addDoc(collection(db, COLLECTIONS.REMINDERS), newReminder);
        await logAction('Nieuwe herinnering aangemaakt (Smart)', 'reminder', docRef.id, `Titel: ${reminderData.title}`);
        return docRef.id;
      }
    } catch (err) {
      console.error('Error in reminder upsert:', err);
      return null;
    }
  },

  async save(reminderData: any, selectedReminder: Reminder | null) {
    try {
      const now = new Date().toISOString();
      const type = reminderData.type || 'other';
      const key = reminderData.uniqueReminderKey || this.generateKey(type, reminderData.customerId, reminderData.machineId);

      const data = {
        ...reminderData,
        uniqueReminderKey: key,
        normalizedTitle: normalizeText(reminderData.title),
        updatedAt: now
      };

      Object.keys(data).forEach(k => data[k] === undefined && delete data[k]);

      if (selectedReminder) {
        // Track status change in history
        if (reminderData.status !== selectedReminder.status) {
          const history = selectedReminder.history || [];
          history.push({
            status: reminderData.status,
            date: now,
            reason: 'Handmatige statuswijziging',
            userName: 'Gebruiker'
          });
          data.history = history;
        }

        await updateDoc(doc(db, COLLECTIONS.REMINDERS, selectedReminder.id), data);
        await logAction('Herinnering aangepast', 'reminder', selectedReminder.id, `Titel: ${data.title}`);
        return selectedReminder.id;
      } else {
        // Use upsert for new reminders created via UI to ensure no duplicates
        return await this.upsert(data, 'Gebruiker');
      }
    } catch (err) {
      handleFirestoreError(err, selectedReminder ? OperationType.UPDATE : OperationType.CREATE, COLLECTIONS.REMINDERS);
      return null;
    }
  },

  async delete(id: string) {
    try {
      await deleteDoc(doc(db, COLLECTIONS.REMINDERS, id));
      await logAction('Herinnering verwijderd', 'reminder', id);
      return true;
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, COLLECTIONS.REMINDERS);
      return false;
    }
  }
};
