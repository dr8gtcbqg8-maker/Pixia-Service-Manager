import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  Printer, 
  Wrench, 
  Package, 
  Bell, 
  Menu, 
  X,
  LogOut,
  Settings,
  Plus,
  ClipboardList,
  FileText,
  Calendar,
  Briefcase,
  ShieldCheck,
  Clock
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { BusinessSettings } from '../types';

const navItems = [
  { name: 'Dashboard', icon: LayoutDashboard, path: '/', roles: ['admin', 'planner'] },
  { name: 'Vandaag', icon: Clock, path: '/vandaag', roles: ['technician'] },
  { name: 'Planning', icon: Calendar, path: '/calendar', roles: ['admin', 'planner'] },
  { name: 'Interventies', icon: Wrench, path: '/interventions', roles: ['admin', 'planner'] },
  { name: 'Werkbonnen', icon: ClipboardList, path: '/work-orders', roles: ['admin', 'planner', 'technician'] },
  { name: 'Klanten', icon: Users, path: '/customers', roles: ['admin', 'planner', 'technician'] },
  { name: 'Machines', icon: Printer, path: '/machines', roles: ['admin', 'planner', 'technician'] },
  { name: 'Voorraad', icon: Package, path: '/inventory', roles: ['admin', 'planner', 'technician'] },
  { name: 'Acties', icon: Bell, path: '/actions', roles: ['admin', 'planner', 'technician'] },
  { name: 'Audit Logs', icon: ShieldCheck, path: '/audit-logs', roles: ['admin'] },
  { name: 'Instellingen', icon: Settings, path: '/settings', roles: ['admin', 'planner'] },
];

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [businessSettings, setBusinessSettings] = useState<BusinessSettings | null>(null);
  const location = useLocation();
  const { profile, logout } = useAuth();

  useEffect(() => {
    const fetchBusiness = async () => {
      try {
        const docSnap = await getDoc(doc(db, 'settings', 'business'));
        if (docSnap.exists()) {
          setBusinessSettings(docSnap.data() as BusinessSettings);
        }
      } catch (err) {
        console.error('Error fetching business settings for layout:', err);
      }
    };
    fetchBusiness();
  }, []);

  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);

  const filteredNavItems = navItems.filter(item => {
    if (!item.roles) return true;
    const role = profile?.role || 'technician';
    return item.roles.includes(role);
  });

  return (
    <div className="min-h-screen flex bg-slate-50">
      {/* Mobile Backdrop */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={toggleSidebar}
            className="fixed inset-0 bg-slate-900/40 z-40 lg:hidden backdrop-blur-sm"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 text-white flex flex-col transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0 shadow-2xl lg:shadow-none",
          isSidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="h-full flex flex-col">
          <div className="p-6 border-b border-slate-800/50 flex items-center justify-between">
            <Link to="/" className="flex items-center space-x-3 group">
              <div className="shrink-0">
                {businessSettings?.iconUrl || businessSettings?.logoUrl ? (
                  <img src={businessSettings?.iconUrl || businessSettings?.logoUrl} alt="Company Logo" className="w-10 h-10 object-contain" />
                ) : (
                  <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20 group-hover:scale-105 transition-transform duration-300">
                    <Printer className="text-white w-6 h-6" />
                  </div>
                )}
              </div>
              <div className="flex flex-col min-w-0">
                <span className="font-bold text-base tracking-tight text-white truncate leading-tight">
                  {businessSettings?.name || 'Pixia'}
                </span>
                <span className="text-[10px] font-medium text-slate-400 uppercase tracking-wider">
                  Serviceplatform
                </span>
              </div>
            </Link>
            <button 
              onClick={toggleSidebar} 
              className="lg:hidden p-2 text-slate-400 hover:bg-slate-800 rounded-lg transition-colors"
              aria-label="Sluit menu"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <nav className="flex-1 p-4 space-y-1 overflow-y-auto custom-scrollbar">
            {filteredNavItems.map((item) => {
              const isActive = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setIsSidebarOpen(false)}
                  className={cn(
                    "flex items-center space-x-3 px-3 py-2.5 rounded-lg transition-all duration-200 text-sm font-medium border border-transparent",
                    isActive 
                      ? "bg-blue-600 text-white shadow-lg shadow-blue-900/20" 
                      : "text-slate-400 hover:bg-slate-800 hover:text-white"
                  )}
                >
                  <item.icon className={cn(
                    "w-4 h-4 transition-colors",
                    isActive ? "text-white" : "text-slate-500"
                  )} />
                  <span>{item.name}</span>
                </Link>
              );
            })}
          </nav>

          {/* User Section */}
          <div className="p-4 border-t border-slate-800/50">
            <div className="flex items-center space-x-3 px-2 mb-4">
              <div className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center text-sm font-bold text-blue-400 border border-slate-700 shadow-inner">
                {profile?.displayName?.charAt(0) || 'U'}
              </div>
              <div className="flex flex-col min-w-0">
                <span className="text-sm font-semibold text-white truncate">
                  {profile?.displayName || 'Gebruiker'}
                </span>
                <span className="text-[11px] text-slate-500 font-medium capitalize">
                  {profile?.role === 'admin' ? 'Admin' : profile?.role === 'customer' ? 'Klant' : 'Technicus'}
                </span>
              </div>
            </div>
            <button 
              onClick={logout}
              className="w-full flex items-center space-x-3 px-3 py-2 text-slate-500 hover:bg-red-500/10 hover:text-red-400 rounded-lg transition-all text-sm font-medium"
            >
              <LogOut className="w-4 h-4" />
              <span>Uitloggen</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 lg:px-8 shrink-0 z-30">
          <div className="flex items-center space-x-4 flex-1">
            <button 
              onClick={toggleSidebar} 
              className="lg:hidden p-2 text-slate-500 hover:bg-slate-50 rounded-lg transition-colors"
              aria-label="Open menu"
            >
              <Menu className="w-6 h-6" />
            </button>
            <div className="relative w-full max-w-md hidden sm:block">
              <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 pointer-events-none">
                <Menu className="w-4 h-4" />
              </span>
              <input 
                type="text" 
                placeholder="Zoek klant, machine of serienummer..." 
                className="block w-full pl-10 pr-3 py-2 border border-slate-200 rounded-lg text-sm bg-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:border-blue-500 transition-all placeholder:text-slate-400"
              />
            </div>
          </div>
          
          <div className="flex items-center space-x-2 sm:space-x-4">
            <Link 
              to="/actions"
              className="p-2 text-slate-500 hover:bg-slate-50 rounded-lg relative transition-colors"
              aria-label="Acties"
            >
              <Bell className="w-5 h-5" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </Link>
            <div className="h-6 w-[1px] bg-slate-200 mx-1 hidden sm:block"></div>
            {profile?.role !== 'customer' && (
              <Link 
                to="/interventions"
                className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-semibold flex items-center gap-2 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all shadow-sm active:scale-[0.98]"
              >
                <Plus className="w-4 h-4" />
                <span className="hidden md:inline">Planning</span>
              </Link>
            )}
          </div>
        </header>

        <main className="flex-1 overflow-y-auto bg-slate-50">
          <div className="p-4 lg:p-8 max-w-[1600px] mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};
