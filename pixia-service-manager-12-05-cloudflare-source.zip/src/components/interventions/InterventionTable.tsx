import React from 'react';
import { format } from 'date-fns';
import { nl } from 'date-fns/locale';
import { motion } from 'motion/react';
import { 
  Calendar, Printer, Trash2, FileText, History 
} from 'lucide-react';
import { Intervention, Customer, Machine } from '../../types';

interface InterventionTableProps {
  interventions: Intervention[];
  customers: Customer[];
  machines: Machine[];
  onOpenDetails: (i: Intervention) => void;
  onOpenEdit: (i: Intervention) => void;
  onPlanAppointment: (i: Intervention) => void;
  onCreateWorkOrder: (i: Intervention) => void;
  onDelete: (id: string) => void;
  getStatusStyle: (status: string) => string;
  getStatusLabel: (status: string) => string;
  getPriorityStyle: (priority: string) => string;
}

const InterventionTable: React.FC<InterventionTableProps> = ({
  interventions,
  customers,
  machines,
  onOpenDetails,
  onPlanAppointment,
  onCreateWorkOrder,
  onDelete,
  getStatusStyle,
  getStatusLabel,
  getPriorityStyle
}) => {
  const getCustomerName = (id: string) => customers.find(c => c.id === id)?.name || 'Onbekende Klant';
  const getMachineSimpleInfo = (id: string) => {
    const m = machines.find(m => m.id === id);
    return m ? `${m.brand} ${m.model}` : 'Onbekende Machine';
  };

  if (interventions.length === 0) {
    return (
    <div className="bg-white p-16 rounded-2xl border border-slate-200 text-center flex flex-col items-center gap-4">
      <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center text-slate-300">
        <History className="w-8 h-8" />
      </div>
      <div>
        <h3 className="text-base font-bold text-slate-900">Geen interventies gevonden</h3>
        <p className="text-sm text-slate-500 max-w-xs mx-auto">Start met het registreren van werkzaamheden of pas de filters aan.</p>
      </div>
    </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
      <div className="hidden md:grid grid-cols-12 gap-4 px-6 py-3 bg-slate-50 border-b border-slate-200 text-[10px] font-bold uppercase tracking-wider text-slate-500">
        <div className="col-span-3">Klant / Machine</div>
        <div className="col-span-2">Datum / Tijd</div>
        <div className="col-span-2">Type / Prioriteit</div>
        <div className="col-span-2">Technicus</div>
        <div className="col-span-2">Status</div>
        <div className="col-span-1 text-right">Acties</div>
      </div>

      <div className="divide-y divide-slate-100">
        {interventions.map((i) => (
          <motion.div
            layout
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            key={i.id}
            className="group hover:bg-slate-50/50 transition-all cursor-pointer"
            onClick={() => onOpenDetails(i)}
          >
            <div className="hidden md:grid grid-cols-12 gap-4 items-center px-6 py-4">
              <div className="col-span-3 min-w-0">
                <div className="text-sm font-bold text-slate-900 truncate">{getCustomerName(i.customerId)}</div>
                <div className="text-[10px] text-blue-600 flex items-center gap-1 mt-0.5 truncate font-bold font-mono">
                  <Printer className="w-3 h-3" />
                  {getMachineSimpleInfo(i.machineId)}
                </div>
              </div>
              <div className="col-span-2">
                <div className="text-xs font-bold text-slate-700">{i.date ? format(new Date(i.date), 'dd MMM yyyy', { locale: nl }) : '-'}</div>
                <div className="text-[10px] text-slate-400 font-mono">{i.time || '--:--'}</div>
              </div>
              <div className="col-span-2">
                <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">{i.type}</div>
                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[8px] font-bold uppercase tracking-wider border ${getPriorityStyle(i.priority || 'normal')}`}>
                  {i.priority || 'normal'}
                </span>
              </div>
              <div className="col-span-2 text-sm font-medium text-slate-600">
                {i.technicianName || '-'}
              </div>
              <div className="col-span-2">
                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider border ${getStatusStyle(i.status)}`}>
                  {getStatusLabel(i.status)}
                </span>
              </div>
              <div className="col-span-1 flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button 
                  onClick={(e) => { e.stopPropagation(); onPlanAppointment(i); }}
                  className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-white rounded-md border border-transparent hover:border-slate-200 transition-all shadow-sm"
                  title="Afspraak plannen"
                >
                  <Calendar className="w-4 h-4" />
                </button>
                <button 
                  onClick={(e) => { e.stopPropagation(); onCreateWorkOrder(i); }}
                  className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-white rounded-md border border-transparent hover:border-slate-200 transition-all shadow-sm"
                  title="Werkbon maken"
                >
                  <FileText className="w-4 h-4" />
                </button>
                <button 
                  onClick={(e) => { e.stopPropagation(); onDelete(i.id!); }}
                  className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-white rounded-md border border-transparent hover:border-slate-200 transition-all shadow-sm"
                  title="Verwijderen"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Mobile View */}
            <div className="md:hidden p-4 space-y-3">
              <div className="flex justify-between items-start">
                <div className="min-w-0">
                  <div className="text-sm font-bold text-slate-900 truncate">{getCustomerName(i.customerId)}</div>
                  <div className="text-[10px] font-bold text-blue-600 truncate mt-0.5">{getMachineSimpleInfo(i.machineId)}</div>
                </div>
                <span className={`text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded-lg border ${getStatusStyle(i.status)}`}>
                  {getStatusLabel(i.status)}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-4 text-[10px] bg-slate-50 p-3 rounded-xl">
                <div>
                  <span className="block text-slate-400 uppercase font-black mb-0.5 tracking-tighter">Datum</span>
                  <span className="font-bold text-slate-700">{i.date ? format(new Date(i.date), 'dd MMM yyyy', { locale: nl }) : '-'}</span>
                </div>
                <div>
                  <span className="block text-slate-400 uppercase font-black mb-0.5 tracking-tighter">Type</span>
                  <span className={`font-bold uppercase ${i.priority === 'urgent' ? 'text-red-600' : 'text-slate-600'}`}>{i.type}</span>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default InterventionTable;
