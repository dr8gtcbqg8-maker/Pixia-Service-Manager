import ConfirmDialog from '../components/ConfirmDialog';
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { collection, doc, getDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { WorkOrder, Customer, Machine, Intervention, WorkOrderStatus, InterventionType } from '../types';
import { 
  ClipboardList, Download, ExternalLink, Calendar, 
  User, CheckCircle2, Clock, Plus, X, Printer, MapPin, 
  Hash, Wrench, AlertCircle, FileText, ChevronRight, PenTool, Trash2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { handleFirestoreError, OperationType, cn } from '../lib/utils';
import { logAction } from '../lib/audit';
import { format } from 'date-fns';
import { nl } from 'date-fns/locale';
import SignaturePad from '../components/SignaturePad';
import DocumentSection from '../components/DocumentSection';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { useAuth } from '../contexts/AuthContext';
import { useWorkOrders } from '../hooks/useWorkOrders';
import { workOrderService } from '../services/workOrderService';
import WorkOrderTable from '../components/work-orders/WorkOrderTable';
import WorkOrderFilters from '../components/work-orders/WorkOrderFilters';
import { COLLECTIONS } from '../constants/collections';

const WorkOrders: React.FC = () => {
  const { profile } = useAuth();
  const { 
    workOrders, customers, machines, inventory, loading, settings, 
    businessSettings, pdfLayoutSettings, refreshData 
  } = useWorkOrders();
  const [isDeleting, setIsDeleting] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [search, setSearch] = useState('');
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<WorkOrder | null>(null);
  const [isSigning, setIsSigning] = useState(false);
  const [signingEntity, setSigningEntity] = useState<'client' | 'technician' | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const pdfTemplateRef = useRef<HTMLDivElement>(null);

  const [isDirty, setIsDirty] = useState(false);
  const [isCancelConfirmOpen, setIsCancelConfirmOpen] = useState(false);
  const [formData, setFormData] = useState({
    orderNumber: `WB-${format(new Date(), 'yyyyMMdd')}-${Math.floor(1000 + Math.random() * 9000)}`,
    date: format(new Date(), 'yyyy-MM-dd'),
    endDate: '',
    customerId: '',
    customerLocation: '',
    contactPerson: '',
    machineId: '',
    brand: '',
    model: '',
    serialNumber: '',
    interventionId: '',
    interventionNumber: '',
    technicianName: '',
    type: 'onderhoud' as InterventionType,
    workDescription: '',
    partsUsed: [] as { itemId?: string; name: string; quantity: number; unitPrice?: number }[],
    hoursWorked: 0,
    travelTime: 0,
    notes: '',
    internalNotes: '',
    clientName: '',
    status: 'concept' as WorkOrderStatus,
    visitNumber: undefined as number | undefined
  });

  const STANDARD_TASKS = [
    'Periodiek onderhoud uitgevoerd volgens protocol.',
    'Storing onderzocht en verholpen.',
    'Slijtageonderdelen preventief vervangen.',
    'Machine gereinigd en gekalibreerd.',
    'Software en firmware gecontroleerd op updates.',
    'Testafdrukken gemaakt en gecontroleerd op kwaliteit.'
  ];

  const COMMON_PARTS = [
    { name: 'Filter Set A', price: 45.00 },
    { name: 'Smeermiddel (500ml)', price: 12.50 },
    { name: 'Aandrijfriem XL', price: 34.00 },
    { name: 'Sensormodule V2', price: 89.00 },
    { name: 'Reinigingskit', price: 19.95 }
  ];

  const generateOrderNumber = () => {
    const prefix = settings?.workOrderPrefix?.replace('-', '') || 'WB';
    return `${prefix}-${format(new Date(), 'yyyyMMdd')}-${Math.floor(1000 + Math.random() * 9000)}`;
  };

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const intId = params.get('interventionId');
    if (intId) {
      loadInterventionData(intId);
    }
  }, []);

  const loadInterventionData = async (id: string) => {
    try {
      // Rule: Prevent duplicate work orders per intervention
      const existingWO = await workOrderService.findExistingWorkOrderForIntervention(id);
      if (existingWO) {
        setSelectedOrder(existingWO);
        const customer = customers.find(c => c.id === existingWO.customerId);
        const machine = machines.find(m => m.id === existingWO.machineId);
        setFormData({
            orderNumber: existingWO.orderNumber,
            date: existingWO.date,
            endDate: existingWO.endDate || '',
            customerId: existingWO.customerId,
            customerLocation: existingWO.customerLocation || customer?.address || '',
            contactPerson: existingWO.contactPerson || customer?.contactPerson || '',
            machineId: existingWO.machineId,
            brand: existingWO.brand || machine?.brand || '',
            model: existingWO.model || machine?.model || '',
            serialNumber: existingWO.serialNumber || machine?.serialNumber || '',
            interventionId: existingWO.interventionId || id,
            interventionNumber: existingWO.interventionNumber || '',
            technicianName: existingWO.technicianName,
            type: existingWO.type as InterventionType,
            workDescription: existingWO.workDescription,
            partsUsed: existingWO.partsUsed || [],
            hoursWorked: existingWO.hoursWorked,
            travelTime: existingWO.travelTime,
            notes: existingWO.notes || '',
            internalNotes: existingWO.internalNotes || '',
            clientName: existingWO.clientName || '',
            status: existingWO.status,
            visitNumber: existingWO.visitNumber || undefined
        });
        setIsModalOpen(true);
        return;
      }

      const docSnap = await getDoc(doc(db, COLLECTIONS.INTERVENTIONS, id));
      if (docSnap.exists()) {
        const int = docSnap.data() as Intervention;
        
        const customer = customers.find(c => c.id === int.customerId);
        const machine = machines.find(m => m.id === int.machineId);

        setFormData(prev => ({
          ...prev,
          orderNumber: generateOrderNumber(),
          customerId: int.customerId,
          customerLocation: int.location || customer?.address || '',
          contactPerson: customer?.contactPerson || '',
          machineId: int.machineId,
          brand: machine?.brand || '',
          model: machine?.model || '',
          serialNumber: machine?.serialNumber || '',
          interventionId: id,
          interventionNumber: int.interventionNumber || '',
          date: int.date,
          endDate: int.endDate || '',
          technicianName: int.technicianName || '',
          type: int.type,
          workDescription: int.workPerformed || (int.problemDescription ? `STORINGSMELDING: ${int.problemDescription}\n\nUITGEVOERD:\n` : ''),
          partsUsed: int.partsUsed || [],
          hoursWorked: int.hoursWorked || 0,
          travelTime: int.travelTime || 0,
          status: 'concept'
        }));
        setIsModalOpen(true);
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, `interventions/${id}`);
    }
  };

  
  const updateFormData = (updates: any) => {
    setFormData((prev: any) => ({ ...prev, ...updates }));
    setIsDirty(true);
  };

  const handleCloseModal = () => {
    if (isDirty ) {
      setIsCancelConfirmOpen(true);
    } else {
      closeModal();
    }
  };

  const closeModal = () => {
    setIsCancelConfirmOpen(false);
    setIsModalOpen(false);
    setIsDirty(false);
  };

  const handleDelete = async (order: WorkOrder) => {
    setIsDeleting(true);
    const success = await workOrderService.delete(order.id, order.orderNumber);
    if (success) {
      if (selectedOrder?.id === order.id) {
        setIsModalOpen(false);
        setSelectedOrder(null);
      }
      setDeleteId(null);
      refreshData();
      alert('Werkbon succesvol verwijderd.');
    } else {
      alert('Fout bij verwijderen.');
    }
    setIsDeleting(false);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isSaving) return;
    setIsSaving(true);
    
    try {
      // Check for duplicate order number
      const isDuplicate = await workOrderService.checkDuplicateOrderNumber(formData.orderNumber, selectedOrder?.id);
      if (isDuplicate) {
        alert('Dit werkbonnummer bestaat al. Genereer een nieuw nummer.');
        setIsSaving(false);
        return;
      }

      const woId = await workOrderService.save(formData, selectedOrder);
      if (woId) {
        setIsModalOpen(false);
        refreshData();
      }
    } catch (err) {
      console.error('Error saving work order:', err);
    } finally {
      setIsSaving(false);
    }
  };

  const handleSignatureSave = async (signatureData: string) => {
    if (!signingEntity || !selectedOrder) return;

    if (signingEntity === 'client') {
      const signed = await workOrderService.sign(selectedOrder.id, 'client', signatureData, selectedOrder.clientName);
      if (signed) {
        await workOrderService.processStock(selectedOrder);
      }
    } else {
      await workOrderService.sign(selectedOrder.id, 'technician', signatureData);
    }

    setIsSigning(false);
    setSigningEntity(null);
    refreshData();
    
    // Refresh selected order to show signature
    const newDoc = await getDoc(doc(db, COLLECTIONS.WORK_ORDERS, selectedOrder.id));
    if (newDoc.exists()) {
      setSelectedOrder({ id: newDoc.id, ...newDoc.data() } as WorkOrder);
    }
  };

  const exportToPDF = async () => {
    if (!pdfTemplateRef.current || !selectedOrder) return;
    
    try {
      const element = pdfTemplateRef.current;
      
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff',
        onclone: (clonedDoc) => {
          // Robust fix for Tailwind 4 oklch colors
          const styleTags = clonedDoc.getElementsByTagName('style');
          for (let i = 0; i < styleTags.length; i++) {
            // Replace oklch(...) with a safe hex color for compatibility
            styleTags[i].innerHTML = styleTags[i].innerHTML.replace(/oklch\([^)]+\)/g, '#1e293b');
          }

          const clonedElement = clonedDoc.getElementById('pdf-order-template');
          if (clonedElement) {
            clonedElement.style.display = 'block';
            clonedElement.style.visibility = 'visible';
            clonedElement.style.position = 'relative';
            clonedElement.style.width = '210mm';
            clonedElement.style.margin = '0';
            clonedElement.style.backgroundColor = '#ffffff';
          }
        }
      });
      
      const imgData = canvas.toDataURL('image/png');
      
      if (!imgData || imgData === 'data:,' || imgData.length < 100) {
        throw new Error('Canvas rendering failed to produce valid image data');
      }

      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight, undefined, 'FAST');
      pdf.save(`Werkbon_${selectedOrder.orderNumber}.pdf`);
      
      await logAction('Werkbon PDF geëxporteerd', 'work_order', selectedOrder.id);
    } catch (err) {
      console.error('PDF Export Error:', err);
      alert('Fout bij PDF export: ' + (err instanceof Error ? err.message : 'Onbekende fout'));
    }
  };

  const getCustomer = (id: string) => customers.find(c => c.id === id);
  const getMachine = (id: string) => machines.find(m => m.id === id);

  const filteredOrders = useMemo(() => workOrders.filter(o => 
    o.orderNumber.toLowerCase().includes(search.toLowerCase()) ||
    getCustomer(o.customerId)?.name.toLowerCase().includes(search.toLowerCase())
  ), [workOrders, search, customers]);

  const getStatusStyle = (status: WorkOrderStatus) => {
    switch (status) {
      case 'Afgerond':
      case 'completed': return 'bg-green-50 text-green-700 border-green-100';
      case 'Gefactureerd': return 'bg-emerald-50 text-emerald-700 border-emerald-100';
      case 'Wachten klant': return 'bg-amber-50 text-amber-700 border-amber-100';
      case 'Wachten onderdelen': return 'bg-orange-50 text-orange-700 border-orange-100';
      case 'Bezig':
      case 'in-progress': return 'bg-brand-50 text-blue-700 border-brand-200';
      case 'Onderweg': return 'bg-brand-50 text-indigo-700 border-indigo-100';
      case 'Concept':
      case 'concept':
      case 'draft': return 'bg-surface-50 text-surface-500 border-surface-100';
      default: return 'bg-surface-50 text-surface-700 border-surface-100';
    }
  };

  const getStatusLabelText = (status: WorkOrderStatus) => {
    switch (status) {
      case 'completed': return 'Afgerond';
      case 'in-progress': return 'Bezig';
      case 'concept':
      case 'draft': return 'Concept';
      default: return status;
    }
  };

  return (
    <div className="space-y-4 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-surface-200 pb-6">
        <div>
          <h1 className="text-2xl font-bold text-surface-900 leading-tight">Werkbonnen</h1>
          <p className="text-sm text-surface-500 mt-1">Beheer en ondertekening van werkrapportages.</p>
        </div>
        <button 
          onClick={() => {
            setSelectedOrder(null);
            setFormData({
              orderNumber: generateOrderNumber(),
              date: format(new Date(), 'yyyy-MM-dd'),
              endDate: '',
              customerId: '',
              customerLocation: '',
              contactPerson: '',
              machineId: '',
              brand: '',
              model: '',
              serialNumber: '',
              interventionId: '',
              interventionNumber: '',
              technicianName: '',
              type: 'onderhoud',
              workDescription: '',
              partsUsed: [],
              hoursWorked: 0,
              travelTime: 0,
              notes: '',
              internalNotes: '',
              clientName: '',
              status: 'concept',
              visitNumber: undefined
            });
            setIsModalOpen(true);
          }}
          className="btn-primary"
        >
          <Plus className="w-4 h-4" />
          <span>Nieuwe Werkbon</span>
        </button>
      </div>
      <WorkOrderFilters search={search} setSearch={setSearch} />

      {loading ? (
        <div className="flex justify-center p-24">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-surface-200 border-t-blue-600"></div>
        </div>
      ) : (
        <WorkOrderTable 
          workOrders={filteredOrders}
          customers={customers}
          machines={machines}
          onSelect={(order) => {
            setSelectedOrder(order);
            const customer = customers.find(c => c.id === order.customerId);
            const machine = machines.find(m => m.id === order.machineId);
            setFormData({
                orderNumber: order.orderNumber,
                date: order.date,
                endDate: order.endDate || '',
                customerId: order.customerId,
                customerLocation: order.customerLocation || customer?.address || '',
                contactPerson: order.contactPerson || customer?.contactPerson || '',
                machineId: order.machineId,
                brand: order.brand || machine?.brand || '',
                model: order.model || machine?.model || '',
                serialNumber: order.serialNumber || machine?.serialNumber || '',
                interventionId: order.interventionId || '',
                interventionNumber: order.interventionNumber || '',
                technicianName: order.technicianName,
                type: order.type as InterventionType,
                workDescription: order.workDescription,
                partsUsed: order.partsUsed || [],
                hoursWorked: order.hoursWorked,
                travelTime: order.travelTime,
                notes: order.notes || '',
                internalNotes: order.internalNotes || '',
                clientName: order.clientName || '',
                status: order.status,
                visitNumber: order.visitNumber || undefined
            });
            setIsModalOpen(true);
          }}
          onDelete={handleDelete}
          deleteId={deleteId}
          setDeleteId={setDeleteId}
          isDeleting={isDeleting}
          profile={profile}
          getStatusLabelText={getStatusLabelText}
          getStatusStyle={getStatusStyle}
        />
      )}

      {/* Modal for Details / Sign / Edit */}
      <AnimatePresence>
        {isModalOpen && (
          <motion.div 
            key="workorder-modal-wrapper"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center p-4"
          >
            <motion.div
              key="backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-surface-900/60 backdrop-blur-sm"

            />
            <motion.div
              key="modal"
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-5xl rounded-lg shadow-2xl p-5 md:p-5 overflow-y-auto max-h-[95vh]"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 pb-6 border-b border-surface-100 gap-4">
                <div className="flex-1">
                    <div className="flex flex-wrap items-center gap-3">
                        <h2 className="text-xl font-bold text-surface-900 flex items-center gap-2">
                            <FileText className="w-5 h-5 text-brand-500" />
                            <span>{formData.orderNumber}</span>
                            {formData.visitNumber && (
                              <span className="inline-flex items-center px-2 py-0.5 rounded bg-blue-100 text-[10px] font-bold text-blue-800 font-mono">
                                Bezoek #{formData.visitNumber}
                              </span>
                            )}
                        </h2>
                        <select 
                          className={cn(
                            "text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full border outline-none",
                            getStatusStyle(formData.status)
                          )}
                          value={formData.status}
                          onChange={(e) => updateFormData({ status: e.target.value as WorkOrderStatus})}
                        >
                          <option value="Concept">Concept</option>
                          <option value="Onderweg">Onderweg</option>
                          <option value="Bezig">Bezig</option>
                          <option value="Wachten klant">Wachten klant</option>
                          <option value="Wachten onderdelen">Wachten onderdelen</option>
                          <option value="Afgerond">Afgerond</option>
                          <option value="Gefactureerd">Gefactureerd</option>
                        </select>
                    </div>
                    <p className="text-[11px] font-medium text-surface-500 mt-1">
                      Klant: {getCustomer(formData.customerId)?.name || 'Niet geselecteerd'}
                    </p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                    {selectedOrder && (
                       <button 
                        onClick={exportToPDF}
                        className="btn-ghost !p-2 text-surface-400 hover:text-brand-500"
                        title="Export PDF"
                       >
                         <Download className="w-5 h-5" />
                       </button>
                    )}
                    <button 
                        onClick={handleCloseModal}
                        className="p-2 hover:bg-surface-100 rounded-lg text-surface-400"
                    >
                        <X className="w-6 h-6" />
                    </button>
                </div>
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                <form onSubmit={handleSave} className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label className="label">Klant</label>
                        <select 
                            required
                            className="input-field"
                            value={formData.customerId}
                            onChange={(e) => updateFormData({ customerId: e.target.value, machineId: ''})}
                        >
                            <option value="">Klant...</option>
                            {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className="label">Machine</label>
                        <select 
                            required
                            className="input-field"
                            value={formData.machineId}
                            onChange={(e) => updateFormData({ machineId: e.target.value})}
                        >
                             <option value="">{formData.customerId ? 'Selecteer Machine...' : 'Kies eerst een klant'}</option>
                             {machines.filter(m => m.customerId === formData.customerId).map(m => (
                               <option key={m.id} value={m.id}>{m.model} ({m.serialNumber})</option>
                             ))}
                        </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="grid grid-cols-2 gap-2">
                        <div>
                            <label className="label">Begindatum</label>
                            <input 
                                type="date"
                                className="input-field"
                                value={formData.date}
                                onChange={(e) => updateFormData({ date: e.target.value})}
                            />
                        </div>
                        <div>
                            <label className="label">Einddatum</label>
                            <input 
                                type="date"
                                className="input-field"
                                value={formData.endDate}
                                min={formData.date}
                                onChange={(e) => updateFormData({ endDate: e.target.value})}
                            />
                        </div>
                    </div>
                    <div>
                        <label className="label">Technicus</label>
                        <input 
                            type="text"
                            className="input-field"
                            value={formData.technicianName}
                            onChange={(e) => updateFormData({ technicianName: e.target.value})}
                        />
                    </div>
                  </div>

                  <div>
                      <label className="label">Omschrijving Werkzaamheden</label>
                      <div className="flex flex-wrap gap-1.5 mb-3">
                        {STANDARD_TASKS.map((task, idx) => (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => setFormData(prev => ({ 
                              ...prev, 
                              workDescription: prev.workDescription ? `${prev.workDescription}\n- ${task}` : `- ${task}` 
                            }))}
                            className="px-2.5 py-1 bg-brand-50 text-brand-500 rounded-lg text-[9px] font-bold uppercase tracking-wider hover:bg-blue-100 transition-all border border-brand-200"
                          >
                            + {task.split(' ')[0]}...
                          </button>
                        ))}
                      </div>
                      <textarea 
                        rows={5}
                        placeholder="Voer hier de uitgevoerde werkzaamheden in..."
                        className="input-field resize-none min-h-[140px]"
                        value={formData.workDescription}
                        onChange={(e) => updateFormData({ workDescription: e.target.value})}
                      />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label className="label">Gewerkte Uren</label>
                        <input 
                            type="number" step="0.25"
                            className="input-field"
                            value={formData.hoursWorked}
                            onChange={(e) => updateFormData({ hoursWorked: parseFloat(e.target.value)})}
                        />
                    </div>
                    <div>
                        <label className="label">Reistijd (min)</label>
                        <input 
                            type="number"
                            className="input-field"
                            value={formData.travelTime}
                            onChange={(e) => updateFormData({ travelTime: parseInt(e.target.value)})}
                        />
                    </div>
                  </div>

                  <div>
                      <label className="label">Naam Ondertekenaar / Contactpersoon</label>
                      <input 
                        type="text"
                        placeholder="Naam van de klant"
                        className="input-field"
                        value={formData.clientName}
                        onChange={(e) => updateFormData({ clientName: e.target.value})}
                      />
                  </div>

                  <div className="space-y-4 pt-4 border-t border-surface-100">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold uppercase tracking-wider text-surface-400">Gebruikte Onderdelen</label>
                      <div className="flex items-center gap-2">
                          <span className="text-[10px] font-bold text-surface-400 uppercase">Snel Toevoegen:</span>
                          <select 
                            className="text-xs font-bold bg-surface-50 border border-surface-200 rounded-lg px-2 py-1 outline-none"
                            onChange={(e) => {
                              const item = inventory.find(i => i.id === e.target.value);
                              if (item) {
                                const existing = formData.partsUsed.find(p => p.itemId === item.id);
                                if (existing) {
                                  updateFormData({ partsUsed: formData.partsUsed.map(p => p.itemId === item.id ? { ...p, quantity: p.quantity + 1 } : p)
                                  });
                                } else {
                                  updateFormData({ partsUsed: [...formData.partsUsed, { 
                                      itemId: item.id, 
                                      name: item.name, 
                                      quantity: 1, 
                                      unitPrice: item.sellingPrice 
                                    }]
                                  });
                                }
                              }
                              e.target.value = '';
                            }}
                          >
                            <option value="">Kies onderdeel...</option>
                            {inventory.filter(i => i.status === 'active').map(i => (
                              <option key={i.id} value={i.id}>{i.name} (€{i.sellingPrice?.toFixed(2)})</option>
                            ))}
                          </select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      {formData.partsUsed.map((part, idx) => (
                        <div key={idx} className="flex items-center gap-3 bg-white p-3 rounded-md border border-surface-100 shadow-sm transition-all hover:border-surface-200">
                          <span className="flex-1 text-xs font-bold text-surface-700 truncate">{part.name}</span>
                          <div className="flex items-center gap-1 bg-surface-50 rounded-lg p-0.5 border border-surface-100">
                             <button 
                               type="button"
                               onClick={() => {
                                 const newParts = [...formData.partsUsed];
                                 if (newParts[idx].quantity > 1) {
                                   newParts[idx].quantity -= 1;
                                   updateFormData({ partsUsed: newParts});
                                 } else {
                                   updateFormData({ partsUsed: newParts.filter((_, i) => i !== idx)});
                                 }
                               }}
                               className="w-7 h-7 flex items-center justify-center text-surface-400 hover:text-brand-500 hover:bg-white rounded transition-all"
                             >
                               <Trash2 className="w-3.5 h-3.5" />
                             </button>
                             <span className="w-8 text-center text-xs font-bold">{part.quantity}</span>
                             <button 
                               type="button"
                               onClick={() => {
                                 const newParts = [...formData.partsUsed];
                                 newParts[idx].quantity += 1;
                                 updateFormData({ partsUsed: newParts});
                               }}
                               className="w-7 h-7 flex items-center justify-center text-surface-400 hover:text-brand-500 hover:bg-white rounded transition-all"
                             >
                               <Plus className="w-3.5 h-3.5" />
                             </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center gap-3 pt-6 border-t border-surface-100">
                     <button 
                        type="submit"
                        disabled={isSaving}
                        className="btn-primary flex-1 !py-2"
                     >
                        {isSaving ? (
                          <div className="flex items-center justify-center gap-3">
                            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                            <span>Verwerken...</span>
                          </div>
                        ) : (
                          <span>{selectedOrder ? 'Gegevens Bijwerken' : 'Werkbon Concept Opslaan'}</span>
                        )}
                     </button>
                  </div>
                </form>

                {/* Signatures & Preview */}
                <div className="space-y-4 bg-surface-50 p-5 md:p-5 rounded-lg border border-surface-100 h-full">
                  <div className="flex items-center justify-between border-b border-surface-200 pb-4">
                     <h3 className="text-xs font-bold uppercase tracking-wider text-surface-900 flex items-center gap-2">
                        <PenTool className="w-4 h-4 text-brand-500" />
                        Ondertekening
                     </h3>
                     {selectedOrder && (
                        <span className={cn(
                          "text-[9px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full border",
                          getStatusStyle(selectedOrder.status)
                        )}>
                            {selectedOrder.status}
                        </span>
                     )}
                  </div>

                  <div className="space-y-3">
                    {/* Client Signature */}
                    <div className="p-5 bg-white border border-surface-200 rounded-lg shadow-sm space-y-4">
                      {selectedOrder?.clientSignature ? (
                        <div className="space-y-4">
                           <div className="flex items-center justify-between">
                              <label className="text-[10px] font-bold uppercase tracking-wider text-surface-400">Handtekening Klant</label>
                              <span className="text-[9px] font-medium text-surface-400">Getekend op: {format(new Date(selectedOrder.signedAt || ''), 'dd-MM-yyyy HH:mm')}</span>
                           </div>
                           <div className="bg-surface-50/50 p-4 rounded-md border border-surface-100">
                             <img src={selectedOrder.clientSignature} alt="Client Signature" className="max-w-full h-24 object-contain mx-auto mix-blend-multiply" />
                           </div>
                           <p className="text-center text-xs font-bold text-surface-900">{selectedOrder.clientName}</p>
                        </div>
                      ) : (
                        <div className="text-center py-2">
                           <p className="text-xs font-medium text-surface-500 mb-6">Klant: <span className="font-bold text-surface-900">{formData.clientName || getCustomer(formData.customerId)?.name || 'Onbekend'}</span></p>
                           {selectedOrder && (
                              <button 
                               type="button"
                               onClick={() => { setIsSigning(true); setSigningEntity('client'); }}
                               className="btn-primary w-full !py-2 shadow-blue-200"
                              >
                                <PenTool className="w-5 h-5" />
                                <span>Nu Laten Tekenen</span>
                              </button>
                           )}
                        </div>
                      )}
                    </div>

                    {/* Technician Signature */}
                    <div className="p-5 bg-white border border-surface-200 rounded-lg shadow-sm space-y-4">
                      {selectedOrder?.technicianSignature ? (
                        <div className="space-y-4">
                           <label className="text-[10px] font-bold uppercase tracking-wider text-surface-400">Handtekening Technicus</label>
                           <div className="bg-surface-50/50 p-4 rounded-md border border-surface-100">
                             <img src={selectedOrder.technicianSignature} alt="Technician Signature" className="max-w-full h-20 object-contain mx-auto mix-blend-multiply" />
                           </div>
                           <p className="text-center text-xs font-bold text-surface-900">{selectedOrder.technicianName}</p>
                        </div>
                      ) : (
                        <div className="text-center py-2">
                           <p className="text-xs font-medium text-surface-500 mb-6">Eigen handtekening</p>
                           {selectedOrder && (
                              <button 
                               type="button"
                               onClick={() => { setIsSigning(true); setSigningEntity('technician'); }}
                               className="btn-secondary w-full !py-2 !bg-surface-900 !text-white !border-surface-900"
                              >
                                <PenTool className="w-5 h-5" />
                                <span>Zelf Tekenen</span>
                              </button>
                           )}
                        </div>
                      )}
                    </div>
                  </div>

                  {selectedOrder && (
                    <div className="pt-6 border-t border-surface-200 space-y-3">
                       <DocumentSection 
                         workOrderId={selectedOrder.id} 
                         customerId={formData.customerId}
                         machineId={formData.machineId}
                       />
                       <div className="p-4 bg-brand-50/50 rounded-md border border-brand-200 flex gap-3">
                          <AlertCircle className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                          <p className="text-[10px] text-blue-700 font-medium leading-relaxed">
                            Interventies worden pas afgerond na volledige ondertekening door de klant.
                          </p>
                       </div>
                    </div>
                  )}
                </div>
              </div>

              {/* PDF Preview Container (Off-screen for Export) */}
              <div style={{ position: 'fixed', left: '-10000px', top: '0', pointerEvents: 'none' }} aria-hidden="true">
                 <div 
                    ref={pdfTemplateRef} 
                    id="pdf-order-template"
                    style={{ 
                        width: '210mm', 
                        padding: '40px', 
                        fontFamily: 'Inter, system-ui, sans-serif',
                        minHeight: '297mm', 
                        color: pdfLayoutSettings?.variant === 'modern' ? '#ffffff' : '#0f172a', 
                        backgroundColor: pdfLayoutSettings?.variant === 'modern' ? '#0f172a' : '#ffffff',
                        position: 'relative'
                    }}
                 >
                    {/* Header */}
                    <div style={{ 
                      display: 'flex', 
                      justifyContent: 'space-between', 
                      alignItems: 'flex-start', 
                      paddingBottom: '40px', 
                      marginBottom: '40px', 
                      borderBottom: `4px solid ${pdfLayoutSettings?.primaryColor || '#2563eb'}` 
                    }}>
                       <div>
                          <h1 style={{ 
                            fontSize: '32px', 
                            fontWeight: 900, 
                            textTransform: 'uppercase', 
                            letterSpacing: '-0.02em', 
                            marginBottom: '4px', 
                            margin: 0,
                            color: pdfLayoutSettings?.variant === 'modern' ? '#ffffff' : '#0f172a'
                          }}>Service Werkbon</h1>
                          <p style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '4px', color: pdfLayoutSettings?.primaryColor || '#2563eb', margin: 0 }}>{formData.orderNumber}</p>
                          <p style={{ fontWeight: 500, color: '#94a3b8', margin: 0 }}>
                            Datum: {formData.date} {formData.endDate && formData.endDate !== formData.date ? `t/m ${formData.endDate}` : ''}
                          </p>
                       </div>
                       <div style={{ textAlign: 'right', display: 'flex', flexDirection: 'column', alignItems: 'flex-end' }}>
                          {pdfLayoutSettings?.showLogo && businessSettings?.logoUrl ? (
                            <img src={businessSettings.logoUrl} alt="Logo" style={{ maxHeight: '60px', marginBottom: '12px', display: 'block' }} />
                          ) : (
                            <p style={{ fontSize: '20px', fontWeight: 900, fontStyle: 'italic', margin: 0, color: pdfLayoutSettings?.variant === 'modern' ? '#ffffff' : '#0f172a' }}>
                              {businessSettings?.name || 'Pixia Service Manager'}
                            </p>
                          )}
                          <p style={{ fontSize: '12px', marginTop: '4px', color: '#94a3b8', margin: 0 }}>
                            {businessSettings?.address}<br/>
                            Tel: {businessSettings?.phone} | {businessSettings?.email}<br/>
                            {businessSettings?.website}<br/>
                            KvK: {businessSettings?.kvk} | BTW: {businessSettings?.btw}
                          </p>
                       </div>
                    </div>

                    {/* Customer & Machine Info */}
                    <div style={{ display: 'flex', gap: '30px', marginBottom: '40px' }}>
                       <div style={{ 
                         flex: 1, 
                         padding: '24px', 
                         borderRadius: '24px', 
                         backgroundColor: pdfLayoutSettings?.variant === 'modern' ? 'rgba(255,255,255,0.05)' : '#f8fafc', 
                         border: `1px solid ${pdfLayoutSettings?.variant === 'modern' ? 'rgba(255,255,255,0.1)' : '#f1f5f9'}` 
                       }}>
                          <h3 style={{ fontSize: '11px', fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: '12px', fontStyle: 'italic', color: '#94a3b8', margin: 0 }}>Klantgegevens</h3>
                          <p style={{ fontSize: '16px', fontWeight: 900, margin: 0 }}>{getCustomer(formData.customerId)?.name}</p>
                          <p style={{ color: '#64748b', margin: '4px 0 0 0', fontSize: '13px' }}>{getCustomer(formData.customerId)?.address}</p>
                          <p style={{ fontStyle: 'italic', marginTop: '6px', color: '#64748b', margin: 0, fontSize: '13px' }}>{getCustomer(formData.customerId)?.email}</p>
                       </div>
                       <div style={{ 
                         flex: 1, 
                         padding: '24px', 
                         borderRadius: '24px', 
                         backgroundColor: pdfLayoutSettings?.variant === 'modern' ? 'rgba(255,255,255,0.05)' : '#f8fafc', 
                         border: `1px solid ${pdfLayoutSettings?.variant === 'modern' ? 'rgba(255,255,255,0.1)' : '#f1f5f9'}` 
                       }}>
                          <h3 style={{ fontSize: '11px', fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: '12px', fontStyle: 'italic', color: '#94a3b8', margin: 0 }}>Machinegegevens</h3>
                          <p style={{ fontSize: '16px', fontWeight: 900, margin: 0 }}>{getMachine(formData.machineId)?.brand} {getMachine(formData.machineId)?.model}</p>
                          {pdfLayoutSettings?.includeMachineSerial && (
                            <p style={{ color: '#64748b', margin: '4px 0 0 0', fontSize: '13px' }}>S/N: {getMachine(formData.machineId)?.serialNumber}</p>
                          )}
                          <p style={{ fontWeight: 'bold', marginTop: '8px', color: pdfLayoutSettings?.primaryColor || '#2563eb', margin: 0, fontSize: '13px' }}>Type: {formData.type}</p>
                       </div>
                    </div>

                    {/* Work Description */}
                    <div style={{ marginBottom: '40px' }}>
                       <div style={{ marginBottom: '10px' }}>
                          <h3 style={{ fontSize: '11px', fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.1em', fontStyle: 'italic', color: '#94a3b8', margin: 0 }}>Werkzaamheden</h3>
                       </div>
                       <div style={{ 
                          padding: '24px', 
                          borderRadius: '20px', 
                          border: `1px solid ${pdfLayoutSettings?.variant === 'modern' ? 'rgba(255,255,255,0.1)' : '#e2e8f0'}`, 
                          backgroundColor: pdfLayoutSettings?.variant === 'modern' ? 'rgba(255,255,255,0.02)' : '#ffffff',
                          minHeight: '80px'
                       }}>
                          <div style={{ whiteSpace: 'pre-wrap', lineHeight: '1.6', fontSize: '13px', color: pdfLayoutSettings?.variant === 'modern' ? '#cbd5e1' : '#1e293b', margin: 0 }}>
                             {formData.workDescription}
                          </div>
                       </div>
                    </div>

                    {/* Parts Table */}
                    {formData.partsUsed && formData.partsUsed.length > 0 && (
                       <div style={{ marginBottom: '40px' }}>
                          <div style={{ marginBottom: '10px' }}>
                             <h3 style={{ fontSize: '11px', fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.1em', fontStyle: 'italic', color: '#94a3b8', margin: 0 }}>Gebruikte Onderdelen / Materialen</h3>
                          </div>
                          <div style={{ borderRadius: '20px', border: `1px solid ${pdfLayoutSettings?.variant === 'modern' ? 'rgba(255,255,255,0.1)' : '#f1f5f9'}`, overflow: 'hidden', backgroundColor: pdfLayoutSettings?.variant === 'modern' ? 'rgba(255,255,255,0.02)' : '#ffffff' }}>
                             <div style={{ display: 'flex', borderBottom: `1px solid ${pdfLayoutSettings?.variant === 'modern' ? 'rgba(255,255,255,0.1)' : '#f1f5f9'}`, backgroundColor: pdfLayoutSettings?.variant === 'modern' ? 'rgba(255,255,255,0.05)' : '#f8fafc', padding: '12px 20px' }}>
                                <div style={{ flex: 1, color: '#94a3b8', fontSize: '9px', textTransform: 'uppercase', fontWeight: 900 }}>Omschrijving</div>
                                <div style={{ width: '80px', color: '#94a3b8', fontSize: '9px', textTransform: 'uppercase', fontWeight: 900, textAlign: 'center' }}>Aantal</div>
                             </div>
                             {formData.partsUsed.map((part, idx) => (
                                <div key={idx} style={{ display: 'flex', padding: '12px 20px', borderBottom: idx === formData.partsUsed.length - 1 ? 'none' : `1px solid ${pdfLayoutSettings?.variant === 'modern' ? 'rgba(255,255,255,0.05)' : '#f1f5f9'}` }}>
                                   <div style={{ flex: 1, fontWeight: 'bold', color: pdfLayoutSettings?.variant === 'modern' ? '#f8fafc' : '#1e293b', fontSize: '13px' }}>{part.name}</div>
                                   <div style={{ width: '80px', textAlign: 'center', fontWeight: 'bold', color: pdfLayoutSettings?.variant === 'modern' ? '#f8fafc' : '#1e293b', fontSize: '13px' }}>{part.quantity}</div>
                                </div>
                             ))}
                          </div>
                       </div>
                    )}

                    {/* Stats */}
                    <div style={{ display: 'flex', gap: '20px', marginBottom: '40px' }}>
                       <div style={{ 
                         flex: 1, 
                         padding: '16px', 
                         borderRadius: '16px', 
                         border: `1px solid ${pdfLayoutSettings?.variant === 'modern' ? 'rgba(255,255,255,0.1)' : '#f1f5f9'}`, 
                         backgroundColor: pdfLayoutSettings?.variant === 'modern' ? 'rgba(255,255,255,0.05)' : '#f8fafc' 
                       }}>
                          <p style={{ fontSize: '9px', fontWeight: 900, textTransform: 'uppercase', marginBottom: '2px', color: '#94a3b8', margin: 0 }}>Technicus</p>
                          <p style={{ fontWeight: 'bold', margin: 0, fontSize: '13px' }}>{formData.technicianName}</p>
                       </div>
                       <div style={{ 
                         flex: 1, 
                         padding: '16px', 
                         borderRadius: '16px', 
                         border: `1px solid ${pdfLayoutSettings?.variant === 'modern' ? 'rgba(255,255,255,0.1)' : '#f1f5f9'}`, 
                         backgroundColor: pdfLayoutSettings?.variant === 'modern' ? 'rgba(255,255,255,0.05)' : '#f8fafc' 
                       }}>
                          <p style={{ fontSize: '9px', fontWeight: 900, textTransform: 'uppercase', marginBottom: '2px', color: '#94a3b8', margin: 0 }}>Gewerkte Uren</p>
                          <p style={{ fontWeight: 'bold', margin: 0, fontSize: '13px' }}>{formData.hoursWorked} uur</p>
                       </div>
                       <div style={{ 
                         flex: 1, 
                         padding: '16px', 
                         borderRadius: '16px', 
                         border: `1px solid ${pdfLayoutSettings?.variant === 'modern' ? 'rgba(255,255,255,0.1)' : '#f1f5f9'}`, 
                         backgroundColor: pdfLayoutSettings?.variant === 'modern' ? 'rgba(255,255,255,0.05)' : '#f8fafc' 
                       }}>
                          <p style={{ fontSize: '9px', fontWeight: 900, textTransform: 'uppercase', marginBottom: '2px', color: '#94a3b8', margin: 0 }}>Reistijd</p>
                          <p style={{ fontWeight: 'bold', margin: 0, fontSize: '13px' }}>{formData.travelTime} min</p>
                       </div>
                    </div>

                    {/* Signatures */}
                    <div style={{ display: 'flex', gap: '60px', marginTop: '60px' }}>
                       {pdfLayoutSettings?.includeTechnicianSignature && (
                       <div style={{ flex: 1 }}>
                          <p style={{ fontSize: '9px', fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.1em', color: '#94a3b8', marginBottom: '12px', margin: 0 }}>Handtekening Technicus</p>
                          {selectedOrder?.technicianSignature && (
                             <img src={selectedOrder.technicianSignature} style={{ maxHeight: '80px', maxWidth: '100%', objectFit: 'contain' }} />
                          )}
                          <div style={{ fontSize: '13px', fontWeight: 'bold', paddingTop: '6px', borderTop: `1px solid ${pdfLayoutSettings?.variant === 'modern' ? 'rgba(255,255,255,0.1)' : '#e2e8f0'}`, marginTop: '12px' }}>{formData.technicianName}</div>
                       </div>
                       )}
                       {pdfLayoutSettings?.includeClientSignature && (
                       <div style={{ flex: 1 }}>
                          <p style={{ fontSize: '9px', fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.1em', color: '#94a3b8', marginBottom: '12px', margin: 0 }}>Handtekening Klant</p>
                          {selectedOrder?.clientSignature && (
                             <img src={selectedOrder.clientSignature} style={{ maxHeight: '80px', maxWidth: '100%', objectFit: 'contain' }} />
                          )}
                          <div style={{ fontSize: '13px', fontWeight: 'bold', paddingTop: '6px', borderTop: `1px solid ${pdfLayoutSettings?.variant === 'modern' ? 'rgba(255,255,255,0.1)' : '#e2e8f0'}`, marginTop: '12px' }}>{formData.clientName || getCustomer(formData.customerId)?.name}</div>
                          {selectedOrder?.signedAt && (
                             <p style={{ fontSize: '9px', color: '#94a3b8', marginTop: '6px', margin: 0 }}>Getekend op {format(new Date(selectedOrder.signedAt), 'dd MMMM yyyy HH:mm', { locale: nl })}</p>
                          )}
                       </div>
                       )}
                    </div>

                    {/* Footer / Terms */}
                    <div style={{ marginTop: 'auto', paddingTop: '40px' }}>
                      {pdfLayoutSettings?.termsAndConditions && (
                        <div style={{ marginBottom: '20px', padding: '20px', border: `1px solid ${pdfLayoutSettings?.variant === 'modern' ? 'rgba(255,255,255,0.1)' : '#f1f5f9'}`, borderRadius: '16px', fontSize: '9px', color: '#94a3b8', lineHeight: '1.4' }}>
                           <p style={{ fontWeight: 900, textTransform: 'uppercase', marginBottom: '4px', margin: 0 }}>Algemene Voorwaarden</p>
                           {pdfLayoutSettings.termsAndConditions}
                        </div>
                      )}
                      <p style={{ fontSize: '10px', color: '#94a3b8', textAlign: 'center', margin: 0 }}>{pdfLayoutSettings?.footerText}</p>
                    </div>

                    {/* Watermark */}
                    {pdfLayoutSettings?.showWatermark && (
                      <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%) rotate(-45deg)', fontSize: '120px', fontWeight: 900, color: 'rgba(0,0,0,0.03)', pointerEvents: 'none', zIndex: -1 }}>
                        PIXIA
                      </div>
                    )}
                 </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Signature Modal */}
      <AnimatePresence>
        {isSigning && (
          <motion.div 
            key="signature-modal-wrapper"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[70] flex items-center justify-center p-4"
          >
            <motion.div
              key="signature-backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-surface-900/80 backdrop-blur-md"
            />
            <motion.div
              key="signature-modal"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="relative bg-white w-full max-w-lg rounded-lg shadow-2xl p-5"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-base font-black text-surface-900 uppercase tracking-widest italic">
                  Digitale Handtekening
                </h2>
                <button 
                  onClick={() => setIsSigning(false)}
                  className="p-2 hover:bg-surface-50 rounded-md text-surface-400"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="bg-brand-50/50 p-4 rounded-md border border-brand-200 mb-6 flex items-start gap-3">
                 <AlertCircle className="w-5 h-5 text-brand-500 shrink-0 mt-0.5" />
                 <p className="text-[11px] text-blue-700 font-medium leading-relaxed">
                   U ondertekent als <strong>{signingEntity === 'client' ? 'Klant' : 'Technicus'}</strong>. Plaats uw handtekening in het onderstaande veld.
                 </p>
              </div>

              <SignaturePad 
                title={signingEntity === 'client' ? "Handtekening Klant" : "Handtekening Technicus"}
                onSave={handleSignatureSave}
              />
              
              <button 
                 onClick={() => setIsSigning(false)}
                 className="w-full mt-4 py-3 text-surface-400 font-black text-[10px] uppercase tracking-widest hover:bg-surface-50 rounded-md transition-all"
              >
                Annuleren
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      <ConfirmDialog
        isOpen={isCancelConfirmOpen}
        title="Onopgeslagen Wijzigingen"
        message="Je hebt onopgeslagen wijzigingen. Weet je zeker dat je wilt annuleren? Al je werk gaat verloren."
        onConfirm={closeModal}
        onCancel={() => setIsCancelConfirmOpen(false)}
        variant="danger"
        confirmText="Ja, werk weggooien"
        cancelText="Terug"
      />
    </div>
  );
};

export default WorkOrders;
