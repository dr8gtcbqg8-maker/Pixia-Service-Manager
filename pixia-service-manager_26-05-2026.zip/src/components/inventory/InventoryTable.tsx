import React from 'react';
import { Package, AlertTriangle, ArrowUpRight, ArrowDownRight, Edit3, Trash2, Tag, MapPin, Hash, DollarSign } from 'lucide-react';
import { motion } from 'motion/react';
import { InventoryItem } from '../../types';

interface InventoryTableProps {
  items: InventoryItem[];
  onDetails: (item: InventoryItem) => void;
  onEdit: (item: InventoryItem) => void;
  onDelete: (id: string, e: React.MouseEvent) => void;
  onMutation: (item: InventoryItem, type: 'increase' | 'decrease') => void;
}

const InventoryTable: React.FC<InventoryTableProps> = ({ items, onDetails, onEdit, onDelete, onMutation }) => {
  if (items.length === 0) {
    return (
      <div className="p-5 text-center bg-white rounded-lg border border-surface-200">
        <p className="text-sm text-surface-500 font-medium">Geen artikelen gevonden.</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg border border-surface-200 overflow-hidden shadow-sm">
      <div className="hidden lg:grid grid-cols-12 gap-4 px-6 py-2 bg-surface-50/50 border-b border-surface-200 text-[10px] font-black uppercase tracking-widest text-surface-400">
        <div className="col-span-4">Artikel / Categorie</div>
        <div className="col-span-2">Locatie / Supplier</div>
        <div className="col-span-2">Voorraad</div>
        <div className="col-span-2">Prijs (In/Uit)</div>
        <div className="col-span-2 text-right">Acties</div>
      </div>

      <div className="divide-y divide-surface-100">
        {items.map((item) => (
          <motion.div
            layout
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            key={item.id}
            className="group hover:bg-surface-50/50 transition-all cursor-pointer"
            onClick={() => onDetails(item)}
          >
            {/* Desktop Row */}
            <div className="hidden lg:grid grid-cols-12 gap-4 items-center px-6 py-2">
              <div className="col-span-4 flex items-center gap-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center font-bold transition-colors uppercase shrink-0 ${
                  item.stockCount < item.minStock 
                    ? 'bg-amber-100 text-amber-600' 
                    : 'bg-surface-100 text-surface-500 group-hover:bg-brand-500 group-hover:text-white'
                }`}>
                  {item.stockCount < item.minStock ? <AlertTriangle className="w-5 h-5" /> : <Package className="w-5 h-5" />}
                </div>
                <div className="min-w-0">
                  <div className="text-sm font-bold text-surface-900 truncate">{item.name}</div>
                  <div className="flex items-center gap-2 text-[10px] font-black text-surface-400 uppercase tracking-widest">
                    <Tag className="w-3 h-3" />
                    {item.category}
                    {item.partNumber && <span className="text-surface-300">| {item.partNumber}</span>}
                  </div>
                </div>
              </div>
              <div className="col-span-2 space-y-1">
                <div className="flex items-center gap-2 text-xs text-surface-600">
                  <MapPin className="w-3 h-3 text-surface-400" />
                  <span>{item.location || '-'}</span>
                </div>
                <div className="text-[10px] text-surface-400 truncate">{item.supplier || '-'}</div>
              </div>
              <div className="col-span-2">
                <div className="flex items-center gap-2">
                  <span className={`text-sm font-bold ${item.stockCount < item.minStock ? 'text-amber-600' : 'text-surface-900'}`}>
                    {item.stockCount}
                  </span>
                  <span className="text-[10px] text-surface-400">/ min {item.minStock}</span>
                </div>
                <div className="w-24 h-1.5 bg-surface-100 rounded-full mt-1 overflow-hidden">
                  <div 
                    className={`h-full rounded-full ${item.stockCount < item.minStock ? 'bg-amber-500' : 'bg-green-500'}`}
                    style={{ width: `${Math.min(100, (item.stockCount / (item.minStock * 2)) * 100)}%` }}
                  />
                </div>
              </div>
              <div className="col-span-2 space-y-0.5">
                <div className="text-xs font-bold text-surface-900">€{item.sellingPrice?.toFixed(2)}</div>
                <div className="text-[10px] text-surface-400 italic">Inkoop: €{item.purchasePrice?.toFixed(2)}</div>
              </div>
              <div className="col-span-2 flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button 
                  onClick={(e) => { e.stopPropagation(); onMutation(item, 'increase'); }}
                  className="p-1.5 text-surface-400 hover:text-green-600 hover:bg-white rounded-md border border-transparent hover:border-surface-200 transition-all shadow-sm"
                  title="Voorraad bijboeken"
                >
                  <ArrowUpRight className="w-4 h-4" />
                </button>
                <button 
                  onClick={(e) => { e.stopPropagation(); onMutation(item, 'decrease'); }}
                  className="p-1.5 text-surface-400 hover:text-red-600 hover:bg-white rounded-md border border-transparent hover:border-surface-200 transition-all shadow-sm"
                  title="Voorraad afboeken"
                >
                  <ArrowDownRight className="w-4 h-4" />
                </button>
                <button 
                  onClick={(e) => { e.stopPropagation(); onEdit(item); }}
                  className="p-1.5 text-surface-400 hover:text-brand-500 hover:bg-white rounded-md border border-transparent hover:border-surface-200 transition-all shadow-sm"
                >
                  <Edit3 className="w-4 h-4" />
                </button>
                <button 
                  onClick={(e) => { e.stopPropagation(); onDelete(item.id, e); }}
                  className="p-1.5 text-surface-400 hover:text-red-600 hover:bg-white rounded-md border border-transparent hover:border-surface-200 transition-all shadow-sm"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Mobile View */}
            <div className="lg:hidden p-4 space-y-3">
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center font-bold shrink-0 ${
                    item.stockCount < item.minStock ? 'bg-amber-100 text-amber-600' : 'bg-surface-100 text-surface-500'
                  }`}>
                    {item.stockCount < item.minStock ? <AlertTriangle className="w-5 h-5" /> : <Package className="w-5 h-5" />}
                  </div>
                  <div>
                    <div className="text-sm font-bold text-surface-900">{item.name}</div>
                    <div className="text-[10px] font-black text-surface-400 uppercase tracking-widest">{item.category}</div>
                  </div>
                </div>
                <div className="flex gap-1">
                  <button onClick={(e) => { e.stopPropagation(); onEdit(item); }} className="p-2 text-surface-400 border border-surface-100 rounded-lg"><Edit3 className="w-4 h-4" /></button>
                  <button onClick={(e) => { e.stopPropagation(); onDelete(item.id, e); }} className="p-2 text-red-400 border border-red-50 rounded-lg"><Trash2 className="w-4 h-4" /></button>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <span className="text-[10px] text-surface-400 uppercase font-black tracking-widest">Voorraad</span>
                  <div className="text-sm font-bold text-surface-900">{item.stockCount} <span className="text-xs font-normal text-surface-400">/ {item.minStock}</span></div>
                </div>
                <div className="space-y-1 text-right">
                  <span className="text-[10px] text-surface-400 uppercase font-black tracking-widest">Verkoopprijs</span>
                  <div className="text-sm font-bold text-surface-900">€{item.sellingPrice?.toFixed(2)}</div>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default InventoryTable;
