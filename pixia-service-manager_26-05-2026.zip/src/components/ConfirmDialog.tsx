import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, X } from 'lucide-react';

interface ConfirmDialogProps {
  isOpen: boolean;
  title: string;
  message: string;
  onConfirm: () => void;
  onCancel: () => void;
  confirmText?: string;
  cancelText?: string;
  variant?: 'danger' | 'warning' | 'info';
}

const ConfirmDialog: React.FC<ConfirmDialogProps> = ({
  isOpen,
  title,
  message,
  onConfirm,
  onCancel,
  confirmText = 'Bevestigen',
  cancelText = 'Annuleren',
  variant = 'danger'
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
          key="confirm-dialog-container"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-4"
        >
          <motion.div
            key="backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-surface-900/60 backdrop-blur-sm"

          />
          <motion.div
            key="modal"
            initial={{ opacity: 0, scale: 0.95, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 10 }}
            className="relative bg-white w-full max-w-md rounded-lg shadow-2xl overflow-hidden"
          >
            <div className="p-5">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  variant === 'danger' ? 'bg-red-50 text-red-600' : 
                  variant === 'warning' ? 'bg-amber-50 text-amber-600' : 'bg-brand-50 text-brand-500'
                }`}>
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <button 
                  onClick={onCancel}
                  className="text-surface-400 hover:text-surface-600 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <h3 className="text-base font-bold text-surface-900 mb-2">{title}</h3>
              <p className="text-sm text-surface-500 leading-relaxed">{message}</p>
            </div>
            
            <div className="p-5 bg-surface-50 flex flex-col sm:flex-row gap-3">
              <button
                onClick={onCancel}
                className="flex-1 py-2.5 px-4 bg-white border border-surface-200 text-surface-600 text-sm font-bold rounded-md hover:bg-surface-50 transition-colors"
              >
                {cancelText}
              </button>
              <button
                onClick={() => {
                  onConfirm();
                }}
                className={`flex-1 py-2.5 px-4 text-white text-sm font-bold rounded-md shadow-lg transition-all active:scale-[0.98] ${
                  variant === 'danger' ? 'bg-red-600 hover:bg-red-700 shadow-red-100' :
                  variant === 'warning' ? 'bg-amber-500 hover:bg-amber-600 shadow-amber-100' : 'bg-brand-500 hover:bg-blue-700 shadow-blue-100'
                }`}
              >
                {confirmText}
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default ConfirmDialog;
