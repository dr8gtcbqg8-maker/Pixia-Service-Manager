import React from 'react';
import { Search, Filter } from 'lucide-react';
import { Customer, Machine } from '../../types';

interface InterventionFiltersProps {
  search: string;
  setSearch: (s: string) => void;
  filterCustomer: string;
  setFilterCustomer: (s: string) => void;
  filterMachine: string;
  setFilterMachine: (s: string) => void;
  filterType: string;
  setFilterType: (s: string) => void;
  filterStatus: string;
  setFilterStatus: (s: string) => void;
  filterPriority: string;
  setFilterPriority: (s: string) => void;
  filterDate: string;
  setFilterDate: (s: string) => void;
  customers: Customer[];
  machines: Machine[];
}

const InterventionFilters: React.FC<InterventionFiltersProps> = ({
  search, setSearch,
  filterCustomer, setFilterCustomer,
  filterMachine, setFilterMachine,
  filterType, setFilterType,
  filterStatus, setFilterStatus,
  filterPriority, setFilterPriority,
  filterDate, setFilterDate,
  customers,
  machines
}) => {
  return (
    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text"
            placeholder="Zoek op klant, machine of technicus..."
            className="input-field pl-12"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="flex flex-wrap gap-2">
          <select 
            className="input-field !w-auto !py-2 !text-[11px] !h-10 px-4"
            value={filterCustomer}
            onChange={(e) => setFilterCustomer(e.target.value)}
          >
            <option value="">Alle Klanten</option>
            {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <select 
            className="input-field !w-auto !py-2 !text-[11px] !h-10 px-4"
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
          >
            <option value="">Alle Status</option>
            <option value="to-be-scheduled">Nog te plannen</option>
            <option value="planned">Gepland</option>
            <option value="on-route">Onderweg</option>
            <option value="in-progress">Bezig</option>
            <option value="waiting-parts">Wacht op onderdelen</option>
            <option value="completed">Afgerond</option>
            <option value="cancelled">Geannuleerd</option>
          </select>
          <select 
            className="input-field !w-auto !py-2 !text-[11px] !h-10 px-4"
            value={filterPriority}
            onChange={(e) => setFilterPriority(e.target.value)}
          >
            <option value="">Alle Prioriteiten</option>
            <option value="urgent">Urgent</option>
            <option value="high">Hoog</option>
            <option value="normal">Normaal</option>
            <option value="low">Laag</option>
          </select>
          <input 
            type="date"
            className="input-field !w-auto !py-2 !text-[11px] !h-10 px-4"
            value={filterDate}
            onChange={(e) => setFilterDate(e.target.value)}
          />
        </div>
      </div>
    </div>
  );
};

export default InterventionFilters;
