import { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  Machine, Reminder, Intervention, Customer, InventoryItem, 
  SmartAlert, EmailLog, OutlookConnection, Period 
} from '../types';
import { dashboardService } from '../services/dashboardService';
import { 
  startOfMonth, endOfMonth, isWithinInterval, 
  startOfWeek, endOfWeek, startOfYear, endOfYear, 
  parseISO, subMonths, format
} from 'date-fns';

export function useDashboard() {
  const [data, setData] = useState<{
    machines: Machine[];
    reminders: Reminder[];
    interventions: Intervention[];
    customers: Customer[];
    inventory: InventoryItem[];
    allInterventions: Intervention[];
    alerts: SmartAlert[];
    emailLogs: EmailLog[];
    outlookConnection: OutlookConnection | null;
  }>({
    machines: [],
    reminders: [],
    interventions: [],
    customers: [],
    inventory: [],
    allInterventions: [],
    alerts: [],
    emailLogs: [],
    outlookConnection: null
  });
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState<Period>('month');
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('all');
  const [selectedMachineType, setSelectedMachineType] = useState<string>('all');

  const fetchData = useCallback(async () => {
    setLoading(true);
    const result = await dashboardService.fetchDashboardData();
    if (result) {
      setData(result);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const machineTypes = useMemo(() => {
    const types = new Set(data.machines.map(m => m.type));
    return Array.from(types);
  }, [data.machines]);

  // Combined Filters
  const filteredInterventions = useMemo(() => {
    const now = new Date();
    let start: Date, end: Date;

    if (period === 'week') {
      start = startOfWeek(now, { weekStartsOn: 1 });
      end = endOfWeek(now, { weekStartsOn: 1 });
    } else if (period === 'month') {
      start = startOfMonth(now);
      end = endOfMonth(now);
    } else {
      start = startOfYear(now);
      end = endOfYear(now);
    }

    return data.allInterventions.filter(i => {
      // Period filter
      let inPeriod = false;
      try {
        const date = parseISO(i.date);
        inPeriod = isWithinInterval(date, { start, end });
      } catch {
        inPeriod = false;
      }
      if (!inPeriod) return false;

      // Customer filter
      if (selectedCustomerId !== 'all' && i.customerId !== selectedCustomerId) return false;

      // Machine Type filter
      if (selectedMachineType !== 'all') {
        const m = data.machines.find(mach => mach.id === i.machineId);
        if (!m || m.type !== selectedMachineType) return false;
      }

      return true;
    });
  }, [data.allInterventions, period, selectedCustomerId, selectedMachineType, data.machines]);

  // Aggregations
  const statsOverview = useMemo(() => {
    const closed = filteredInterventions.filter(i => i.status === 'completed').length;
    const maintenance = filteredInterventions.filter(i => i.type === 'maintenance').length;
    const repairs = filteredInterventions.filter(i => i.type === 'fault').length;
    
    return {
      total: filteredInterventions.length,
      closed,
      maintenance,
      repairs
    };
  }, [filteredInterventions]);

  const trendsData = useMemo(() => {
    return Array.from({ length: 6 }).map((_, i) => {
      const date = subMonths(new Date(), 5 - i);
      const monthLabel = format(date, 'MMM');
      const monthStart = startOfMonth(date);
      const monthEnd = endOfMonth(date);

      const count = data.allInterventions.filter(inv => {
        try {
          const d = parseISO(inv.date);
          return isWithinInterval(d, { start: monthStart, end: monthEnd });
        } catch {
          return false;
        }
      }).length;

      return { name: monthLabel, count };
    });
  }, [data.allInterventions]);

  const typeData = useMemo(() => [
    { name: 'Onderhoud', value: statsOverview.maintenance, color: '#3b82f6' },
    { name: 'Reparatie', value: statsOverview.repairs, color: '#f59e0b' },
    { name: 'Installatie', value: filteredInterventions.filter(i => i.type === 'installation').length, color: '#10b981' }
  ].filter(d => d.value > 0), [statsOverview, filteredInterventions]);

  const statusData = useMemo(() => [
    { name: 'Open', value: filteredInterventions.filter(i => i.status === 'to-be-scheduled' || i.status === 'planned').length, color: '#94a3b8' },
    { name: 'Onderweg', value: filteredInterventions.filter(i => i.status === 'on-route').length, color: '#6366f1' },
    { name: 'Bezig', value: filteredInterventions.filter(i => i.status === 'in-progress').length, color: '#3b82f6' },
    { name: 'Wacht op onderdelen', value: filteredInterventions.filter(i => i.status === 'waiting-parts').length, color: '#f59e0b' },
    { name: 'Afgerond', value: filteredInterventions.filter(i => i.status === 'completed').length, color: '#10b981' }
  ].filter(d => d.value > 0), [filteredInterventions]);

  const topFaultyMachines = useMemo(() => {
    const machineCounts: Record<string, number> = {};
    data.allInterventions.filter(i => i.type === 'fault').forEach(i => {
      if (i.machineId) {
        machineCounts[i.machineId] = (machineCounts[i.machineId] || 0) + 1;
      }
    });

    return Object.entries(machineCounts)
      .map(([id, count]) => ({ machine: data.machines.find(m => m.id === id), count }))
      .filter(item => item.machine)
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
  }, [data.allInterventions, data.machines]);

  const topCustomers = useMemo(() => {
    const customerCounts: Record<string, number> = {};
    data.allInterventions.forEach(i => {
      customerCounts[i.customerId] = (customerCounts[i.customerId] || 0) + 1;
    });

    return Object.entries(customerCounts)
      .map(([id, count]) => ({ customer: data.customers.find(c => c.id === id), count }))
      .filter(item => item.customer)
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
  }, [data.allInterventions, data.customers]);

  const lowStockItems = useMemo(() => data.inventory.filter(item => item.stockCount <= item.minStock && item.status === 'active'), [data.inventory]);

  const expiringWarrantyCount = useMemo(() => data.machines.filter(m => {
    if (!m.warrantyEndDate) return false;
    try {
      const end = parseISO(m.warrantyEndDate);
      const now = new Date();
      const diffTime = end.getTime() - now.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays > 0 && diffDays <= 30;
    } catch {
      return false;
    }
  }).length, [data.machines]);

  const upcomingMaintenance = useMemo(() => data.machines
    .filter(m => {
      if (!m.nextMaintenanceDate) return false;
      try {
        const next = parseISO(m.nextMaintenanceDate);
        const now = new Date();
        const diffTime = next.getTime() - now.getTime();
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        return diffDays >= 0 && diffDays <= 14;
      } catch {
        return false;
      }
    })
    .sort((a, b) => (a.nextMaintenanceDate || '').localeCompare(b.nextMaintenanceDate || '')), [data.machines]);

  return {
    ...data,
    loading,
    period,
    setPeriod,
    selectedCustomerId,
    setSelectedCustomerId,
    selectedMachineType,
    setSelectedMachineType,
    machineTypes,
    statsOverview,
    trendsData,
    typeData,
    statusData,
    topFaultyMachines,
    topCustomers,
    lowStockItems,
    expiringWarrantyCount,
    upcomingMaintenance,
    refreshData: fetchData
  };
}
