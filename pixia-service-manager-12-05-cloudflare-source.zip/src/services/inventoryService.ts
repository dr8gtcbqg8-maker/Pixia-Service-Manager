import { collection, addDoc, doc, updateDoc, deleteDoc, getDocs, query, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { InventoryItem, MutationType } from '../types';
import { handleFirestoreError, OperationType } from '../lib/utils';
import { logAction } from '../lib/audit';
import { COLLECTIONS } from '../constants/collections';

export const inventoryService = {
  async save(itemData: any, selectedItem: InventoryItem | null) {
    try {
      const data = {
        ...itemData,
        stockCount: Number(itemData.stockCount),
        minStock: Number(itemData.minStock),
        purchasePrice: Number(itemData.purchasePrice),
        sellingPrice: Number(itemData.sellingPrice),
        updatedAt: new Date().toISOString()
      };

      if (selectedItem) {
        const docRef = doc(db, COLLECTIONS.INVENTORY, selectedItem.id);
        await updateDoc(docRef, data);
        await logAction('Voorraadartikel aangepast', 'inventory', selectedItem.id, `Naam: ${data.name}`);
        return selectedItem.id;
      } else {
        const docRef = await addDoc(collection(db, COLLECTIONS.INVENTORY), {
          ...data,
          createdAt: new Date().toISOString()
        });
        await logAction('Voorraadartikel aangemaakt', 'inventory', docRef.id, `Naam: ${data.name} (Start: ${data.stockCount})`);
        return docRef.id;
      }
    } catch (err) {
      handleFirestoreError(err, selectedItem ? OperationType.UPDATE : OperationType.CREATE, `${COLLECTIONS.INVENTORY}/${selectedItem?.id || 'new'}`);
      return null;
    }
  },

  async delete(id: string) {
    try {
      await deleteDoc(doc(db, COLLECTIONS.INVENTORY, id));
      await logAction('Voorraadartikel verwijderd', 'inventory', id);
      return true;
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `${COLLECTIONS.INVENTORY}/${id}`);
      return false;
    }
  },

  async saveMutation(itemId: string, currentStock: number, mutationType: MutationType, quantity: number, reason: string) {
    try {
      const mutationQty = Number(quantity);
      let newCount = Number(currentStock);
      
      if (mutationType === 'increase') newCount += mutationQty;
      else if (mutationType === 'decrease' || mutationType === 'intervention') newCount -= mutationQty;
      else if (mutationType === 'correction') newCount = mutationQty;

      if (!isFinite(newCount)) throw new Error('Ongeldige berekening');

      // Update item
      await updateDoc(doc(db, COLLECTIONS.INVENTORY, itemId), {
        stockCount: newCount,
        updatedAt: new Date().toISOString()
      });

      // Save mutation record
      const mutationDiff = mutationType === 'correction' ? (newCount - currentStock) : mutationQty;
      await addDoc(collection(db, COLLECTIONS.INVENTORY_MUTATIONS), {
        itemId,
        type: mutationType,
        quantity: mutationDiff,
        reason,
        timestamp: new Date().toISOString()
      });

      await logAction('Voorraad aangepast', 'inventory', itemId, `Type: ${mutationType}, Aantal: ${quantity}, Nieuw totaal: ${newCount}`);
      return true;
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `${COLLECTIONS.INVENTORY_MUTATIONS}/${itemId}`);
      return false;
    }
  }
};
