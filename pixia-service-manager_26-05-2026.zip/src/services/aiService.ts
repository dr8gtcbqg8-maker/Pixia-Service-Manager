import { Intervention, Customer, Machine } from '../types';

export const aiService = {
  /**
   * Helper to call the server-side AI proxy
   */
  async callAi(prompt: string, modelName: string = "gemini-3-flash-preview") {
    try {
      const response = await fetch("/api/ai/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, modelName }),
      });
      
      if (!response.ok) {
        throw new Error(`AI Request failed: ${response.statusText}`);
      }
      
      const data = await response.json();
      return data.text;
    } catch (err) {
      console.error("AI Proxy call failed:", err);
      return null;
    }
  },

  /**
   * Genereert een concept e-mail voor de klant na een interventie
   */
  async generateEmailDraft(params: {
    intervention: Intervention;
    customer: Customer;
    machine: Machine;
  }) {
    const { intervention, customer, machine } = params;
    
    const prompt = `
      Schrijf een professionele en vriendelijke e-mail namens Pixia Service naar de klant over een uitgevoerde interventie.
      Gebruik de volgende gegevens:
      - Klantnaam: ${customer.name}
      - Contactpersoon: ${customer.contactPerson || 'Klant'}
      - Machine: ${machine.brand} ${machine.model} (SN: ${machine.serialNumber})
      - Type interventie: ${intervention.type}
      - Datum: ${intervention.date}
      - Probleem: ${intervention.problemDescription || 'Niet gespecificeerd'}
      - Uitgevoerd werk: ${intervention.workPerformed || 'Niet gespecificeerd'}
      - Status: ${intervention.status}
      - Eventuele vervolgactie: ${intervention.followUpAction || 'Geen'}

      De e-mail moet in het Nederlands zijn, professioneel maar benaderbaar. Gebruik een duidelijke onderwerpregel.
      Eindig met een groet van het Pixia Service Team.
    `;

    const result = await this.callAi(prompt);
    return result || "Fout bij het genereren van de e-mail. Probeer het later opnieuw.";
  },

  /**
   * Vat een technische beschrijving samen tot een korte tekst
   */
  async summarizeIntervention(workPerformed: string) {
    if (!workPerformed) return "";

    const prompt = `
      Vat de volgende technische werkomschrijving samen in maximaal 2 korte zinnen voor een dashboard overzicht:
      "${workPerformed}"
    `;

    const result = await this.callAi(prompt);
    return result || workPerformed; // Fallback to original
  },

  /**
   * Geeft onderhoudsadvies op basis van machine status
   */
  async getMaintenanceAdvice(machine: Machine) {
    const prompt = `
      Geef een kort, deskundig onderhoudsadvies (max 50 woorden) voor de volgende machine:
      - Type: ${machine.type}
      - Merk/Model: ${machine.brand} ${machine.model}
      - Status: ${machine.status}
      - Laatste onderhoud: ${machine.lastMaintenanceDate || 'Onbekend'}
      - Contract: ${machine.hasServiceContract ? 'Ja' : 'Nee'}
    `;

    const result = await this.callAi(prompt);
    return result || "Houd de reguliere onderhoudsintervallen aan.";
  }
};
