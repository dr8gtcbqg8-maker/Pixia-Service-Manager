import { collection, query, getDocs, orderBy, limit, where } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { 
  Machine, Reminder, Intervention, Customer, InventoryItem, 
  SmartAlert, EmailLog, OutlookConnection 
} from '../types';
import { handleFirestoreError, OperationType } from '../lib/utils';
import { checkAndGenerateAlerts } from '../lib/alertService';
import { COLLECTIONS } from '../constants/collections';

export const dashboardService = {
  async fetchDashboardData() {
    try {
      const fetchCollection = async (path: string, queryConstraints: any[] = []) => {
        try {
          const q = queryConstraints.length > 0 
            ? query(collection(db, path), ...queryConstraints)
            : collection(db, path);
          const snap = await getDocs(q);
          return snap.docs;
        } catch (err) {
          console.warn(`Error fetching ${path}:`, err);
          return [];
        }
      };

      const sixMonthsAgo = new Date();
      sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
      const sixMonthsAgoStr = sixMonthsAgo.toISOString().split('T')[0];

      const [mDocs, rDocs, iDocs, cDocs, invDocs, recentInterventionsDocs, alertDocs, logDocs, outlookDocs] = await Promise.all([
        fetchCollection(COLLECTIONS.MACHINES),
        fetchCollection(COLLECTIONS.REMINDERS, [where('status', '==', 'open'), orderBy('dueDate', 'asc'), limit(20)]),
        fetchCollection(COLLECTIONS.INTERVENTIONS, [where('status', '!=', 'completed'), orderBy('date', 'asc'), limit(10)]),
        fetchCollection(COLLECTIONS.CUSTOMERS, [orderBy('createdAt', 'desc')]),
        fetchCollection(COLLECTIONS.INVENTORY),
        fetchCollection(COLLECTIONS.INTERVENTIONS, [where('date', '>=', sixMonthsAgoStr), orderBy('date', 'desc')]),
        fetchCollection(COLLECTIONS.SMART_ALERTS, [where('status', '==', 'open'), orderBy('createdAt', 'desc'), limit(5)]),
        fetchCollection(COLLECTIONS.EMAIL_LOGS, [orderBy('timestamp', 'desc'), limit(10)]),
        fetchCollection(COLLECTIONS.OUTLOOK_CONNECTIONS, [where('status', '==', 'connected'), limit(1)])
      ]);

      const fetchedMachines = mDocs.map(doc => ({ id: doc.id, ...doc.data() } as Machine));
      const fetchedInventory = invDocs.map(doc => ({ id: doc.id, ...doc.data() } as InventoryItem));
      const fetchedInterventions = recentInterventionsDocs.map(doc => ({ id: doc.id, ...doc.data() } as Intervention));
      const fetchedCustomers = cDocs.map(doc => ({ id: doc.id, ...doc.data() } as Customer));

      // Run alert checks in background with already fetched data
      // checkAndGenerateAlerts({
      //   machines: fetchedMachines,
      //   inventory: fetchedInventory,
      //   interventions: fetchedInterventions,
      //   customers: fetchedCustomers
      // });

      return {
        machines: fetchedMachines,
        reminders: rDocs.map(doc => ({ id: doc.id, ...doc.data() } as Reminder)),
        interventions: iDocs.map(doc => ({ id: doc.id, ...doc.data() } as Intervention)),
        customers: fetchedCustomers,
        inventory: fetchedInventory,
        allInterventions: fetchedInterventions,
        alerts: alertDocs.map(doc => ({ id: doc.id, ...doc.data() } as SmartAlert)),
        emailLogs: logDocs.map(doc => ({ id: doc.id, ...doc.data() } as EmailLog)),
        outlookConnection: outlookDocs.length > 0 ? { id: outlookDocs[0].id, ...outlookDocs[0].data() } as OutlookConnection : null
      };
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'dashboard_data');
      return null;
    }
  }
};
