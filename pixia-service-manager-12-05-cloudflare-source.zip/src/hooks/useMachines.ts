import { useState, useEffect, useCallback } from 'react';
import { machineService } from '../services/machineService';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Machine, Customer } from '../types';
import { COLLECTIONS } from '../constants/collections';

export const useMachines = () => {
  const [machines, setMachines] = useState<Machine[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);

  const refreshData = useCallback(async () => {
    setLoading(true);
    try {
      const [mSnap, cSnap] = await Promise.all([
        machineService.getAll(),
        getDocs(collection(db, COLLECTIONS.CUSTOMERS))
      ]);
      setMachines(mSnap);
      setCustomers(cSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Customer)));
    } catch (err) {
      console.error('Error fetching machines data:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  return {
    machines,
    customers,
    loading,
    refreshData
  };
};
