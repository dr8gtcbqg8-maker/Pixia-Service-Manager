import { useState, useEffect, useCallback } from 'react';
import { collection, getDocs, query, orderBy, where, limit } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { InventoryItem, InventoryMutation } from '../types';
import { COLLECTIONS } from '../constants/collections';

export const useInventory = () => {
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [loading, setLoading] = useState(true);

  const refreshData = useCallback(async () => {
    setLoading(true);
    try {
      const q = query(collection(db, COLLECTIONS.INVENTORY), orderBy('name', 'asc'));
      const snap = await getDocs(q);
      setItems(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as InventoryItem)));
    } catch (err) {
      console.error('Error fetching inventory:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  const fetchMutations = async (itemId: string) => {
    try {
      const q = query(
        collection(db, COLLECTIONS.INVENTORY_MUTATIONS), 
        where('itemId', '==', itemId),
        orderBy('timestamp', 'desc'),
        limit(20)
      );
      const snap = await getDocs(q);
      return snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as InventoryMutation));
    } catch (err) {
      console.error('Error fetching mutations:', err);
      return [];
    }
  };

  return {
    items,
    loading,
    refreshData,
    fetchMutations
  };
};
