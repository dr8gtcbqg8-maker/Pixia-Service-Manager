import React, { useEffect, useState, useMemo } from 'react';
import { Customer, Intervention, WorkOrder } from '../types';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Plus, MapPin, Phone, Mail, Edit3, Trash2, ExternalLink, User, Printer, Wrench, FileText, X, Navigation, Headphones, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ConfirmDialog from '../components/ConfirmDialog';
import DocumentSection from '../components/DocumentSection';
import { useCustomers } from '../hooks/useCustomers';
import { customerService } from '../services/customerService';
import CustomerTable from '../components/customers/CustomerTable';
import CustomerFilters from '../components/customers/CustomerFilters';
import { cn } from '../lib/utils';
import { format, parseISO } from 'date-fns';
import { nl } from 'date-fns/locale';

const Customers: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { customers, loading, refreshData } = useCustomers();
  const [search, setSearch] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<{ isOpen: boolean; id: string | null }>({ isOpen: false, id: null });
  const [isSaving, setIsSaving] = useState(false);
  const [duplicateWarning, setDuplicateWarning] = useState<{ isOpen: boolean; matches: Customer[] }>({ isOpen: false, matches: [] });
  const [isDirty, setIsDirty] = useState(false);
  const [isCancelConfirmOpen, setIsCancelConfirmOpen] = useState(false);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  
  // Other existing state which we must not lose:
  const [selectedTab, setSelectedTab] = useState<'gegevens' | 'machines' | 'interventies' | 'werkbonnen' | 'support' | 'documenten'>('gegevens');
  const [customerMachines, setCustomerMachines] = useState<any[]>([]);
  const [customerInterventions, setCustomerInterventions] = useState<Intervention[]>([]);
  const [customerWorkOrders, setCustomerWorkOrders] = useState<WorkOrder[]>([]);
  const [customerSupportLogs, setCustomerSupportLogs] = useState<any[]>([]);
  const [newCustomer, setNewCustomer] = useState({
    name: '',
    contactPerson: '',
    email: '',
    phone: '',
    address: '',
    billingAddress: '',
    status: 'active' as Customer['status'],
    notes: '',
    internalNotes: '',
    locations: [] as string[]
  });

  
  const updateFormData = (updates: any) => {
    setNewCustomer((prev: any) => ({ ...prev, ...updates }));
    setIsDirty(true);
  };

  const handleCloseModal = () => {
    if (isDirty ) {
      setIsCancelConfirmOpen(true);
    } else {
      closeModal();
    }
  };

  const closeModal = () => {
    setIsCancelConfirmOpen(false);
    setIsAddModalOpen(false);
    setIsDirty(false);
  };

  const handleOpenAddModal = () => {
    setSelectedCustomer(null);
    setDuplicateWarning({ isOpen: false, matches: [] });
    setNewCustomer({ 
      name: '', 
      contactPerson: '', 
      email: '', 
      phone: '', 
      address: '', 
      billingAddress: '',
      status: 'active',
      notes: '',
      internalNotes: '',
      locations: []
    });
    setIsAddModalOpen(true);
  };

  const handleOpenEditModal = (customer: Customer) => {
    setSelectedCustomer(customer);
    setDuplicateWarning({ isOpen: false, matches: [] });
    setNewCustomer({
      name: customer.name,
      contactPerson: customer.contactPerson || '',
      email: customer.email || '',
      phone: customer.phone || '',
      address: customer.address || '',
      billingAddress: customer.billingAddress || '',
      status: customer.status,
      notes: customer.notes || '',
      internalNotes: customer.internalNotes || '',
      locations: customer.locations || []
    });
    setIsAddModalOpen(true);
  };

  const handleSaveCustomer = async (e?: React.FormEvent, bypassDuplicateCheck = false) => {
    if (e) e.preventDefault();
    
    if (isSaving) return;

    if (!bypassDuplicateCheck) {
      setIsSaving(true);
      const matches = await customerService.findPotentialDuplicates(newCustomer as any, selectedCustomer?.id);
      setIsSaving(false);
      
      if (matches.length > 0) {
        setDuplicateWarning({ isOpen: true, matches });
        return;
      }
    }

    setIsSaving(true);
    const resultId = await customerService.save(newCustomer, selectedCustomer);
    setIsSaving(false);
    
    if (resultId) {
      setIsAddModalOpen(false);
      setNewCustomer({ 
        name: '', 
        contactPerson: '', 
        email: '', 
        phone: '', 
        address: '', 
        billingAddress: '',
        status: 'active',
        notes: '',
        internalNotes: '',
        locations: []
      });
      refreshData();
    }
  };



  const handleOpenDetails = async (customer: Customer) => {
    setSelectedCustomer(customer);
    setSelectedTab('gegevens');
    const { machines, interventions, workOrders, supportLogs } = await customerService.getRelatedData(customer.id);
    setCustomerMachines(machines);
    setCustomerInterventions(interventions as Intervention[]);
    setCustomerWorkOrders(workOrders as WorkOrder[]);
    setCustomerSupportLogs(supportLogs);
    setIsDetailsModalOpen(true);
  };

  useEffect(() => {
    const id = searchParams.get('id');
    if (id && customers.length > 0) {
      const c = customers.find(x => x.id === id);
      if (c && (!selectedCustomer || selectedCustomer.id !== id)) {
        handleOpenDetails(c);
        // Clear param so it doesn't reopen if closed
        const newParams = new URLSearchParams(searchParams);
        newParams.delete('id');
        setSearchParams(newParams, { replace: true });
      }
    }
  }, [searchParams, customers, selectedCustomer, setSearchParams]);

  const handleDeleteClick = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setDeleteConfirm({ isOpen: true, id });
  };

  const confirmDelete = async () => {
    if (!deleteConfirm.id) return;
    const success = await customerService.delete(deleteConfirm.id);
    if (success) {
      setDeleteConfirm({ isOpen: false, id: null });
      refreshData();
    }
  };

  const filteredCustomers = useMemo(() => customers.filter(c => 
    c.name.toLowerCase().includes(search.toLowerCase()) || 
    c.contactPerson?.toLowerCase().includes(search.toLowerCase()) ||
    c.email?.toLowerCase().includes(search.toLowerCase()) ||
    c.phone?.toLowerCase().includes(search.toLowerCase()) ||
    c.address?.toLowerCase().includes(search.toLowerCase()) ||
    c.locations?.some(loc => loc.toLowerCase().includes(search.toLowerCase()))
  ), [customers, search]);

  return (
    <div className="space-y-3">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-surface-200 pb-6">
        <div>
          <h1 className="text-2xl font-bold text-surface-900">Klantenbeheer</h1>
          <p className="text-sm text-surface-500 mt-1">Beheer uw relaties en machineparken.</p>
        </div>
        <button 
          onClick={handleOpenAddModal}
          className="btn-primary"
        >
          <Plus className="w-4 h-4" />
          <span>Nieuwe Klant</span>
        </button>
      </div>

      <CustomerFilters search={search} setSearch={setSearch} />

      {loading ? (
        <div className="flex justify-center p-20">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-600"></div>
        </div>
      ) : (
        <CustomerTable 
          customers={filteredCustomers}
          onSelect={handleOpenDetails}
          onEdit={handleOpenEditModal}
          onDelete={handleDeleteClick}
        />
      )}

      <ConfirmDialog
        isOpen={deleteConfirm.isOpen}
        title="Klant Verwijderen"
        message="LET OP: Weet u zeker dat u deze klant wilt verwijderen? Hiermee worden ook alle historische gegevens, machines en interventierapporten van deze klant onbereikbaar of verwijderd uit de context. Deze actie is definitief."
        onConfirm={confirmDelete}
        onCancel={() => setDeleteConfirm({ isOpen: false, id: null })}
      />

      {/* Add/Edit Modal */}
      <AnimatePresence>
        {isAddModalOpen && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-surface-900/40 backdrop-blur-sm"

            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative bg-white w-full max-w-2xl rounded-lg shadow-xl p-5 max-h-[90vh] overflow-y-auto custom-scrollbar"
            >
              <div className="flex items-center justify-between mb-8 pb-4 border-b border-surface-100">
                <h2 className="text-xl font-bold text-surface-900">
                  {selectedCustomer ? 'Klant bewerken' : 'Nieuwe klant toevoegen'}
                </h2>
                <button onClick={handleCloseModal} className="p-2 hover:bg-surface-100 rounded-lg text-surface-400 transition-all">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveCustomer} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-4">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-surface-400">Basis informatie</h3>
                    <div className="space-y-3">
                      <div>
                        <label className="label">Bedrijfsnaam *</label>
                        <input 
                          required 
                          type="text" 
                          placeholder="Bijv. Pixia Service"
                          className="input-field" 
                          value={newCustomer.name}
                          onChange={(e) => updateFormData({ name: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="label">Contactpersoon</label>
                        <input 
                          type="text" 
                          placeholder="Naam hoofdcontact"
                          className="input-field" 
                          value={newCustomer.contactPerson}
                          onChange={(e) => updateFormData({ contactPerson: e.target.value})}
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="label">Telefoon</label>
                          <input 
                            type="text" 
                            className="input-field" 
                            value={newCustomer.phone}
                            onChange={(e) => updateFormData({ phone: e.target.value})}
                          />
                        </div>
                        <div>
                          <label className="label">Status</label>
                          <select 
                            className="input-field"
                            value={newCustomer.status}
                            onChange={(e) => updateFormData({ status: e.target.value as Customer['status']})}
                          >
                            <option value="active">Actief</option>
                            <option value="inactive">Inactief</option>
                            <option value="lead">Lead</option>
                            <option value="prospect">Prospect</option>
                          </select>
                        </div>
                      </div>
                      <div>
                        <label className="label">Email adres</label>
                        <input 
                          type="email" 
                          placeholder="klant@bedrijf.nl"
                          className="input-field" 
                          value={newCustomer.email}
                          onChange={(e) => updateFormData({ email: e.target.value})}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-surface-400">Locaties & Adres</h3>
                    <div className="space-y-3">
                      <div>
                        <label className="label">Bezoekadres</label>
                        <textarea 
                          rows={2}
                          placeholder="Straat en nummer, Postcode, Stad"
                          className="input-field resize-none min-h-[80px]" 
                          value={newCustomer.address}
                          onChange={(e) => updateFormData({ address: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="label">Factuuradres</label>
                        <textarea 
                          rows={2}
                          placeholder="Laat leeg indien hetzelfde als bezoekadres"
                          className="input-field resize-none min-h-[80px]" 
                          value={newCustomer.billingAddress}
                          onChange={(e) => updateFormData({ billingAddress: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="label">Extra Locaties (één per regel)</label>
                        <textarea 
                          rows={2}
                          placeholder="Magazijn A, Tweede Vestiging..."
                          className="input-field resize-none min-h-[80px]" 
                          value={newCustomer.locations.join('\n')}
                          onChange={(e) => updateFormData({ locations: e.target.value.split('\n').filter(l => l.trim() !== '')})}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-6 border-t border-surface-100 space-y-4">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-surface-400">Notities</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                      <label className="label">Algemeen</label>
                      <textarea 
                        rows={3}
                        placeholder="Algemene klantinformatie..."
                        className="input-field resize-none" 
                        value={newCustomer.notes}
                        onChange={(e) => updateFormData({ notes: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="label text-rose-500 font-bold">Interne opmerkingen (geheim)</label>
                      <textarea 
                        rows={3}
                        placeholder="Zichtbaar alleen voor admins en technici..."
                        className="input-field bg-rose-50/20 border-rose-100 focus:ring-rose-500 resize-none font-medium text-rose-900" 
                        value={newCustomer.internalNotes}
                        onChange={(e) => updateFormData({ internalNotes: e.target.value})}
                      />
                    </div>
                  </div>
                </div>

                <AnimatePresence>
                  {duplicateWarning.isOpen && (
                    <motion.div 
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="bg-amber-50 border border-amber-100 rounded-md p-4 overflow-hidden"
                    >
                      <div className="flex items-start gap-3">
                        <div className="p-2 bg-amber-100 text-amber-600 rounded-lg shrink-0">
                          <Trash2 className="w-5 h-5" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-bold text-amber-900">Mogelijke dubbele klant gevonden</p>
                          <p className="text-xs text-amber-700 mt-1">
                            Er zijn klanten gevonden die lijken op de gegevens die u invoert. Wilt u doorgaan of een bestaande klant openen?
                          </p>
                          <div className="mt-3 space-y-2">
                            {duplicateWarning.matches.map(m => (
                              <div key={m.id} className="flex items-center justify-between p-2 bg-white/50 rounded-lg border border-amber-200/50">
                                <span className="text-[11px] font-bold text-surface-700">{m.name} ({m.email || m.phone || 'Geen contactinfo'})</span>
                                <button 
                                  type="button"
                                  onClick={(e) => {
                                    e.preventDefault();
                                    setIsAddModalOpen(false);
                                    handleOpenDetails(m);
                                  }}
                                  className="text-[10px] font-black uppercase text-amber-600 hover:text-amber-700"
                                >
                                  Openen
                                </button>
                              </div>
                            ))}
                          </div>
                          <div className="mt-4 flex items-center gap-3">
                             <button
                               type="button"
                               onClick={() => setDuplicateWarning({ isOpen: false, matches: [] })}
                               className="text-xs font-bold text-surface-500 hover:text-surface-700"
                             >
                               Aanpassen
                             </button>
                             <button
                               type="button"
                               onClick={() => handleSaveCustomer(undefined, true)}
                               className="text-xs font-bold text-amber-600 hover:text-amber-700 underline underline-offset-2"
                             >
                               Toch opslaan als nieuwe klant
                             </button>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <div className="flex items-center justify-end gap-3 pt-6 border-t border-surface-100">
                  <button 
                    type="button" 
                    disabled={isSaving}
                    onClick={handleCloseModal}
                    className="btn-ghost"
                  >
                    Annuleren
                  </button>
                  <button 
                    type="submit" 
                    disabled={isSaving}
                    className="btn-primary min-w-[160px]"
                  >
                    {isSaving ? (
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        <span>Verwerken...</span>
                      </div>
                    ) : (
                      <span>{selectedCustomer ? 'Wijzigingen opslaan' : 'Klant aanmaken'}</span>
                    )}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Details Modal / Dossier */}
      <AnimatePresence>
        {isDetailsModalOpen && selectedCustomer && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-surface-900/40 backdrop-blur-sm"

            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative bg-white w-full max-w-5xl rounded-lg shadow-xl overflow-hidden flex flex-col max-h-[90vh]"
            >
              {/* Header */}
              <div className="px-5 py-6 border-b border-surface-100 flex items-center justify-between bg-surface-50">
                <div className="flex items-center gap-5">
                  <div className="w-16 h-16 bg-brand-500 rounded-lg flex items-center justify-center text-white text-2xl font-bold shadow-lg shadow-blue-500/20 uppercase">
                    {selectedCustomer.name.charAt(0)}
                  </div>
                  <div>
                    <div className="flex items-center gap-3">
                      <h2 className="text-2xl font-bold text-surface-900 leading-tight">{selectedCustomer.name}</h2>
                      <span className={cn(
                        "px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border",
                        selectedCustomer.status === 'active' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 'bg-surface-100 text-surface-600 border-surface-200'
                      )}>
                        {selectedCustomer.status}
                      </span>
                    </div>
                    <p className="text-sm font-medium text-surface-500 mt-1 flex items-center gap-2">
                       #{selectedCustomer.id.slice(-6).toUpperCase()}
                       <span className="w-1 h-1 bg-surface-300 rounded-full" />
                       {customerMachines.length} machines in park
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => handleOpenEditModal(selectedCustomer)}
                    className="btn-ghost !p-2 text-surface-400 hover:text-brand-500 transition-all"
                    title="Bewerken"
                  >
                    <Edit3 className="w-5 h-5" />
                  </button>
                  <button onClick={() => setIsDetailsModalOpen(false)} className="p-2 hover:bg-surface-100 rounded-lg text-surface-400 transition-all">
                    <X className="w-6 h-6" />
                  </button>
                </div>
              </div>

              <div className="flex flex-1 overflow-hidden">
                {/* Stats Sidebar */}
                <div className="w-72 border-r border-surface-100 bg-surface-50/50 p-5 space-y-4 hidden md:block overflow-y-auto custom-scrollbar">
                  <div className="space-y-4">
                    <h3 className="text-[10px] font-bold text-surface-400 uppercase tracking-widest">Contactinformatie</h3>
                    <div className="space-y-4">
                      <div className="flex items-start gap-3">
                         <div className="p-2 bg-white rounded-md border border-surface-200 text-surface-400 shrink-0 shadow-sm">
                           <User className="w-4 h-4" />
                         </div>
                         <div className="min-w-0">
                           <p className="text-xs font-bold text-surface-900 truncate">{selectedCustomer.contactPerson || 'Geen contactpersoon'}</p>
                           <p className="text-[10px] text-surface-500 mt-0.5">Focuspersoon</p>
                         </div>
                      </div>
                      <div className="flex items-start gap-3">
                         <div className="p-2 bg-white rounded-md border border-surface-200 text-surface-400 shrink-0 shadow-sm">
                           <Phone className="w-4 h-4" />
                         </div>
                         <div className="min-w-0">
                           <p className="text-xs font-bold text-surface-900">{selectedCustomer.phone || '-'}</p>
                           <p className="text-[10px] text-surface-500 mt-0.5">Direct nummer</p>
                         </div>
                      </div>
                      <div className="flex items-start gap-3">
                         <div className="p-2 bg-white rounded-md border border-surface-200 text-surface-400 shrink-0 shadow-sm">
                           <Mail className="w-4 h-4" />
                         </div>
                         <div className="min-w-0">
                           <p className="text-xs font-bold text-surface-900 truncate" title={selectedCustomer.email}>{selectedCustomer.email || '-'}</p>
                           <p className="text-[10px] text-surface-500 mt-0.5">E-mail adres</p>
                         </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4 pt-8 border-t border-surface-200">
                    <h3 className="text-[10px] font-bold text-surface-400 uppercase tracking-widest">Operationele Stats</h3>
                    <div className="grid grid-cols-2 gap-3">
                       <div className="bg-white p-3.5 rounded-lg border border-surface-200 shadow-sm text-center">
                          <p className="text-xl font-bold text-surface-900 leading-tight">{customerMachines.length}</p>
                          <p className="text-[9px] font-bold text-surface-500 uppercase mt-0.5 tracking-tighter">Machines</p>
                       </div>
                       <div className="bg-white p-3.5 rounded-lg border border-surface-200 shadow-sm text-center">
                          <p className="text-xl font-bold text-brand-500 leading-tight">{customerInterventions.filter(i => i.status !== 'completed').length}</p>
                          <p className="text-[9px] font-bold text-surface-500 uppercase mt-0.5 tracking-tighter">Open Interv.</p>
                       </div>
                    </div>
                  </div>

                  <div className="pt-8 border-t border-surface-200">
                    <button 
                      onClick={() => window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(selectedCustomer.address || '')}`, '_blank')}
                      className="w-full btn-secondary text-[10px] h-10 flex items-center justify-center gap-2 group"
                    >
                      <Navigation className="w-3.5 h-3.5 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" /> 
                      Maps Navigatie
                    </button>
                  </div>
                </div>

                <div className="flex-1 flex flex-col min-w-0 bg-white">
                  {/* Tabs */}
                  <div className="flex px-5 bg-white border-b border-surface-100 overflow-x-auto scrollbar-hide">
                    {[
                      { id: 'gegevens', label: 'Dossier' },
                      { id: 'machines', label: 'Machinepark' },
                      { id: 'interventies', label: 'Interventies' },
                      { id: 'support', label: 'Support' },
                      { id: 'werkbonnen', label: 'Werkbonnen' },
                      { id: 'documenten', label: 'Documentatie' }
                    ].map((tab) => (
                      <button
                        key={tab.id}
                        onClick={() => setSelectedTab(tab.id as any)}
                        className={cn(
                          "px-6 py-3 text-sm font-bold transition-all relative whitespace-nowrap",
                          selectedTab === tab.id 
                            ? "text-brand-500" 
                            : "text-surface-400 hover:text-surface-600"
                        )}
                      >
                        {tab.label}
                        {selectedTab === tab.id && (
                          <motion.div 
                            layoutId="customer-tab-active"
                            className="absolute bottom-0 left-0 right-0 h-1 bg-brand-500 rounded-t-full" 
                          />
                        )}
                      </button>
                    ))}
                  </div>

                  {/* Tab Content */}
                  <div className="flex-1 overflow-y-auto p-5 custom-scrollbar">
                    <AnimatePresence mode="wait">
                      {selectedTab === 'gegevens' && (
                        <motion.div
                          key="tab-gegevens"
                          initial={{ opacity: 0, x: 10 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: -10 }}
                          className="space-y-4"
                        >
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-3">
                              <section>
                                <h4 className="text-xs font-bold text-surface-400 uppercase tracking-widest mb-3">Bezoekadres</h4>
                                <div className="p-4 bg-surface-50 border border-surface-200 rounded-md text-sm font-medium text-surface-700 leading-relaxed">
                                  {selectedCustomer.address || <span className="text-surface-400 font-normal italic">Geen adres ingesteld</span>}
                                </div>
                              </section>
                              <section>
                                <h4 className="text-xs font-bold text-surface-400 uppercase tracking-widest mb-3">Facturatie</h4>
                                <div className="p-4 bg-surface-50 border border-surface-200 rounded-md text-sm font-medium text-surface-700 leading-relaxed">
                                  {selectedCustomer.billingAddress || selectedCustomer.address || <span className="text-surface-400 font-normal italic">Zelfde als bezoekadres</span>}
                                </div>
                              </section>
                            </div>
                            <div className="space-y-3">
                              <section>
                                <h4 className="text-xs font-bold text-surface-400 uppercase tracking-widest mb-3">Extra locaties</h4>
                                <div className="space-y-2">
                                  {selectedCustomer.locations && selectedCustomer.locations.length > 0 ? (
                                    selectedCustomer.locations.map((loc, i) => (
                                      <div key={i} className="flex items-center gap-3 p-3 bg-white border border-surface-200 rounded-lg text-xs font-semibold text-surface-700 shadow-sm">
                                        <MapPin className="w-4 h-4 text-surface-400" />
                                        {loc}
                                      </div>
                                    ))
                                  ) : (
                                    <div className="p-4 bg-surface-50 border border-surface-200 rounded-md text-sm text-surface-400 italic">Geen bijkomende locaties</div>
                                  )}
                                </div>
                              </section>
                            </div>
                          </div>

                          <div className="pt-8 border-t border-surface-100">
                             <h4 className="text-xs font-bold text-surface-400 uppercase tracking-widest mb-4">Interne geschiedenis & Notities</h4>
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                               <div className="space-y-2">
                                 <p className="text-[10px] font-bold text-surface-500 uppercase tracking-wider ml-1">Klantnotities</p>
                                 <div className="p-5 bg-surface-50 border border-surface-200 rounded-md text-sm font-normal text-surface-600 leading-relaxed min-h-[120px] whitespace-pre-wrap">
                                   {selectedCustomer.notes || 'Geen notities geplaatst.'}
                                 </div>
                               </div>
                               <div className="space-y-2">
                                 <p className="text-[10px] font-bold text-rose-500 uppercase tracking-wider ml-1">Interne meldingen</p>
                                 <div className="p-5 bg-rose-50/20 border border-rose-100 rounded-md text-sm font-normal text-rose-900 leading-relaxed min-h-[120px] whitespace-pre-wrap">
                                   {selectedCustomer.internalNotes || 'Geen interne opmerkingen beschikbaar.'}
                                 </div>
                               </div>
                             </div>
                          </div>
                        </motion.div>
                      )}

                      {selectedTab === 'machines' && (
                        <motion.div
                          key="tab-machines"
                          initial={{ opacity: 0, x: 10 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="space-y-3"
                        >
                          <div className="flex items-center justify-between">
                            <h4 className="text-xs font-bold text-surface-500 uppercase tracking-widest">Actieve vloot ({customerMachines.length})</h4>
                            <button className="text-xs font-bold text-brand-500 hover:underline">Machine toevoegen</button>
                          </div>
                          
                          {customerMachines.length > 0 ? (
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                              {customerMachines.map(m => (
                                <div key={m.id} className="p-5 bg-white border border-surface-200 rounded-lg shadow-sm hover:ring-2 hover:ring-blue-100 transition-all group relative">
                                  <div className="flex items-start justify-between mb-4">
                                     <div className="p-2.5 bg-brand-50 text-brand-500 rounded-lg group-hover:bg-brand-500 group-hover:text-white transition-colors">
                                       <Printer className="w-5 h-5" />
                                     </div>
                                     <span className={cn(
                                       "px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider",
                                       m.status === 'active' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'
                                     )}>
                                       {m.status}
                                     </span>
                                  </div>
                                  <div>
                                    <p className="text-base font-bold text-surface-900">{m.brand} {m.model}</p>
                                    <p className="text-[11px] font-medium text-surface-500 mt-0.5">S/N: {m.serialNumber}</p>
                                  </div>
                                  <div className="mt-4 pt-4 border-t border-surface-100 flex items-center justify-between text-xs text-surface-500 font-medium">
                                     <span className="flex items-center gap-1.5"><MapPin className="w-3 h-3" /> {m.location || 'Geen locatie'}</span>
                                     <button className="text-brand-500 font-bold hover:underline">Beheer</button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <div className="p-5 border-2 border-dashed border-surface-200 rounded-md text-center">
                               <Printer className="w-10 h-10 text-surface-300 mx-auto mb-4" />
                               <p className="text-base font-bold text-surface-900">Geen machines gevonden</p>
                               <p className="text-sm text-surface-500 mt-1 max-w-xs mx-auto">Er zijn momenteel geen machines gekoppeld aan deze klant.</p>
                            </div>
                          )}
                        </motion.div>
                      )}

                      {selectedTab === 'interventies' && (
                        <motion.div
                          key="tab-interventies"
                          initial={{ opacity: 0, x: 10 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="space-y-3"
                        >
                          <div className="flex items-center justify-between">
                            <h4 className="text-xs font-bold text-surface-500 uppercase tracking-widest">Interventie geschiedenis</h4>
                            <button className="text-xs font-bold text-brand-500 hover:underline">Nieuwe aanvraag</button>
                          </div>
                          
                          {customerInterventions.length > 0 ? (
                            <div className="space-y-3">
                              {customerInterventions.map(int => (
                                <div key={int.id} className="p-4 bg-white border border-surface-200 rounded-md hover:bg-surface-50 transition-colors flex items-center gap-4 group cursor-pointer">
                                  <div className={cn(
                                    "w-10 h-10 rounded-lg flex items-center justify-center shrink-0 border",
                                    int.status === 'completed' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-brand-50 text-brand-500 border-brand-200'
                                  )}>
                                    <Wrench className="w-4 h-4" />
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <div className="flex items-center justify-between mb-0.5">
                                      <p className="text-sm font-bold text-surface-900 group-hover:text-brand-500 transition-colors capitalize">{int.type}</p>
                                      <span className="text-[10px] font-bold text-surface-500">{format(parseISO(int.date), 'd MMM yyyy', { locale: nl })}</span>
                                    </div>
                                    <p className="text-xs text-surface-500 truncate font-medium">
                                      {customerMachines.find(m => m.id === int.machineId)?.model} — {int.problemDescription}
                                    </p>
                                  </div>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <div className="p-5 border-2 border-dashed border-surface-200 rounded-md text-center">
                               <Wrench className="w-10 h-10 text-surface-300 mx-auto mb-4" />
                               <p className="text-base font-bold text-surface-900">Nog geen interventies</p>
                               <p className="text-sm text-surface-500 mt-1 max-w-xs mx-auto">Er is nog geen onderhoud of reparatie uitgevoerd bij deze klant.</p>
                            </div>
                          )}
                        </motion.div>
                      )}

                      {selectedTab === 'support' && (
                         <motion.div
                           key="tab-support"
                           initial={{ opacity: 0, x: 10 }}
                           animate={{ opacity: 1, x: 0 }}
                           className="space-y-3"
                         >
                           <div className="flex items-center justify-between">
                             <h4 className="text-xs font-bold text-surface-500 uppercase tracking-widest">Support Historie ({customerSupportLogs.length})</h4>
                             <button 
                               onClick={() => navigate('/support-logs', { state: { preSelectedCustomer: selectedCustomer.id } })}
                               className="btn-primary !h-9 !text-[11px] !px-4"
                             >
                                <Plus className="w-3.5 h-3.5" /> Support Loggen
                             </button>
                           </div>

                           {customerSupportLogs.length > 0 ? (
                             <div className="space-y-4">
                               {customerSupportLogs.map(log => (
                                 <div key={log.id} className="p-5 bg-white border border-surface-200 rounded-lg shadow-sm hover:ring-2 hover:ring-blue-100 transition-all group">
                                   <div className="flex items-start justify-between mb-3">
                                      <div className="flex items-center gap-3">
                                         <div className="p-2 bg-brand-50 text-brand-500 rounded-md">
                                            <Headphones className="w-4 h-4" />
                                         </div>
                                         <div>
                                            <p className="text-[10px] font-bold text-surface-400 uppercase">{format(new Date(log.createdAt), 'dd MMM yyyy HH:mm', { locale: nl })}</p>
                                            <p className="text-xs font-bold text-surface-900 line-clamp-1">{log.problem}</p>
                                         </div>
                                      </div>
                                      <span className={cn(
                                        "px-2 py-0.5 rounded-full text-[9px] font-bold uppercase border",
                                        log.status === 'completed' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-amber-50 text-amber-600 border-amber-100'
                                      )}>
                                        {log.status}
                                      </span>
                                   </div>
                                   <div className="bg-surface-50 p-3 rounded-md text-xs text-surface-600 mb-3 line-clamp-2">
                                      {log.solution || 'Geen oplossing geregistreerd...'}
                                   </div>
                                   <div className="flex items-center justify-between text-[10px] text-surface-400 font-bold">
                                      <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {log.duration || 'N/A'}</span>
                                      <span>Technicus: {log.technicianName}</span>
                                   </div>
                                 </div>
                               ))}
                             </div>
                           ) : (
                             <div className="p-5 border-2 border-dashed border-surface-200 rounded-md text-center">
                                <Headphones className="w-10 h-10 text-surface-300 mx-auto mb-4" />
                                <p className="text-base font-bold text-surface-900">Geen support logs</p>
                                <p className="text-sm text-surface-500 mt-1">Er is voor deze klant nog geen remote support geregistreerd.</p>
                             </div>
                           )}
                         </motion.div>
                      )}

                      {/* Other tabs follow similar clean professional scale... */}
                      {selectedTab === 'werkbonnen' && (
                        <motion.div
                          key="tab-werkbonnen"
                          initial={{ opacity: 0, x: 10 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="space-y-4"
                        >
                           {/* Simplified placeholder for brevity, actual logic remains */}
                           <div className="grid grid-cols-1 gap-3">
                             {customerWorkOrders.map(wo => (
                               <div key={wo.id} className="p-4 bg-white border border-surface-200 rounded-md flex items-center justify-between hover:bg-surface-50 transition-colors cursor-pointer group">
                                 <div className="flex items-center gap-4">
                                   <div className="w-10 h-10 bg-surface-100 text-surface-500 rounded-lg flex items-center justify-center">
                                     <FileText className="w-5 h-5" />
                                   </div>
                                   <div>
                                     <p className="text-sm font-bold text-surface-900">Werkbon #{wo.orderNumber}</p>
                                     <p className="text-[11px] text-surface-500 font-medium">{wo.date} · {wo.status}</p>
                                   </div>
                                 </div>
                                 <ExternalLink className="w-4 h-4 text-surface-300 group-hover:text-brand-500 transition-colors" />
                               </div>
                             ))}
                           </div>
                        </motion.div>
                      )}

                      {selectedTab === 'documenten' && (
                         <motion.div
                            key="tab-documenten"
                            initial={{ opacity: 0, x: 10 }}
                            animate={{ opacity: 1, x: 0 }}
                         >
                            <DocumentSection customerId={selectedCustomer.id} />
                         </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
              </div>

              <div className="px-5 py-3 bg-surface-50 border-t border-surface-100 flex items-center justify-between">
                <p className="text-xs font-medium text-surface-500 italic">Laatst bijgewerkt: {new Date(selectedCustomer.updatedAt || '').toLocaleDateString('nl-NL')}</p>
                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => setIsDetailsModalOpen(false)}
                    className="btn-ghost !text-surface-600"
                  >
                    Sluiten
                  </button>
                  <button 
                    onClick={() => {
                        // Action to export or print
                    }}
                    className="btn-secondary h-10"
                  >
                    <Printer className="w-4 h-4" /> Dossier downloaden
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      <ConfirmDialog
        isOpen={isCancelConfirmOpen}
        title="Onopgeslagen Wijzigingen"
        message="Je hebt onopgeslagen wijzigingen. Weet je zeker dat je wilt annuleren? Al je werk gaat verloren."
        onConfirm={closeModal}
        onCancel={() => setIsCancelConfirmOpen(false)}
        variant="danger"
        confirmText="Ja, werk weggooien"
        cancelText="Terug"
      />
    </div>
  );
};

export default Customers;
