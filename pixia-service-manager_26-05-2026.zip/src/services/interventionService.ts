import { 
  collection, 
  query, 
  getDocs, 
  orderBy, 
  deleteDoc, 
  doc, 
  addDoc, 
  updateDoc, 
  getDoc, 
  where, 
  limit,
  Timestamp,
  writeBatch
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { reminderService } from './reminderService';
import { Intervention, AuditLog, WorkOrder, Machine } from '../types';
import { handleFirestoreError, OperationType, calculateNextMaintenanceDate, generateSequenceNumber } from '../lib/utils';
import { logAction } from '../lib/audit';
import { format } from 'date-fns';
import { notificationService } from './notificationService';
import { COLLECTIONS } from '../constants/collections';
import { normalizeText } from '../lib/normalization';

export const interventionService = {
  async getAll() {
    try {
      const q = query(collection(db, COLLECTIONS.INTERVENTIONS), orderBy('date', 'desc'));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Intervention));
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, COLLECTIONS.INTERVENTIONS);
      return [];
    }
  },

  /**
   * Finds potential duplicate interventions
   */
  async findPotentialDuplicates(data: Partial<Intervention>, excludeId?: string): Promise<Intervention[]> {
    try {
      const allInterventions = await this.getAll();
      const normDesc = normalizeText(data.problemDescription);

      return allInterventions.filter(i => {
        if (excludeId && i.id === excludeId) return false;

        const isSameMachine = i.machineId === data.machineId && i.customerId === data.customerId;
        if (!isSameMachine) return false;

        // Rule 1: Open interventions for same machine
        const isOpenMatch = i.status !== 'completed' && i.status !== 'afgerond';
        
        // Rule 2: Identical entries on same date
        const isSameDate = i.date === data.date;
        const isSameType = i.type === data.type;
        const isSameDesc = normDesc && normalizeText(i.problemDescription) === normDesc;

        return isOpenMatch || (isSameDate && isSameType && isSameDesc);
      });
    } catch (err) {
      console.error('Error finding duplicate interventions:', err);
      return [];
    }
  },

  async getById(id: string) {
    try {
      const docSnap = await getDoc(doc(db, COLLECTIONS.INTERVENTIONS, id));
      if (docSnap.exists()) {
        return { id: docSnap.id, ...docSnap.data() } as Intervention;
      }
      return null;
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, `${COLLECTIONS.INTERVENTIONS}/${id}`);
      return null;
    }
  },

  async save(formData: any, selectedIntervention: Intervention | null) {
    const batch = writeBatch(db);
    const now = new Date().toISOString();
    let interventionId = selectedIntervention?.id;

    try {
      const data = {
        ...formData,
        updatedAt: now
      };

      // Remove undefined values since Firestore does not support them
      Object.keys(data).forEach(key => {
        if (data[key] === undefined) {
          delete data[key];
        }
      });

      // 1. Handle Status Change & Stock Reversal
      if (selectedIntervention && formData.status !== selectedIntervention.status) {
        await logAction('Status gewijzigd', 'intervention', selectedIntervention.id, `Van ${selectedIntervention.status} naar ${formData.status}`);
        
        // Notification for technician on status change if assigned
        if (formData.technicianId && formData.technicianId !== selectedIntervention.technicianId) {
           await notificationService.notifyTechnician({
            technicianId: formData.technicianId,
            title: 'Nieuwe Taak Toegewezen',
            message: `Interventie ${formData.interventionNumber} is naar jou overgedragen.`,
            type: 'new_task',
            relatedId: selectedIntervention.id
          });
        }

        // If moving AWAY from completed, reverse stock
        const isCurrentlyCompleted = selectedIntervention.status === 'completed' || selectedIntervention.status === 'afgerond';
        const isNewStatusNotCompleted = formData.status !== 'completed' && formData.status !== 'afgerond';
        
        if (isCurrentlyCompleted && isNewStatusNotCompleted && selectedIntervention.stockProcessed) {
          for (const part of selectedIntervention.partsUsed || []) {
            if (!part.itemId) continue;
            const itemRef = doc(db, COLLECTIONS.INVENTORY, part.itemId);
            const itemDoc = await getDoc(itemRef);
            if (itemDoc.exists()) {
              const currentStock = itemDoc.data().stockCount || 0;
              batch.update(itemRef, {
                stockCount: currentStock + part.quantity,
                updatedAt: now
              });
              
              const mutationRef = doc(collection(db, COLLECTIONS.INVENTORY_MUTATIONS));
              batch.set(mutationRef, {
                itemId: part.itemId,
                type: 'correction',
                quantity: part.quantity,
                interventionId: selectedIntervention.id,
                reason: `Correctie: Interventie status gewijzigd naar ${formData.status}`,
                technicianName: formData.technicianName,
                timestamp: now
              });
            }
          }
          data.stockProcessed = false;
        }
      }

      // 2. Save Intervention
      if (selectedIntervention) {
        const docRef = doc(db, COLLECTIONS.INTERVENTIONS, selectedIntervention.id);
        batch.update(docRef, data);
        await logAction('Interventie aangepast', 'intervention', selectedIntervention.id, `Status: ${data.status}`);
      } else {
        const collRef = collection(db, COLLECTIONS.INTERVENTIONS);
        const docRef = await addDoc(collRef, { ...data, createdAt: now });
        interventionId = docRef.id;
        await logAction('Interventie aangemaakt', 'intervention', interventionId, `Nummer: ${data.interventionNumber}`);

        // Notification Trigger
        if (data.technicianId) {
          await notificationService.notifyTechnician({
            technicianId: data.technicianId,
            title: 'Nieuwe Interventie',
            message: `Je hebt een nieuwe ${data.type} interventie (${data.interventionNumber}) toegewezen gekregen voor ${data.date}.`,
            type: 'new_task',
            relatedId: interventionId
          });
        }
      }

      // 3. Handle Completion Logic (Stock deduction, Machine updates, Reminders)
      const isFinishing = (formData.status === 'completed' || formData.status === 'afgerond') && 
                          (!selectedIntervention || !selectedIntervention.stockProcessed);

      if (isFinishing && interventionId) {
        batch.update(doc(db, COLLECTIONS.INTERVENTIONS, interventionId), { 
          completedAt: now,
          stockProcessed: true 
        });

        // Deduct Stock
        for (const part of formData.partsUsed) {
          if (!part.itemId) continue;
          const itemRef = doc(db, COLLECTIONS.INVENTORY, part.itemId);
          const itemDoc = await getDoc(itemRef);
          if (itemDoc.exists()) {
            const currentStock = itemDoc.data().stockCount || 0;
            batch.update(itemRef, {
              stockCount: currentStock - part.quantity,
              updatedAt: now
            });

            const mutationRef = doc(collection(db, COLLECTIONS.INVENTORY_MUTATIONS));
            batch.set(mutationRef, {
              itemId: part.itemId,
              type: 'intervention',
              quantity: part.quantity,
              interventionId: interventionId,
              reason: `Gebruikt bij interventie (ID: ${interventionId})`,
              technicianName: formData.technicianName,
              timestamp: now
            });
          }
        }

        // Machine updates
        if (formData.machineId) {
          const machineRef = doc(db, COLLECTIONS.MACHINES, formData.machineId);
          const machineSnap = await getDoc(machineRef);
          const machineData = machineSnap.exists() ? machineSnap.data() as Machine : null;

          const machineUpdates: any = { status: 'active' };

          if (formData.type === 'onderhoud' || formData.type === 'maintenance') {
            machineUpdates.lastMaintenanceDate = formData.date;
            
            if (machineData?.autoScheduleEnabled && !formData.nextMaintenanceDate) {
              const calculatedNext = calculateNextMaintenanceDate({
                lastMaintenanceDate: formData.date,
                maintenanceInterval: machineData.maintenanceInterval,
                firstMaintenanceMonths: machineData.firstMaintenanceMonths
              });
              if (calculatedNext) machineUpdates.nextMaintenanceDate = calculatedNext;
            }
          }

          if (formData.nextMaintenanceDate) machineUpdates.nextMaintenanceDate = formData.nextMaintenanceDate;
          batch.update(machineRef, machineUpdates);
        }
      }

      await batch.commit();

      // 4. Smart Reminders (Outside batch because it needs check-then-set logic)
      if (isFinishing && interventionId && formData.machineId) {
        const machineRef = doc(db, COLLECTIONS.MACHINES, formData.machineId);
        const machineSnap = await getDoc(machineRef);
        const machineData = machineSnap.exists() ? machineSnap.data() as Machine : null;

        // Maintenance Reminder
        let targetDueDate = formData.nextMaintenanceDate;
        if (!targetDueDate && (formData.type === 'onderhoud' || formData.type === 'maintenance')) {
             targetDueDate = calculateNextMaintenanceDate({
                lastMaintenanceDate: formData.date,
                maintenanceInterval: machineData?.maintenanceInterval || 'annual',
                firstMaintenanceMonths: machineData?.firstMaintenanceMonths
              });
        }

        if (targetDueDate) {
          await reminderService.upsert({
            title: `Volgend onderhoud: ${machineData?.model || 'Machine'}`,
            description: `Automatisch aangemaakt na interventie op ${formData.date}`,
            customerId: formData.customerId,
            machineId: formData.machineId,
            dueDate: targetDueDate,
            priority: 'normal',
            status: 'open',
            type: 'maintenance'
          });
        }

        if (formData.followUpAction) {
          await reminderService.upsert({
            title: `Follow-up: ${formData.followUpAction}`,
            description: `Gemaakt nav interventie ID: ${interventionId}`,
            customerId: formData.customerId,
            machineId: formData.machineId,
            dueDate: format(new Date(), 'yyyy-MM-dd'),
            priority: 'high',
            status: 'open',
            type: 'follow-up'
          });
        }
      }

      return interventionId;
    } catch (err) {
      handleFirestoreError(err, selectedIntervention ? OperationType.UPDATE : OperationType.CREATE, COLLECTIONS.INTERVENTIONS);
      return null;
    }
  },

  async delete(id: string) {
    try {
      await deleteDoc(doc(db, COLLECTIONS.INTERVENTIONS, id));
      await logAction('Intervention verwijderd', 'intervention', id, '');
      return true;
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `${COLLECTIONS.INTERVENTIONS}/${id}`);
      return false;
    }
  },

  async getLinkedWorkOrder(interventionId: string) {
    try {
      const woQuery = query(
        collection(db, COLLECTIONS.WORK_ORDERS), 
        where('interventionId', '==', interventionId), 
        limit(1)
      );
      const snapshot = await getDocs(woQuery);
      if (!snapshot.empty) {
        return { id: snapshot.docs[0].id, ...snapshot.docs[0].data() } as WorkOrder;
      }
      return null;
    } catch (err) {
      console.error('Error fetching linked work order:', err);
      return null;
    }
  },

  async getLinkedWorkOrders(interventionId: string): Promise<WorkOrder[]> {
    try {
      const q = query(
        collection(db, COLLECTIONS.WORK_ORDERS),
        where('interventionId', '==', interventionId)
      );
      const snapshot = await getDocs(q);
      const orders = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as WorkOrder));
      return orders.sort((a, b) => {
        const nrA = a.visitNumber || 1;
        const nrB = b.visitNumber || 1;
        if (nrA !== nrB) return nrA - nrB;
        const dateA = a.createdAt || '';
        const dateB = b.createdAt || '';
        return dateA.localeCompare(dateB);
      });
    } catch (err) {
      console.error('Error fetching linked work orders:', err);
      return [];
    }
  },

  async getAuditLogs(interventionId: string) {
    try {
      const logsQuery = query(
        collection(db, COLLECTIONS.AUDIT_LOGS), 
        where('entityId', '==', interventionId),
        orderBy('timestamp', 'desc')
      );
      const snapshot = await getDocs(logsQuery);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as AuditLog));
    } catch (err) {
      console.error('Error fetching audit logs:', err);
      return [];
    }
  },

  async createWorkOrderFromIntervention(intervention: Intervention, customer: any, machine: any, formData?: any, isFollowUp = false) {
    try {
      const existingQuery = query(
        collection(db, COLLECTIONS.WORK_ORDERS),
        where('interventionId', '==', intervention.id)
      );
      const existingSnap = await getDocs(existingQuery);
      const visitNumber = existingSnap.size + 1;

      const batch = writeBatch(db);

      // Close all existing open work orders if this is a follow-up
      if (isFollowUp) {
        existingSnap.docs.forEach(docSnap => {
          const data = docSnap.data();
          if (data.status !== 'Afgerond' && data.status !== 'Gefactureerd' && data.status !== 'afgerond' && data.status !== 'gefactureerd' && data.status !== 'completed') {
            batch.update(docSnap.ref, { status: 'Afgerond', updatedAt: new Date().toISOString() });
          }
        });
      }

      const newWorkOrderRef = doc(collection(db, COLLECTIONS.WORK_ORDERS));
      const workOrderData: Omit<WorkOrder, 'id'> = {
        orderNumber: generateSequenceNumber('WB'),
        date: formData?.date || intervention.date || format(new Date(), 'yyyy-MM-dd'),
        customerId: intervention.customerId || '',
        customerLocation: intervention.location || customer?.address || '',
        contactPerson: customer?.contactPerson || '',
        machineId: intervention.machineId || '',
        brand: machine?.brand || '',
        model: machine?.model || '',
        serialNumber: machine?.serialNumber || '',
        interventionId: intervention.id || '',
        interventionNumber: intervention.interventionNumber || formData?.interventionNumber || '',
        technicianName: intervention.technicianName || '',
        type: intervention.type || 'onderhoud',
        // Copy problem desc but skip hours/parts
        workDescription: intervention.problemDescription ? `Probleem: ${intervention.problemDescription}\n\nWerkzaamheden:\n` : '',
        partsUsed: [],
        hoursWorked: 0,
        travelTime: 0,
        notes: intervention.customerNotes || '',
        internalNotes: intervention.internalNotes || '',
        status: 'Concept',
        visitNumber: visitNumber,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      batch.set(newWorkOrderRef, workOrderData);
      
      const newStatus = isFollowUp ? 'Gepland vervolgbezoek' : (intervention.status || 'In behandeling');
      batch.update(doc(db, COLLECTIONS.INTERVENTIONS, intervention.id), {
        status: newStatus,
        workOrderId: newWorkOrderRef.id,
        workOrderCount: visitNumber,
        updatedAt: new Date().toISOString()
      });

      await batch.commit();

      await logAction('Werkbon aangemaakt vanuit interventie', 'work_order', newWorkOrderRef.id, `Nummer: ${workOrderData.orderNumber}`);
      return newWorkOrderRef.id;
    } catch (err) {
      console.error('Error creating work order:', err);
      return null;
    }
  }
};
