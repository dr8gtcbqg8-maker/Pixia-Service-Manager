import { 
  collection, 
  query, 
  getDocs, 
  orderBy, 
  deleteDoc, 
  doc, 
  addDoc, 
  updateDoc, 
  getDoc, 
  where, 
  limit,
  Timestamp,
  writeBatch
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Intervention, AuditLog, WorkOrder, Machine } from '../types';
import { handleFirestoreError, OperationType, calculateNextMaintenanceDate, generateSequenceNumber } from '../lib/utils';
import { logAction } from '../lib/audit';
import { format } from 'date-fns';
import { notificationService } from './notificationService';
import { COLLECTIONS } from '../constants/collections';

export const interventionService = {
  async getAll() {
    try {
      const q = query(collection(db, COLLECTIONS.INTERVENTIONS), orderBy('date', 'desc'));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Intervention));
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, COLLECTIONS.INTERVENTIONS);
      return [];
    }
  },

  async getById(id: string) {
    try {
      const docSnap = await getDoc(doc(db, COLLECTIONS.INTERVENTIONS, id));
      if (docSnap.exists()) {
        return { id: docSnap.id, ...docSnap.data() } as Intervention;
      }
      return null;
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, `${COLLECTIONS.INTERVENTIONS}/${id}`);
      return null;
    }
  },

  async save(formData: any, selectedIntervention: Intervention | null) {
    const batch = writeBatch(db);
    const now = new Date().toISOString();
    let interventionId = selectedIntervention?.id;

    try {
      const data = {
        ...formData,
        updatedAt: now
      };

      // 1. Handle Status Change & Stock Reversal
      if (selectedIntervention && formData.status !== selectedIntervention.status) {
        await logAction('Status gewijzigd', 'intervention', selectedIntervention.id, `Van ${selectedIntervention.status} naar ${formData.status}`);
        
        // Notification for technician on status change if assigned
        if (formData.technicianId && formData.technicianId !== selectedIntervention.technicianId) {
           await notificationService.notifyTechnician({
            technicianId: formData.technicianId,
            title: 'Nieuwe Taak Toegewezen',
            message: `Interventie ${formData.interventionNumber} is naar jou overgedragen.`,
            type: 'new_task',
            relatedId: selectedIntervention.id
          });
        }

        // If moving AWAY from completed, reverse stock
        const isCurrentlyCompleted = selectedIntervention.status === 'completed' || selectedIntervention.status === 'afgerond';
        const isNewStatusNotCompleted = formData.status !== 'completed' && formData.status !== 'afgerond';
        
        if (isCurrentlyCompleted && isNewStatusNotCompleted && selectedIntervention.stockProcessed) {
          for (const part of selectedIntervention.partsUsed || []) {
            if (!part.itemId) continue;
            const itemRef = doc(db, COLLECTIONS.INVENTORY, part.itemId);
            const itemDoc = await getDoc(itemRef);
            if (itemDoc.exists()) {
              const currentStock = itemDoc.data().stockCount || 0;
              batch.update(itemRef, {
                stockCount: currentStock + part.quantity,
                updatedAt: now
              });
              
              const mutationRef = doc(collection(db, COLLECTIONS.INVENTORY_MUTATIONS));
              batch.set(mutationRef, {
                itemId: part.itemId,
                type: 'correction',
                quantity: part.quantity,
                interventionId: selectedIntervention.id,
                reason: `Correctie: Interventie status gewijzigd naar ${formData.status}`,
                technicianName: formData.technicianName,
                timestamp: now
              });
            }
          }
          data.stockProcessed = false;
        }
      }

      // 2. Save Intervention
      if (selectedIntervention) {
        const docRef = doc(db, COLLECTIONS.INTERVENTIONS, selectedIntervention.id);
        batch.update(docRef, data);
        await logAction('Interventie aangepast', 'intervention', selectedIntervention.id, `Status: ${data.status}`);
      } else {
        const collRef = collection(db, COLLECTIONS.INTERVENTIONS);
        const docRef = await addDoc(collRef, { ...data, createdAt: now });
        interventionId = docRef.id;
        await logAction('Interventie aangemaakt', 'intervention', interventionId, `Nummer: ${data.interventionNumber}`);

        // Notification Trigger
        if (data.technicianId) {
          await notificationService.notifyTechnician({
            technicianId: data.technicianId,
            title: 'Nieuwe Interventie',
            message: `Je hebt een nieuwe ${data.type} interventie (${data.interventionNumber}) toegewezen gekregen voor ${data.date}.`,
            type: 'new_task',
            relatedId: interventionId
          });
        }
      }

      // 3. Handle Completion Logic (Stock deduction, Machine updates, Reminders)
      const isFinishing = (formData.status === 'completed' || formData.status === 'afgerond') && 
                          (!selectedIntervention || !selectedIntervention.stockProcessed);

      if (isFinishing && interventionId) {
        batch.update(doc(db, COLLECTIONS.INTERVENTIONS, interventionId), { 
          completedAt: now,
          stockProcessed: true 
        });

        // Deduct Stock
        for (const part of formData.partsUsed) {
          if (!part.itemId) continue;
          const itemRef = doc(db, COLLECTIONS.INVENTORY, part.itemId);
          const itemDoc = await getDoc(itemRef);
          if (itemDoc.exists()) {
            const currentStock = itemDoc.data().stockCount || 0;
            batch.update(itemRef, {
              stockCount: currentStock - part.quantity,
              updatedAt: now
            });

            const mutationRef = doc(collection(db, COLLECTIONS.INVENTORY_MUTATIONS));
            batch.set(mutationRef, {
              itemId: part.itemId,
              type: 'intervention',
              quantity: part.quantity,
              interventionId: interventionId,
              reason: `Gebruikt bij interventie (ID: ${interventionId})`,
              technicianName: formData.technicianName,
              timestamp: now
            });
          }
        }

        // Machine & Reminders
        if (formData.machineId) {
          const machineRef = doc(db, COLLECTIONS.MACHINES, formData.machineId);
          const machineSnap = await getDoc(machineRef);
          const machineData = machineSnap.exists() ? machineSnap.data() as Machine : null;

          const machineUpdates: any = { status: 'active' };

          if (formData.type === 'onderhoud' || formData.type === 'maintenance') {
            machineUpdates.lastMaintenanceDate = formData.date;
            
            if (machineData?.autoScheduleEnabled && !formData.nextMaintenanceDate) {
              const calculatedNext = calculateNextMaintenanceDate({
                lastMaintenanceDate: formData.date,
                maintenanceInterval: machineData.maintenanceInterval,
                firstMaintenanceMonths: machineData.firstMaintenanceMonths
              });
              if (calculatedNext) machineUpdates.nextMaintenanceDate = calculatedNext;
            }
          }

          if (formData.nextMaintenanceDate) machineUpdates.nextMaintenanceDate = formData.nextMaintenanceDate;
          batch.update(machineRef, machineUpdates);

          if (machineUpdates.nextMaintenanceDate) {
            const reminderRef = doc(collection(db, COLLECTIONS.REMINDERS));
            batch.set(reminderRef, {
              title: `Volgend onderhoud: ${machineData?.model || 'Machine'}`,
              description: `Automatisch aangemaakt na interventie op ${formData.date}`,
              customerId: formData.customerId,
              machineId: formData.machineId,
              dueDate: machineUpdates.nextMaintenanceDate,
              priority: 'normal',
              status: 'open',
              type: 'maintenance',
              createdAt: now
            });
          }
        }

        if (formData.followUpAction) {
          const reminderRef = doc(collection(db, COLLECTIONS.REMINDERS));
          batch.set(reminderRef, {
            title: `Follow-up: ${formData.followUpAction}`,
            description: `Gemaakt nav interventie ID: ${interventionId}`,
            customerId: formData.customerId,
            machineId: formData.machineId,
            dueDate: format(new Date(), 'yyyy-MM-dd'),
            priority: 'high',
            status: 'open',
            type: 'follow-up',
            createdAt: now
          });
        }
      }

      await batch.commit();
      return interventionId;
    } catch (err) {
      handleFirestoreError(err, selectedIntervention ? OperationType.UPDATE : OperationType.CREATE, COLLECTIONS.INTERVENTIONS);
      return null;
    }
  },

  async delete(id: string) {
    try {
      await deleteDoc(doc(db, COLLECTIONS.INTERVENTIONS, id));
      await logAction('Intervention verwijderd', 'intervention', id, '');
      return true;
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `${COLLECTIONS.INTERVENTIONS}/${id}`);
      return false;
    }
  },

  async getLinkedWorkOrder(interventionId: string) {
    try {
      const woQuery = query(
        collection(db, COLLECTIONS.WORK_ORDERS), 
        where('interventionId', '==', interventionId), 
        limit(1)
      );
      const snapshot = await getDocs(woQuery);
      if (!snapshot.empty) {
        return { id: snapshot.docs[0].id, ...snapshot.docs[0].data() } as WorkOrder;
      }
      return null;
    } catch (err) {
      console.error('Error fetching linked work order:', err);
      return null;
    }
  },

  async getAuditLogs(interventionId: string) {
    try {
      const logsQuery = query(
        collection(db, COLLECTIONS.AUDIT_LOGS), 
        where('entityId', '==', interventionId),
        orderBy('timestamp', 'desc')
      );
      const snapshot = await getDocs(logsQuery);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as AuditLog));
    } catch (err) {
      console.error('Error fetching audit logs:', err);
      return [];
    }
  },

  async createWorkOrderFromIntervention(intervention: Intervention, customer: any, machine: any, formData: any) {
    try {
      const workOrderData: Omit<WorkOrder, 'id'> = {
        orderNumber: generateSequenceNumber('WB'),
        date: intervention.date || format(new Date(), 'yyyy-MM-dd'),
        customerId: intervention.customerId || '',
        customerLocation: intervention.location || customer?.address || '',
        contactPerson: customer?.contactPerson || '',
        machineId: intervention.machineId || '',
        brand: machine?.brand || '',
        model: machine?.model || '',
        serialNumber: machine?.serialNumber || '',
        interventionId: intervention.id || '',
        interventionNumber: intervention.interventionNumber || formData.interventionNumber || '',
        technicianName: intervention.technicianName || '',
        type: intervention.type || 'onderhoud',
        workDescription: intervention.workPerformed || (intervention.problemDescription ? `Probleem: ${intervention.problemDescription}\n\nWerkzaamheden:\n` : ''),
        partsUsed: intervention.partsUsed || [],
        hoursWorked: intervention.hoursWorked || 0,
        travelTime: intervention.travelTime || 0,
        notes: intervention.customerNotes || '',
        internalNotes: intervention.internalNotes || '',
        status: 'concept',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      const docRef = await addDoc(collection(db, COLLECTIONS.WORK_ORDERS), workOrderData);
      await updateDoc(doc(db, COLLECTIONS.INTERVENTIONS, intervention.id), {
        workOrderId: docRef.id
      });

      await logAction('Werkbon aangemaakt vanuit interventie', 'work_order', docRef.id, `Nummer: ${workOrderData.orderNumber}`);
      return docRef.id;
    } catch (err) {
      console.error('Error creating work order:', err);
      return null;
    }
  }
};
