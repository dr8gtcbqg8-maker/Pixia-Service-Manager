import React from 'react';
import { motion } from 'motion/react';
import { Wrench, ClipboardList, Package, Bell } from 'lucide-react';
import { LucideIcon } from 'lucide-react';
import { cn } from '../../lib/utils';
import { Link } from 'react-router-dom';

interface StatProps {
  label: string;
  value: number;
  icon: LucideIcon;
  color: string;
  bg: string;
  trend?: string;
  up?: boolean;
  to?: string;
}

const StatCard: React.FC<StatProps & { index: number }> = ({ label, value, icon: Icon, color, bg, index, to }) => {
  const content = (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      className={cn(
        "bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all group",
        to && "cursor-pointer"
      )}
    >
      <div className="flex items-center gap-4">
        <div className={cn("p-3 rounded-xl shrink-0 transition-transform group-hover:scale-105", bg, color)}>
          <Icon className="w-6 h-6" />
        </div>
        <div>
          <p className="text-sm font-medium text-slate-500 mb-0.5">{label}</p>
          <p className="text-2xl font-bold text-slate-900 tracking-tight">{value}</p>
        </div>
      </div>
    </motion.div>
  );

  if (to) {
    return <Link to={to}>{content}</Link>;
  }

  return content;
};

interface DashboardStatsProps {
  totalInterventions: number;
  closedInterventions: number;
  lowStockCount: number;
  openReminders: number;
}

const DashboardStats: React.FC<DashboardStatsProps> = ({ 
  totalInterventions, 
  closedInterventions, 
  lowStockCount, 
  openReminders 
}) => {
  const stats = [
    { label: 'Open Interventies', value: totalInterventions - closedInterventions, icon: Wrench, color: 'text-blue-600', bg: 'bg-blue-50', to: '/interventions' },
    { label: 'Vandaag Afgerond', value: closedInterventions, icon: ClipboardList, color: 'text-emerald-600', bg: 'bg-emerald-50', to: '/interventions' },
    { label: 'Lage Voorraad', value: lowStockCount, icon: Package, color: 'text-rose-600', bg: 'bg-rose-50', to: '/inventory' },
    { label: 'Opstaande Taken', value: openReminders, icon: Bell, color: 'text-amber-600', bg: 'bg-amber-50', to: '/actions' },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat, i) => (
        <StatCard key={stat.label} {...stat} index={i} />
      ))}
    </div>
  );
};

export default DashboardStats;
