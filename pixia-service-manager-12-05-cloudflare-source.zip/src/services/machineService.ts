import { collection, getDocs, query, orderBy, doc, getDoc, where, updateDoc, addDoc, deleteDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Machine, Intervention, WorkOrder } from '../types';
import { handleFirestoreError, OperationType } from '../lib/utils';
import { logAction } from '../lib/audit';
import { COLLECTIONS } from '../constants/collections';

export const machineService = {
  async getAll() {
    try {
      const q = query(collection(db, COLLECTIONS.MACHINES), orderBy('brand', 'asc'));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Machine));
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, COLLECTIONS.MACHINES);
      return [];
    }
  },

  async getByCustomerId(customerId: string) {
    try {
      const q = query(collection(db, COLLECTIONS.MACHINES), where('customerId', '==', customerId));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Machine));
    } catch (err) {
      console.error('Error fetching machines for customer:', err);
      return [];
    }
  },

  async getById(id: string) {
    try {
      const docSnap = await getDoc(doc(db, COLLECTIONS.MACHINES, id));
      if (docSnap.exists()) {
        return { id: docSnap.id, ...docSnap.data() } as Machine;
      }
      return null;
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, `${COLLECTIONS.MACHINES}/${id}`);
      return null;
    }
  },

  async save(machineData: any, selectedMachine: Machine | null) {
    try {
      let machineId = selectedMachine?.id;
      const data = {
        ...machineData,
        updatedAt: new Date().toISOString()
      };

      if (selectedMachine) {
        const docRef = doc(db, COLLECTIONS.MACHINES, selectedMachine.id);
        await updateDoc(docRef, data);
        await logAction('Machine aangepast', 'machine', selectedMachine.id, `Model: ${data.brand} ${data.model}`);
      } else {
        const docRef = await addDoc(collection(db, COLLECTIONS.MACHINES), {
          ...data,
          createdAt: new Date().toISOString(),
        });
        machineId = docRef.id;
        await logAction('Machine aangemaakt', 'machine', machineId, `Model: ${data.brand} ${data.model}`);
      }

      // Handle auto-scheduling reminders
      if (data.autoScheduleEnabled && data.nextMaintenanceDate) {
        const dateChanged = !selectedMachine || data.nextMaintenanceDate !== selectedMachine.nextMaintenanceDate;
        if (dateChanged) {
          const reminderQuery = query(
            collection(db, COLLECTIONS.REMINDERS), 
            where('machineId', '==', machineId),
            where('type', '==', 'maintenance'),
            where('status', '==', 'open')
          );
          const rSnap = await getDocs(reminderQuery);
          
          if (rSnap.empty) {
            await addDoc(collection(db, COLLECTIONS.REMINDERS), {
              title: `Autom. Onderhoud: ${data.brand} ${data.model}`,
              description: `Gepland periodiek onderhoud voor machine met serienummer ${data.serialNumber}`,
              customerId: data.customerId,
              machineId: machineId,
              dueDate: data.nextMaintenanceDate,
              priority: 'normal',
              status: 'open',
              type: 'maintenance',
              createdAt: new Date().toISOString()
            });
          } else {
            const existingReminderId = rSnap.docs[0].id;
            await updateDoc(doc(db, COLLECTIONS.REMINDERS, existingReminderId), {
              dueDate: data.nextMaintenanceDate,
              updatedAt: new Date().toISOString()
            });
          }
        }
      }

      return machineId;
    } catch (err) {
      handleFirestoreError(err, selectedMachine ? OperationType.UPDATE : OperationType.CREATE, `${COLLECTIONS.MACHINES}/${selectedMachine?.id || 'new'}`);
      return null;
    }
  },

  async delete(id: string) {
    try {
      await deleteDoc(doc(db, COLLECTIONS.MACHINES, id));
      await logAction('Machine verwijderd', 'machine', id);
      return true;
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `${COLLECTIONS.MACHINES}/${id}`);
      return false;
    }
  },

  async getRelatedData(machineId: string) {
    try {
      const [iSnap, wSnap] = await Promise.all([
        getDocs(query(collection(db, COLLECTIONS.INTERVENTIONS), where('machineId', '==', machineId), orderBy('date', 'desc'))),
        getDocs(query(collection(db, COLLECTIONS.WORK_ORDERS), where('machineId', '==', machineId), orderBy('createdAt', 'desc')))
      ]);

      return {
        interventions: iSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Intervention)),
        workOrders: wSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as WorkOrder))
      };
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'related-machine-data');
      return { interventions: [], workOrders: [] };
    }
  }
};
