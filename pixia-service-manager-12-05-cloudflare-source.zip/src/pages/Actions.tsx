import React, { useEffect, useState } from 'react';
import { collection, query, getDocs, orderBy, updateDoc, doc, where, deleteDoc, addDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { SmartAlert, AlertStatus, AlertPriority, Reminder, Customer, Machine, ReminderPriority, ReminderType } from '../types';
import { 
  Bell, CheckCircle, Eye, Trash2, Package, Wrench, 
  ShieldAlert, Activity, AlertTriangle, ChevronRight,
  Filter, Search, X, Plus, Calendar, CheckCircle2, Phone, Edit3, User, Printer, Clock
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format } from 'date-fns';
import { nl } from 'date-fns/locale';
import { handleFirestoreError, OperationType, cn } from '../lib/utils';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { COLLECTIONS } from '../constants/collections';
import ConfirmDialog from '../components/ConfirmDialog';
import AppointmentModal from '../components/AppointmentModal';

const Actions: React.FC = () => {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'alerts' | 'reminders'>('alerts');
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  // Alerts states
  const [alerts, setAlerts] = useState<SmartAlert[]>([]);
  const [alertsFilter, setAlertsFilter] = useState<AlertStatus | 'all'>('all');

  // Reminders states
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [machines, setMachines] = useState<Machine[]>([]);
  const [remindersFilterStatus, setRemindersFilterStatus] = useState('');
  
  // Modal states
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedReminder, setSelectedReminder] = useState<Reminder | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<{ isOpen: boolean; id: string | null; type: 'alert' | 'reminder' }>({ 
    isOpen: false, 
    id: null, 
    type: 'alert' 
  });
  const [isAppointmentModalOpen, setIsAppointmentModalOpen] = useState(false);
  const [appointmentInitialData, setAppointmentInitialData] = useState<any>({});

  const [newReminder, setNewReminder] = useState({
    title: '',
    description: '',
    customerId: '',
    machineId: '',
    dueDate: format(new Date(), 'yyyy-MM-dd'),
    priority: 'normal' as ReminderPriority,
    status: 'open' as Reminder['status'],
    type: 'other' as ReminderType,
    internalNotes: ''
  });

  const fetchData = async () => {
    setLoading(true);
    try {
      const [aSnap, rSnap, cSnap, mSnap] = await Promise.all([
        getDocs(query(collection(db, 'smart_alerts'), orderBy('createdAt', 'desc'))),
        getDocs(query(collection(db, COLLECTIONS.REMINDERS), orderBy('dueDate', 'asc'))),
        getDocs(collection(db, COLLECTIONS.CUSTOMERS)),
        getDocs(collection(db, COLLECTIONS.MACHINES))
      ]);
      
      setAlerts(aSnap.docs.map(d => ({ id: d.id, ...d.data() } as SmartAlert)));
      setReminders(rSnap.docs.map(d => ({ id: d.id, ...d.data() } as Reminder)));
      setCustomers(cSnap.docs.map(d => ({ id: d.id, ...d.data() } as Customer)));
      setMachines(mSnap.docs.map(d => ({ id: d.id, ...d.data() } as Machine)));
    } catch (err) {
      console.error('Error fetching data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Alert Actions
  const handleUpdateAlertStatus = async (id: string, status: AlertStatus) => {
    try {
      await updateDoc(doc(db, 'smart_alerts', id), {
        status,
        updatedAt: new Date().toISOString()
      });
      setAlerts(prev => prev.map(a => a.id === id ? { ...a, status, updatedAt: new Date().toISOString() } : a));
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `smart_alerts/${id}`);
    }
  };

  const deleteAlert = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'smart_alerts', id));
      setAlerts(prev => prev.filter(a => a.id !== id));
      setDeleteConfirm({ isOpen: false, id: null, type: 'alert' });
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `smart_alerts/${id}`);
    }
  };

  // Reminder Actions
  const handleSaveReminder = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const reminderData = {
        ...newReminder,
        updatedAt: new Date().toISOString()
      };

      if (selectedReminder) {
        await updateDoc(doc(db, COLLECTIONS.REMINDERS, selectedReminder.id), reminderData);
      } else {
        await addDoc(collection(db, COLLECTIONS.REMINDERS), {
          ...reminderData,
          createdAt: new Date().toISOString()
        });
      }
      setIsAddModalOpen(false);
      fetchData();
    } catch (err) {
      handleFirestoreError(err, selectedReminder ? OperationType.UPDATE : OperationType.CREATE, COLLECTIONS.REMINDERS);
    }
  };

  const handleUpdateReminderStatus = async (id: string, status: Reminder['status']) => {
    try {
      await updateDoc(doc(db, COLLECTIONS.REMINDERS, id), { status, updatedAt: new Date().toISOString() });
      fetchData();
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `${COLLECTIONS.REMINDERS}/${id}`);
    }
  };

  const deleteReminder = async (id: string) => {
    try {
      await deleteDoc(doc(db, COLLECTIONS.REMINDERS, id));
      setReminders(prev => prev.filter(r => r.id !== id));
      setDeleteConfirm({ isOpen: false, id: null, type: 'reminder' });
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `${COLLECTIONS.REMINDERS}/${id}`);
    }
  };

  const handleConfirmDelete = () => {
    if (!deleteConfirm.id) return;
    if (deleteConfirm.type === 'alert') {
      deleteAlert(deleteConfirm.id);
    } else {
      deleteReminder(deleteConfirm.id);
    }
  };

  // UI Helpers
  const getAlertPriorityColor = (priority: AlertPriority) => {
    switch (priority) {
      case 'urgent': return 'bg-rose-500 text-white';
      case 'high': return 'bg-amber-500 text-white';
      case 'normal': return 'bg-blue-500 text-white';
      case 'low': return 'bg-slate-400 text-white';
      default: return 'bg-slate-500 text-white';
    }
  };

  const getReminderPriorityColor = (priority: ReminderPriority) => {
    switch (priority) {
      case 'urgent': return 'bg-red-500 text-white';
      case 'high': return 'bg-amber-500 text-white';
      case 'normal': return 'bg-blue-500 text-white';
      case 'low': return 'bg-slate-400 text-white';
      default: return 'bg-slate-500 text-white';
    }
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'stock': return <Package className="w-5 h-5" />;
      case 'maintenance': return <Wrench className="w-5 h-5" />;
      case 'warranty': return <ShieldAlert className="w-5 h-5" />;
      case 'failure': return <AlertTriangle className="w-5 h-5" />;
      case 'inactivity': return <Activity className="w-5 h-5" />;
      default: return <Bell className="w-5 h-5" />;
    }
  };

  const getReminderIcon = (type: ReminderType) => {
    switch (type) {
      case 'maintenance': return <Wrench className="w-4 h-4" />;
      case 'warranty': return <ShieldAlert className="w-4 h-4" />;
      case 'contract': return <ShieldAlert className="w-4 h-4" />;
      case 'call': return <Phone className="w-4 h-4" />;
      case 'follow-up': return <ChevronRight className="w-4 h-4" />;
      case 'stock': return <Package className="w-4 h-4" />;
      default: return <Bell className="w-4 h-4" />;
    }
  };

  const getCustomerName = (id?: string) => customers.find(c => c.id === id)?.name || 'Geen klant';
  const getMachineInfo = (id?: string) => {
    const m = machines.find(mac => mac.id === id);
    return m ? `${m.brand} ${m.model}` : 'Geen machine';
  };

  // Filtered Lists
  const filteredAlerts = alerts.filter(a => {
    const matchesFilter = alertsFilter === 'all' || a.status === alertsFilter;
    const matchesSearch = a.title.toLowerCase().includes(search.toLowerCase()) || 
                          a.description.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const filteredReminders = reminders.filter(r => {
    const matchesSearch = 
      (r.title || '').toLowerCase().includes(search.toLowerCase()) || 
      (r.description || '').toLowerCase().includes(search.toLowerCase()) ||
      getCustomerName(r.customerId).toLowerCase().includes(search.toLowerCase());
    const matchesStatus = !remindersFilterStatus || r.status === remindersFilterStatus;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-8 pb-20">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight italic flex items-center gap-4">
            Acties
            <Bell className="w-8 h-8 text-blue-600" />
          </h1>
          <p className="text-slate-500 font-medium italic text-sm mt-1">Wat vraagt vandaag je aandacht?</p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text"
              placeholder="Zoeken..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-11 pr-4 py-3 bg-white border border-slate-200 rounded-2xl text-xs font-bold outline-none focus:ring-4 focus:ring-blue-100 transition-all w-64 shadow-sm"
            />
          </div>
          {activeTab === 'reminders' && (
            <button 
              onClick={() => {
                setSelectedReminder(null);
                setNewReminder({
                  title: '',
                  description: '',
                  customerId: '',
                  machineId: '',
                  dueDate: format(new Date(), 'yyyy-MM-dd'),
                  priority: 'normal',
                  status: 'open',
                  type: 'other',
                  internalNotes: ''
                });
                setIsAddModalOpen(true);
              }}
              className="bg-blue-600 text-white px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-xl shadow-blue-100 flex items-center gap-2 hover:bg-blue-700 transition-all active:scale-95"
            >
              <Plus className="w-5 h-5" />
              Nieuw
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 p-1.5 bg-slate-100 rounded-[2rem] w-fit shadow-inner">
        <button
          onClick={() => setActiveTab('alerts')}
          className={cn(
            "px-8 py-3 rounded-[1.5rem] text-xs font-black uppercase tracking-[0.2em] transition-all flex items-center gap-2",
            activeTab === 'alerts' ? "bg-white text-blue-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
          )}
        >
          Systeem Meldingen
          {alerts.filter(a => a.status === 'open').length > 0 && (
            <span className="w-5 h-5 bg-blue-600 text-white text-[10px] rounded-full flex items-center justify-center font-bold">
              {alerts.filter(a => a.status === 'open').length}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('reminders')}
          className={cn(
            "px-8 py-3 rounded-[1.5rem] text-xs font-black uppercase tracking-[0.2em] transition-all flex items-center gap-2",
            activeTab === 'reminders' ? "bg-white text-blue-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
          )}
        >
          Herinneringen
          {reminders.filter(r => r.status === 'open').length > 0 && (
            <span className="w-5 h-5 bg-blue-600 text-white text-[10px] rounded-full flex items-center justify-center font-bold">
              {reminders.filter(r => r.status === 'open').length}
            </span>
          )}
        </button>
      </div>

      {/* Content Area */}
      <div className="grid grid-cols-1 gap-6">
        {loading ? (
          <div className="flex items-center justify-center p-20">
            <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600"></div>
          </div>
        ) : (
          <AnimatePresence mode="wait">
            {activeTab === 'alerts' ? (
              <motion.div
                key="alerts-view"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-4"
              >
                {/* Alerts Filters */}
                <div className="flex gap-2">
                  {(['all', 'open', 'resolved'] as const).map((f) => (
                    <button
                      key={f}
                      onClick={() => setAlertsFilter(f)}
                      className={cn(
                        "px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border",
                        alertsFilter === f 
                          ? "bg-white border-blue-200 text-blue-600 shadow-sm" 
                          : "bg-slate-50 border-slate-100 text-slate-500 hover:text-slate-700"
                      )}
                    >
                      {f === 'all' ? 'Alle' : f === 'open' ? 'Open' : 'Opgelost'}
                    </button>
                  ))}
                </div>

                <div className="grid grid-cols-1 gap-4">
                  {filteredAlerts.length > 0 ? (
                    filteredAlerts.map((alert) => (
                      <div
                        key={alert.id}
                        className={cn(
                          "bg-white border rounded-[2rem] p-6 shadow-sm hover:shadow-xl hover:shadow-slate-100 transition-all group flex flex-col md:flex-row items-stretch md:items-center gap-6",
                          alert.status === 'open' ? "border-slate-200" : "border-slate-100 opacity-60"
                        )}
                      >
                        <div className={cn(
                          "w-12 h-12 md:w-14 md:h-14 rounded-2xl flex items-center justify-center shrink-0 shadow-lg",
                          getAlertPriorityColor(alert.priority)
                        )}>
                          {getAlertIcon(alert.type)}
                        </div>

                        <div className="flex-1 space-y-1 min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <h3 className="text-base md:text-lg font-black text-slate-900 leading-tight truncate">{alert.title}</h3>
                            <span className={cn(
                              "text-[8px] md:text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded-lg border",
                              alert.status === 'open' ? "bg-blue-50 text-blue-600 border-blue-100" : "bg-slate-50 text-slate-400 border-slate-100"
                            )}>
                              {alert.status}
                            </span>
                          </div>
                          <p className="text-xs md:text-sm font-medium text-slate-500 leading-relaxed max-w-2xl">{alert.description}</p>
                          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest pt-1">
                            {format(new Date(alert.createdAt), 'dd MMM yyyy HH:mm', { locale: nl })}
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          {alert.status === 'open' && (
                            <>
                              <button
                                onClick={() => handleUpdateAlertStatus(alert.id, 'seen')}
                                className="p-3 bg-slate-50 text-slate-400 hover:text-blue-600 hover:bg-white hover:border-slate-200 border border-transparent hover:shadow-md rounded-xl transition-all"
                                title="Markeren als gezien"
                              >
                                <Eye className="w-5 h-5" />
                              </button>
                              <button
                                onClick={() => handleUpdateAlertStatus(alert.id, 'resolved')}
                                className="p-3 bg-slate-50 text-slate-400 hover:text-green-600 hover:bg-white hover:border-slate-200 border border-transparent hover:shadow-md rounded-xl transition-all"
                                title="Markeren als opgelost"
                              >
                                <CheckCircle className="w-5 h-5" />
                              </button>
                            </>
                          )}
                          <button
                            onClick={() => setDeleteConfirm({ isOpen: true, id: alert.id, type: 'alert' })}
                            className="p-3 bg-slate-50 text-slate-400 hover:text-red-500 hover:bg-white hover:border-slate-200 border border-transparent hover:shadow-md rounded-xl transition-all"
                            title="Verwijderen"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="bg-white border border-dashed border-slate-200 rounded-[2.5rem] p-20 flex flex-col items-center justify-center text-center">
                      <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-200 mb-4">
                        <Bell className="w-8 h-8" />
                      </div>
                      <h3 className="text-lg font-black text-slate-900">Geen meldingen</h3>
                      <p className="text-slate-400 font-medium text-sm">Alles loopt op rolletjes!</p>
                    </div>
                  )}
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="reminders-view"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-4"
              >
                {/* Reminders Filters */}
                <div className="flex gap-2">
                  {(['all', 'open', 'planned', 'executed'] as const).map((s) => (
                    <button
                      key={s}
                      onClick={() => setRemindersFilterStatus(s === 'all' ? '' : s)}
                      className={cn(
                        "px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border",
                        (remindersFilterStatus === s || (s === 'all' && !remindersFilterStatus))
                          ? "bg-white border-blue-200 text-blue-600 shadow-sm" 
                          : "bg-slate-50 border-slate-100 text-slate-500 hover:text-slate-700"
                      )}
                    >
                      {s === 'all' ? 'Alle' : s.charAt(0).toUpperCase() + s.slice(1)}
                    </button>
                  ))}
                </div>

                <div className="grid grid-cols-1 gap-4">
                  {filteredReminders.length > 0 ? (
                    filteredReminders.map((reminder) => (
                      <div
                        key={reminder.id}
                        onClick={() => {
                          setSelectedReminder(reminder);
                          setNewReminder({
                            title: reminder.title,
                            description: reminder.description,
                            customerId: reminder.customerId || '',
                            machineId: reminder.machineId || '',
                            dueDate: reminder.dueDate,
                            priority: reminder.priority,
                            status: reminder.status,
                            type: reminder.type,
                            internalNotes: reminder.internalNotes || ''
                          });
                          setIsAddModalOpen(true);
                        }}
                        className={cn(
                          "bg-white border rounded-[2rem] p-6 shadow-sm hover:shadow-xl hover:shadow-slate-100 transition-all group flex flex-col md:flex-row items-stretch md:items-center gap-6 cursor-pointer",
                          reminder.status === 'open' ? "border-slate-200" : "border-slate-100 opacity-60"
                        )}
                      >
                        <div className={cn(
                          "w-12 h-12 md:w-14 md:h-14 rounded-2xl flex items-center justify-center shrink-0 shadow-lg",
                          getReminderPriorityColor(reminder.priority)
                        )}>
                          {getReminderIcon(reminder.type)}
                        </div>

                        <div className="flex-1 space-y-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <h3 className="text-base font-black text-slate-900 truncate">{reminder.title}</h3>
                            <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest">
                              {reminder.dueDate}
                            </span>
                          </div>
                          <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
                             <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-500">
                               <User className="w-3.5 h-3.5" />
                               {getCustomerName(reminder.customerId)}
                             </div>
                             <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-400">
                               <Printer className="w-3.5 h-3.5" />
                               {getMachineInfo(reminder.machineId)}
                             </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                          {reminder.status === 'open' && (
                            <>
                              <button 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setAppointmentInitialData({
                                    date: reminder.dueDate,
                                    reminderId: reminder.id,
                                    customerId: reminder.customerId,
                                    machineId: reminder.machineId,
                                    title: reminder.title
                                  });
                                  setIsAppointmentModalOpen(true);
                                }}
                                className="p-3 bg-slate-50 text-slate-400 hover:text-indigo-600 hover:bg-white hover:border-slate-200 border border-transparent shadow-sm rounded-xl transition-all"
                                title="Plan Afspraak"
                              >
                                <Calendar className="w-5 h-5" />
                              </button>
                              <button 
                                onClick={(e) => { e.stopPropagation(); handleUpdateReminderStatus(reminder.id, 'executed'); }}
                                className="p-3 bg-slate-50 text-slate-400 hover:text-green-600 hover:bg-white hover:border-slate-200 border border-transparent shadow-sm rounded-xl transition-all"
                                title="Voltooien"
                              >
                                <CheckCircle2 className="w-5 h-5" />
                              </button>
                            </>
                          )}
                          <button 
                            onClick={(e) => { e.stopPropagation(); setDeleteConfirm({ isOpen: true, id: reminder.id, type: 'reminder' }); }}
                            className="p-3 bg-slate-50 text-slate-400 hover:text-red-500 hover:bg-white hover:border-slate-200 border border-transparent shadow-sm rounded-xl transition-all"
                            title="Verwijderen"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="bg-white border border-dashed border-slate-200 rounded-[2.5rem] p-20 flex flex-col items-center justify-center text-center">
                      <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-200 mb-4">
                        <Clock className="w-8 h-8" />
                      </div>
                      <h3 className="text-lg font-black text-slate-900">Geen herinneringen</h3>
                      <p className="text-slate-400 font-medium text-sm">Plan een actie in om te beginnen.</p>
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        )}
      </div>

      {/* Add/Edit Reminder Modal */}
      <AnimatePresence>
        {isAddModalOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center p-4"
          >
            <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setIsAddModalOpen(false)} />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-2xl rounded-3xl shadow-2xl p-8 overflow-y-auto max-h-[90vh]"
            >
              <h2 className="text-xl font-black text-slate-900 mb-8 border-b border-slate-100 pb-6 flex items-center gap-3 italic">
                <Bell className="w-6 h-6 text-blue-600" />
                {selectedReminder ? 'Herinnering Bewerken' : 'Nieuwe Herinnering'}
              </h2>
              <form onSubmit={handleSaveReminder} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="md:col-span-2 space-y-1">
                    <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">Titel *</label>
                    <input 
                      required 
                      type="text" 
                      placeholder="bijv. Klant bellen voor afspraak"
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-sm focus:ring-2 focus:ring-blue-500 outline-none" 
                      value={newReminder.title}
                      onChange={(e) => setNewReminder({...newReminder, title: e.target.value})}
                    />
                  </div>

                  <div className="md:col-span-2 space-y-1">
                    <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">Omschrijving</label>
                    <textarea 
                      rows={3}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-sm focus:ring-2 focus:ring-blue-500 outline-none resize-none" 
                      value={newReminder.description}
                      onChange={(e) => setNewReminder({...newReminder, description: e.target.value})}
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">Klant</label>
                    <select 
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                      value={newReminder.customerId}
                      onChange={(e) => setNewReminder({...newReminder, customerId: e.target.value})}
                    >
                      <option value="">Koppel aan klant...</option>
                      {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">Machine</label>
                    <select 
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                      value={newReminder.machineId}
                      onChange={(e) => setNewReminder({...newReminder, machineId: e.target.value})}
                    >
                      <option value="">Koppel aan machine...</option>
                      {machines.filter(m => !newReminder.customerId || m.customerId === newReminder.customerId).map(m => (
                        <option key={m.id} value={m.id}>{m.brand} {m.model} ({m.serialNumber})</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">Datum</label>
                    <input 
                      type="date" 
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-sm focus:ring-2 focus:ring-blue-500 outline-none" 
                      value={newReminder.dueDate}
                      onChange={(e) => setNewReminder({...newReminder, dueDate: e.target.value})}
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">Prioriteit</label>
                    <select 
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                      value={newReminder.priority}
                      onChange={(e) => setNewReminder({...newReminder, priority: e.target.value as ReminderPriority})}
                    >
                      <option value="low">Laag</option>
                      <option value="normal">Normaal</option>
                      <option value="high">Hoog</option>
                      <option value="urgent">Urgent / Nu</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">Type Herinnering</label>
                    <select 
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                      value={newReminder.type}
                      onChange={(e) => setNewReminder({...newReminder, type: e.target.value as ReminderType})}
                    >
                      <option value="maintenance">Onderhoud</option>
                      <option value="warranty">Garantie</option>
                      <option value="contract">Onderhoudscontract</option>
                      <option value="call">Afspraak / Tel.</option>
                      <option value="follow-up">Follow-up</option>
                      <option value="stock">Voorraad</option>
                      <option value="other">Overig</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                     <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">Status</label>
                     <select 
                       className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                       value={newReminder.status}
                       onChange={(e) => setNewReminder({...newReminder, status: e.target.value as Reminder['status']})}
                     >
                       <option value="open">Open</option>
                       <option value="planned">Ingepland</option>
                       <option value="executed">Voltooid</option>
                       <option value="ignored">Genegeerd</option>
                     </select>
                  </div>
                </div>

                <div className="flex items-center gap-4 pt-8 shrink-0">
                  <button 
                    type="button" 
                    onClick={() => setIsAddModalOpen(false)}
                    className="flex-1 py-4 text-slate-600 font-black text-xs uppercase tracking-[0.2em] hover:bg-slate-50 rounded-2xl transition-all"
                  >
                    Annuleren
                  </button>
                  <button 
                    type="submit" 
                    className="flex-1 py-4 bg-blue-600 text-white font-black text-xs uppercase tracking-[0.2em] rounded-2xl shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all active:scale-[0.98]"
                  >
                    {selectedReminder ? 'Opslaan' : 'Toevoegen'}
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <ConfirmDialog
        isOpen={deleteConfirm.isOpen}
        title={`${deleteConfirm.type === 'alert' ? 'Melding' : 'Herinnering'} Verwijderen`}
        message="Weet u zeker dat u dit wilt verwijderen? Deze actie kan niet ongedaan worden gemaakt."
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteConfirm({ ...deleteConfirm, isOpen: false })}
      />

      <AppointmentModal 
        isOpen={isAppointmentModalOpen}
        onClose={() => setIsAppointmentModalOpen(false)}
        appointment={null}
        initialData={appointmentInitialData}
        onSave={() => {
          setIsAppointmentModalOpen(false);
          fetchData();
        }}
        customers={customers}
        machines={machines}
        reminders={reminders}
        interventions={[]}
      />
    </div>
  );
};

export default Actions;
