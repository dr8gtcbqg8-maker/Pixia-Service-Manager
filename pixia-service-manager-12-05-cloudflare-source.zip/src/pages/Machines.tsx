import React, { useEffect, useState, useMemo } from 'react';
import { collection, addDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Machine, Customer, MachineStatus, MaintenanceInterval, MachineType, ReminderPriority, ReminderType, Intervention, WorkOrder } from '../types';
import { 
  Plus, Printer, Tag, Hash, Calendar, MoreVertical, MapPin, 
  Settings, Edit3, Trash2, Wrench, User, Filter, X, 
  History, FileText, Camera, Bell, Info, ShieldCheck, CreditCard, ChevronRight,
  QrCode, Share2, Download
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import DocumentSection from '../components/DocumentSection';
import { motion, AnimatePresence } from 'motion/react';
import { handleFirestoreError, OperationType, calculateNextMaintenanceDate, cn } from '../lib/utils';
import ConfirmDialog from '../components/ConfirmDialog';
import { format } from 'date-fns';
import { useMachines } from '../hooks/useMachines';
import { machineService } from '../services/machineService';
import MachineTable from '../components/machines/MachineTable';
import MachineFilters from '../components/machines/MachineFilters';
import { COLLECTIONS } from '../constants/collections';

const Machines: React.FC = () => {
  const { machines, customers, loading, refreshData } = useMachines();
  
  // Search & Filter state
  const [search, setSearch] = useState('');
  const [filterCustomer, setFilterCustomer] = useState('');
  const [filterType, setFilterType] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterInstallDate, setFilterInstallDate] = useState('');
  const [filterWarrantyDate, setFilterWarrantyDate] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [selectedMachine, setSelectedMachine] = useState<Machine | null>(null);
  const [selectedTab, setSelectedTab] = useState('dossier');
  const [deleteConfirm, setDeleteConfirm] = useState<{ isOpen: boolean; id: string | null }>({ isOpen: false, id: null });
  
  // Reminder Modal State
  const [isReminderModalOpen, setIsReminderModalOpen] = useState(false);
  const [reminderTarget, setReminderTarget] = useState<{ machineId: string; customerId: string } | null>(null);
  const [newReminderData, setNewReminderData] = useState({
    title: '',
    description: '',
    dueDate: format(new Date(), 'yyyy-MM-dd'),
    priority: 'normal' as ReminderPriority,
    type: 'maintenance' as ReminderType
  });

  const [newMachine, setNewMachine] = useState({
    customerId: '',
    type: 'printer' as MachineType,
    brand: '',
    model: '',
    serialNumber: '',
    saleDate: '',
    installDate: '',
    warrantyPeriodMonths: 12,
    warrantyEndDate: '',
    hasServiceContract: false,
    maintenanceInterval: 'annual' as MaintenanceInterval,
    firstMaintenanceMonths: 6,
    autoScheduleEnabled: true,
    lastMaintenanceDate: '',
    nextMaintenanceDate: '',
    location: '',
    status: 'active' as MachineStatus,
    notes: '',
    internalNotes: ''
  });

  useEffect(() => {
    if (isAddModalOpen) {
      const nextDate = calculateNextMaintenanceDate({
        installDate: newMachine.installDate,
        lastMaintenanceDate: newMachine.lastMaintenanceDate,
        maintenanceInterval: newMachine.maintenanceInterval,
        firstMaintenanceMonths: newMachine.firstMaintenanceMonths
      });
      if (nextDate && nextDate !== newMachine.nextMaintenanceDate) {
        setNewMachine(prev => ({ ...prev, nextMaintenanceDate: nextDate }));
      }
    }
  }, [newMachine.installDate, newMachine.lastMaintenanceDate, newMachine.maintenanceInterval, newMachine.firstMaintenanceMonths, isAddModalOpen]);

  const handleOpenAddModal = () => {
    setSelectedMachine(null);
    setNewMachine({
      customerId: '',
      type: 'printer',
      brand: '',
      model: '',
      serialNumber: '',
      saleDate: '',
      installDate: '',
      warrantyPeriodMonths: 12,
      warrantyEndDate: '',
      hasServiceContract: false,
      maintenanceInterval: 'annual',
      firstMaintenanceMonths: 6,
      autoScheduleEnabled: true,
      lastMaintenanceDate: '',
      nextMaintenanceDate: '',
      location: '',
      status: 'active',
      notes: '',
      internalNotes: ''
    });
    setIsAddModalOpen(true);
  };

  const handleOpenEditModal = (machine: Machine) => {
    setSelectedMachine(machine);
    setNewMachine({
      customerId: machine.customerId,
      type: machine.type || 'printer',
      brand: machine.brand,
      model: machine.model,
      serialNumber: machine.serialNumber,
      saleDate: machine.saleDate || '',
      installDate: machine.installDate || '',
      warrantyPeriodMonths: machine.warrantyPeriodMonths || 12,
      warrantyEndDate: machine.warrantyEndDate || '',
      hasServiceContract: machine.hasServiceContract,
      maintenanceInterval: machine.maintenanceInterval,
      firstMaintenanceMonths: machine.firstMaintenanceMonths || 6,
      autoScheduleEnabled: machine.autoScheduleEnabled !== undefined ? machine.autoScheduleEnabled : true,
      lastMaintenanceDate: machine.lastMaintenanceDate || '',
      nextMaintenanceDate: machine.nextMaintenanceDate || '',
      location: machine.location || '',
      status: machine.status,
      notes: machine.notes || '',
      internalNotes: machine.internalNotes || ''
    });
    setIsAddModalOpen(true);
  };

  const [machineInterventions, setMachineInterventions] = useState<Intervention[]>([]);
  const [machineWorkOrders, setMachineWorkOrders] = useState<WorkOrder[]>([]);

  const handleOpenDetails = async (machine: Machine) => {
    setSelectedMachine(machine);
    setSelectedTab('dossier');
    const { interventions, workOrders } = await machineService.getRelatedData(machine.id);
    setMachineInterventions(interventions);
    setMachineWorkOrders(workOrders);
    setIsDetailsModalOpen(true);
  };

  const handleSaveMachine = async (e: React.FormEvent) => {
    e.preventDefault();
    const machineId = await machineService.save(newMachine, selectedMachine);
    if (machineId) {
      setIsAddModalOpen(false);
      refreshData();
    }
  };

  const handleOpenReminderModal = (machine: Machine) => {
    setReminderTarget({ machineId: machine.id, customerId: machine.customerId });
    setNewReminderData({
      title: `Onderhoud ${machine.brand} ${machine.model}`,
      description: `Ingepland onderhoud voor machine ${machine.serialNumber}`,
      dueDate: format(new Date(), 'yyyy-MM-dd'),
      priority: 'normal',
      type: 'maintenance'
    });
    setIsReminderModalOpen(true);
  };

  const handleSaveManualReminder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reminderTarget) return;

    try {
      await addDoc(collection(db, COLLECTIONS.REMINDERS), {
        ...newReminderData,
        machineId: reminderTarget.machineId,
        customerId: reminderTarget.customerId,
        status: 'open',
        createdAt: new Date().toISOString()
      });
      setIsReminderModalOpen(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, COLLECTIONS.REMINDERS);
    }
  };

  const handleDeleteClick = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setDeleteConfirm({ isOpen: true, id });
  };

  const confirmDelete = async () => {
    if (!deleteConfirm.id) return;
    const success = await machineService.delete(deleteConfirm.id);
    if (success) {
      setDeleteConfirm({ isOpen: false, id: null });
      refreshData();
    }
  };

  const getCustomerName = (id: string) => customers.find(c => c.id === id)?.name || 'Onbekende klant';

  const filteredMachines = useMemo(() => machines.filter(m => {
    const matchesSearch = 
      m.brand.toLowerCase().includes(search.toLowerCase()) || 
      m.model.toLowerCase().includes(search.toLowerCase()) || 
      m.serialNumber.toLowerCase().includes(search.toLowerCase()) ||
      getCustomerName(m.customerId).toLowerCase().includes(search.toLowerCase());
    
    const matchesCustomer = !filterCustomer || m.customerId === filterCustomer;
    const matchesType = !filterType || m.type === filterType;
    const matchesStatus = !filterStatus || m.status === filterStatus;
    const matchesInstallDate = !filterInstallDate || m.installDate === filterInstallDate;
    const matchesWarrantyDate = !filterWarrantyDate || m.warrantyEndDate === filterWarrantyDate;

    return matchesSearch && matchesCustomer && matchesType && matchesStatus && matchesInstallDate && matchesWarrantyDate;
  }), [machines, search, filterCustomer, filterType, filterStatus, filterInstallDate, filterWarrantyDate, customers]);

  const getStatusColor = (status: MachineStatus) => {
    switch (status) {
      case 'active': return 'bg-green-50 text-green-700 border-green-100';
      case 'maintenance-needed': return 'bg-amber-50 text-amber-700 border-amber-100';
      case 'faulty': return 'bg-red-50 text-red-700 border-red-100';
      case 'out-of-service': return 'bg-slate-100 text-slate-500 border-slate-200';
      case 'replaced': return 'bg-blue-50 text-blue-700 border-blue-100';
      default: return 'bg-slate-50 text-slate-500';
    }
  };

  return (
    <div className="space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 leading-tight">Machinepark</h1>
          <p className="text-sm font-medium text-slate-500 mt-1">Beheer en monitor de volledige machinevloot.</p>
        </div>
        <button 
          onClick={handleOpenAddModal}
          className="btn-primary shadow-blue-200"
        >
          <Plus className="w-4 h-4" />
          <span>Machine Toevoegen</span>
        </button>
      </div>

      <MachineFilters 
        search={search} setSearch={setSearch}
        showFilters={showFilters} setShowFilters={setShowFilters}
        filterCustomer={filterCustomer} setFilterCustomer={setFilterCustomer}
        filterType={filterType} setFilterType={setFilterType}
        filterStatus={filterStatus} setFilterStatus={setFilterStatus}
        filterInstallDate={filterInstallDate} setFilterInstallDate={setFilterInstallDate}
        filterWarrantyDate={filterWarrantyDate} setFilterWarrantyDate={setFilterWarrantyDate}
        customers={customers}
      />

      {loading ? (
        <div className="flex justify-center p-24">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-slate-200 border-t-blue-600"></div>
        </div>
      ) : (
        <MachineTable 
          machines={filteredMachines}
          customers={customers}
          onOpenDetails={handleOpenDetails}
          onOpenEdit={handleOpenEditModal}
          onOpenReminder={handleOpenReminderModal}
          onDelete={handleDeleteClick}
        />
      )}

      {/* Add/Edit Modal */}
      <AnimatePresence>
        {isAddModalOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
              onClick={() => setIsAddModalOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative bg-white w-full max-w-3xl rounded-2xl shadow-xl p-8 overflow-y-auto max-h-[90vh] custom-scrollbar"
            >
              <div className="flex items-center justify-between mb-8 pb-4 border-b border-slate-100">
                <h2 className="text-xl font-bold text-slate-900">
                  {selectedMachine ? 'Machine bewerken' : 'Nieuwe machine registreren'}
                </h2>
                <button onClick={() => setIsAddModalOpen(false)} className="p-2 hover:bg-slate-100 rounded-lg text-slate-400 transition-all">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveMachine} className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Left Column */}
                  <div className="space-y-4">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Basis informatie</h3>
                    <div className="space-y-3">
                      <div>
                        <label className="label">Klant *</label>
                        <select 
                          required
                          className="input-field"
                          value={newMachine.customerId}
                          onChange={(e) => setNewMachine({...newMachine, customerId: e.target.value})}
                        >
                          <option value="">Selecteer een klant...</option>
                          {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </select>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="label">Type *</label>
                          <select 
                            className="input-field"
                            value={newMachine.type}
                            onChange={(e) => setNewMachine({...newMachine, type: e.target.value as MachineType})}
                          >
                            <option value="printer">Printer</option>
                            <option value="laminator">Laminator</option>
                            <option value="other">Overig</option>
                          </select>
                        </div>
                        <div>
                          <label className="label">Status</label>
                          <select 
                            className="input-field"
                            value={newMachine.status}
                            onChange={(e) => setNewMachine({...newMachine, status: e.target.value as MachineStatus})}
                          >
                            <option value="active">Actief</option>
                            <option value="maintenance-needed">Onderhoud nodig</option>
                            <option value="faulty">Storing</option>
                            <option value="out-of-service">Buiten gebruik</option>
                            <option value="replaced">Vervangen</option>
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="label">Merk *</label>
                          <input 
                            required 
                            type="text" 
                            placeholder="bijv. HP, Roland"
                            className="input-field" 
                            value={newMachine.brand}
                            onChange={(e) => setNewMachine({...newMachine, brand: e.target.value})}
                          />
                        </div>
                        <div>
                          <label className="label">Model *</label>
                          <input 
                            required 
                            type="text" 
                            placeholder="bijv. Latex 360"
                            className="input-field" 
                            value={newMachine.model}
                            onChange={(e) => setNewMachine({...newMachine, model: e.target.value})}
                          />
                        </div>
                      </div>

                      <div>
                        <label className="label">Serienummer *</label>
                        <input 
                          required 
                          type="text" 
                          className="input-field font-mono" 
                          value={newMachine.serialNumber}
                          onChange={(e) => setNewMachine({...newMachine, serialNumber: e.target.value})}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Right Column */}
                  <div className="space-y-4">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Service & Garantie</h3>
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="label">Installatie datum</label>
                          <input 
                            type="date" 
                            className="input-field" 
                            value={newMachine.installDate}
                            onChange={(e) => setNewMachine({...newMachine, installDate: e.target.value})}
                          />
                        </div>
                        <div>
                          <label className="label">Einddatum garantie</label>
                          <input 
                            type="date" 
                            className="input-field" 
                            value={newMachine.warrantyEndDate}
                            onChange={(e) => setNewMachine({...newMachine, warrantyEndDate: e.target.value})}
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                         <label className="flex items-center gap-3 p-3.5 bg-slate-50/50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition-all group">
                           <input 
                             type="checkbox" 
                             className="w-5 h-5 rounded border-slate-300 text-blue-600 focus:ring-0 transition-all"
                             checked={newMachine.hasServiceContract}
                             onChange={(e) => setNewMachine({...newMachine, hasServiceContract: e.target.checked})}
                           />
                           <span className="text-sm font-bold text-slate-700 group-hover:text-blue-600 transition-colors">Servicecontract actief</span>
                         </label>

                         <label className="flex items-center gap-3 p-3.5 bg-slate-50/50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition-all group">
                           <input 
                             type="checkbox" 
                             className="w-5 h-5 rounded border-slate-300 text-blue-600 focus:ring-0 transition-all"
                             checked={newMachine.autoScheduleEnabled}
                             onChange={(e) => setNewMachine({...newMachine, autoScheduleEnabled: e.target.checked})}
                           />
                           <span className="text-sm font-bold text-slate-700 group-hover:text-blue-600 transition-colors">Automatische onderhoudsplanning</span>
                         </label>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="label">Interval</label>
                          <select 
                            className="input-field"
                            value={newMachine.maintenanceInterval}
                            onChange={(e) => setNewMachine({...newMachine, maintenanceInterval: e.target.value as MaintenanceInterval})}
                          >
                            <option value="annual">Jaarlijks</option>
                            <option value="half-yearly">Halfjaarlijks</option>
                            <option value="quarterly">Kwartaal</option>
                            <option value="monthly">Maandelijks</option>
                            <option value="manual">Handmatig</option>
                          </select>
                        </div>
                        <div>
                          <label className="label">Volgend onderhoud</label>
                          <input 
                            type="date" 
                            className={cn(
                              "input-field",
                              newMachine.autoScheduleEnabled && "bg-blue-50 border-blue-200 text-blue-700 font-bold"
                            )}
                            value={newMachine.nextMaintenanceDate}
                            onChange={(e) => setNewMachine({...newMachine, nextMaintenanceDate: e.target.value})}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4 pt-6 border-t border-slate-100">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Locatie & Notities</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="label">Specifieke locatie bij klant</label>
                      <div className="relative">
                         <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                         <input 
                          type="text" 
                          placeholder="bijv. Productiehal 1, 2e verdieping"
                          className="input-field !pl-10" 
                          value={newMachine.location}
                          onChange={(e) => setNewMachine({...newMachine, location: e.target.value})}
                        />
                      </div>
                    </div>
                    <div>
                      <label className="label">Klantnotities</label>
                      <textarea 
                        rows={2}
                        placeholder="Zichtbaar op werkbonnen..."
                        className="input-field py-2 resize-none h-[44px]" 
                        value={newMachine.notes}
                        onChange={(e) => setNewMachine({...newMachine, notes: e.target.value})}
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="label text-rose-500 font-bold">Interne instructies (geheim)</label>
                      <textarea 
                        rows={2}
                        placeholder="Alleen zichtbaar voor technici..."
                        className="input-field py-2 resize-none bg-rose-50/20 border-rose-100 text-rose-900 h-[60px]" 
                        value={newMachine.internalNotes}
                        onChange={(e) => setNewMachine({...newMachine, internalNotes: e.target.value})}
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-100 flex items-center justify-end gap-3">
                  <button 
                    type="button" 
                    onClick={() => setIsAddModalOpen(false)}
                    className="btn-ghost"
                  >
                    Annuleren
                  </button>
                  <button 
                    type="submit" 
                    className="btn-primary min-w-[160px]"
                  >
                    {selectedMachine ? 'Wijzigingen opslaan' : 'Machine toevoegen'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Machine Details Modal */}
      <AnimatePresence>
        {isDetailsModalOpen && selectedMachine && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
              onClick={() => setIsDetailsModalOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative bg-white w-full max-w-5xl rounded-2xl shadow-xl overflow-hidden flex flex-col max-h-[90vh]"
            >
              {/* Header */}
              <div className="px-8 py-6 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-5">
                  <div className="w-16 h-16 bg-blue-600 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-blue-500/20 uppercase transition-transform hover:scale-105">
                    <Printer className="w-8 h-8" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-slate-900 leading-tight">
                      {selectedMachine.brand} {selectedMachine.model}
                    </h2>
                    <div className="flex items-center gap-2 mt-1">
                       <span className="text-xs font-bold text-slate-400 tracking-wider">S/N: {selectedMachine.serialNumber}</span>
                       <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border ${getStatusColor(selectedMachine.status)}`}>
                         {selectedMachine.status}
                       </span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => handleOpenEditModal(selectedMachine)}
                    className="btn-ghost !p-2 text-slate-400 hover:text-blue-600 transition-all"
                    title="Bewerken"
                  >
                    <Edit3 className="w-5 h-5" />
                  </button>
                  <button onClick={() => setIsDetailsModalOpen(false)} className="p-2 hover:bg-white rounded-lg text-slate-400 transition-all border border-transparent hover:border-slate-200">
                    <X className="w-6 h-6" />
                  </button>
                </div>
              </div>

              <div className="flex flex-1 overflow-hidden">
                {/* Sidebar Info */}
                <div className="w-72 bg-slate-50/50 border-r border-slate-200 p-6 space-y-6 hidden lg:block overflow-y-auto">
                   <div className="space-y-3">
                      <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">Eigenaar</h3>
                      <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-sm">
                         <p className="text-sm font-bold text-slate-900 leading-tight">{getCustomerName(selectedMachine.customerId)}</p>
                         <div className="flex items-start gap-2 mt-2 text-xs text-slate-500 leading-tight">
                            <MapPin className="w-3.5 h-3.5 mt-0.5 shrink-0 text-slate-400" />
                            <span>{selectedMachine.location || 'Geen specifieke locatie.'}</span>
                         </div>
                      </div>
                   </div>

                   <div className="space-y-3">
                      <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">Service Status</h3>
                      <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-sm space-y-3">
                         <div className="flex items-center justify-between">
                            <span className="text-xs text-slate-500">Contract</span>
                            <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${selectedMachine.hasServiceContract ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 'bg-slate-50 text-slate-400 border-slate-200'}`}>
                               {selectedMachine.hasServiceContract ? 'Actief' : 'Geen'}
                            </span>
                         </div>
                         <div className="flex items-center justify-between">
                            <span className="text-xs text-slate-500">Interval</span>
                            <span className="text-[10px] font-bold uppercase tracking-wider bg-blue-50 text-blue-700 border border-blue-100 px-2 py-0.5 rounded-full">{selectedMachine.maintenanceInterval}</span>
                         </div>
                      </div>
                   </div>

                   <div className="space-y-3">
                      <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">Deadline</h3>
                      <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-sm flex items-center gap-3">
                         <div className="w-10 h-10 bg-amber-50 text-amber-600 rounded-lg flex items-center justify-center shrink-0 border border-amber-100">
                            <Calendar className="w-5 h-5" />
                         </div>
                         <div>
                            <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Volgend onderhoud</p>
                            <p className="text-sm font-bold text-slate-900">{selectedMachine.nextMaintenanceDate || 'Niet gepland'}</p>
                         </div>
                      </div>
                   </div>
                </div>

                {/* Main Content Area */}
                <div className="flex-1 flex flex-col min-w-0">
                  <div className="px-6 border-b border-slate-200 bg-white flex items-center gap-6 overflow-x-auto shrink-0 scrollbar-hide">
                     {[
                       { id: 'dossier', label: 'Dossier', icon: Info },
                       { id: 'historie', label: 'Historie', icon: History },
                       { id: 'werkbonnen', label: 'Werkbonnen', icon: FileText },
                       { id: 'media', label: 'Media & Docs', icon: Camera },
                       { id: 'reminders', label: 'Herinneringen', icon: Bell },
                     ].map((tab) => (
                       <button
                         key={tab.id}
                         onClick={() => setSelectedTab(tab.id)}
                         className={cn(
                           "py-4 text-sm font-medium flex items-center gap-2 border-b-2 transition-all whitespace-nowrap",
                           selectedTab === tab.id 
                           ? "border-blue-600 text-blue-600" 
                           : "border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300"
                         )}
                       >
                         <tab.icon className="w-4 h-4" />
                         {tab.label}
                       </button>
                     ))}
                  </div>

                  <div className="flex-1 overflow-y-auto p-8 bg-white">
                     <AnimatePresence mode="wait">
                        {selectedTab === 'dossier' && (
                           <motion.div
                             key="dossier" 
                             initial={{ opacity: 0, y: 10 }}
                             animate={{ opacity: 1, y: 0 }}
                             exit={{ opacity: 0, y: -10 }}
                             className="space-y-8"
                           >
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                   <div className="space-y-8">
                                      <section className="space-y-4">
                                         <h4 className="text-sm font-bold text-slate-900 border-l-4 border-blue-600 pl-3">Machine Gegevens</h4>
                                         <div className="grid grid-cols-2 gap-4">
                                            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
                                               <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Verkoopdatum</span>
                                               <span className="text-sm text-slate-700">{selectedMachine.saleDate || 'Niet opgegeven'}</span>
                                            </div>
                                            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
                                               <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Installatiedatum</span>
                                               <span className="text-sm text-slate-700">{selectedMachine.installDate || 'Niet opgegeven'}</span>
                                            </div>
                                            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
                                               <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Garantie tot</span>
                                               <span className="text-sm text-slate-700 font-bold text-emerald-600">{selectedMachine.warrantyEndDate || '-'}</span>
                                            </div>
                                            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
                                               <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Serienummer</span>
                                               <span className="text-sm text-slate-700 font-mono">{selectedMachine.serialNumber}</span>
                                            </div>
                                         </div>
                                      </section>

                                      <section className="space-y-4">
                                         <h4 className="text-sm font-bold text-slate-900 border-l-4 border-blue-600 pl-3">QR Code</h4>
                                         <div className="p-6 bg-white border border-slate-200 rounded-2xl flex items-center gap-6 shadow-sm">
                                            <div className="p-2 bg-slate-50 rounded-xl border border-slate-100">
                                               <QRCodeSVG 
                                                 id="machine-qr"
                                                 value={`${window.location.origin}/machines?id=${selectedMachine.id}`} 
                                                 size={120}
                                                 level="H"
                                                 includeMargin={true}
                                               />
                                            </div>
                                            <div className="flex-1 space-y-3">
                                               <p className="text-xs text-slate-500 leading-relaxed">Scan deze code met een mobiel toestel om direct naar het machinedossier te gaan.</p>
                                               <div className="flex gap-2">
                                                  <button 
                                                    onClick={() => {/* download logic */}}
                                                    className="btn-ghost !py-2 !px-3 text-[10px] uppercase tracking-wider"
                                                  >
                                                     <Download className="w-4 h-4" />
                                                     <span>Opslaan</span>
                                                  </button>
                                                  <button 
                                                    onClick={() => {/* print logic */}}
                                                    className="btn-ghost !py-2 !px-3 text-[10px] uppercase tracking-wider"
                                                  >
                                                     <Printer className="w-4 h-4" />
                                                     <span>Printen</span>
                                                  </button>
                                               </div>
                                            </div>
                                         </div>
                                      </section>
                                   </div>

                                   <div className="space-y-6">
                                      <section className="space-y-4">
                                         <h4 className="text-sm font-bold text-slate-900 border-l-4 border-blue-600 pl-3">Notities & Informatie</h4>
                                         <div className="space-y-4">
                                            <div className="p-5 bg-slate-50 border border-slate-200 rounded-2xl">
                                               <h5 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Publieke notities</h5>
                                               <p className="text-sm text-slate-600 italic">
                                                  {selectedMachine.notes || 'Geen klantnotities beschikbaar.'}
                                               </p>
                                            </div>
                                            {selectedMachine.internalNotes && (
                                               <div className="p-5 bg-amber-50/30 border border-amber-100 rounded-2xl">
                                                  <h5 className="text-[10px] font-bold text-amber-600 uppercase tracking-wider mb-2">Interne notities</h5>
                                                  <p className="text-sm text-slate-700 italic">
                                                     {selectedMachine.internalNotes}
                                                  </p>
                                               </div>
                                            )}
                                         </div>
                                      </section>
                                   </div>
                                </div>
                           </motion.div>
                        )}

                        {selectedTab === 'historie' && (
                           <motion.div
                             key="historie"
                             initial={{ opacity: 0, y: 10 }}
                             animate={{ opacity: 1, y: 0 }}
                             exit={{ opacity: 0, y: -10 }}
                             className="space-y-6"
                           >
                              <div className="flex items-center justify-between">
                                 <h4 className="text-lg font-bold text-slate-900">Interventie historie</h4>
                                 <button 
                                  onClick={() => window.location.href = `/interventions/new?machineId=${selectedMachine.id}`}
                                  className="btn-primary !py-2 !text-xs"
                                 >
                                  <Plus className="w-4 h-4" />
                                  <span>Nieuw rapport</span>
                                 </button>
                              </div>
                              
                              {machineInterventions.length > 0 ? (
                                 <div className="space-y-4">
                                   {machineInterventions.map(int => (
                                     <div key={int.id} className="p-5 bg-white border border-slate-200 rounded-2xl hover:border-blue-300 transition-all shadow-sm group">
                                        <div className="flex items-start gap-4">
                                           <div className={cn(
                                             "w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border",
                                             int.status === 'completed' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-amber-50 text-amber-600 border-amber-100'
                                           )}>
                                              <Wrench className="w-5 h-5" />
                                           </div>
                                           <div className="flex-1">
                                              <div className="flex items-center justify-between mb-1">
                                                 <span className="text-xs font-bold text-slate-400">{int.date}</span>
                                                 <span className={cn(
                                                   "text-[10px] font-bold uppercase px-2 py-0.5 rounded-full",
                                                   int.status === 'completed' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                                                 )}>{int.status}</span>
                                              </div>
                                              <h5 className="text-sm font-bold text-slate-900 mb-1">{int.type}</h5>
                                              <p className="text-xs text-slate-500 line-clamp-2">{int.problemDescription}</p>
                                           </div>
                                        </div>
                                     </div>
                                   ))}
                                 </div>
                              ) : (
                                 <div className="p-12 text-center border-2 border-dashed border-slate-200 rounded-2xl">
                                    <p className="text-sm text-slate-500">Nog geen interventies geregistreerd.</p>
                                 </div>
                              )}
                           </motion.div>
                        )}

                        {selectedTab === 'media' && (
                           <motion.div
                             key="media"
                             initial={{ opacity: 0 }}
                             animate={{ opacity: 1 }}
                             exit={{ opacity: 0 }}
                           >
                              <DocumentSection machineId={selectedMachine.id} />
                           </motion.div>
                        )}
                        
                        {/* other tabs follow similar cleanup... */}
                     </AnimatePresence>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="px-8 py-5 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
                 <p className="text-xs text-slate-400">Machine ID: <span className="font-mono">{selectedMachine.id}</span></p>
                 <button 
                   onClick={() => setIsDetailsModalOpen(false)}
                   className="btn-primary min-w-[120px]"
                 >
                   Sluiten
                 </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <ConfirmDialog
        isOpen={deleteConfirm.isOpen}
        title="Machine verwijderen"
        message="Weet u zeker dat u deze machine permanent wilt verwijderen? Dit kan niet ongedaan worden gemaakt."
        onConfirm={confirmDelete}
        onCancel={() => setDeleteConfirm({ isOpen: false, id: null })}
      />

      {/* Manual Reminder Modal */}
      <AnimatePresence>
        {isReminderModalOpen && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
              onClick={() => setIsReminderModalOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative bg-white w-full max-w-lg rounded-2xl shadow-xl p-8"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                  <Bell className="w-5 h-5 text-blue-600" />
                  Taak inplannen
                </h2>
                <button onClick={() => setIsReminderModalOpen(false)} className="p-2 hover:bg-slate-100 rounded-lg text-slate-400">
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <form onSubmit={handleSaveManualReminder} className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <label className="label">Titel *</label>
                    <input 
                      required 
                      type="text" 
                      className="input-field" 
                      value={newReminderData.title}
                      onChange={(e) => setNewReminderData({...newReminderData, title: e.target.value})}
                    />
                  </div>

                  <div>
                    <label className="label">Omschrijving</label>
                    <textarea 
                      rows={3}
                      className="input-field py-2 resize-none" 
                      value={newReminderData.description}
                      onChange={(e) => setNewReminderData({...newReminderData, description: e.target.value})}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="label">Datum</label>
                      <input 
                        type="date" 
                        className="input-field" 
                        value={newReminderData.dueDate}
                        onChange={(e) => setNewReminderData({...newReminderData, dueDate: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="label">Prioriteit</label>
                      <select 
                        className="input-field"
                        value={newReminderData.priority}
                        onChange={(e) => setNewReminderData({...newReminderData, priority: e.target.value as ReminderPriority})}
                      >
                        <option value="low">Laag</option>
                        <option value="normal">Normaal</option>
                        <option value="high">Hoog</option>
                        <option value="urgent">Urgent</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-100 flex items-center justify-end gap-3">
                  <button 
                    type="button" 
                    onClick={() => setIsReminderModalOpen(false)}
                    className="btn-ghost"
                  >
                    Annuleren
                  </button>
                  <button 
                    type="submit" 
                    className="btn-primary"
                  >
                    Inplannen
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Machines;
