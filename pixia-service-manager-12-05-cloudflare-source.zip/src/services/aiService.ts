import { GoogleGenAI } from "@google/genai";
import { Intervention, Customer, Machine } from '../types';

// Initialize the Gemini API
const geminiApiKey = import.meta.env.VITE_GEMINI_API_KEY || process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({ apiKey: geminiApiKey });
const modelName = "gemini-3-flash-preview";

export const aiService = {
  /**
   * Genereert een concept e-mail voor de klant na een interventie
   */
  async generateEmailDraft(params: {
    intervention: Intervention;
    customer: Customer;
    machine: Machine;
  }) {
    const { intervention, customer, machine } = params;
    
    const prompt = `
      Schrijf een professionele en vriendelijke e-mail namens Pixia Service naar de klant over een uitgevoerde interventie.
      Gebruik de volgende gegevens:
      - Klantnaam: ${customer.name}
      - Contactpersoon: ${customer.contactPerson || 'Klant'}
      - Machine: ${machine.brand} ${machine.model} (SN: ${machine.serialNumber})
      - Type interventie: ${intervention.type}
      - Datum: ${intervention.date}
      - Probleem: ${intervention.problemDescription || 'Niet gespecificeerd'}
      - Uitgevoerd werk: ${intervention.workPerformed || 'Niet gespecificeerd'}
      - Status: ${intervention.status}
      - Eventuele vervolgactie: ${intervention.followUpAction || 'Geen'}

      De e-mail moet in het Nederlands zijn, professioneel maar benaderbaar. Gebruik een duidelijke onderwerpregel.
      Eindig met een groet van het Pixia Service Team.
    `;

    try {
      const response = await ai.models.generateContent({
        model: modelName,
        contents: prompt,
      });
      return response.text;
    } catch (err) {
      console.error('AI Email Generation failed:', err);
      return "Fout bij het genereren van de e-mail. Probeer het later opnieuw.";
    }
  },

  /**
   * Vat een technische beschrijving samen tot een korte tekst
   */
  async summarizeIntervention(workPerformed: string) {
    if (!workPerformed) return "";

    const prompt = `
      Vat de volgende technische werkomschrijving samen in maximaal 2 korte zinnen voor een dashboard overzicht:
      "${workPerformed}"
    `;

    try {
      const response = await ai.models.generateContent({
        model: modelName,
        contents: prompt,
      });
      return response.text;
    } catch (err) {
      console.error('AI Summary failed:', err);
      return workPerformed; // Fallback to original
    }
  },

  /**
   * Geeft onderhoudsadvies op basis van machine status
   */
  async getMaintenanceAdvice(machine: Machine) {
    const prompt = `
      Geef een kort, deskundig onderhoudsadvies (max 50 woorden) voor de volgende machine:
      - Type: ${machine.type}
      - Merk/Model: ${machine.brand} ${machine.model}
      - Status: ${machine.status}
      - Laatste onderhoud: ${machine.lastMaintenanceDate || 'Onbekend'}
      - Contract: ${machine.hasServiceContract ? 'Ja' : 'Nee'}
    `;

    try {
      const response = await ai.models.generateContent({
        model: modelName,
        contents: prompt,
      });
      return response.text;
    } catch (err) {
      console.error('AI Advice failed:', err);
      return "Houd de reguliere onderhoudsintervallen aan.";
    }
  }
};
