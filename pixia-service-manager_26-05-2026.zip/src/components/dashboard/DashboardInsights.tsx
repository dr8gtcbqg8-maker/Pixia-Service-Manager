import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { ShieldAlert, Calendar, TrendingUp, Printer } from 'lucide-react';
import { InventoryItem, Machine, Customer } from '../../types';
import { format } from 'date-fns';

interface DashboardInsightsProps {
  lowStockItems: InventoryItem[];
  expiringWarrantyCount: number;
  faultyMachinesCount: number;
  upcomingMaintenance: Machine[];
  customers: Customer[];
}

const DashboardInsights: React.FC<DashboardInsightsProps> = ({
  lowStockItems,
  expiringWarrantyCount,
  faultyMachinesCount,
  upcomingMaintenance,
  customers
}) => {
  const navigate = useNavigate();
  const getCustomer = (id: string) => customers.find(c => c.id === id);

  return (
    <div className="space-y-4">
      <section className="bg-surface-900 text-white rounded-md p-5 shadow-lg relative overflow-hidden group">
         <div className="relative z-10 space-y-4">
            <div className="flex items-center gap-2 text-red-400 border-b border-white/5 pb-4">
               <ShieldAlert className="w-5 h-5 text-red-500" />
               <h2 className="text-sm font-display font-bold">Business Alerts</h2>
            </div>
            
            <div className="space-y-4">
               {lowStockItems.length > 0 && (
                  <motion.div 
                    whileHover={{ scale: 1.02 }}
                    onClick={() => navigate('/inventory')}
                    className="bg-red-500/10 backdrop-blur-md rounded-md p-4 border border-red-500/20 cursor-pointer"
                  >
                     <p className="text-[11px] font-semibold text-red-300 uppercase tracking-wide mb-1">Kritieke Voorraad</p>
                     <p className="text-2xl font-display font-bold text-white leading-none text-left mb-4">{lowStockItems.length} Artikelen</p>
                     <div className="space-y-2">
                        {lowStockItems.slice(0, 3).map(item => (
                           <div key={item.id} className="text-xs font-semibold text-red-100 flex justify-between items-center bg-white/5 p-2 rounded-md">
                              <span className="truncate mr-2">{item.name}</span>
                              <span className="bg-red-500/20 text-red-200 px-2 py-0.5 rounded text-[11px] whitespace-nowrap">{item.stockCount} st.</span>
                           </div>
                        ))}
                     </div>
                  </motion.div>
               )}

               <div 
                onClick={() => navigate('/machines')}
                className="bg-white/5 backdrop-blur-md rounded-md p-4 border border-white/5 cursor-pointer hover:bg-white/10 transition-colors text-left"
               >
                  <p className="text-[11px] font-semibold text-surface-400 uppercase tracking-wide mb-1">Garantie verlopen (30d)</p>
                  <p className="text-xl font-display font-bold text-white">{expiringWarrantyCount} Machines</p>
               </div>
               
               <div 
                onClick={() => navigate('/machines')}
                className="bg-white/5 backdrop-blur-md rounded-md p-4 border border-white/5 cursor-pointer hover:bg-white/10 transition-colors text-left"
               >
                  <p className="text-[11px] font-semibold text-surface-400 uppercase tracking-wide mb-1">Defect gemeld</p>
                  <p className="text-xl font-display font-bold text-red-400">{faultyMachinesCount} Machines</p>
               </div>
            </div>

            <div className="pt-5 border-t border-white/5 text-left">
               <p className="text-xs text-surface-500 font-medium">Laatst bijgewerkt om {format(new Date(), 'HH:mm')}</p>
            </div>
         </div>
      </section>

      <section className="card overflow-hidden">
         <div className="p-4 bg-surface-50/50 border-b border-surface-200">
            <h3 className="text-[13px] font-bold text-surface-900 uppercase tracking-wide flex items-center gap-2">
               <Calendar className="w-4 h-4 text-brand-500" />
               Komend Onderhoud
            </h3>
         </div>
         <div className="divide-y divide-surface-100">
            {upcomingMaintenance.length > 0 ? (
              upcomingMaintenance.slice(0, 5).map(m => (
                <div 
                  key={m.id} 
                  onClick={() => navigate('/machines')}
                  className="p-4 hover:bg-surface-50 transition-colors cursor-pointer text-left"
                >
                   <div className="flex items-center justify-between mb-1">
                      <p className="text-sm font-semibold text-surface-900 truncate">{m.brand} {m.model}</p>
                      <span className="text-[10px] font-bold text-brand-600 uppercase bg-brand-50 border border-brand-100 px-2 py-0.5 rounded-sm">Gepland</span>
                   </div>
                   <p className="text-xs font-medium text-surface-500">{m.nextMaintenanceDate}</p>
                   <p className="text-xs text-surface-400 font-medium truncate mt-1">{getCustomer(m.customerId)?.name}</p>
                </div>
              ))
            ) : (
              <div className="p-5 text-center text-xs font-medium text-surface-400">Geen onderhoud gepland</div>
            )}
         </div>
      </section>

      <section className="bg-brand-500 text-white rounded-md p-5 shadow-lg relative overflow-hidden group">
         <div className="relative z-10 text-left">
            <h3 className="text-xs font-semibold text-white/70 uppercase tracking-wide mb-4">Systeem Status</h3>
            <div className="flex items-center gap-4 mb-6">
               <div className="h-12 w-12 bg-white/10 rounded-md flex items-center justify-center backdrop-blur-md">
                  <TrendingUp className="w-6 h-6" />
               </div>
               <div>
                  <p className="text-2xl font-display font-bold tracking-tight">99.9%</p>
                  <p className="text-[11px] font-medium text-white/70">Uptime Systemen</p>
               </div>
            </div>
            <button 
              onClick={() => navigate('/machines')}
              className="w-full bg-white text-surface-900 py-2.5 rounded-md text-sm font-bold shadow-sm hover:bg-surface-50 transition-all active:scale-95"
            >
              Machinepark Beheer
            </button>
         </div>
         <div className="absolute top-0 right-0 -m-4 opacity-10 group-hover:rotate-6 transition-transform duration-500">
            <Printer className="w-40 h-40" />
         </div>
      </section>
    </div>
  );
};

export default DashboardInsights;
