const fs = require('fs');
const path = require('path');

function walkDir(dir, callback) {
  fs.readdirSync(dir).forEach(f => {
    const dirPath = path.join(dir, f);
    if (fs.statSync(dirPath).isDirectory()) {
      walkDir(dirPath, callback);
    } else {
      callback(path.join(dir, f));
    }
  });
}

function processFile(filePath) {
  if (!filePath.endsWith('.tsx')) return;
  let content = fs.readFileSync(filePath, 'utf8');
  
  const lines = content.split('\n');
  let modified = false;
  
  for (let i = 0; i < lines.length; i++) {
    // Multi-line checking: sometimes backdrop-blur is on one line and onClick on another.
    // In our case, often it's on the same line:
    if (lines[i].includes('backdrop-blur') && lines[i].includes('onClick={')) {
      lines[i] = lines[i].replace(/onClick=\{[^}]+\}/, '');
      modified = true;
    }
  }

  // Also catch multi-line:
  // <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
  //   onClick={() => setIsAddModalOpen(false)} />
  for (let i = 0; i < lines.length - 1; i++) {
    if (lines[i].includes('backdrop-blur') && lines[i].match(/<div [^>]*$/)) {
      if (lines[i+1].includes('onClick={')) {
        let replaceMatched = lines[i+1].replace(/onClick=\{[^}]+\}/, '');
        if (replaceMatched !== lines[i+1]) {
           lines[i+1] = replaceMatched;
           modified = true;
        }
      }
    }
  }

  if (modified) {
    fs.writeFileSync(filePath, lines.join('\n'));
    console.log(`Modified ${filePath}`);
  }
}

walkDir('/app/applet/src', processFile);
