const fs = require('fs');
const path = require('path');

function walkDir(dir, callback) {
  fs.readdirSync(dir).forEach(f => {
    let dirPath = path.join(dir, f);
    let isDirectory = fs.statSync(dirPath).isDirectory();
    isDirectory ? walkDir(dirPath, callback) : callback(path.join(dir, f));
  });
}

function processFile(file) {
  if (!file.endsWith('.tsx') && !file.endsWith('.ts')) return;
  
  let original = fs.readFileSync(file, 'utf8');
  let content = original;

  // 1. Containers & Modals
  content = content.replace(/\bp-16\b/g, 'p-8');
  content = content.replace(/\bp-12\b/g, 'p-6');
  content = content.replace(/\bp-10\b/g, 'p-6');
  content = content.replace(/\bp-8\b/g, 'p-5');
  content = content.replace(/\bpx-12\b/g, 'px-6');
  content = content.replace(/\bpx-10\b/g, 'px-6');
  content = content.replace(/\bpx-8\b/g, 'px-5');
  content = content.replace(/\bpy-16\b/g, 'py-8');
  content = content.replace(/\bpy-12\b/g, 'py-6');
  content = content.replace(/\bpy-10\b/g, 'py-6');
  content = content.replace(/\bpy-8\b/g, 'py-5');

  // 2. Forms & Gaps
  content = content.replace(/\bgap-10\b/g, 'gap-5');
  content = content.replace(/\bgap-8\b/g, 'gap-4');
  content = content.replace(/\bgap-6\b/g, 'gap-3');
  content = content.replace(/\bgap-x-8\b/g, 'gap-x-4');
  content = content.replace(/\bgap-x-6\b/g, 'gap-x-3');
  content = content.replace(/\bgap-y-8\b/g, 'gap-y-4');
  content = content.replace(/\bgap-y-6\b/g, 'gap-y-3');
  
  content = content.replace(/\bspace-y-10\b/g, 'space-y-5');
  content = content.replace(/\bspace-y-8\b/g, 'space-y-4');
  content = content.replace(/\bspace-y-6\b/g, 'space-y-3');

  // 3. Lists/Tables (Row padding adjustment)
  // Instead of py-4 or py-5 in tables, let's use py-3 or py-2
  content = content.replace(/\bpy-5\b/g, 'py-3');
  content = content.replace(/\bpy-4\b/g, 'py-2');
  content = content.replace(/\!py-5\b/g, '!py-3');
  content = content.replace(/\!py-4\b/g, '!py-2');

  // 4. Border Radius
  content = content.replace(/\brounded-3xl\b/g, 'rounded-xl');
  content = content.replace(/\brounded-2xl\b/g, 'rounded-lg');
  content = content.replace(/\brounded-\[2rem\]\b/g, 'rounded-xl');
  content = content.replace(/\brounded-\[3rem\]\b/g, 'rounded-xl');

  // 5. Explicit Overrides on input-field
  content = content.replace(/\!py-8\b/g, '');
  content = content.replace(/\!px-10\b/g, '');
  content = content.replace(/\!px-8\b/g, '');
  content = content.replace(/\btext-lg\b/g, 'text-base');

  if (content !== original) {
    fs.writeFileSync(file, content);
    console.log('Refactored:', file);
  }
}

walkDir('src', processFile);
