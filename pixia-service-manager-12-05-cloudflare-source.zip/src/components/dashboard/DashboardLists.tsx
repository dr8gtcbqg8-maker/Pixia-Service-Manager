import React from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertCircle, Users, Clock, ChevronRight, Wrench } from 'lucide-react';
import { Machine, Customer, Intervention } from '../../types';

interface DashboardListsProps {
  topFaultyMachines: { machine: Machine | undefined; count: number }[];
  topCustomers: { customer: Customer | undefined; count: number }[];
  interventions: Intervention[];
  customers: Customer[];
}

const DashboardLists: React.FC<DashboardListsProps> = ({ 
  topFaultyMachines, 
  topCustomers, 
  interventions, 
  customers 
}) => {
  const navigate = useNavigate();

  return (
    <div className="space-y-8">
      {/* Faulty Machines & Top Customers */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <section className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
           <div className="p-6 border-b border-slate-50 flex items-center justify-between bg-slate-50/30">
              <h3 className="text-[10px] font-black text-slate-900 uppercase tracking-[0.2em] flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-500" />
                Storingsgevoelig
              </h3>
           </div>
           <div className="p-2">
              {topFaultyMachines.map(({ machine, count }, idx) => (
                <div key={idx} className="flex items-center gap-4 p-4 hover:bg-slate-50 rounded-2xl transition-all">
                   <span className="text-xl font-black text-slate-200 w-6 italic text-left">#{idx + 1}</span>
                   <div className="flex-1 text-left">
                      <p className="text-sm font-black text-slate-900">{machine?.brand} {machine?.model}</p>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{machine?.serialNumber}</p>
                   </div>
                   <div className="bg-rose-50 text-rose-600 px-3 py-1 rounded-lg text-[10px] font-black">
                     {count}x Storing
                   </div>
                </div>
              ))}
              {topFaultyMachines.length === 0 && (
                <div className="p-10 text-center text-[10px] font-black text-slate-300 uppercase tracking-widest">Geen data beschikbaar</div>
              )}
           </div>
        </section>

        <section className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
           <div className="p-6 border-b border-slate-50 flex items-center justify-between bg-slate-50/30">
              <h3 className="text-[10px] font-black text-slate-900 uppercase tracking-[0.2em] flex items-center gap-2">
                <Users className="w-4 h-4 text-blue-500" />
                Top Klanten
              </h3>
           </div>
           <div className="p-2">
              {topCustomers.map(({ customer, count }, idx) => (
                <div key={idx} className="flex items-center gap-4 p-4 hover:bg-slate-50 rounded-2xl transition-all">
                   <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center text-xs font-black text-slate-400">
                      {customer?.name.charAt(0)}
                   </div>
                   <div className="flex-1 text-left">
                      <p className="text-sm font-black text-slate-900 line-clamp-1">{customer?.name}</p>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest truncate">{customer?.email}</p>
                   </div>
                   <div className="bg-blue-50 text-blue-600 px-3 py-1 rounded-lg text-[10px] font-black">
                     {count}x Visit
                   </div>
                </div>
              ))}
              {topCustomers.length === 0 && (
                <div className="p-10 text-center text-[10px] font-black text-slate-300 uppercase tracking-widest">Geen data beschikbaar</div>
              )}
           </div>
        </section>
      </div>

      {/* Open Interventions */}
      <section className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-50 flex items-center justify-between">
          <h2 className="text-[10px] font-black text-slate-900 uppercase tracking-[0.2em] flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-500" />
            Open Interventies
          </h2>
          <button onClick={() => navigate('/interventions')} className="text-[10px] font-black text-blue-600 uppercase tracking-widest hover:underline cursor-pointer">
            Lijst &rarr;
          </button>
        </div>
        <div className="divide-y divide-slate-50">
          {interventions.length > 0 ? (
            interventions.map((i) => (
              <div key={i.id} onClick={() => navigate('/interventions')} className="p-6 hover:bg-slate-50/50 transition-colors flex items-center justify-between gap-4 cursor-pointer">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center shrink-0 border border-blue-100">
                     <Wrench className="w-5 h-5" />
                  </div>
                  <div className="text-left">
                    <h4 className="text-sm font-black text-slate-900">{customers.find(c => c.id === i.customerId)?.name || 'Onbekend'}</h4>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{i.date} • {i.type}</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-300" />
              </div>
            ))
          ) : (
            <div className="p-12 text-center text-slate-400 text-sm italic font-medium">Alle klussen zijn klaar!</div>
          )}
        </div>
      </section>
    </div>
  );
};

export default DashboardLists;
