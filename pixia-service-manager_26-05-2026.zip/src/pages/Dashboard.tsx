import React from 'react';
import { useDashboard } from '../hooks/useDashboard';
import { dashboardService } from '../services/dashboardService'; // Still needed for handleDismissAlert if not in hook
import { updateDoc, doc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import DashboardFilters from '../components/dashboard/DashboardFilters';
import DashboardStats from '../components/dashboard/DashboardStats';
import DashboardCharts from '../components/dashboard/DashboardCharts';
import DashboardAlerts from '../components/dashboard/DashboardAlerts';
import DashboardLists from '../components/dashboard/DashboardLists';
import DashboardQuickActions from '../components/dashboard/DashboardQuickActions';
import DashboardInsights from '../components/dashboard/DashboardInsights';

import { COLLECTIONS } from '../constants/collections';

const Dashboard: React.FC = () => {
  const {
    loading,
    period, setPeriod,
    selectedCustomerId, setSelectedCustomerId,
    selectedMachineType, setSelectedMachineType,
    customers,
    machineTypes,
    statsOverview,
    trendsData,
    typeData,
    statusData,
    topFaultyMachines,
    topCustomers,
    lowStockItems,
    expiringWarrantyCount,
    upcomingMaintenance,
    interventions,
    reminders,
    alerts,
    emailLogs,
    outlookConnection,
    machines,
    refreshData
  } = useDashboard();

  const handleDismissAlert = async (id: string) => {
    try {
      await updateDoc(doc(db, COLLECTIONS.SMART_ALERTS, id), {
        status: 'seen',
        updatedAt: new Date().toISOString()
      });
      refreshData();
    } catch (err) {
      console.error('Error dismissing alert:', err);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-20">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-5 pb-20">
      <DashboardFilters 
        period={period}
        setPeriod={setPeriod}
        selectedCustomerId={selectedCustomerId}
        setSelectedCustomerId={setSelectedCustomerId}
        selectedMachineType={selectedMachineType}
        setSelectedMachineType={setSelectedMachineType}
        customers={customers}
        machineTypes={machineTypes}
      />

      <DashboardStats 
        totalInterventions={statsOverview.total}
        closedInterventions={statsOverview.closed}
        lowStockCount={lowStockItems.length}
        openReminders={reminders.length}
      />

      <DashboardAlerts 
        alerts={alerts}
        onDismiss={handleDismissAlert}
      />

      <DashboardCharts 
        trendsData={trendsData}
        typeData={typeData}
        statusData={statusData}
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-4">
          <DashboardQuickActions 
            outlookConnection={outlookConnection}
            emailLogs={emailLogs}
          />
          <DashboardLists 
            topFaultyMachines={topFaultyMachines}
            topCustomers={topCustomers}
            interventions={interventions}
            customers={customers}
          />
        </div>

        <DashboardInsights 
          lowStockItems={lowStockItems}
          expiringWarrantyCount={expiringWarrantyCount}
          faultyMachinesCount={machines.filter(m => m.status === 'faulty').length}
          upcomingMaintenance={upcomingMaintenance}
          customers={customers}
        />
      </div>
    </div>
  );
};

export default Dashboard;
;
