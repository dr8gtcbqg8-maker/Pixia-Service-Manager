import { useState, useEffect, useCallback } from 'react';
import { Intervention, Customer, Machine, InventoryItem } from '../types';
import { interventionService } from '../services/interventionService';
import { customerService } from '../services/customerService';
import { machineService } from '../services/machineService';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { COLLECTIONS } from '../constants/collections';

export const useInterventions = () => {
  const [interventions, setInterventions] = useState<Intervention[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [machines, setMachines] = useState<Machine[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refreshData = useCallback(async () => {
    setLoading(true);
    try {
      const [iData, cData, mData, invSnap] = await Promise.all([
        interventionService.getAll(),
        customerService.getAll(),
        machineService.getAll(),
        getDocs(collection(db, COLLECTIONS.INVENTORY))
      ]);
      
      setInterventions(iData);
      setCustomers(cData);
      setMachines(mData);
      setInventory(invSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as InventoryItem)));
      setError(null);
    } catch (err) {
      console.error('Error fetching intervention page data:', err);
      setError('Er is een fout opgetreden bij het laden van de gegevens.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  return {
    interventions,
    customers,
    machines,
    inventory,
    loading,
    error,
    refreshData
  };
};
