import React, { useState, useEffect } from 'react';
import { 
  collection, query, where, getDocs, doc, updateDoc, onSnapshot, getDoc, addDoc
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { 
  Calendar, Clock, MapPin, Phone, Navigation, Play, 
  ChevronRight, AlertCircle, Printer, FileText, Plus,
  Hammer, Wrench
} from 'lucide-react';
import { motion } from 'motion/react';
import { format, isToday, parseISO } from 'date-fns';
import { nl } from 'date-fns/locale';
import { 
  Customer, Machine, Intervention, Appointment, WorkOrder, Reminder,
  InterventionStatus
} from '../types';
import { handleFirestoreError, OperationType, cn } from '../lib/utils';
import { logAction } from '../lib/audit';
import { useNavigate } from 'react-router-dom';
import { COLLECTIONS } from '../constants/collections';

const TechnicianToday: React.FC = () => {
  const navigate = useNavigate();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [machines, setMachines] = useState<Machine[]>([]);
  const [interventions, setInterventions] = useState<Intervention[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>([]);
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [custSnap, machSnap] = await Promise.all([
          getDocs(collection(db, COLLECTIONS.CUSTOMERS)),
          getDocs(collection(db, COLLECTIONS.MACHINES))
        ]);
        setCustomers(custSnap.docs.map(d => ({ id: d.id, ...d.data() } as Customer)));
        setMachines(machSnap.docs.map(d => ({ id: d.id, ...d.data() } as Machine)));
      } catch (err) {
        console.error(err);
      }
    };

    fetchData();

    const todayStr = format(new Date(), 'yyyy-MM-dd');

    const unsubInterventions = onSnapshot(
      query(collection(db, COLLECTIONS.INTERVENTIONS), where('date', '==', todayStr)),
      (snap) => {
        setInterventions(snap.docs.map(d => ({ id: d.id, ...d.data() } as Intervention)));
        setIsLoading(false);
      }
    );

    const unsubAppointments = onSnapshot(
      query(collection(db, COLLECTIONS.APPOINTMENTS), where('date', '==', todayStr)),
      (snap) => {
        setAppointments(snap.docs.map(d => ({ id: d.id, ...d.data() } as Appointment)));
      }
    );

    const unsubWorkOrders = onSnapshot(
      query(collection(db, COLLECTIONS.WORK_ORDERS), where('status', 'in', ['draft', 'ready-to-sign'])),
      (snap) => {
        setWorkOrders(snap.docs.map(d => ({ id: d.id, ...d.data() } as WorkOrder)));
      }
    );

    const unsubReminders = onSnapshot(
      query(collection(db, COLLECTIONS.REMINDERS), where('status', '==', 'open'), where('priority', '==', 'urgent')),
      (snap) => {
        setReminders(snap.docs.map(d => ({ id: d.id, ...d.data() } as Reminder)));
      }
    );

    return () => {
      unsubInterventions();
      unsubAppointments();
      unsubWorkOrders();
      unsubReminders();
    };
  }, []);

  const getCustomerName = (id: string) => customers.find(c => c.id === id)?.name || 'Onbekend';
  const getCustomerAddress = (id: string) => customers.find(c => c.id === id)?.address || '';
  const getCustomerPhone = (id: string) => customers.find(c => c.id === id)?.phone || '';
  const getMachineInfo = (id: string) => {
    const m = machines.find(mac => mac.id === id);
    return m ? `${m.brand} ${m.model}` : 'Geen machine';
  };

  const handleUpdateStatus = async (task: any, status: InterventionStatus) => {
    try {
      const data: any = { 
        status, 
        updatedAt: new Date().toISOString() 
      };
      
      if (status === 'in-progress' && !task.startedAt) {
        data.startedAt = new Date().toISOString();
      }

      if (status === 'completed' && !task.stockProcessed && task.partsUsed?.length > 0) {
        for (const part of task.partsUsed) {
          if (!part.itemId) continue;
          const itemRef = doc(db, COLLECTIONS.INVENTORY, part.itemId);
          const itemDoc = await getDoc(itemRef);
          if (itemDoc.exists()) {
             const currentStock = itemDoc.data().stockCount || 0;
             await updateDoc(itemRef, {
                stockCount: currentStock - part.quantity,
                updatedAt: new Date().toISOString()
             });

             await addDoc(collection(db, COLLECTIONS.INVENTORY_MUTATIONS), {
                itemId: part.itemId,
                type: 'intervention',
                quantity: part.quantity,
                interventionId: task.id,
                reason: `Afgerond via Vandaag scherm: Gebruikt voor ${getCustomerName(task.customerId)}`,
                technicianName: task.technicianName || 'Onbekend',
                timestamp: new Date().toISOString()
             });
          }
        }
        data.stockProcessed = true;
      }

      await updateDoc(doc(db, COLLECTIONS.INTERVENTIONS, task.id), data);
      await logAction('Status gewijzigd (Vandaag)', 'intervention', task.id, `Status naar: ${status}`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `interventions/${task.id}`);
    }
  };

  const getStatusLabelText = (status: string) => {
    switch (status) {
      case 'completed': return 'Afgerond';
      case 'in-progress': return 'Bezig';
      case 'on-route': return 'Onderweg';
      case 'planned': return 'Gepland';
      case 'waiting-parts': return 'Wacht op onderdelen';
      default: return 'Gepland';
    }
  };

  type TodayTask = Omit<Partial<Intervention> & Partial<Appointment>, 'type' | 'status'> & { 
    type: string;
    status: string;
    taskType: 'intervention' | 'appointment'; 
    taskTime: string; 
    id: string 
  };

  const todayTasks: TodayTask[] = [
    ...interventions.map(i => ({ ...i, taskType: 'intervention' as const, taskTime: i.time || '00:00' })),
    ...appointments.filter(a => !a.interventionId).map(a => ({ ...a, taskType: 'appointment' as const, taskTime: a.startTime || '00:00' })),
  ].sort((a, b) => a.taskTime.localeCompare(b.taskTime));

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto pb-24 space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between mb-2">
        <div>
          <h1 className="text-2xl font-bold text-surface-900">Vandaag</h1>
          <p className="text-sm font-medium text-brand-500 mt-0.5">
            {format(new Date(), 'EEEE d MMMM', { locale: nl })}
          </p>
        </div>
        <button 
          onClick={() => navigate('/interventions?new=true')}
          className="w-12 h-12 bg-white border border-surface-200 text-surface-600 rounded-md flex items-center justify-center shadow-sm hover:bg-surface-50 transition-all active:scale-95"
          aria-label="Nieuwe Interventie"
        >
          <Plus className="w-6 h-6" />
        </button>
      </div>

      {/* Urgent Alerts */}
      {reminders.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-rose-600 uppercase tracking-wider px-1 flex items-center gap-2">
            <AlertCircle className="w-3.5 h-3.5" />
            Urgent ({reminders.length})
          </h3>
          {reminders.map(r => (
            <motion.div 
              key={r.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 bg-rose-50 border border-rose-100 rounded-md flex items-center gap-4 hover:bg-rose-100 transition-colors cursor-pointer group"
              onClick={() => navigate('/reminders')}
            >
              <div className="w-10 h-10 bg-rose-500 rounded-lg flex items-center justify-center shrink-0 shadow-sm">
                <AlertCircle className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-rose-900 truncate">{r.title}</p>
                <p className="text-xs font-medium text-rose-700 mt-0.5">{getCustomerName(r.customerId || '')}</p>
              </div>
              <ChevronRight className="w-5 h-5 text-rose-300 group-hover:translate-x-1 transition-transform" />
            </motion.div>
          ))}
        </div>
      )}

      {/* Main List */}
      <div className="space-y-4">
        <h3 className="text-xs font-bold text-surface-500 uppercase tracking-wider px-1">Planning</h3>
        
        {todayTasks.length === 0 ? (
          <div className="bg-white border border-surface-200 rounded-lg p-5 text-center space-y-4 shadow-sm">
            <div className="w-16 h-16 bg-surface-50 rounded-lg flex items-center justify-center text-surface-300 mx-auto">
              <Calendar className="w-8 h-8" />
            </div>
            <div>
              <p className="text-surface-500 font-medium text-sm">Geen taken voor vandaag</p>
              <button 
                onClick={() => navigate('/calendar')}
                className="text-brand-500 font-semibold text-sm mt-2 hover:underline"
              >
                Bekijk volledige planning
              </button>
            </div>
          </div>
        ) : (
          todayTasks.map((task) => (
            <motion.div 
              key={`${task.taskType}-${task.id}`}
              className={cn(
                "bg-white border rounded-lg p-5 shadow-sm space-y-4 transition-all relative overflow-hidden",
                task.status === 'in-progress' ? 'border-blue-300 ring-4 ring-blue-50' : 'border-surface-200'
              )}
            >
              {task.priority === 'urgent' && (
                <div className="absolute top-0 right-0">
                  <div className="bg-rose-500 text-white text-[10px] font-bold uppercase tracking-wider px-3 py-1 rounded-bl-lg">
                    Urgent
                  </div>
                </div>
              )}

              <div 
                className="flex items-start justify-between cursor-pointer"
                onClick={() => task.taskType === 'intervention' ? navigate(`/interventions?id=${task.id}`) : null}
              >
                <div className="space-y-2.5 flex-1">
                   <div className="flex items-center gap-2">
                     <div className="flex items-center gap-1.5 bg-surface-100 text-surface-600 px-2 py-1 rounded-md">
                        <Clock className="w-3.5 h-3.5" />
                        <span className="text-[11px] font-bold">{task.taskTime}</span>
                     </div>
                     <span className={cn(
                       "text-[11px] font-bold px-2 py-1 rounded-md border uppercase tracking-wider",
                       task.status === 'completed' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' :
                       task.status === 'in-progress' ? 'bg-brand-500 text-white border-blue-600' :
                       task.status === 'on-route' ? 'bg-amber-50 text-amber-700 border-amber-100' :
                       'bg-surface-50 text-surface-500 border-surface-200'
                     )}>
                       {getStatusLabelText(task.status || 'planned')}
                     </span>
                   </div>
                   <h3 className="text-base font-bold text-surface-900 leading-snug">
                     {getCustomerName(task.customerId)}
                   </h3>
                   <div className="flex items-center gap-2 text-surface-500">
                     <Printer className="w-4 h-4" />
                     <span className="text-xs font-semibold">{getMachineInfo(task.machineId)}</span>
                   </div>
                </div>
                <div className="shrink-0 ml-4">
                  <div className={cn(
                    "w-12 h-12 rounded-md flex items-center justify-center transition-all",
                    task.status === 'in-progress' ? 'bg-brand-500 shadow-md ring-4 ring-blue-100' : 'bg-surface-100 text-surface-400'
                  )}>
                    {task.taskType === 'intervention' ? (
                      <Wrench className={cn("w-6 h-6", task.status === 'in-progress' ? 'text-white' : '')} />
                    ) : (
                      <Calendar className={cn("w-6 h-6", task.status === 'in-progress' ? 'text-white' : '')} />
                    )}
                  </div>
                </div>
              </div>

              {/* Location Bar */}
              <button 
                onClick={() => window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(getCustomerAddress(task.customerId))}`, '_blank')}
                className="w-full flex items-center gap-3 bg-surface-50 p-3 rounded-md hover:bg-surface-100 transition-colors border border-surface-200/50 text-left"
              >
                <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center shadow-sm shrink-0 border border-surface-200/50">
                   <MapPin className="w-4 h-4 text-rose-500" />
                </div>
                <span className="text-xs font-semibold text-surface-600 truncate flex-1">{getCustomerAddress(task.customerId)}</span>
                <Navigation className="w-4 h-4 text-surface-400" />
              </button>

              {/* Problem Description Snippet */}
              {task.problemDescription && (
                <div className="bg-amber-50/50 border border-amber-100 p-3 rounded-md text-xs text-amber-900 leading-relaxed">
                  <span className="font-bold text-amber-700 mr-2 uppercase text-[10px]">Probleem:</span>
                  {task.problemDescription}
                </div>
              )}

              {/* Actions */}
              <div className="grid grid-cols-2 gap-2 pt-1">
                {task.taskType === 'intervention' && task.status === 'planned' ? (
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      handleUpdateStatus(task, 'on-route');
                    }}
                    className="btn-primary col-span-2 h-12"
                  >
                    <Navigation className="w-4 h-4" /> Start route
                  </button>
                ) : task.taskType === 'intervention' && task.status === 'on-route' ? (
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      handleUpdateStatus(task, 'in-progress');
                    }}
                    className="btn-primary col-span-2 h-12 !bg-amber-600 hover:!bg-amber-700"
                  >
                    <Play className="w-4 h-4 fill-current" /> Ik ben aangekomen
                  </button>
                ) : task.taskType === 'intervention' && task.status === 'in-progress' ? (
                   <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      navigate(`/work-orders?interventionId=${task.id}`);
                    }}
                    className="btn-primary col-span-2 h-12 !bg-emerald-600 hover:!bg-emerald-700"
                  >
                    <ChevronRight className="w-4 h-4" /> Werkbon invullen
                  </button>
                ) : (
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      if (task.taskType === 'intervention') {
                        navigate(`/interventions?id=${task.id}`);
                      }
                    }}
                    className="btn-secondary col-span-2 h-12"
                  >
                    Details bekijken
                  </button>
                )}
                
                <div className="contents">
                  <a 
                    href={`tel:${getCustomerPhone(task.customerId || '')}`} 
                    onClick={(e) => e.stopPropagation()}
                    className={cn(
                      "btn-secondary h-12",
                      !getCustomerPhone(task.customerId || '') && "opacity-50 pointer-events-none"
                    )}
                    aria-label="Bel klant"
                  >
                    <Phone className="w-4 h-4" />
                  </a>
                  <a 
                    href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(getCustomerAddress(task.customerId || ''))}`}
                    target="_blank"
                    rel="noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className={cn(
                      "btn-secondary h-12",
                      !getCustomerAddress(task.customerId || '') && "opacity-50 pointer-events-none"
                    )}
                    aria-label="Navigeer"
                  >
                    <Navigation className="w-4 h-4" />
                  </a>
                </div>
              </div>
            </motion.div>
          ))
        )}
      </div>

      {/* Open Work Orders */}
      {workOrders.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-surface-500 uppercase tracking-wider px-1">Concept Werkbonnen ({workOrders.length})</h3>
          <div className="grid grid-cols-1 gap-2">
            {workOrders.map(wo => (
              <button 
                key={wo.id}
                onClick={() => navigate('/work-orders')}
                className="p-4 bg-white border border-surface-200 rounded-md flex items-center justify-between group hover:bg-surface-50 transition-all text-left shadow-sm"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-brand-50 rounded-lg flex items-center justify-center border border-brand-200 shrink-0">
                    <FileText className="w-5 h-5 text-brand-500" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-surface-900">{getCustomerName(wo.customerId)}</p>
                    <p className="text-[11px] font-medium text-surface-500 uppercase tracking-wider mt-0.5">{wo.status}</p>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-surface-300 group-hover:text-blue-500 group-hover:translate-x-1 transition-all" />
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default TechnicianToday;
