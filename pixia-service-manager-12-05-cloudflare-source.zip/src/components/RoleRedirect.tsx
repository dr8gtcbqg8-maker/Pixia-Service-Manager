import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Loader2 } from 'lucide-react';

export const RoleRedirect: React.FC = () => {
  const { profile, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading) {
      if (profile?.role === 'technician') {
        navigate('/vandaag', { replace: true });
      } else if (profile?.role === 'customer') {
        navigate('/customer-portal', { replace: true });
      } else {
        // admin or planner
        navigate('/dashboard', { replace: true });
      }
    }
  }, [profile, loading, navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50">
      <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
    </div>
  );
};
