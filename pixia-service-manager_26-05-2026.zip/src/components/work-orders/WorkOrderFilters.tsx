import React from 'react';
import { Search } from 'lucide-react';

interface WorkOrderFiltersProps {
  search: string;
  setSearch: (s: string) => void;
}

const WorkOrderFilters: React.FC<WorkOrderFiltersProps> = ({ search, setSearch }) => {
  return (
    <div className="bg-white px-5 py-4 rounded-lg border border-surface-200 shadow-sm">
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
        <input 
          type="text" 
          placeholder="Zoek op bonnummer of klant..." 
          className="input-field pl-12"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>
    </div>
  );
};

export default WorkOrderFilters;
