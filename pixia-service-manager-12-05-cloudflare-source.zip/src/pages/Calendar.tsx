import React, { useEffect, useState, useMemo, useCallback } from 'react';
import { collection, query, getDocs, orderBy, where, addDoc, updateDoc, doc, deleteDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { 
  Appointment, Customer, Machine, Intervention, Reminder, 
  InterventionStatus, ReminderPriority, InventoryItem,
  AppointmentType, AppointmentPriority
} from '../types';
import { 
  Calendar as CalendarIcon, ChevronLeft, ChevronRight, Plus, 
  Clock, MapPin, User, Printer, AlertCircle, CheckCircle2, 
  X, Mail, Bell, Wrench, ShieldAlert, History, Trash2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  format, addMonths, subMonths, startOfMonth, endOfMonth, 
  eachDayOfInterval, isSameMonth, isSameDay, addDays, 
  startOfWeek, endOfWeek, parseISO, isToday,
  startOfDay, endOfDay
} from 'date-fns';
import { nl } from 'date-fns/locale';
import { useNavigate } from 'react-router-dom';
import { handleFirestoreError, OperationType, cn } from '../lib/utils';
import AppointmentModal from '../components/AppointmentModal';
import { logAction } from '../lib/audit';
import ConfirmDialog from '../components/ConfirmDialog';
import { COLLECTIONS } from '../constants/collections';

const Calendar: React.FC = () => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewMode, setViewMode] = useState<'month' | 'week' | 'day' | 'list'>('month');
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [interventions, setInterventions] = useState<Intervention[]>([]);
  const [machines, setMachines] = useState<Machine[]>([]);
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [technicians, setTechnicians] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null);
  const [detailPanelOpen, setDetailPanelOpen] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<any>(null);

  const [filters, setFilters] = useState({
    type: 'all',
    status: 'all',
    priority: 'all',
    customerId: 'all',
    technicianId: 'all',
    search: ''
  });

  const [initialData, setInitialData] = useState<{
    date?: string;
    reminderId?: string;
    interventionId?: string;
    customerId?: string;
    machineId?: string;
  }>({});

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const Collections = COLLECTIONS as any;
      const [appSnap, intSnap, machSnap, remSnap, custSnap, invSnap, userSnap] = await Promise.all([
        getDocs(collection(db, Collections.APPOINTMENTS || 'appointments')),
        getDocs(collection(db, Collections.INTERVENTIONS)),
        getDocs(collection(db, Collections.MACHINES)),
        getDocs(collection(db, Collections.REMINDERS)),
        getDocs(collection(db, Collections.CUSTOMERS)),
        getDocs(collection(db, Collections.INVENTORY)),
        getDocs(query(collection(db, Collections.USERS), where('role', '==', 'technician')))
      ]);

      setAppointments(appSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Appointment)));
      setInterventions(intSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Intervention)));
      setMachines(machSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Machine)));
      setReminders(remSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Reminder)));
      setCustomers(custSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Customer)));
      setInventory(invSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as InventoryItem)));
      setTechnicians(userSnap.docs.map(doc => ({ uid: doc.id, ...doc.data() })));
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'calendar_data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, []);

  // Unified Event Mapper
  const filteredEvents = useMemo(() => {
    const events: any[] = [];

    // 1. Explicit Appointments
    appointments.forEach(app => {
      events.push({
        ...app,
        sourceType: 'appointment',
        start: parseISO(`${app.date}T${app.startTime || '00:00'}`),
        end: parseISO(`${app.endDate || app.date}T${app.endTime || '23:59'}`),
      });
    });

    // 2. Interventions (not already linked to appointments)
    interventions.forEach(int => {
      const linkedApp = appointments.find(a => a.interventionId === int.id);
      if (!linkedApp) {
        events.push({
          id: int.id,
          title: `Interventie: ${int.type}`,
          customerId: int.customerId,
          machineId: int.machineId,
          date: int.date,
          endDate: int.endDate,
          startTime: '09:00',
          endTime: '10:00',
          type: int.type as AppointmentType,
          priority: int.priority || 'normal',
          status: int.status === 'completed' ? 'completed' : int.status === 'planned' ? 'planned' : 'waiting',
          description: int.problemDescription,
          interventionId: int.id,
          sourceType: 'intervention',
          start: parseISO(`${int.date}T09:00`),
          end: parseISO(`${int.endDate || int.date}T10:00`),
        });
      }
    });

    // 3. Reminders (not already linked to appointments)
    reminders.forEach(rem => {
      const linkedApp = appointments.find(a => a.reminderId === rem.id);
      if (!linkedApp) {
        events.push({
          id: rem.id,
          title: `Herinnering: ${rem.title}`,
          customerId: rem.customerId,
          machineId: rem.machineId,
          date: rem.dueDate,
          startTime: '08:00',
          endTime: '08:30',
          type: 'follow-up', // Default for reminders
          priority: rem.priority,
          status: rem.status === 'executed' ? 'completed' : 'planned',
          description: rem.description,
          reminderId: rem.id,
          sourceType: 'reminder',
          start: parseISO(`${rem.dueDate}T08:00`),
          end: parseISO(`${rem.dueDate}T08:30`),
        });
      }
    });

    // 4. Warranties & Next Maintenance (as milestones)
    machines.forEach(m => {
      if (m.nextMaintenanceDate) {
        events.push({
          id: `maint-${m.id}`,
          title: `Onderhoud: ${m.brand} ${m.model}`,
          customerId: m.customerId,
          machineId: m.id,
          date: m.nextMaintenanceDate,
          startTime: '10:00',
          endTime: '11:00',
          type: 'maintenance',
          priority: 'high',
          status: 'planned',
          description: `Periodiek onderhoud voor machine ${m.serialNumber}`,
          sourceType: 'machine_milestone',
          start: parseISO(`${m.nextMaintenanceDate}T10:00`),
          end: parseISO(`${m.nextMaintenanceDate}T11:00`),
        });
      }
      if (m.warrantyEndDate) {
        events.push({
          id: `warranty-${m.id}`,
          title: `Garantie Verloopt: ${m.brand} ${m.model}`,
          customerId: m.customerId,
          machineId: m.id,
          date: m.warrantyEndDate,
          startTime: '09:00',
          endTime: '09:30',
          type: 'warranty',
          priority: 'urgent',
          status: 'waiting',
          description: `Einde garantieperiode voor machine ${m.serialNumber}`,
          sourceType: 'machine_milestone',
          start: parseISO(`${m.warrantyEndDate}T09:00`),
          end: parseISO(`${m.warrantyEndDate}T09:30`),
        });
      }
    });

    // 5. Stock Alerts
    inventory.forEach(item => {
      if (item.stockCount <= item.minStock && item.status === 'active') {
        const todayStr = format(new Date(), 'yyyy-MM-dd');
        events.push({
          id: `stock-${item.id}`,
          title: `Lage Voorraad: ${item.name}`,
          date: todayStr, // Today as milestone
          startTime: '08:00',
          endTime: '09:00',
          type: 'stock',
          priority: 'high',
          status: 'waiting',
          description: `Voorraad van ${item.name} is ${item.stockCount}, minimum is ${item.minStock}.`,
          sourceType: 'stock_alert',
          start: parseISO(`${todayStr}T08:00`),
          end: parseISO(`${todayStr}T09:00`),
        });
      }
    });

    // Filters
    return events.filter(e => {
      if (filters.type !== 'all' && e.type !== filters.type) return false;
      if (filters.status !== 'all' && e.status !== filters.status) return false;
      if (filters.priority !== 'all' && e.priority !== filters.priority) return false;
      if (filters.customerId !== 'all' && e.customerId !== filters.customerId) return false;
      if (filters.technicianId !== 'all' && e.technicianId !== filters.technicianId) return false;
      if (filters.search) {
        const search = filters.search.toLowerCase();
        return (
          e.title.toLowerCase().includes(search) ||
          e.description?.toLowerCase().includes(search)
        );
      }
      return true;
    });
  }, [appointments, interventions, machines, reminders, inventory, filters]);

  const next = () => {
    if (viewMode === 'month') setCurrentDate(addMonths(currentDate, 1));
    else if (viewMode === 'week') setCurrentDate(addDays(currentDate, 7));
    else setCurrentDate(addDays(currentDate, 1));
  };

  const prev = () => {
    if (viewMode === 'month') setCurrentDate(subMonths(currentDate, 1));
    else if (viewMode === 'week') setCurrentDate(addDays(currentDate, -7));
    else setCurrentDate(addDays(currentDate, -1));
  };

  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(monthStart);
  const startDate = startOfWeek(monthStart, { weekStartsOn: 1 });
  const endDate = endOfWeek(monthEnd, { weekStartsOn: 1 });

  const calendarDays = useMemo(() => eachDayOfInterval({ start: startDate, end: endDate }), [startDate, endDate]);

  const getDayEvents = useCallback((day: Date) => {
    const dayStart = startOfDay(day);
    const dayEnd = endOfDay(day);
    
    return filteredEvents.filter(e => {
      // Check if event start or end falls within this day, OR if day is between start and end
      return (e.start <= dayEnd && e.end >= dayStart);
    });
  }, [filteredEvents]);

  const handleEventClick = (event: any) => {
    setSelectedEvent(event);
    setDetailPanelOpen(true);
  };

  const handleDragStart = (e: React.DragEvent, eventId: string) => {
    e.dataTransfer.setData('appointmentId', eventId);
  };

  const handleDrop = async (e: React.DragEvent, date: Date) => {
    e.preventDefault();
    const appointmentId = e.dataTransfer.getData('appointmentId');
    const newDateStr = format(date, 'yyyy-MM-dd');
    
    // Alleen verplaatsen voor echte appointments (niet voor milestones)
    const app = appointments.find(a => a.id === appointmentId);
    if (!app) return;

    try {
      // Conflict detectie
      if (app.technicianId) {
        const hasConflict = appointments.some(a => 
          a.id !== appointmentId && 
          a.technicianId === app.technicianId && 
          a.date === newDateStr &&
          ((a.startTime < app.endTime && a.endTime > app.startTime))
        );

        if (hasConflict) {
          if (!window.confirm('Er is een overlap voor deze technicus op deze dag. Wil je toch doorgaan?')) {
            return;
          }
        }
      }

      await updateDoc(doc(db, COLLECTIONS.APPOINTMENTS || 'appointments', appointmentId), {
        date: newDateStr,
        updatedAt: new Date().toISOString()
      });
      fetchData();
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'appointment_move');
    }
  };

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const getEventStyle = (type: AppointmentType) => {
    switch (type) {
      case 'maintenance': return 'bg-blue-50 border-blue-100 text-blue-700';
      case 'fault': return 'bg-rose-50 border-rose-100 text-rose-700';
      case 'installation': return 'bg-indigo-50 border-indigo-100 text-indigo-700';
      case 'follow-up': return 'bg-amber-50 border-amber-100 text-amber-700';
      case 'warranty': return 'bg-purple-50 border-purple-100 text-purple-700';
      case 'contract': return 'bg-emerald-50 border-emerald-100 text-emerald-700';
      case 'stock': return 'bg-orange-50 border-orange-100 text-orange-700';
      default: return 'bg-slate-50 border-slate-100 text-slate-700';
    }
  };

  const getEventIcon = (type: AppointmentType) => {
    switch (type) {
      case 'maintenance': return History;
      case 'fault': return AlertCircle;
      case 'installation': return Wrench;
      case 'follow-up': return Bell;
      case 'warranty': return ShieldAlert;
      case 'contract': return CheckCircle2;
      case 'stock': return Plus;
      default: return CalendarIcon;
    }
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 flex items-center gap-3">
            Planning & Agenda
            <CalendarIcon className="w-8 h-8 text-blue-500" />
          </h1>
          <p className="text-slate-500 font-medium text-sm mt-1">Beheer alle werkzaamheden en service afspraken</p>
        </div>
        
        <div className="flex flex-wrap items-center gap-3">
          <div className="bg-white p-1 rounded-xl flex items-center border border-slate-200 shadow-sm overflow-x-auto">
            {(['month', 'week', 'day', 'list'] as const).map((mode) => (
              <button
                key={mode}
                onClick={() => setViewMode(mode)}
                className={cn(
                  "px-4 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap",
                  viewMode === mode 
                    ? "bg-slate-900 text-white shadow-sm" 
                    : "text-slate-500 hover:text-slate-700 hover:bg-slate-50"
                )}
              >
                {mode === 'month' ? 'Maand' : mode === 'week' ? 'Week' : mode === 'day' ? 'Dag' : 'Lijst'}
              </button>
            ))}
          </div>
          <button 
            onClick={() => {
              setSelectedAppointment(null);
              setInitialData({});
              setIsModalOpen(true);
            }}
            className="btn-primary"
          >
            <Plus className="w-4 h-4" />
            <span>Nieuwe Afspraak</span>
          </button>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center gap-4">
        <div className="flex-1 min-w-[240px]">
          <div className="relative">
            <input 
              type="text"
              placeholder="Zoeken op titel..."
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm font-medium focus:ring-2 focus:ring-blue-500/20 outline-none transition-all placeholder:text-slate-400"
              value={filters.search}
              onChange={(e) => setFilters({ ...filters, search: e.target.value })}
            />
            <CalendarIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          </div>
        </div>
        <select 
          className="input-field max-w-[200px]"
          value={filters.technicianId}
          onChange={(e) => setFilters({ ...filters, technicianId: e.target.value })}
        >
          <option value="all">Alle Technici</option>
          {technicians.map(t => (
            <option key={t.uid} value={t.uid}>{t.displayName || t.email}</option>
          ))}
        </select>
        <select 
          className="input-field max-w-[150px]"
          value={filters.type}
          onChange={(e) => setFilters({ ...filters, type: e.target.value })}
        >
          <option value="all">Alle Types</option>
          <option value="maintenance">Onderhoud</option>
          <option value="fault">Storing</option>
          <option value="installation">Installatie</option>
          <option value="follow-up">Follow-up</option>
          <option value="warranty">Garantie</option>
        </select>
        <select 
          className="input-field max-w-[150px]"
          value={filters.status}
          onChange={(e) => setFilters({ ...filters, status: e.target.value })}
        >
          <option value="all">Alle Statussen</option>
          <option value="planned">Gepland</option>
          <option value="in-progress">Bezig</option>
          <option value="completed">Afgerond</option>
          <option value="waiting">Wacht op klant</option>
        </select>
      </div>

      {/* Calendar Content */}
      <div className="bg-white border border-slate-100 rounded-[3.5rem] shadow-sm overflow-hidden">
        {/* Navigation Header */}
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <h2 className="text-xl font-bold text-slate-900 capitalize tracking-tight">
            {viewMode === 'month' ? format(currentDate, 'MMMM yyyy', { locale: nl }) : 
             viewMode === 'week' ? `Week ${format(currentDate, 'w')}, ${format(currentDate, 'yyyy')}` :
             format(currentDate, 'd MMMM yyyy', { locale: nl })}
          </h2>
          <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-200 shadow-sm">
            <button onClick={prev} className="p-2 hover:bg-slate-50 rounded-lg text-slate-500 transition-colors">
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button 
              onClick={() => setCurrentDate(new Date())}
              className="px-4 py-1.5 text-xs font-bold text-slate-600 hover:bg-slate-50 rounded-lg transition-colors"
            >
              Vandaag
            </button>
            <button onClick={next} className="p-2 hover:bg-slate-50 rounded-lg text-slate-500 transition-colors">
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Views */}
        {viewMode === 'month' && (
          <>
            <div className="grid grid-cols-7 border-b border-slate-100">
              {['Ma', 'Di', 'Wo', 'Do', 'Vr', 'Za', 'Zo'].map(day => (
                <div key={day} className="py-3 text-center text-xs font-bold text-slate-500 uppercase tracking-wider border-r border-slate-100 last:border-0 bg-slate-50/50">
                  {day}
                </div>
              ))}
            </div>
            <div className="grid grid-cols-7 border-b border-slate-100">
              {calendarDays.map((day) => {
                const dayEvents = getDayEvents(day);
                return (
                  <div 
                    key={day.toISOString()} 
                    onDragOver={onDragOver}
                    onDrop={(e) => handleDrop(e, day)}
                    className={`min-h-[160px] p-2 border-r border-b border-slate-50 last:border-r-0 relative group transition-all hover:bg-slate-50/50 ${!isSameMonth(day, currentDate) ? 'bg-slate-50/20 opacity-40' : ''}`}
                  >
                    <div className="flex items-center justify-between mb-2 p-1">
                      <span className={`text-xs font-black p-1.5 rounded-lg w-8 h-8 flex items-center justify-center ${isToday(day) ? 'bg-blue-600 text-white shadow-lg shadow-blue-200' : 'text-slate-400'}`}>
                        {format(day, 'd')}
                      </span>
                    </div>

                    <div className="space-y-1">
                      {dayEvents.map(event => {
                        const Icon = getEventIcon(event.type);
                        return (
                          <button 
                            key={event.id} 
                            onClick={() => handleEventClick(event)}
                            draggable={event.sourceType === 'appointment'}
                            onDragStart={(e) => handleDragStart(e, event.id)}
                            className={`w-full text-left p-1.5 border rounded-lg text-[9px] font-bold truncate transition-all flex items-center gap-1 cursor-grab active:cursor-grabbing ${getEventStyle(event.type)}`}
                          >
                            <Icon className="w-2.5 h-2.5 shrink-0" />
                            {event.title}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}

        {viewMode === 'week' && (
          <div className="flex flex-col">
            <div className="grid grid-cols-8 border-b border-slate-100">
              <div className="p-4 border-r border-slate-50 overflow-hidden"></div>
              {eachDayOfInterval({ 
                start: startOfWeek(currentDate, { weekStartsOn: 1 }), 
                end: endOfWeek(currentDate, { weekStartsOn: 1 }) 
              }).map(day => (
                <div key={day.toISOString()} className="p-4 text-center border-r border-slate-50 last:border-0">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{format(day, 'eee', { locale: nl })}</p>
                  <p className={`text-sm font-black mt-1 ${isToday(day) ? 'text-blue-600' : 'text-slate-900'}`}>{format(day, 'd MMM')}</p>
                </div>
              ))}
            </div>
            <div className="max-h-[800px] overflow-y-auto">
              <div className="grid grid-cols-8">
                <div className="border-r border-slate-50 bg-slate-50/30">
                  {Array.from({ length: 24 }).map((_, i) => (
                    <div key={i} className="h-20 border-b border-slate-100 p-2 text-right">
                       <span className="text-[10px] font-black text-slate-300">{i}:00</span>
                    </div>
                  ))}
                </div>
                {eachDayOfInterval({ 
                  start: startOfWeek(currentDate, { weekStartsOn: 1 }), 
                  end: endOfWeek(currentDate, { weekStartsOn: 1 }) 
                }).map(day => (
                  <div 
                    key={day.toISOString()} 
                    onDragOver={onDragOver}
                    onDrop={(e) => handleDrop(e, day)}
                    className="relative border-r border-slate-50 last:border-0 bg-white min-h-[1920px]"
                  >
                    {Array.from({ length: 24 }).map((_, i) => (
                      <div key={i} className="h-20 border-b border-slate-100"></div>
                    ))}
                    {getDayEvents(day).map(event => {
                      const startHour = event.start.getHours();
                      const startMinutes = event.start.getMinutes();
                      const endHour = event.end.getHours();
                      const endMinutes = event.end.getMinutes();
                      const top = (startHour * 80) + (startMinutes * (80/60));
                      const height = Math.max(40, ((endHour * 80) + (endMinutes * (80/60))) - top);
                      const Icon = getEventIcon(event.type);

                      return (
                        <button
                          key={event.id}
                          onClick={() => handleEventClick(event)}
                          draggable={event.sourceType === 'appointment'}
                          onDragStart={(e) => handleDragStart(e, event.id)}
                          className={`absolute left-1 right-1 p-2 border rounded-xl text-[9px] font-black shadow-sm overflow-hidden flex flex-col gap-1 transition-all hover:shadow-lg hover:z-10 cursor-grab active:cursor-grabbing ${getEventStyle(event.type)}`}
                          style={{ top, height }}
                        >
                          <div className="flex items-center gap-1">
                            <Icon className="w-3 h-3 shrink-0" />
                            <span className="truncate">{event.title}</span>
                          </div>
                          <span className="opacity-60">{format(event.start, 'HH:mm')}</span>
                        </button>
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {viewMode === 'day' && (
          <div className="flex flex-col">
            <div className="max-h-[800px] overflow-y-auto">
              <div className="grid grid-cols-[100px_1fr]">
                <div className="border-r border-slate-50 bg-slate-50/30">
                  {Array.from({ length: 24 }).map((_, i) => (
                    <div key={i} className="h-24 border-b border-slate-100 p-4 text-right">
                       <span className="text-xs font-black text-slate-300 italic">{i}:00</span>
                    </div>
                  ))}
                </div>
                <div 
                  onDragOver={onDragOver}
                  onDrop={(e) => handleDrop(e, currentDate)}
                  className="relative bg-white min-h-[2304px]"
                >
                  {Array.from({ length: 24 }).map((_, i) => (
                    <div key={i} className="h-24 border-b border-slate-100"></div>
                  ))}
                  {getDayEvents(currentDate).map(event => {
                    const startHour = event.start.getHours();
                    const startMinutes = event.start.getMinutes();
                    const endHour = event.end.getHours();
                    const endMinutes = event.end.getMinutes();
                    const top = (startHour * 96) + (startMinutes * (96/60));
                    const height = Math.max(60, ((endHour * 96) + (endMinutes * (96/60))) - top);
                    const Icon = getEventIcon(event.type);

                    return (
                      <button
                        key={event.id}
                        onClick={() => handleEventClick(event)}
                        draggable={event.sourceType === 'appointment'}
                        onDragStart={(e) => handleDragStart(e, event.id)}
                        className={`absolute left-4 right-4 p-4 border rounded-2xl text-xs font-black shadow-md overflow-hidden flex flex-col gap-1 transition-all hover:shadow-xl hover:z-10 cursor-grab active:cursor-grabbing ${getEventStyle(event.type)}`}
                        style={{ top, height }}
                      >
                        <div className="flex items-center gap-2">
                          <Icon className="w-4 h-4 shrink-0" />
                          <span className="truncate text-base">{event.title}</span>
                        </div>
                        <div className="flex items-center gap-4 mt-2 opacity-70">
                           <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {format(event.start, 'HH:mm')} - {format(event.end, 'HH:mm')}</span>
                           <span className="flex items-center gap-1 uppercase tracking-widest text-[10px]"><MapPin className="w-3 h-3" /> {event.location || 'Geen locatie'}</span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )}

        {viewMode === 'list' && (
          <div className="divide-y divide-slate-50">
            {filteredEvents.length === 0 ? (
              <div className="p-20 text-center text-slate-400 font-medium">Geen items gevonden voor deze selectie.</div>
            ) : (
              filteredEvents
                .sort((a, b) => a.start.getTime() - b.start.getTime())
                .map(event => {
                  const Icon = getEventIcon(event.type);
                  const customer = customers.find(c => c.id === event.customerId);
                  return (
                    <div 
                      key={event.id} 
                      onClick={() => handleEventClick(event)}
                      className="p-6 hover:bg-slate-50 transition-all flex items-center justify-between group cursor-pointer"
                    >
                      <div className="flex items-center gap-6">
                        <div className="text-center min-w-[60px]">
                           <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{format(event.start, 'MMM')}</p>
                           <p className="text-2xl font-black italic text-slate-900">{format(event.start, 'd')}</p>
                        </div>
                        <div className={`p-4 rounded-2xl border ${getEventStyle(event.type)}`}>
                           <Icon className="w-6 h-6" />
                        </div>
                        <div>
                          <p className="font-bold text-slate-900">{event.title}</p>
                          <div className="flex items-center gap-4 mt-1">
                            <span className="flex items-center gap-1 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                              <Clock className="w-3 h-3" />
                              {format(event.start, 'HH:mm')} - {format(event.end, 'HH:mm')}
                            </span>
                            {customer && (
                              <span className="flex items-center gap-1 text-[10px] font-bold text-blue-600 uppercase tracking-widest">
                                <User className="w-3 h-3" />
                                {customer.name}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                      <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-blue-500 transition-colors" />
                    </div>
                  );
                })
            )}
          </div>
        )}
      </div>

      <AppointmentModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        appointment={selectedAppointment}
        initialData={initialData}
        onSave={() => {
          fetchData();
          setIsModalOpen(false);
        }}
        customers={customers}
        machines={machines}
        reminders={reminders}
        interventions={interventions}
      />

      <DetailSidePanel 
        isOpen={detailPanelOpen}
        onClose={() => setDetailPanelOpen(false)}
        event={selectedEvent}
        onEdit={() => {
          if (selectedEvent.sourceType === 'appointment') {
            setSelectedAppointment(selectedEvent);
            setIsModalOpen(true);
            setDetailPanelOpen(false);
          }
        }}
        onRefresh={fetchData}
        customers={customers}
        machines={machines}
      />
    </div>
  );
};

// --- Helper Component: DetailSidePanel ---
const DetailSidePanel: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  event: any;
  onEdit: () => void;
  onRefresh: () => void;
  customers: Customer[];
  machines: Machine[];
}> = ({ isOpen, onClose, event, onEdit, onRefresh, customers, machines }) => {
  if (!event) return null;

  const customer = customers.find(c => c.id === event.customerId);
  const machine = machines.find(m => m.id === event.machineId);
  const navigate = useNavigate();

  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);

  const handleStatusChange = async (newStatus: any) => {
    try {
      const collectionName = event.sourceType === 'reminder' ? COLLECTIONS.REMINDERS : 
                            event.sourceType === 'intervention' ? COLLECTIONS.INTERVENTIONS : 
                            COLLECTIONS.APPOINTMENTS || 'appointments';
      const docRef = doc(db, collectionName, event.id);
      await updateDoc(docRef, { 
        status: newStatus,
        updatedAt: new Date().toISOString()
      });
      await logAction('Status gewijzigd via kalender', event.sourceType === 'appointment' ? 'appointment' : event.sourceType === 'reminder' ? 'reminder' : 'intervention' as any, event.id, `Nieuwe status: ${newStatus}`, 'calendar');
      onRefresh();
      onClose();
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'status_update');
    }
  };

  const handleDelete = async () => {
    try {
      const collectionName = event.sourceType === 'reminder' ? COLLECTIONS.REMINDERS : 
                            event.sourceType === 'intervention' ? COLLECTIONS.INTERVENTIONS : 
                            COLLECTIONS.APPOINTMENTS || 'appointments';
      
      if (['machine_milestone', 'stock_alert'].includes(event.sourceType)) {
        alert('Dit is een automatisch gegenereerd item en kan niet direct verwijderd worden.');
        return;
      }

      await deleteDoc(doc(db, collectionName, event.id));
      await logAction('Verwijderd via kalender', event.sourceType === 'appointment' ? 'appointment' : event.sourceType === 'reminder' ? 'reminder' : 'intervention' as any, event.id, `Titel: ${event.title}`, 'calendar');
      
      setIsDeleteConfirmOpen(false);
      onRefresh();
      onClose();
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `calendar_item_${event.id}`);
    }
  };

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            key="backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[110]"
            onClick={onClose}
          />
        )}
        {isOpen && (
          <motion.div
            key="panel"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed top-0 right-0 bottom-0 w-full max-w-lg bg-white z-[120] shadow-2xl overflow-y-auto"
          >
                <div className="p-8">
                   <div className="flex items-center justify-between mb-8">
                      <div className="bg-slate-100 p-2 rounded-xl text-slate-500">
                        {event.sourceType === 'appointment' ? <CalendarIcon className="w-5 h-5" /> : 
                         event.sourceType === 'intervention' ? <Wrench className="w-5 h-5" /> : <Bell className="w-5 h-5" />}
                      </div>
                      <button onClick={onClose} className="p-2 hover:bg-slate-50 rounded-xl text-slate-400">
                        <X className="w-6 h-6" />
                      </button>
                   </div>

                 <div className="space-y-8">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                         <span className={`px-2 py-0.5 rounded-full text-[8px] font-black uppercase tracking-widest ${
                           event.priority === 'urgent' ? 'bg-red-500 text-white' :
                           event.priority === 'high' ? 'bg-orange-500 text-white' :
                           'bg-blue-500 text-white'
                         }`}>
                            {event.priority}
                         </span>
                         <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{event.type}</span>
                      </div>
                      <h2 className="text-3xl font-black italic tracking-tighter text-slate-900 leading-tight">{event.title}</h2>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                         <p className="text-[8px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">Datum</p>
                         <p className="font-bold text-slate-900">
                            {format(event.start, 'd MMM', { locale: nl })}
                            {event.endDate && event.endDate !== event.date ? ` t/m ${format(parseISO(event.endDate), 'd MMM yyyy', { locale: nl })}` : ` ${format(event.start, 'yyyy')}`}
                         </p>
                      </div>
                      <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                         <p className="text-[8px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">Tijd</p>
                         <p className="font-bold text-slate-900">{format(event.start, 'HH:mm')} - {format(event.end, 'HH:mm')}</p>
                      </div>
                    </div>

                    {customer && (
                      <div className="space-y-4">
                         <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Klant & Locatie</h3>
                         <div className="flex items-start gap-4 p-6 bg-blue-50/50 border border-blue-100 rounded-3xl">
                            <div className="w-12 h-12 bg-white rounded-2xl shadow-sm flex items-center justify-center shrink-0">
                              <User className="w-6 h-6 text-blue-600" />
                            </div>
                            <div className="flex-1">
                              <p className="font-bold text-slate-900">{customer.name}</p>
                              <p className="text-xs text-slate-500 mt-1 flex items-center gap-1">
                                <MapPin className="w-3 h-3" />
                                {event.location || customer.address || 'Geen locatie opgegeven'}
                              </p>
                            </div>
                            <button 
                              onClick={() => navigate('/customers')}
                              className="p-3 bg-white border border-slate-200 rounded-xl text-blue-600 hover:bg-blue-50 transition-all shadow-sm"
                              title="Klant openen"
                            >
                               <ChevronRight className="w-5 h-5" />
                            </button>
                         </div>
                      </div>
                    )}

                    {machine && (
                      <div className="space-y-4">
                         <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Betrokken Machine</h3>
                         <div className="flex items-center gap-4 p-6 bg-slate-900 rounded-3xl text-white">
                            <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center shrink-0">
                              <Printer className="w-6 h-6" />
                            </div>
                            <div className="flex-1">
                              <p className="font-bold italic">{machine.brand} {machine.model}</p>
                              <p className="text-[10px] text-white/50 font-bold uppercase tracking-widest mt-1">SN: {machine.serialNumber}</p>
                            </div>
                            <button 
                              onClick={() => navigate('/machines')}
                              className="p-3 bg-white/10 rounded-xl text-white hover:bg-white/20 transition-all"
                              title="Machine openen"
                            >
                               <ChevronRight className="w-5 h-5" />
                            </button>
                         </div>
                      </div>
                    )}

                    <div className="space-y-4">
                       <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Status & Acties</h3>
                       <div className="flex flex-wrap gap-2">
                          {['planned', 'in-progress', 'completed', 'waiting'].map(s => (
                            <button
                              key={s}
                              onClick={() => handleStatusChange(s)}
                              className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                                event.status === s ? 'bg-slate-900 text-white shadow-lg' : 'bg-slate-50 text-slate-400 hover:bg-slate-100'
                              }`}
                            >
                              {s}
                            </button>
                          ))}
                       </div>
                    </div>

                    <div className="space-y-4">
                      <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Omschrijving</h3>
                      <div className="p-6 bg-slate-50 border border-slate-100 rounded-3xl">
                        <p className="text-sm font-medium text-slate-600 leading-relaxed">
                          {event.description || 'Geen omschrijving beschikbaar.'}
                        </p>
                      </div>
                    </div>

                    {(event.interventionId || event.reminderId) && (
                      <div className="space-y-4">
                         <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Gekoppelde Items</h3>
                         <div className="space-y-2">
                            {event.interventionId && (
                              <button 
                                onClick={() => navigate('/interventions')}
                                className="w-full flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100 hover:bg-white hover:border-blue-200 transition-all text-left"
                              >
                                 <div className="flex items-center gap-3">
                                    <Wrench className="w-4 h-4 text-blue-600" />
                                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-600">Interventie Bekijken</span>
                                 </div>
                                 <ChevronRight className="w-4 h-4 text-slate-300" />
                              </button>
                            )}
                            {event.reminderId && (
                              <button 
                                onClick={() => navigate('/reminders')}
                                className="w-full flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100 hover:bg-white hover:border-blue-200 transition-all text-left"
                              >
                                 <div className="flex items-center gap-3">
                                    <Bell className="w-4 h-4 text-amber-600" />
                                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-600">Herinnering Bekijken</span>
                                 </div>
                                 <ChevronRight className="w-4 h-4 text-slate-300" />
                              </button>
                            )}
                         </div>
                      </div>
                    )}

                    {event.internalNotes && (
                      <div className="space-y-4">
                        <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Interne Notities</h3>
                        <div className="p-6 bg-yellow-50 border border-yellow-100 rounded-3xl">
                          <p className="text-sm font-medium text-amber-900 leading-relaxed">
                            {event.internalNotes}
                          </p>
                        </div>
                      </div>
                    )}

                    <div className="pt-8 border-t border-slate-100 flex gap-4">
                       <button 
                         onClick={onEdit}
                         className="flex-1 py-4 bg-slate-900 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-blue-600 transition-all shadow-xl active:scale-95"
                       >
                         Bewerken
                       </button>
                       <button 
                         onClick={() => setIsDeleteConfirmOpen(true)}
                         className="p-4 bg-slate-50 text-red-500 rounded-2xl hover:bg-red-50 transition-all"
                         title="Verwijderen"
                       >
                          <Trash2 className="w-5 h-5" />
                       </button>
                    </div>
                 </div>
              </div>
            </motion.div>
        )}
      </AnimatePresence>

      <ConfirmDialog
        isOpen={isDeleteConfirmOpen}
        title="Item verwijderen"
        message={`Weet u zeker dat u "${event.title}" wilt verwijderen? Dit kan niet ongedaan worden gemaakt.`}
        confirmText="Verwijderen"
        onConfirm={handleDelete}
        onCancel={() => setIsDeleteConfirmOpen(false)}
      />
    </>
  );
};

export default Calendar;
