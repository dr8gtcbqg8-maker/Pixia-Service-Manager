import React from 'react';
import { Printer, Edit3, Bell, Trash2, History } from 'lucide-react';
import { motion } from 'motion/react';
import { Machine, Customer } from '../../types';

interface MachineTableProps {
  machines: Machine[];
  customers: Customer[];
  onOpenDetails: (machine: Machine) => void;
  onOpenEdit: (machine: Machine) => void;
  onOpenReminder: (machine: Machine) => void;
  onDelete: (id: string, e: React.MouseEvent) => void;
}

const MachineTable: React.FC<MachineTableProps> = ({
  machines,
  customers,
  onOpenDetails,
  onOpenEdit,
  onOpenReminder,
  onDelete
}) => {
  const getCustomerName = (id: string) => customers.find(c => c.id === id)?.name || 'Onbekende klant';

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-50 text-green-700 border-green-100';
      case 'maintenance-needed': return 'bg-amber-50 text-amber-700 border-amber-100';
      case 'faulty': return 'bg-red-50 text-red-700 border-red-100';
      case 'out-of-service': return 'bg-surface-100 text-surface-500 border-surface-200';
      case 'replaced': return 'bg-brand-50 text-blue-700 border-brand-200';
      default: return 'bg-surface-50 text-surface-500';
    }
  };

  if (machines.length === 0) {
    return (
    <div className="bg-white px-5 py-4 rounded-lg border border-surface-200 text-center flex flex-col items-center gap-4">
      <div className="w-16 h-16 bg-surface-50 rounded-full flex items-center justify-center text-surface-300">
        <Printer className="w-8 h-8" />
      </div>
      <div>
        <h3 className="text-base font-bold text-surface-900">Geen machines gevonden</h3>
        <p className="text-sm text-surface-500 max-w-xs mx-auto">Pas uw zoekopdracht of filters aan, of voeg een nieuwe machine toe.</p>
      </div>
    </div>
    );
  }

  return (
    <div className="bg-white rounded-lg border border-surface-200 overflow-hidden shadow-sm">
      {/* Desktop Header */}
      <div className="hidden md:grid grid-cols-12 gap-4 px-6 py-3 bg-surface-50 border-b border-surface-200 text-[10px] font-bold uppercase tracking-wider text-surface-500">
        <div className="col-span-3">Machine / Model</div>
        <div className="col-span-3">Klant</div>
        <div className="col-span-2">Serienummer</div>
        <div className="col-span-2">Volgend Onderhoud</div>
        <div className="col-span-1">Status</div>
        <div className="col-span-1 text-right">Acties</div>
      </div>

      <div className="divide-y divide-surface-100">
        {machines.map((machine) => (
          <motion.div
            layout
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            key={machine.id}
            className="group hover:bg-surface-50/50 transition-all cursor-pointer"
            onClick={() => onOpenDetails(machine)}
          >
            {/* Desktop Row */}
            <div className="hidden md:grid grid-cols-12 gap-4 items-center px-6 py-2">
              <div className="col-span-3 flex items-center gap-3">
                <div className="w-10 h-10 bg-brand-50 text-brand-500 rounded-lg flex items-center justify-center shrink-0">
                  <Printer className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <div className="text-sm font-bold text-surface-900 truncate group-hover:text-brand-500 transition-colors leading-tight">{machine.brand}</div>
                  <div className="text-[10px] font-bold text-surface-400 uppercase tracking-wide truncate mt-0.5">{machine.model}</div>
                </div>
              </div>
              <div className="col-span-3 text-sm font-medium text-surface-600 truncate">
                {getCustomerName(machine.customerId)}
              </div>
              <div className="col-span-2 text-xs font-mono font-bold text-surface-500">
                {machine.serialNumber}
              </div>
              <div className="col-span-2 text-xs font-bold text-amber-600">
                {machine.nextMaintenanceDate || 'Niet gepland'}
              </div>
              <div className="col-span-1">
                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider border ${getStatusColor(machine.status)}`}>
                  {machine.status}
                </span>
              </div>
              <div className="col-span-1 flex justify-end gap-1 px-2 opacity-100 md:opacity-0 group-hover:opacity-100 transition-all">
                <button 
                  onClick={(e) => { e.stopPropagation(); onOpenEdit(machine); }}
                  className="p-1.5 text-surface-400 hover:text-brand-500 hover:bg-white rounded-md border border-transparent hover:border-surface-200 transition-all shadow-sm"
                  title="Bewerken"
                >
                  <Edit3 className="w-4 h-4" />
                </button>
                <button 
                  onClick={(e) => { e.stopPropagation(); onOpenReminder(machine); }}
                  className="p-1.5 text-surface-400 hover:text-amber-600 hover:bg-white rounded-md border border-transparent hover:border-surface-200 transition-all shadow-sm"
                  title="Herinnering"
                >
                  <Bell className="w-4 h-4" />
                </button>
                <button 
                  onClick={(e) => { e.stopPropagation(); onDelete(machine.id, e); }}
                  className="p-1.5 text-surface-400 hover:text-red-600 hover:bg-white rounded-md border border-transparent hover:border-surface-200 transition-all shadow-sm"
                  title="Verwijderen"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Mobile View */}
            <div className="md:hidden p-4 space-y-3">
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-brand-50 text-brand-500 rounded-lg flex items-center justify-center shrink-0">
                    <Printer className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-surface-900">{machine.brand} {machine.model}</div>
                    <div className="text-[10px] font-black text-brand-500 uppercase tracking-widest mt-0.5 truncate max-w-[200px]">{getCustomerName(machine.customerId)}</div>
                  </div>
                </div>
                <span className={`shrink-0 text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded-lg border ${getStatusColor(machine.status)}`}>
                  {machine.status}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-4 text-[10px] bg-surface-50 p-3 rounded-md">
                <div>
                  <span className="block text-surface-400 uppercase font-black mb-0.5 tracking-tighter">Serienummer</span>
                  <span className="font-mono font-bold text-surface-700">{machine.serialNumber}</span>
                </div>
                <div>
                  <span className="block text-surface-400 uppercase font-black mb-0.5 tracking-tighter">Onderhoud</span>
                  <span className="font-bold text-amber-600">{machine.nextMaintenanceDate || '-'}</span>
                </div>
              </div>

              <div className="flex gap-2">
                <button 
                  onClick={(e) => { e.stopPropagation(); onOpenEdit(machine); }}
                  className="flex-1 py-2 text-xs font-bold text-surface-600 bg-white border border-surface-200 rounded-lg"
                >
                  Bewerken
                </button>
                <button 
                  onClick={(e) => { e.stopPropagation(); onOpenReminder(machine); }}
                  className="flex-1 py-2 text-xs font-bold text-amber-600 bg-white border border-surface-200 rounded-lg"
                >
                  Plan Taak
                </button>
                <button 
                  onClick={(e) => onDelete(machine.id, e)}
                  className="p-2 text-red-400 bg-white border border-surface-200 rounded-lg"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default MachineTable;
