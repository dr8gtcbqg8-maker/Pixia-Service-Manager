import React from 'react';
import { SmartAlert } from '../../types';
import { Bell, ShieldAlert, ChevronRight, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format } from 'date-fns';

import { Link } from 'react-router-dom';

interface DashboardAlertsProps {
  alerts: SmartAlert[];
  onDismiss: (id: string) => void;
}

const DashboardAlerts: React.FC<DashboardAlertsProps> = ({ alerts, onDismiss }) => {
  if (alerts.length === 0) return null;

  const getAlertPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'text-rose-500 bg-rose-50';
      case 'high': return 'text-amber-500 bg-amber-50';
      case 'normal': return 'text-blue-500 bg-blue-50';
      default: return 'text-slate-500 bg-slate-50';
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-2 px-1">
        <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
          <Bell className="w-4 h-4 text-blue-500" />
          Systeemmeldingen
        </h3>
        <span className="text-xs text-slate-400 font-medium">{alerts.length} actieve meldingen</span>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <AnimatePresence>
          {alerts.map((alert) => (
            <motion.div
              layout
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              key={alert.id}
              className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm hover:shadow-md transition-all group relative overflow-hidden"
            >
              <div className="flex items-start gap-4">
                <div className={`p-2.5 rounded-lg shrink-0 ${getAlertPriorityColor(alert.priority)}`}>
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[11px] font-medium text-slate-400">{format(new Date(alert.createdAt), 'dd MMM, HH:mm')}</span>
                    <button 
                      onClick={() => onDismiss(alert.id)}
                      className="p-1.5 hover:bg-slate-100 rounded-lg transition-all text-slate-400 hover:text-slate-600"
                      aria-label="Verwijder Melding"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <h4 className="text-sm font-bold text-slate-900 leading-tight mb-1">{alert.title}</h4>
                  <p className="text-xs text-slate-500 leading-relaxed line-clamp-2 mb-3">{alert.description}</p>
                  
                  <div className="flex items-center gap-2">
                    <Link 
                      to="/actions"
                      className="text-[11px] font-bold text-blue-600 hover:text-blue-700 underline underline-offset-4 decoration-blue-200 hover:decoration-blue-400 transition-all flex items-center gap-1 group/btn"
                    >
                      Bekijk details
                      <ChevronRight className="w-3 h-3 group-hover/btn:translate-x-0.5 transition-transform" />
                    </Link>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default DashboardAlerts;
