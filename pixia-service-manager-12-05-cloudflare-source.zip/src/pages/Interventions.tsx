import React, { useEffect, useState, useMemo } from 'react';
import { format } from 'date-fns';
import { nl } from 'date-fns/locale';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, Search, Filter, History, Calendar, FileText, Briefcase, 
  MapPin, User, Clock, AlertCircle, CheckCircle2, ChevronRight, X,
  Trash2, Mail, Edit, PlayCircle, ExternalLink, Package, Minus,
  Edit3, Wrench, MoreVertical, ClipboardList, Printer, Sparkles
} from 'lucide-react';

import { useInterventions } from '../hooks/useInterventions';
import { interventionService } from '../services/interventionService';
import { 
  Intervention, Customer, Machine, InterventionStatus, 
  InterventionType, InventoryItem, WorkOrder, AuditLog, 
  AlertPriority, ReminderPriority 
} from '../types';

import { 
  handleFirestoreError, OperationType, cn,
  calculateNextMaintenanceDate, generateSequenceNumber 
} from '../lib/utils';
import { logAction } from '../lib/audit';
import { emailService } from '../lib/emailService';
import { aiService } from '../services/aiService';

import ConfirmDialog from '../components/ConfirmDialog';
import DocumentSection from '../components/DocumentSection';
import AppointmentModal from '../components/AppointmentModal';
import InterventionTable from '../components/interventions/InterventionTable';
import InterventionFilters from '../components/interventions/InterventionFilters';
import { COLLECTIONS } from '../constants/collections';

const Interventions: React.FC = () => {
  const { 
    interventions, 
    customers, 
    machines, 
    inventory, 
    loading, 
    refreshData 
  } = useInterventions();
  
  // Filters
  const [search, setSearch] = useState('');
  const [filterCustomer, setFilterCustomer] = useState('');
  const [filterMachine, setFilterMachine] = useState('');
  const [filterType, setFilterType] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterPriority, setFilterPriority] = useState('');
  const [filterDate, setFilterDate] = useState('');

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isAppointmentModalOpen, setIsAppointmentModalOpen] = useState(false);
  const [isSendingEmail, setIsSendingEmail] = useState(false);
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const [aiDraft, setAiDraft] = useState<string | null>(null);
  const [appointmentInitialData, setAppointmentInitialData] = useState<any>({});
  const [selectedIntervention, setSelectedIntervention] = useState<Intervention | null>(null);
  const [isDetailView, setIsDetailView] = useState(false);
  const [interventionWorkOrder, setInterventionWorkOrder] = useState<WorkOrder | null>(null);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [deleteConfirm, setDeleteConfirm] = useState<{ isOpen: boolean; id: string | null }>({ isOpen: false, id: null });

  // Form State
  const [formData, setFormData] = useState({
    interventionNumber: '',
    date: format(new Date(), 'yyyy-MM-dd'),
    endDate: '',
    time: format(new Date(), 'HH:mm'),
    startTime: format(new Date(), 'HH:mm'),
    endTime: format(new Date(new Date().getTime() + 60 * 60 * 1000), 'HH:mm'),
    customerId: '',
    machineId: '',
    location: '',
    technicianName: '',
    type: 'onderhoud' as InterventionType,
    status: 'gepland' as InterventionStatus,
    priority: 'normal' as AlertPriority,
    problemDescription: '',
    workPerformed: '',
    hoursWorked: 0,
    travelTime: 0,
    followUpAction: '',
    nextMaintenanceDate: '',
    internalNotes: '',
    customerNotes: '',
    workOrderId: '',
    partsUsed: [] as { itemId?: string; quantity: number; name: string; unitPrice?: number }[]
  });

  useEffect(() => {
    // Handle URL parameters for pre-filling new intervention
    const params = new URLSearchParams(window.location.search);
    const machineId = params.get('machine');
    const customerId = params.get('customer');
    const interventionId = params.get('id');
    const shouldOpenNew = params.get('new') === 'true';

    if (machineId || customerId || shouldOpenNew) {
      setFormData(prev => ({
        ...prev,
        machineId: machineId || prev.machineId,
        customerId: customerId || prev.customerId,
        interventionNumber: generateSequenceNumber('INT')
      }));
      setIsAddModalOpen(true);
    } else if (interventionId) {
      const searchAndOpen = async () => {
        const interv = await interventionService.getById(interventionId);
        if (interv) {
          handleOpenEditModal(interv);
        }
      };
      searchAndOpen();
    }
  }, []);

  const getCustomerName = (id: string) => customers.find(c => c.id === id)?.name || 'Onbekende Klant';
  const getMachineSimpleInfo = (id: string) => {
    const m = machines.find(m => m.id === id);
    return m ? `${m.brand} ${m.model}` : 'Onbekende Machine';
  };
  const getMachineInfo = (id: string) => {
    const m = machines.find(mac => mac.id === id);
    return m ? `${m.brand} ${m.model} (${m.serialNumber})` : 'Onbekende machine';
  };

  const handleOpenAddModal = () => {
    setSelectedIntervention(null);
    setIsDetailView(false);
    setFormData({
      interventionNumber: generateSequenceNumber('INT'),
      date: format(new Date(), 'yyyy-MM-dd'),
      endDate: '',
      time: format(new Date(), 'HH:mm'),
      startTime: format(new Date(), 'HH:mm'),
      endTime: format(new Date(new Date().getTime() + 60 * 60 * 1000), 'HH:mm'),
      customerId: '',
      machineId: '',
      location: '',
      technicianName: '',
      type: 'onderhoud',
      status: 'gepland',
      priority: 'normal',
      problemDescription: '',
      workPerformed: '',
      hoursWorked: 0,
      travelTime: 0,
      followUpAction: '',
      nextMaintenanceDate: '',
      internalNotes: '',
      customerNotes: '',
      workOrderId: '',
      partsUsed: []
    });
    setIsAddModalOpen(true);
  };

  const fetchInterventionDetails = async (intervention: Intervention) => {
    if (!intervention.id) return;
    const [wo, logs] = await Promise.all([
      interventionService.getLinkedWorkOrder(intervention.id),
      interventionService.getAuditLogs(intervention.id)
    ]);
    setInterventionWorkOrder(wo);
    setAuditLogs(logs);
  };

  const handleOpenDetails = (intervention: Intervention) => {
    setSelectedIntervention(intervention);
    setIsDetailView(true);
    setAiDraft(null); // Reset AI draft
    // Fill formData for detail view if needed by components
    handleOpenEditModal(intervention, true);
    setIsDetailView(true);
  };

  const handleOpenEditModal = (intervention: Intervention, detailsOnly = false) => {
    setSelectedIntervention(intervention);
    if (!detailsOnly) setIsDetailView(false);
    
    setFormData({
      interventionNumber: intervention.interventionNumber || '',
      date: intervention.date,
      endDate: intervention.endDate || '',
      time: intervention.time || '',
      startTime: intervention.startTime || '',
      endTime: intervention.endTime || '',
      customerId: intervention.customerId,
      machineId: intervention.machineId,
      location: intervention.location || '',
      technicianName: intervention.technicianName || '',
      type: intervention.type,
      status: intervention.status,
      priority: intervention.priority,
      problemDescription: intervention.problemDescription || '',
      workPerformed: intervention.workPerformed || '',
      hoursWorked: intervention.hoursWorked || 0,
      travelTime: intervention.travelTime || 0,
      followUpAction: intervention.followUpAction || '',
      nextMaintenanceDate: intervention.nextMaintenanceDate || '',
      internalNotes: intervention.internalNotes || '',
      customerNotes: intervention.customerNotes || '',
      workOrderId: intervention.workOrderId || '',
      partsUsed: intervention.partsUsed || []
    });
    fetchInterventionDetails(intervention);
    setIsAddModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const successId = await interventionService.save(formData, selectedIntervention);
    if (successId) {
      setIsAddModalOpen(false);
      refreshData();
    }
  };

  const handleDelete = async () => {
    if (deleteConfirm.id) {
      const success = await interventionService.delete(deleteConfirm.id);
      if (success) {
        setDeleteConfirm({ isOpen: false, id: null });
        refreshData();
      }
    }
  };

  const handleCreateWorkOrder = async () => {
    if (!selectedIntervention) return;
    const customer = customers.find(c => c.id === selectedIntervention.customerId);
    const machine = machines.find(m => m.id === selectedIntervention.machineId);
    
    const woId = await interventionService.createWorkOrderFromIntervention(
      selectedIntervention, customer, machine, formData
    );
    
    if (woId) {
      alert('Werkbon succesvol aangemaakt.');
      window.location.href = `/work-orders?interventionId=${selectedIntervention.id}`;
    } else {
      alert('Fout bij maken werkbon.');
    }
  };

  const handleGenerateAIDraft = async () => {
    if (!selectedIntervention) return;
    setIsGeneratingAI(true);
    try {
      const customer = customers.find(c => c.id === selectedIntervention.customerId);
      const machine = machines.find(m => m.id === selectedIntervention.machineId);
      
      if (customer && machine) {
        const draft = await aiService.generateEmailDraft({
          intervention: selectedIntervention,
          customer,
          machine
        });
        setAiDraft(draft || 'Geen concept gegenereerd.');
      }
    } catch (err) {
      console.error('AI Draft failed:', err);
    } finally {
      setIsGeneratingAI(false);
    }
  };
  const handleSendConfirmation = async () => {
    if (!selectedIntervention) return;
    setIsSendingEmail(true);
    try {
      const customer = customers.find(c => c.id === selectedIntervention.customerId);
      const machine = machines.find(m => m.id === selectedIntervention.machineId);
      
      if (!customer?.email) {
        alert('Klant heeft geen e-mailadres ingesteld.');
        return;
      }

      await emailService.triggerAutomation('appointment_confirmation', {
        customer,
        machine,
        intervention: selectedIntervention,
        appointment: {
          date: selectedIntervention.date,
          startTime: selectedIntervention.time,
          location: customer.address
        }
      });
      
      alert('Bevestigingsmail is verzonden naar ' + customer.email);
    } catch (err) {
      console.error('Email sending failed:', err);
      alert('Fout bij het verzenden van de e-mail.');
    } finally {
      setIsSendingEmail(false);
    }
  };

  const filteredInterventions = useMemo(() => interventions.filter(i => {
    const matchesSearch = 
      getCustomerName(i.customerId).toLowerCase().includes(search.toLowerCase()) ||
      getMachineInfo(i.machineId).toLowerCase().includes(search.toLowerCase()) ||
      (i.problemDescription || '').toLowerCase().includes(search.toLowerCase()) ||
      (i.technicianName || '').toLowerCase().includes(search.toLowerCase());
    
    const matchesCustomer = !filterCustomer || i.customerId === filterCustomer;
    const matchesMachine = !filterMachine || i.machineId === filterMachine;
    const matchesType = !filterType || i.type === filterType;
    const matchesStatus = !filterStatus || i.status === filterStatus;
    const matchesPriority = !filterPriority || i.priority === filterPriority;
    const matchesDate = !filterDate || i.date === filterDate;

    return matchesSearch && matchesCustomer && matchesMachine && matchesType && matchesStatus && matchesPriority && matchesDate;
  }), [interventions, search, filterCustomer, filterMachine, filterType, filterStatus, filterPriority, filterDate, customers, machines]);

  const getStatusStyle = (status: InterventionStatus) => {
    switch (status) {
      case 'completed':
      case 'afgerond': return 'bg-green-50 text-green-700 border-green-100';
      case 'in-progress':
      case 'bezig': return 'bg-blue-50 text-blue-700 border-blue-100';
      case 'on-route':
      case 'onderweg': return 'bg-indigo-50 text-indigo-700 border-indigo-100';
      case 'waiting-parts':
      case 'wacht op onderdelen': return 'bg-orange-50 text-orange-700 border-orange-100';
      case 'planned':
      case 'gepland': return 'bg-amber-50 text-amber-700 border-amber-100';
      case 'cancelled':
      case 'geannuleerd': return 'bg-slate-100 text-slate-500 border-slate-200';
      case 'to-be-scheduled': return 'bg-purple-50 text-purple-700 border-purple-100';
      case 'gefactureerd':
      case 'invoiced': return 'bg-emerald-50 text-emerald-700 border-emerald-100';
      default: return 'bg-slate-50 text-slate-700 border-slate-100';
    }
  };

  const getStatusLabel = (status: InterventionStatus) => {
    switch (status) {
      case 'completed':
      case 'afgerond': return 'Afgerond';
      case 'in-progress':
      case 'bezig': return 'Bezig';
      case 'on-route':
      case 'onderweg': return 'Onderweg';
      case 'waiting-parts':
      case 'wacht op onderdelen': return 'Wacht op onderdelen';
      case 'planned':
      case 'gepland': return 'Gepland';
      case 'cancelled':
      case 'geannuleerd': return 'Geannuleerd';
      case 'to-be-scheduled': return 'Nog te plannen';
      case 'gefactureerd':
      case 'invoiced': return 'Gefactureerd';
      default: return status;
    }
  };

  const getPriorityStyle = (priority: ReminderPriority) => {
    switch (priority) {
      case 'urgent': return 'text-red-600 bg-red-50 border-red-100';
      case 'high': return 'text-amber-600 bg-amber-50 border-amber-100';
      case 'normal': return 'text-blue-600 bg-blue-50 border-blue-100';
      case 'low': return 'text-slate-500 bg-slate-50 border-slate-100';
      default: return 'text-slate-500 bg-slate-50 border-slate-100';
    }
  };

  return (
    <div className="space-y-8 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 leading-tight">Interventies & Onderhoud</h1>
          <p className="text-sm text-slate-500 mt-1">Beheer servicebezoeken en reparaties.</p>
        </div>
        <button 
          onClick={handleOpenAddModal}
          className="btn-primary"
        >
          <Plus className="w-4 h-4" />
          <span>Nieuwe Interventie</span>
        </button>
      </div>

      <InterventionFilters 
        search={search} setSearch={setSearch}
        filterCustomer={filterCustomer} setFilterCustomer={setFilterCustomer}
        filterMachine={filterMachine} setFilterMachine={setFilterMachine}
        filterType={filterType} setFilterType={setFilterType}
        filterStatus={filterStatus} setFilterStatus={setFilterStatus}
        filterPriority={filterPriority} setFilterPriority={setFilterPriority}
        filterDate={filterDate} setFilterDate={setFilterDate}
        customers={customers}
        machines={machines}
      />

      {loading ? (
        <div className="flex justify-center p-24">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-slate-200 border-t-blue-600"></div>
        </div>
      ) : (
        <InterventionTable 
          interventions={filteredInterventions}
          customers={customers}
          machines={machines}
          onOpenDetails={handleOpenDetails}
          onOpenEdit={handleOpenEditModal}
          onPlanAppointment={(i) => {
            setAppointmentInitialData({
              date: i.date,
              interventionId: i.id,
              customerId: i.customerId,
              machineId: i.machineId,
              title: `Interventie: ${getCustomerName(i.customerId)}`
            });
            setIsAppointmentModalOpen(true);
          }}
          onCreateWorkOrder={(i) => {
            setSelectedIntervention(i);
            handleCreateWorkOrder();
          }}
          onDelete={(id) => setDeleteConfirm({ isOpen: true, id })}
          getStatusLabel={getStatusLabel}
          getStatusStyle={getStatusStyle}
          getPriorityStyle={getPriorityStyle}
        />
      )}

      {/* Add/Edit Modal */}
      <AnimatePresence>
        {isAddModalOpen && (
          <motion.div 
            key="intervention-modal-container"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center p-4"
          >
            <motion.div
              key="backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
              onClick={() => setIsAddModalOpen(false)}
            />
            <motion.div
              key="modal-content"
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-4xl rounded-[2.5rem] shadow-2xl p-10 overflow-y-auto max-h-[95vh] focus:outline-none"
            >
              <div className="flex items-center justify-between mb-8 pb-6 border-b border-slate-100">
                <div className="flex flex-col">
                  <div className="flex items-center gap-3">
                    <h2 className="text-xl font-bold text-slate-900 flex items-center gap-4">
                      <div className="p-2.5 bg-blue-600 text-white rounded-xl shadow-lg shadow-blue-500/20">
                        <ClipboardList className="w-5 h-5" />
                      </div>
                      {isDetailView ? `Interventie: ${formData.interventionNumber || 'Nieuw'}` : (selectedIntervention ? 'Interventie Aanpassen' : 'Nieuwe Interventie')}
                    </h2>
                    <select 
                      className={cn(
                        "text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full border outline-none",
                        getStatusStyle(formData.status)
                      )}
                      value={formData.status}
                      onChange={(e) => setFormData({...formData, status: e.target.value as InterventionStatus})}
                    >
                      <option value="gepland">Gepland</option>
                      <option value="onderweg">Onderweg</option>
                      <option value="bezig">Bezig</option>
                      <option value="wacht op onderdelen">Wacht op onderdelen</option>
                      <option value="afgerond">Afgerond</option>
                      <option value="gefactureerd">Gefactureerd</option>
                      <option value="geannuleerd">Geannuleerd</option>
                    </select>
                  </div>
                  {isDetailView && (
                    <p className="text-[11px] font-medium text-slate-500 mt-2 ml-14">
                      Klant: {getCustomerName(formData.customerId)} • Machine: {getMachineSimpleInfo(formData.machineId)}
                    </p>
                  )}
                </div>
                
                <div className="flex items-center gap-2">
                  {isDetailView && (
                    <button 
                       onClick={handleGenerateAIDraft}
                       disabled={isGeneratingAI}
                       className="btn-ghost !bg-amber-50 !text-amber-700 hover:!bg-amber-100 border border-amber-200"
                       title="Genereer AI E-mail concept"
                    >
                       <Sparkles className={cn("w-4 h-4", isGeneratingAI && "animate-spin")} />
                       <span className="hidden sm:inline">{isGeneratingAI ? 'AI Schrijft...' : 'AI Concept'}</span>
                    </button>
                  )}
                  {isDetailView && (
                    <button 
                      onClick={() => setIsDetailView(false)}
                      className="btn-ghost !bg-slate-100 !text-slate-700 hover:!bg-slate-200"
                    >
                      <Edit className="w-4 h-4" />
                      <span className="hidden sm:inline">Bewerken</span>
                    </button>
                  )}
                  {selectedIntervention && (
                    <>
                      <button 
                        type="button"
                        onClick={handleSendConfirmation}
                        disabled={isSendingEmail}
                        className="btn-ghost !p-2 text-slate-400 hover:text-indigo-600"
                        title="Verstuur Bevestiging"
                      >
                        <Mail className={cn("w-5 h-5", isSendingEmail && "animate-pulse")} />
                      </button>
                      <button 
                        type="button"
                        onClick={() => window.print()}
                        className="btn-ghost !p-2 text-slate-400 hover:text-blue-600"
                        title="Afdrukken / PDF"
                      >
                        <Printer className="w-5 h-5" />
                      </button>
                    </>
                  )}
                  <button 
                    onClick={() => setIsAddModalOpen(false)}
                    className="p-2 hover:bg-slate-100 rounded-lg text-slate-400"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>
              </div>

              {isDetailView ? (
                <div className="space-y-10">
                  {/* Action Buttons for Details View */}
                  <div className="flex flex-wrap gap-4 p-5 bg-slate-50 rounded-2xl border border-slate-100">
                    {formData.status === 'gepland' && (
                      <button 
                         onClick={() => {
                           setFormData({...formData, status: 'bezig', startTime: format(new Date(), 'HH:mm')});
                           handleSave({ preventDefault: () => {} } as any);
                         }}
                         className="flex-1 min-w-[180px] btn-primary !py-3.5 !bg-blue-600 hover:!bg-blue-700"
                      >
                        <PlayCircle className="w-5 h-5" />
                        <span>Start Interventie</span>
                      </button>
                    )}
                    
                    {(formData.status === 'bezig' || formData.status === 'in-progress') && (
                      <button 
                         onClick={() => {
                           setFormData({...formData, status: 'afgerond', endTime: format(new Date(), 'HH:mm')});
                           handleSave({ preventDefault: () => {} } as any);
                         }}
                         className="flex-1 min-w-[180px] btn-primary !py-3.5 !bg-emerald-600 hover:!bg-emerald-700 shadow-emerald-100"
                      >
                        <CheckCircle2 className="w-5 h-5" />
                        <span>Afronden</span>
                      </button>
                    )}

                    {!interventionWorkOrder ? (
                      <button 
                         onClick={handleCreateWorkOrder}
                         className="flex-1 min-w-[180px] btn-secondary !py-3.5 border-2 border-slate-900 bg-white text-slate-900 hover:bg-slate-900 hover:text-white"
                      >
                        <FileText className="w-5 h-5" /> 
                        <span>Werkbon Aanmaken</span>
                      </button>
                    ) : (
                      <button 
                         onClick={() => window.location.href = `/work-orders?interventionId=${selectedIntervention?.id}`}
                         className="flex-1 min-w-[180px] btn-secondary !py-3.5 bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100"
                      >
                        <ExternalLink className="w-5 h-5" />
                        <span>Open Werkbon ({interventionWorkOrder.orderNumber})</span>
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div className="md:col-span-2 space-y-8">
                      {/* Detailed Info Sections */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div className="p-5 bg-white border border-slate-100 rounded-2xl shadow-sm">
                          <h4 className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
                             <User className="w-3.5 h-3.5" /> Klant Informatie
                          </h4>
                          <div className="space-y-1">
                             <p className="text-sm font-bold text-slate-900">{getCustomerName(formData.customerId)}</p>
                             <p className="text-xs text-slate-500 font-medium">{customers.find(c => c.id === formData.customerId)?.address}</p>
                             <p className="text-xs text-blue-600 font-bold mt-2">{customers.find(c => c.id === formData.customerId)?.contactPerson}</p>
                          </div>
                        </div>
                        <div className="p-5 bg-white border border-slate-100 rounded-2xl shadow-sm">
                          <h4 className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-2">
                             <Printer className="w-3.5 h-3.5" /> Machine Details
                          </h4>
                          <div className="space-y-1">
                             <p className="text-sm font-bold text-slate-900">{getMachineSimpleInfo(formData.machineId)}</p>
                             <p className="text-xs text-slate-500 font-medium">Serienummer: <span className="font-mono font-bold text-slate-700">{machines.find(m => m.id === formData.machineId)?.serialNumber || 'N/A'}</span></p>
                             <p className="text-xs text-slate-500 font-medium">Locatie: {formData.location || machines.find(m => m.id === formData.machineId)?.location || 'Standaard'}</p>
                          </div>
                        </div>
                      </div>

                      <div className="p-6 bg-white border border-slate-100 rounded-2xl shadow-sm space-y-5">
                        <div className="flex items-center justify-between border-b border-slate-50 pb-4">
                           <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">Werkzaamheden & Bevindingen</h4>
                           <span className="px-2 py-0.5 rounded-full bg-slate-100 text-[10px] font-bold uppercase tracking-wider text-slate-600">
                             {formData.type}
                           </span>
                        </div>
                        <div className="space-y-6">
                           <div>
                              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Probleemomschrijving</p>
                              <div className="text-sm text-slate-600 leading-relaxed bg-slate-50 p-4 rounded-xl italic">
                                {formData.problemDescription || 'Geen omschrijving ingevoerd.'}
                              </div>
                           </div>
                           <div>
                              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Uitgevoerde Werkzaamheden</p>
                              <div className="space-y-4">
                                <div className="text-sm text-slate-900 leading-relaxed bg-blue-50/30 p-4 rounded-xl font-medium border border-blue-50">
                                  {formData.workPerformed || 'Nog geen werkzaamheden geregistreerd.'}
                                </div>
                                
                                {aiDraft && (
                                  <motion.div 
                                    initial={{ opacity: 0, scale: 0.98 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    className="p-5 bg-amber-50/50 border border-amber-100 rounded-xl space-y-4"
                                  >
                                     <div className="flex items-center gap-2 text-amber-700">
                                        <Sparkles className="w-4 h-4" />
                                        <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800">AI Gegenereerd Concept Mail</span>
                                     </div>
                                     <div className="text-sm text-slate-700 whitespace-pre-wrap leading-relaxed italic">
                                        {aiDraft}
                                     </div>
                                     <div className="flex justify-end gap-2 pt-4 border-t border-amber-100">
                                        <button 
                                          onClick={() => {
                                            navigator.clipboard.writeText(aiDraft);
                                          }}
                                          className="btn-secondary !text-[10px] !py-2 !px-4"
                                        >
                                          Kopiëren
                                        </button>
                                     </div>
                                  </motion.div>
                                )}
                              </div>
                           </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div className="p-5 bg-white border border-slate-100 rounded-2xl shadow-sm">
                           <h4 className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-4 flex items-center gap-2">
                              <Clock className="w-3.5 h-3.5" /> Uren & Tijden
                           </h4>
                           <div className="grid grid-cols-2 gap-4">
                              <div>
                                 <p className="text-[9px] font-bold text-slate-400 uppercase">Werktijd</p>
                                 <p className="text-lg font-bold text-slate-900">{formData.hoursWorked}<span className="text-xs text-slate-400 ml-1">u</span></p>
                              </div>
                              <div>
                                 <p className="text-[9px] font-bold text-slate-400 uppercase">Reistijd</p>
                                 <p className="text-lg font-bold text-slate-900">{formData.travelTime}<span className="text-xs text-slate-400 ml-1">min</span></p>
                              </div>
                              <div className="col-span-2 grid grid-cols-2 gap-2 pt-3 border-t border-slate-50">
                                 <div>
                                    <p className="text-[9px] font-bold text-slate-400 uppercase">Start</p>
                                    <p className="text-xs font-bold text-slate-600">{formData.startTime || '--:--'}</p>
                                 </div>
                                 <div>
                                    <p className="text-[9px] font-bold text-slate-400 uppercase">Eind</p>
                                    <p className="text-xs font-bold text-slate-600">{formData.endTime || '--:--'}</p>
                                 </div>
                              </div>
                           </div>
                        </div>

                        <div className="p-5 bg-white border border-slate-100 rounded-2xl shadow-sm">
                           <h4 className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-4 flex items-center gap-2">
                              <Package className="w-3.5 h-3.5" /> Onderdelen
                           </h4>
                           <div className="space-y-2 max-h-[140px] overflow-y-auto pr-2 custom-scrollbar">
                              {formData.partsUsed.map((p, idx) => (
                                 <div key={idx} className="flex justify-between items-center text-xs font-bold bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                                    <span className="text-slate-700 truncate">{p.name}</span>
                                    <span className="text-blue-600 shrink-0 ml-2 bg-white px-2 py-0.5 rounded border border-blue-100">{p.quantity}x</span>
                                 </div>
                              ))}
                              {formData.partsUsed.length === 0 && (
                                 <div className="flex flex-col items-center justify-center py-6 text-slate-300">
                                   <Package className="w-6 h-6 mb-1 opacity-20" />
                                   <p className="text-[10px] font-bold uppercase tracking-wider">Geen onderdelen</p>
                                 </div>
                              )}
                           </div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-8">
                       {/* Timeline / Audit Log */}
                       <div className="p-6 bg-slate-900 text-white rounded-2xl shadow-xl space-y-6 h-full min-h-[400px] flex flex-col">
                          <h4 className="text-xs font-bold uppercase tracking-wider flex items-center gap-3 border-b border-slate-800 pb-4">
                             <History className="w-4 h-4 text-blue-400" />
                             Status Verloop
                          </h4>
                          <div className="flex-1 overflow-y-auto space-y-6 pr-2 custom-scrollbar py-2">
                             {auditLogs.map((log, idx) => (
                                <div key={log.id} className="relative pl-6 pb-2">
                                   {idx !== auditLogs.length - 1 && (
                                      <div className="absolute left-[3px] top-4 bottom-0 w-px bg-slate-800" />
                                   )}
                                   <div className="absolute left-0 top-1.5 w-1.5 h-1.5 rounded-full bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.5)]" />
                                   <div className="space-y-1">
                                      <div className="flex justify-between items-start">
                                         <p className="text-[10px] font-bold uppercase text-blue-400 leading-none">{log.action}</p>
                                         <span className="text-[9px] font-medium text-slate-500 uppercase">{format(new Date(log.timestamp), 'HH:mm')}</span>
                                      </div>
                                      <p className="text-[11px] text-slate-300 leading-relaxed">
                                         {log.details}
                                      </p>
                                      <p className="text-[9px] font-bold text-slate-500 uppercase flex items-center gap-1.5 mt-1">
                                         <User className="w-2.5 h-2.5" /> {log.userName || log.userEmail.split('@')[0]} 
                                         <span className="text-slate-700 mx-1">•</span> 
                                         {format(new Date(log.timestamp), 'dd MMM')}
                                      </p>
                                   </div>
                                </div>
                             ))}
                             {auditLogs.length === 0 && (
                                <div className="flex flex-col items-center justify-center py-12 text-slate-600 opacity-50">
                                   <History className="w-8 h-8 mb-2" />
                                   <p className="text-[10px] font-bold uppercase tracking-widest">Geen acties gevonden</p>
                                </div>
                             )}
                          </div>
                       </div>
                    </div>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSave} className="space-y-8">
                  {formData.status === 'waiting-parts' && (
                    <motion.div 
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex items-center gap-4 p-5 bg-orange-50 border border-orange-200 rounded-2xl text-orange-800"
                    >
                      <AlertCircle className="w-6 h-6 text-orange-500 shrink-0" />
                      <div>
                        <p className="text-xs font-bold uppercase tracking-wider">Wacht op onderdelen</p>
                        <p className="text-[11px] font-medium opacity-80 mt-0.5">Zorg dat de benodigde onderdelen zijn besteld en vermeld de vervolgactie onderaan.</p>
                      </div>
                    </motion.div>
                  )}

                  {formData.status === 'completed' && (
                    <motion.div 
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex flex-col md:flex-row md:items-center gap-4 p-5 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-800"
                    >
                      <div className="flex items-center gap-4 flex-1">
                        <CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0" />
                        <div>
                          <p className="text-xs font-bold uppercase tracking-wider">Interventie Afgerond</p>
                          <p className="text-[11px] font-medium opacity-80 mt-0.5">Zorg dat de klant de werkbon tekent voor akkoord.</p>
                        </div>
                      </div>
                      {selectedIntervention && (
                        <button 
                          type="button"
                          onClick={() => window.location.href = `/work-orders?interventionId=${selectedIntervention.id}`}
                          className="btn-primary !bg-emerald-600 !py-2 !px-4 text-[11px]"
                        >
                          Maak Werkbon
                        </button>
                      )}
                    </motion.div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {/* Basic Info */}
                    <div>
                      <label className="label">Klant *</label>
                      <select 
                        required
                        className="input-field"
                        value={formData.customerId}
                        onChange={(e) => setFormData({...formData, customerId: e.target.value, machineId: ''})}
                      >
                        <option value="">Selecteer klant...</option>
                        {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                      </select>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="label">Begindatum *</label>
                        <input 
                          required type="date" 
                          className="input-field" 
                          value={formData.date}
                          onChange={(e) => setFormData({...formData, date: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="label">Einddatum (optioneel)</label>
                        <input 
                          type="date" 
                          className="input-field" 
                          value={formData.endDate}
                          min={formData.date}
                          onChange={(e) => setFormData({...formData, endDate: e.target.value})}
                        />
                      </div>
                    </div>
                    <div>
                      <label className="label">Tijd</label>
                      <input 
                        type="time" 
                        className="input-field" 
                        value={formData.time}
                        onChange={(e) => setFormData({...formData, time: e.target.value})}
                      />
                    </div>

                    <div className="md:col-span-2">
                      <label className="label">Machine *</label>
                      <select 
                        required
                        className="input-field"
                        value={formData.machineId}
                        onChange={(e) => setFormData({...formData, machineId: e.target.value})}
                      >
                        <option value="">{formData.customerId ? 'Selecteer machine...' : 'Kies eerst een klant'}</option>
                        {machines.filter(m => m.customerId === formData.customerId).map(m => (
                          <option key={m.id} value={m.id}>{m.brand} {m.model} ({m.serialNumber})</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="label">Technicus</label>
                      <input 
                        type="text" 
                        placeholder="Naam technicus"
                        className="input-field" 
                        value={formData.technicianName}
                        onChange={(e) => setFormData({...formData, technicianName: e.target.value})}
                      />
                    </div>

                    <div>
                      <label className="label">Type *</label>
                      <select 
                        required
                        className="input-field"
                        value={formData.type}
                        onChange={(e) => setFormData({...formData, type: e.target.value as InterventionType})}
                      >
                        <option value="onderhoud">Onderhoud</option>
                        <option value="storing">Storing</option>
                        <option value="installatie">Installatie</option>
                        <option value="inspectie">Inspectie</option>
                        <option value="garantie">Garantie</option>
                        <option value="training">Training</option>
                        <option value="anders">Overig</option>
                      </select>
                    </div>
                    <div>
                      <label className="label">Prioriteit</label>
                      <select 
                        className="input-field"
                        value={formData.priority}
                        onChange={(e) => setFormData({...formData, priority: e.target.value as ReminderPriority})}
                      >
                        <option value="low">Laag</option>
                        <option value="normal">Normaal</option>
                        <option value="high">Hoog</option>
                        <option value="urgent">Urgent</option>
                      </select>
                    </div>
                    <div>
                      <label className="label">Status</label>
                      <select 
                        className={cn("input-field font-bold", getStatusStyle(formData.status))}
                        value={formData.status}
                        onChange={(e) => setFormData({...formData, status: e.target.value as InterventionStatus})}
                      >
                        <option value="to-be-scheduled">Nog te plannen</option>
                        <option value="planned">Gepland</option>
                        <option value="on-route">Onderweg</option>
                        <option value="in-progress">Bezig</option>
                        <option value="waiting-parts">Wacht op onderdelen</option>
                        <option value="completed">Afgerond</option>
                        <option value="cancelled">Geannuleerd</option>
                      </select>
                    </div>

                    <div className="md:col-span-3 pt-4 border-t border-slate-100">
                      <div className="flex items-center justify-between mb-3">
                        <label className="text-xs font-bold uppercase tracking-wider text-slate-500">Onderdelen & Verbruik</label>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-bold text-slate-400 uppercase">Snel Toevoegen:</span>
                          <select 
                            className="text-xs font-bold bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 outline-none"
                            onChange={(e) => {
                              const item = inventory.find(i => i.id === e.target.value);
                              if (item) {
                                if (!formData.partsUsed.find(p => p.itemId === item.id)) {
                                  setFormData({
                                    ...formData,
                                    partsUsed: [...formData.partsUsed, { 
                                      itemId: item.id, 
                                      quantity: 1, 
                                      name: item.name,
                                      unitPrice: item.sellingPrice
                                    }]
                                  });
                                }
                              }
                              e.target.value = '';
                            }}
                          >
                            <option value="">Kies onderdeel...</option>
                            {inventory.filter(i => i.status === 'active').map(i => (
                              <option key={i.id} value={i.id}>
                                {i.name} (€{i.sellingPrice?.toFixed(2)})
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {formData.partsUsed.map((part, idx) => (
                          <div key={part.itemId} className="flex items-center gap-3 p-3 bg-slate-50 border border-slate-200 rounded-xl group transition-all hover:border-slate-300">
                            <div className="p-2 bg-white rounded-lg text-blue-600 shadow-sm border border-slate-100 italic">
                              <Package className="w-3.5 h-3.5" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-bold text-slate-900 truncate">{part.name}</p>
                              <div className="flex items-center gap-2 mt-0.5">
                                <p className="text-[9px] text-slate-400 font-bold uppercase">
                                   Stock: {inventory.find(i => i.id === part.itemId)?.stockCount || 0}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-lg p-0.5 shadow-sm">
                              <button 
                                type="button"
                                onClick={() => {
                                  const newParts = [...formData.partsUsed];
                                  if (newParts[idx].quantity > 1) {
                                    newParts[idx].quantity -= 1;
                                    setFormData({ ...formData, partsUsed: newParts });
                                  }
                                }}
                                className="w-7 h-7 flex items-center justify-center text-slate-400 hover:text-blue-600 hover:bg-slate-50 rounded"
                              >
                                <Minus className="w-3.5 h-3.5" />
                              </button>
                              <span className="w-6 text-center text-xs font-bold">{part.quantity}</span>
                              <button 
                                type="button"
                                onClick={() => {
                                  const newParts = [...formData.partsUsed];
                                  newParts[idx].quantity += 1;
                                  setFormData({ ...formData, partsUsed: newParts });
                                }}
                                className="w-7 h-7 flex items-center justify-center text-slate-400 hover:text-blue-600 hover:bg-slate-50 rounded"
                              >
                                <Plus className="w-3.5 h-3.5" />
                              </button>
                            </div>
                            <button 
                              type="button"
                              onClick={() => {
                                setFormData({
                                  ...formData,
                                  partsUsed: formData.partsUsed.filter((_, i) => i !== idx)
                                });
                              }}
                              className="p-2 text-slate-300 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-all"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                        {formData.partsUsed.length === 0 && (
                          <div className="md:col-span-2 py-6 border border-dashed border-slate-200 rounded-xl flex flex-col items-center justify-center bg-slate-50/50">
                             <Package className="w-5 h-5 mb-1 text-slate-300" />
                             <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Geen onderdelen geselecteerd</p>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Problem & Solution */}
                    <div className="md:col-span-3 grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="label">Omschrijving probleem</label>
                        <textarea 
                          rows={3}
                          placeholder="Wat was de klacht?"
                          className="input-field resize-none" 
                          value={formData.problemDescription}
                          onChange={(e) => setFormData({...formData, problemDescription: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="label">Uitgevoerde Werkzaamheden</label>
                        <textarea 
                          rows={3}
                          placeholder="Wat heeft u gedaan?"
                          className="input-field resize-none" 
                          value={formData.workPerformed}
                          onChange={(e) => setFormData({...formData, workPerformed: e.target.value})}
                        />
                      </div>
                    </div>

                    {/* Time Tracking */}
                    <div>
                      <label className="label">Gewerkte Uren</label>
                      <div className="relative">
                         <Clock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                         <input 
                          type="number" step="0.25"
                          className="input-field pl-10" 
                          value={formData.hoursWorked}
                          onChange={(e) => setFormData({...formData, hoursWorked: parseFloat(e.target.value)})}
                        />
                      </div>
                    </div>
                    <div>
                      <label className="label">Reistijd (minuten)</label>
                      <input 
                        type="number" 
                        className="input-field" 
                        value={formData.travelTime}
                        onChange={(e) => setFormData({...formData, travelTime: parseInt(e.target.value)})}
                      />
                    </div>
                    <div className="md:col-span-1">
                       {/* Space filler or extra field */}
                    </div>

                    {/* Planning & Follow up */}
                    <div className="md:col-span-3 grid grid-cols-1 md:grid-cols-2 gap-6 bg-slate-50 p-6 rounded-2xl border border-slate-200">
                      <div>
                        <label className="label">Vervolgactie</label>
                        <input 
                          type="text" 
                          placeholder="Nabestellen, herhaalbezoek, etc."
                          className="input-field underline-offset-4" 
                          value={formData.followUpAction}
                          onChange={(e) => setFormData({...formData, followUpAction: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="label">Volgende Onderhoudsdatum</label>
                        <input 
                          type="date" 
                          className="input-field" 
                          value={formData.nextMaintenanceDate}
                          onChange={(e) => setFormData({...formData, nextMaintenanceDate: e.target.value})}
                        />
                      </div>
                    </div>

                    {/* Notes */}
                    <div className="md:col-span-3 grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-100">
                      <div>
                        <label className="label">Interne Opmerkingen</label>
                        <textarea 
                          rows={2}
                          className="input-field resize-none" 
                          value={formData.internalNotes}
                          onChange={(e) => setFormData({...formData, internalNotes: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="label">Publieke Opmerkingen (op werkbon)</label>
                        <textarea 
                          rows={2}
                          className="input-field resize-none" 
                          value={formData.customerNotes}
                          onChange={(e) => setFormData({...formData, customerNotes: e.target.value})}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-3 pt-8 border-t border-slate-100">
                    <button 
                      type="button" 
                      onClick={() => setIsAddModalOpen(false)}
                      className="btn-ghost"
                    >
                      Annuleren
                    </button>
                    <button 
                      type="submit" 
                      className="btn-primary min-w-[200px]"
                    >
                      {selectedIntervention ? 'Wijzigingen Opslaan' : 'Interventie Registreren'}
                    </button>
                  </div>
                </form>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <ConfirmDialog
        isOpen={deleteConfirm.isOpen}
        title="Interventie Verwijderen"
        message="Weet u zeker dat u deze interventie wilt verwijderen? Dit kan niet ongedaan worden gemaakt."
        onConfirm={handleDelete}
        onCancel={() => setDeleteConfirm({ isOpen: false, id: null })}
      />

      <AppointmentModal 
        isOpen={isAppointmentModalOpen}
        onClose={() => setIsAppointmentModalOpen(false)}
        appointment={null}
        initialData={appointmentInitialData}
        onSave={() => {
          setIsAppointmentModalOpen(false);
          refreshData();
        }}
        customers={customers}
        machines={machines}
        reminders={[]}
        interventions={interventions}
      />
    </div>
  );
};

export default Interventions;
