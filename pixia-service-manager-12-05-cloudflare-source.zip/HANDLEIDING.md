# Gebruikershandleiding: Pixia Service Manager

Welkom bij de Pixia Service Manager. Deze handleiding helpt u stap voor stap om het maximale uit de applicatie te halen. De software is ontworpen om uw serviceprocessen te digitaliseren, van klantenbeheer tot automatische planning en voorraadbeheer.

---

## 1. Introductie
**Wat doet de app?**
De Pixia Service Manager is een centraal platform voor technische dienstverlening. Het vervangt papieren werkbonnen, Excel-lijsten en losse agenda's door één slim digitaal systeem.

**Voor wie is het bedoeld?**
- **Administratie/Planners:** Voor het beheren van klanten, machines en de centrale planning.
- **Technici:** Voor het inzien van hun dagplanning, het registreren van werkzaamheden op locatie en het laten ondertekenen van werkbonnen.

**Belangrijkste voordelen:**
- **Altijd overzicht:** Direct inzicht in de status van alle lopende interventies.
- **Geen onderhoud vergeten:** Automatische meldingen wanneer een machine onderhoud nodig heeft.
- **Snelle facturatie:** Werkbonnen zijn direct digitaal beschikbaar na afronding.
- **Voorraadcontrole:** Onderdelen worden automatisch van de voorraad afgeboekt bij gebruik.

---

## 2. Inloggen en starten
1.  **Inloggen:** Ga naar de URL van de applicatie. Log in met uw zakelijke e-mailadres of via de "Google Login" knop.
2.  **Het Dashboard:** Na het inloggen komt u op het Dashboard. Hier ziet u:
    *   **Statistieken:** Aantal openstaande taken, machines in onderhoud en voorraadstatus.
    *   **Smart Alerts:** Slimme meldingen (bijv. "Voorraad bijna op" of "Garantie verloopt").
    *   **Snelkoppelingen:** Directe knoppen om een nieuwe klant of interventie toe te voegen.

---

## 3. Navigatie uitleg
In het menu aan de linkerzijde vindt u de volgende onderdelen:
- **Dashboard:** Uw centrale cockpit met live data.
- **Klanten:** Overzicht van alle bedrijven en contactpersonen.
- **Machines:** De volledige database van alle geïnstalleerde apparatuur.
- **Interventies:** Alle servicebezoeken, reparaties en installaties.
- **Voorraad:** Beheer van onderdelen en verbruiksartikelen.
- **Reminders:** Uw takenlijst en automatische herinneringen.
- **Audit Logs:** (Admin) Overzicht van wie wat heeft gedaan in het systeem.
- **Instellingen:** Beheer van uw profiel, bedrijfsgegevens en e-mailtemplates.

---

## 4. Klantenbeheer
**Een nieuwe klant toevoegen:**
1. Ga naar **Klanten** in het zijmenu.
2. Klik op de knop **+ Nieuwe Klant**.
3. Vul de gegevens in (Naam, Adres, Contactpersoon, E-mail).
4. Klik op **Klant Opslaan**.

**Klant zoeken:** Gebruik de zoekbalk bovenin de klantenlijst om te filteren op naam of plaats.

---

## 5. Machinebeheer
Elke machine is gekoppeld aan een klant.
1. **Toevoegen:** Ga naar **Machines** en klik op **+ Nieuwe Machine**.
2. **Koppelen:** Selecteer de klant waar de machine staat.
3. **Belangrijke Velden:**
   *   **Model/Merk:** Welk type machine is het?
   *   **Serienummer:** Cruciaal voor garantieclaims.
   *   **Installatiedatum:** Hierop wordt de garantie berekend.
   *   **Onderhoudsinterval:** Hoe vaak (om de hoeveel maanden) heeft de machine service nodig?
4. **QR-code:** Elke machine krijgt automatisch een unieke code. Deze kunt u uitprinten en op de machine plakken voor snelle identificatie.

---

## 6. Onderhoud en interventies
**Interventie aanmaken:**
1. Ga naar **Interventies** en klik op **+ Nieuwe Interventie**.
2. Kies de klant en de specifieke machine.
3. Selecteer het type (Onderhoud, Storing, Installatie).
4. Plan een datum en wijs een technicus toe.

**Status wijzigen:**
- **To-be-scheduled:** Moet nog ingepland worden.
- **Planned:** Staat in de agenda.
- **In Progress:** De technicus is momenteel aan het werk.
- **Completed:** De klus is geklaard. *Let op: Bij afronding wordt de voorraad automatisch bijgewerkt!*

---

## 7. Agenda en planning
**Voor technici:**
Ga naar de pagina **Technicus Vandaag**. Hier ziet u alleen de taken van vandaag in een overzichtelijke lijst.
- Klik op een taak om de adresgegevens te zien.
- Start de navigatie direct via de Map-knop.

---

## 8. Werkbonnen
Aan het einde van een interventie maakt u de digitale werkbon op:
1. Vul de uitgevoerde werkzaamheden in.
2. Voeg de gebruikte onderdelen toe uit de voorraadlijst.
3. Laat de klant tekenen op het scherm (tablet of telefoon).
4. Klik op **Afronden**. De werkbon is nu als PDF opgeslagen en kan direct gemaild worden.

---

## 9. Voorraadbeheer
1. **Artikelen:** Voeg onderdelen toe met een naam, SKU-code en minimale voorraad.
2. **Automatische afboeking:** Wanneer u in een interventie een onderdeel selecteert ("Toner X"), wordt dit bij afronding automatisch van de voorraad afgehaald.
3. **Bestellen:** Artikelen die onder de "Minimale Voorraad" komen, verschijnen als alert op het dashboard.

---

## 10. Meldingen en herinneringen
Het systeem denkt met u mee:
- **Garantie-alert:** Melding als een machine bijna uit de garantie loopt.
- **Onderhoud-reminder:** Automatische taak in de lijst als het interval van een machine is verstreken.
- **Checklist:** Gebruik de 'Reminders' tab om eigen taken (bijv. "Klant terugbellen") vast te leggen.

---

## 11. E-mail en Outlook
Indien geconfigureerd:
- **Bevestigingen:** De klant ontvangt automatisch een mail wanneer een afspraak wordt gepland.
- **Outlook Sync:** Afspraken verschijnen direct in uw persoonlijke Outlook-agenda.
- **Templates:** In de instellingen kunt u de teksten van deze e-mails zelf aanpassen.

---

## 12. Gebruikersbeheer (Admin)
Onder **Instellingen > Gebruikers**:
- **Admin:** Heeft toegang tot alle financiële data, logs en instellingen.
- **Technician:** Kan alleen eigen taken zien en werkbonnen invullen.
- **Viewer:** Kan alleen gegevens bekijken (bijv. voor een magazijnmedewerker).

---

## 13. Veelgemaakte acties (Quick Guide)
*   **Nieuwe machine plaatsen?** Klant aanmaken -> Machine toevoegen -> Eerste onderhoud plannen.
*   **Storing oplossen?** Interventie maken (Type: Storing) -> Technicus toewijzen -> Werkbon laten tekenen.
*   **Voorraad tellen?** Ga naar Voorraad -> Klik op het edit-icoon bij een artikel -> Pas de 'Stock Count' aan.

---

## 14. Tips voor dagelijks gebruik
- **Zoekfunctie:** Gebruik de zoekbalken boven elk overzicht. U hoeft niet te scrollen.
- **Mobiel:** Gebruik de app op uw telefoon voor onderweg; de interface past zich automatisch aan.
- **Statussen:** Houd statussen accuraat bij. Dit zorgt voor de juiste data in de rapportages.

---

## 15. Problemen oplossen (FAQ)
*   **Inloggen lukt niet?** Controleer of uw e-mail is toegevoegd door de beheerder.
*   **Geen data zichtbaar?** Ververs de pagina (F5) of controleer uw internetverbinding.
*   **Kan niet tekenen?** Zorg dat u op een touchscreen werkt of gebruik uw muis op een laptop.
*   **E-mail niet ontvangen?** Controleer de spambox van de klant of check de 'Email Logs' in de instellingen.

---

## 16. Veiligheid en gegevens
- Alle data wordt veilig opgeslagen in een versleutelde database.
- Gebruikers hebben alleen toegang tot de onderdelen die voor hun rol relevant zijn.
- Voer gegevens altijd correct in; dit is de basis voor uw facturatie en garantie-afhandeling.

---

## 17. Toekomstige uitbreidingen
We werken continu aan verbeteringen. Op de planning staan:
- **Klantportaal:** Waar klanten zelf hun machinehistorie kunnen inzien.
- **Directe Facturatie:** Koppeling met boekhoudpakketten.
- **Foto-upload:** Foto's toevoegen aan werkbonnen voor schadedocumentatie.

---
*Pixia Service Manager - Versie 1.0*
