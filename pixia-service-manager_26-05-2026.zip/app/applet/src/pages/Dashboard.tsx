import React, { useMemo } from 'react';
import { useDashboard } from '../hooks/useDashboard';
import { updateDoc, doc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import DashboardFilters from '../components/dashboard/DashboardFilters';
import DashboardStats from '../components/dashboard/DashboardStats';
import DashboardCharts from '../components/dashboard/DashboardCharts';
import DashboardAlerts from '../components/dashboard/DashboardAlerts';
import DashboardLists from '../components/dashboard/DashboardLists';
import DashboardQuickActions from '../components/dashboard/DashboardQuickActions';
import DashboardInsights from '../components/dashboard/DashboardInsights';
import { COLLECTIONS } from '../constants/collections';

const Dashboard: React.FC = () => {
  const {
    loading,
    period, setPeriod,
    selectedCustomerId, setSelectedCustomerId,
    selectedMachineType, setSelectedMachineType,
    customers,
    machineTypes,
    statsOverview,
    trendsData,
    typeData,
    statusData,
    topFaultyMachines,
    topCustomers,
    lowStockItems,
    expiringWarrantyCount,
    upcomingMaintenance,
    interventions,
    reminders,
    alerts,
    emailLogs,
    outlookConnection,
    machines,
    refreshData
  } = useDashboard();

  const handleDismissAlert = async (id: string) => {
    try {
      await updateDoc(doc(db, COLLECTIONS.SMART_ALERTS, id), {
        status: 'seen',
        updatedAt: new Date().toISOString()
      });
      refreshData();
    } catch (err) {
      console.error('Error dismissing alert:', err);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-20">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-500"></div>
      </div>
    );
  }

  // Laag 2: Live Status Interventies (Bezig, Onderweg, etc.)
  const activeInterventions = useMemo(() => {
    return interventions.filter(i => 
      ['bezig', 'in-progress', 'onderweg', 'on-route'].includes(i.status.toLowerCase())
    );
  }, [interventions]);

  return (
    <div className="flex flex-col gap-6 pb-20">
      
      {/* Filters (Algemeen) */}
      <div>
        <DashboardFilters 
          period={period}
          setPeriod={setPeriod}
          selectedCustomerId={selectedCustomerId}
          setSelectedCustomerId={setSelectedCustomerId}
          selectedMachineType={selectedMachineType}
          setSelectedMachineType={setSelectedMachineType}
          customers={customers}
          machineTypes={machineTypes}
        />
      </div>

      {/* 2/3 en 1/3 Vlakverdeling middels CSS Grid */}
      <div className="flex flex-col lg:grid lg:grid-cols-12 gap-6 items-start">

        {/* --- RECHTERKOLOM (Actie & Feed) -> 1/3 van het scherm --- */}
        {/* Order-1 op mobiel: Laag 1 Actie & Urgentie rolt als eerste in de stack */}
        <div className="order-1 lg:order-2 lg:col-span-4 flex flex-col gap-6 w-full">

          {/* LAAG 1: ACTIE & URGENTIE */}
          <div className="flex flex-col gap-4">
            {/* Actieve Alerts hebben de hoogste prioriteit */}
            <DashboardAlerts 
              alerts={alerts}
              onDismiss={handleDismissAlert}
            />

            {/* Inzichten voor Kritieke Voorraad en Garantie/Onderhoud */}
            <DashboardInsights 
              lowStockItems={lowStockItems}
              expiringWarrantyCount={expiringWarrantyCount}
              faultyMachinesCount={machines.filter(m => m.status === 'faulty').length}
              upcomingMaintenance={upcomingMaintenance}
              customers={customers}
            />
          </div>

          {/* Actieknoppen voor snelle toegang (Feed/Quick Actions) */}
          <div className="flex flex-col gap-4">
            <DashboardQuickActions 
              outlookConnection={outlookConnection}
              emailLogs={emailLogs}
            />
          </div>

        </div>

        {/* --- HOOFDKOLOM (Datadichtheid & Operatie) -> 2/3 van het scherm --- */}
        {/* Order-2 op mobiel: Live overzichten en tabellen */}
        <div className="order-2 lg:order-1 lg:col-span-8 flex flex-col gap-8 w-full">

          {/* LAAG 2: DE DAGELIJKSE OPERATIE (Live Status) */}
          <div className="flex flex-col gap-4">
            <h2 className="text-sm font-bold text-surface-900 uppercase tracking-widest border-b border-surface-200 pb-2">
              Live Status & Dagelijkse Operatie
            </h2>
            {/* DashboardLists toont actieve interventions in deze context */}
            <DashboardLists 
              topFaultyMachines={topFaultyMachines}
              topCustomers={topCustomers}
              interventions={activeInterventions.length > 0 ? activeInterventions : interventions.slice(0, 5)} 
              customers={customers}
            />
          </div>

          {/* LAAG 3: BACKLOG & OVERZICHT (Statistieken, Openstaande zaken, Data) */}
          <div className="flex flex-col gap-6">
            <h2 className="text-sm font-bold text-surface-900 uppercase tracking-widest border-b border-surface-200 pb-2">
              KPI's, Trending & Backlog
            </h2>
            
            <DashboardStats 
              totalInterventions={statsOverview.total}
              closedInterventions={statsOverview.closed}
              lowStockCount={lowStockItems.length}
              openReminders={reminders.length}
            />

            <DashboardCharts 
              trendsData={trendsData}
              typeData={typeData}
              statusData={statusData}
            />
          </div>

        </div>

      </div>
    </div>
  );
};

export default Dashboard;
