import { collection, query, where, getDocs, Timestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Appointment, UserProfile, Intervention } from '../types';
import { format, addHours, parseISO, isWithinInterval, addDays, startOfDay, endOfDay } from 'date-fns';
import { COLLECTIONS } from '../constants/collections';

export const schedulingService = {
  /**
   * Haalt alle actieve technici op
   */
  async getTechnicians(): Promise<UserProfile[]> {
    const q = query(
      collection(db, COLLECTIONS.USERS),
      where('role', '==', 'technician'),
      where('status', '==', 'active')
    );
    const snap = await getDocs(q);
    return snap.docs.map(doc => ({ uid: doc.id, ...doc.data() } as UserProfile));
  },

  /**
   * Haalt alle afspraken op voor een specifieke technicus op een bepaalde dag
   */
  async getTechnicianSchedule(technicianId: string, date: string): Promise<Appointment[]> {
    const q = query(
      collection(db, COLLECTIONS.APPOINTMENTS),
      where('technicianId', '==', technicianId),
      where('date', '==', date)
    );
    const snap = await getDocs(q);
    return snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Appointment));
  },

  /**
   * Suggereert vrije slots voor een interventie
   */
  async suggestSlots(params: {
    technicianId?: string;
    date: string;
    durationHours: number;
  }): Promise<{ startTime: string; endTime: string; technicianId: string }[]> {
    const techs = params.technicianId 
      ? [params.technicianId] 
      : (await this.getTechnicians()).map(t => t.uid);
    
    const suggestions: { startTime: string; endTime: string; technicianId: string }[] = [];
    const workingHours = { start: 8, end: 17 }; // 08:00 tot 17:00

    for (const techId of techs) {
      const schedule = await this.getTechnicianSchedule(techId, params.date);
      
      // Simpele logica: we checken per uur of er een gaatje is
      for (let h = workingHours.start; h <= workingHours.end - params.durationHours; h++) {
        const slotStart = `${String(h).padStart(2, '0')}:00`;
        const slotEnd = `${String(h + params.durationHours).padStart(2, '0')}:00`;
        
        const isConflict = schedule.some(app => {
          // Check of tijden overlappen
          const appStart = app.startTime;
          const appEnd = app.endTime;
          return (slotStart < appEnd && slotEnd > appStart);
        });

        if (!isConflict) {
          suggestions.push({
            startTime: slotStart,
            endTime: slotEnd,
            technicianId: techId
          });
        }
        
        if (suggestions.length >= 5) break; 
      }
      if (suggestions.length >= 5) break;
    }

    return suggestions;
  }
};
