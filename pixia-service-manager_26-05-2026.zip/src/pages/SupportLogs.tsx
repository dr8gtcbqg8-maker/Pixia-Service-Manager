import React, { useEffect, useState, useMemo } from 'react';
import { collection, query, getDocs, orderBy, addDoc, updateDoc, doc, deleteDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { format } from 'date-fns';
import { nl } from 'date-fns/locale';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, Search, Headphones, Clock, 
  MessageSquare, CheckCircle2, X,
  Trash2, Edit
} from 'lucide-react';

import { useAuth } from '../contexts/AuthContext';
import { SupportLog, SupportStatus, Customer } from '../types';
import { cn, handleFirestoreError, OperationType } from '../lib/utils';
import ConfirmDialog from '../components/ConfirmDialog';
import { COLLECTIONS } from '../constants/collections';
import { useLocation } from 'react-router-dom';
import { useCustomers } from '../hooks/useCustomers';

const SupportLogs: React.FC = () => {
  const { profile } = useAuth();
  const { customers } = useCustomers();
  const location = useLocation();
  const [logs, setLogs] = useState<SupportLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('');
  const [customerSearch, setCustomerSearch] = useState('');
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedLog, setSelectedLog] = useState<SupportLog | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<{ isOpen: boolean; id: string | null }>({ isOpen: false, id: null });

  const [formData, setFormData] = useState({
    customerId: '',
    status: 'open' as SupportStatus,
    duration: '',
    problem: '',
    solution: '',
  });

  const fetchData = async () => {
    setLoading(true);
    try {
      const logsSnap = await getDocs(query(collection(db, COLLECTIONS.SUPPORT_LOGS), orderBy('createdAt', 'desc')));
      const fetchedLogs = logsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as SupportLog));
      setLogs(fetchedLogs);
    } catch (err) {
      console.error('Error fetching support logs:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    
    // Check if customer was passed from another page
    if (location.state?.preSelectedCustomer) {
      setFormData(prev => ({
        ...prev,
        customerId: location.state.preSelectedCustomer
      }));
      setIsModalOpen(true);
      // Clear location state to prevent modal reopening on refresh/back
      window.history.replaceState({}, document.title);
    }
  }, [location.state]);

  const filteredLogs = useMemo(() => logs.filter(log => {
    const customer = customers.find(c => c.id === log.customerId);
    const matchesSearch = 
      (customer?.name || '').toLowerCase().includes(search.toLowerCase()) ||
      (log.problem || '').toLowerCase().includes(search.toLowerCase()) ||
      (log.solution || '').toLowerCase().includes(search.toLowerCase());
    
    const matchesStatus = !filterStatus || log.status === filterStatus;
    
    return matchesSearch && matchesStatus;
  }), [logs, customers, search, filterStatus]);

  const filteredCustomers = useMemo(() => {
    if (!customerSearch) return customers;
    return customers.filter(c => 
      c.name.toLowerCase().includes(customerSearch.toLowerCase()) ||
      (c.contactPerson || '').toLowerCase().includes(customerSearch.toLowerCase())
    );
  }, [customers, customerSearch]);

  const handleOpenAddModal = () => {
    setSelectedLog(null);
    setCustomerSearch('');
    setFormData({
      customerId: '',
      status: 'open',
      duration: '',
      problem: '',
      solution: '',
    });
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (log: SupportLog) => {
    setSelectedLog(log);
    const customer = customers.find(c => c.id === log.customerId);
    setCustomerSearch(customer?.name || '');
    setFormData({
      customerId: log.customerId,
      status: log.status,
      duration: log.duration || '',
      problem: log.problem,
      solution: log.solution || '',
    });
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;

    try {
      const logData = {
        ...formData,
        customerName: customers.find(c => c.id === formData.customerId)?.name || '',
        technicianId: profile.uid,
        technicianName: profile.displayName || profile.email,
        updatedAt: new Date().toISOString(),
      };

      if (selectedLog) {
        await updateDoc(doc(db, COLLECTIONS.SUPPORT_LOGS, selectedLog.id), logData);
      } else {
        const newLog = {
          ...logData,
          createdAt: new Date().toISOString(),
        };
        await addDoc(collection(db, COLLECTIONS.SUPPORT_LOGS), newLog);
      }

      setIsModalOpen(false);
      fetchData();
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, COLLECTIONS.SUPPORT_LOGS);
    }
  };

  const handleDelete = async () => {
    if (deleteConfirm.id) {
      try {
        await deleteDoc(doc(db, COLLECTIONS.SUPPORT_LOGS, deleteConfirm.id));
        setDeleteConfirm({ isOpen: false, id: null });
        fetchData();
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, COLLECTIONS.SUPPORT_LOGS);
      }
    }
  };

  const getStatusLabel = (status: SupportStatus) => {
    switch (status) {
      case 'open': return 'Open';
      case 'in-progress': return 'In behandeling';
      case 'completed': return 'Afgehandeld';
      default: return status;
    }
  };

  const getStatusStyle = (status: SupportStatus) => {
    switch (status) {
      case 'open': return 'bg-amber-50 text-amber-700 border-amber-100';
      case 'in-progress': return 'bg-brand-50 text-blue-700 border-brand-200';
      case 'completed': return 'bg-emerald-50 text-emerald-700 border-emerald-100';
      default: return 'bg-surface-50 text-surface-700 border-surface-100';
    }
  };

  return (
    <div className="space-y-4 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-surface-200 pb-6">
        <div>
          <h1 className="text-2xl font-bold text-surface-900 leading-tight">Support Log</h1>
          <p className="text-sm text-surface-500 mt-1">Registratie van remote en telefonische support.</p>
        </div>
        <button 
          onClick={handleOpenAddModal}
          className="btn-primary"
        >
          <Plus className="w-4 h-4" />
          <span>Support Registreren</span>
        </button>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-5 bg-white rounded-md border border-surface-200 shadow-sm">
        <div className="md:col-span-2 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
          <input 
            type="text" 
            placeholder="Zoek in probleem, oplossing of klant..."
            className="w-full pl-10 pr-4 py-3 bg-surface-50 border border-surface-100 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/10 transition-all"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div>
          <select 
            className="w-full px-4 py-3 bg-surface-50 border border-surface-100 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/10 transition-all font-medium"
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
          >
            <option value="">Alle statussen</option>
            <option value="open">Open</option>
            <option value="in-progress">In behandeling</option>
            <option value="completed">Afgehandeld</option>
          </select>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center p-24">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-surface-200 border-t-blue-600"></div>
        </div>
      ) : (
        <div className="bg-white rounded-lg border border-surface-200 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-surface-100 bg-surface-50/50">
                  <th className="px-6 py-2 text-[11px] font-bold text-surface-400 uppercase tracking-wider">Klant & Datum</th>
                  <th className="px-6 py-2 text-[11px] font-bold text-surface-400 uppercase tracking-wider">Probleem</th>
                  <th className="px-6 py-2 text-[11px] font-bold text-surface-400 uppercase tracking-wider">Oplossing</th>
                  <th className="px-6 py-2 text-[11px] font-bold text-surface-400 uppercase tracking-wider text-center">Duur</th>
                  <th className="px-6 py-2 text-[11px] font-bold text-surface-400 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-2 text-[11px] font-bold text-surface-400 uppercase tracking-wider text-right">Acties</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-surface-50">
                {filteredLogs.map(log => (
                  <motion.tr
                    layout
                    key={log.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="hover:bg-surface-50/50 transition-colors group"
                  >
                    <td className="px-6 py-2">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-brand-50 text-brand-500 rounded-md">
                          <Headphones className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-surface-900 leading-none mb-1">{log.customerName}</p>
                          <p className="text-[10px] font-bold text-surface-400">
                            {format(new Date(log.createdAt), 'dd MMM yyyy HH:mm', { locale: nl })}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-2 max-w-[200px]">
                      <p className="text-xs text-surface-600 italic line-clamp-2 leading-relaxed">
                        {log.problem}
                      </p>
                    </td>
                    <td className="px-6 py-2 max-w-[250px]">
                      {log.solution ? (
                        <p className="text-xs text-surface-600 line-clamp-2 leading-relaxed">
                          {log.solution}
                        </p>
                      ) : (
                        <span className="text-[10px] italic text-surface-300">Geen oplossing geregistreerd</span>
                      )}
                    </td>
                    <td className="px-6 py-2 text-center">
                      <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-surface-100 rounded-lg text-[10px] font-bold text-surface-600">
                        <Clock className="w-3 h-3 text-blue-500" />
                        {log.duration || 'N/A'}
                      </div>
                    </td>
                    <td className="px-6 py-2">
                      <span className={cn(
                        "inline-flex text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full border",
                        getStatusStyle(log.status)
                      )}>
                        {getStatusLabel(log.status)}
                      </span>
                    </td>
                    <td className="px-6 py-2 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button 
                          onClick={() => handleOpenEditModal(log)}
                          className="p-2 text-surface-400 hover:text-brand-500 hover:bg-brand-50 rounded-md transition-all"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button 
                           onClick={() => setDeleteConfirm({ isOpen: true, id: log.id })}
                           className="p-2 text-surface-400 hover:text-red-500 hover:bg-red-50 rounded-md transition-all"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>

            {filteredLogs.length === 0 && (
              <div className="py-24 flex flex-col items-center justify-center text-surface-300">
                 <Headphones className="w-12 h-12 mb-4 opacity-20" />
                 <p className="text-base font-bold">Geen support logs gevonden</p>
                 <p className="text-sm">Pas uw filters aan of voeg een nieuwe registratie toe.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Add/Edit Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-surface-900/60 backdrop-blur-sm"

            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-2xl rounded-lg shadow-2xl p-5 overflow-y-auto max-h-[95vh] focus:outline-none"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 pb-6 border-b border-surface-100">
                <h2 className="text-xl font-bold text-surface-900 flex items-center gap-3 flex-wrap">
                  <div className="p-2.5 bg-brand-500 text-white rounded-md shadow-lg shadow-blue-500/20 shrink-0">
                    <Headphones className="w-5 h-5" />
                  </div>
                  <span>{selectedLog ? 'Support Registratie Aanpassen' : 'Nieuwe Support Registratie'}</span>
                </h2>
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="p-2 hover:bg-surface-100 rounded-lg text-surface-400 self-end sm:self-auto shrink-0"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <form onSubmit={handleSave} className="space-y-3">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="md:col-span-2">
                    <label className="label">Klant *</label>
                    <div className="space-y-2">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
                        <input 
                          type="text" 
                          placeholder="Zoek klant..." 
                          className="input-field pl-10"
                          value={customerSearch}
                          onChange={(e) => setCustomerSearch(e.target.value)}
                        />
                      </div>
                      <select 
                        required
                        className="input-field"
                        value={formData.customerId}
                        onChange={(e) => {
                          const id = e.target.value;
                          setFormData({...formData, customerId: id});
                          const name = customers.find(c => c.id === id)?.name || '';
                          setCustomerSearch(name);
                        }}
                      >
                        <option value="">Selecteer klant...</option>
                        {filteredCustomers.map(c => (
                          <option key={c.id} value={c.id}>{c.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="label">Status *</label>
                    <select 
                      required
                      className={cn("input-field font-bold", getStatusStyle(formData.status))}
                      value={formData.status}
                      onChange={(e) => setFormData({...formData, status: e.target.value as SupportStatus})}
                    >
                      <option value="open">Open</option>
                      <option value="in-progress">In behandeling</option>
                      <option value="completed">Afgehandeld</option>
                    </select>
                  </div>

                  <div>
                    <label className="label">Duur (bijv: 15 min, 1u)</label>
                    <div className="relative">
                       <Clock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
                       <input 
                        type="text" 
                        placeholder="bijv: 30 min"
                        className="input-field pl-10" 
                        value={formData.duration}
                        onChange={(e) => setFormData({...formData, duration: e.target.value})}
                      />
                    </div>
                  </div>

                  <div className="md:col-span-2">
                    <label className="label">Probleem / Vraag *</label>
                    <textarea 
                      required
                      rows={4}
                      placeholder="Wat is de vraag of het probleem van de klant?"
                      className="input-field resize-none italic" 
                      value={formData.problem}
                      onChange={(e) => setFormData({...formData, problem: e.target.value})}
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="label">Oplossing / Advies</label>
                    <textarea 
                      rows={4}
                      placeholder="Wat is de geboden oplossing of het gegeven advies?"
                      className="input-field resize-none shadow-inner bg-surface-50" 
                      value={formData.solution}
                      onChange={(e) => setFormData({...formData, solution: e.target.value})}
                    />
                  </div>
                </div>

                <div className="flex items-center justify-end gap-3 pt-6 border-t border-surface-100">
                  <button 
                    type="button" 
                    onClick={() => setIsModalOpen(false)}
                    className="btn-ghost"
                  >
                    Annuleren
                  </button>
                  <button 
                    type="submit" 
                    className="btn-primary min-w-[200px]"
                  >
                    Opslaan
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <ConfirmDialog
        isOpen={deleteConfirm.isOpen}
        title="Logs Verwijderen"
        message="Weet u zeker dat u deze support registratie wilt verwijderen?"
        onConfirm={handleDelete}
        onCancel={() => setDeleteConfirm({ isOpen: false, id: null })}
      />
    </div>
  );
};

export default SupportLogs;
