import React from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertCircle, Users, Clock, ChevronRight, Wrench } from 'lucide-react';
import { Machine, Customer, Intervention } from '../../types';

interface DashboardListsProps {
  topFaultyMachines: { machine: Machine | undefined; count: number }[];
  topCustomers: { customer: Customer | undefined; count: number }[];
  interventions: Intervention[];
  customers: Customer[];
}

const DashboardLists: React.FC<DashboardListsProps> = ({ 
  topFaultyMachines, 
  topCustomers, 
  interventions, 
  customers 
}) => {
  const navigate = useNavigate();

  return (
    <div className="space-y-4">
      {/* Faulty Machines & Top Customers */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <section className="card overflow-hidden">
           <div className="p-4 border-b border-surface-200 flex items-center justify-between bg-surface-50/50">
              <h3 className="text-[13px] font-bold text-surface-900 uppercase tracking-wide flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-500" />
                Storingsgevoelig
              </h3>
           </div>
           <div className="p-2">
              {topFaultyMachines.map(({ machine, count }, idx) => (
                <div key={idx} className="flex items-center gap-3 p-3 hover:bg-surface-50 rounded-md transition-all">
                   <span className="text-lg font-bold text-surface-300 w-5 text-center">#{idx + 1}</span>
                   <div className="flex-1 text-left min-w-0">
                      <p className="text-sm font-semibold text-surface-900 truncate">{machine?.brand} {machine?.model}</p>
                      <p className="text-xs font-medium text-surface-500 truncate">{machine?.serialNumber}</p>
                   </div>
                   <div className="bg-red-50 text-red-600 px-2.5 py-1 rounded-sm text-xs font-bold">
                     {count}x Storing
                   </div>
                </div>
              ))}
              {topFaultyMachines.length === 0 && (
                <div className="p-5 text-center text-xs font-medium text-surface-400">Geen data beschikbaar</div>
              )}
           </div>
        </section>

        <section className="card overflow-hidden">
           <div className="p-4 border-b border-surface-200 flex items-center justify-between bg-surface-50/50">
              <h3 className="text-[13px] font-bold text-surface-900 uppercase tracking-wide flex items-center gap-2">
                <Users className="w-4 h-4 text-brand-500" />
                Top Klanten
              </h3>
           </div>
           <div className="p-2">
              {topCustomers.map(({ customer, count }, idx) => (
                <div key={idx} className="flex items-center gap-3 p-3 hover:bg-surface-50 rounded-md transition-all">
                   <div className="w-8 h-8 bg-brand-50 rounded-md flex items-center justify-center text-xs font-bold text-brand-600 shrink-0">
                      {customer?.name.charAt(0)}
                   </div>
                   <div className="flex-1 text-left min-w-0">
                      <p className="text-sm font-semibold text-surface-900 truncate">{customer?.name}</p>
                      <p className="text-xs font-medium text-surface-500 truncate">{customer?.email}</p>
                   </div>
                   <div className="bg-white border text-surface-700 px-2.5 py-1 rounded-sm text-xs font-bold">
                     {count}x Visit
                   </div>
                </div>
              ))}
              {topCustomers.length === 0 && (
                <div className="p-5 text-center text-xs font-medium text-surface-400">Geen data beschikbaar</div>
              )}
           </div>
        </section>
      </div>

      {/* Open Interventions */}
      <section className="card overflow-hidden">
        <div className="p-4 border-b border-surface-200 flex items-center justify-between">
          <h2 className="text-[13px] font-bold text-surface-900 uppercase tracking-wide flex items-center gap-2">
            <Clock className="w-4 h-4 text-accent-500" />
            Open Interventies
          </h2>
          <button onClick={() => navigate('/interventions')} className="text-[11px] font-bold text-brand-500 hover:text-brand-600 uppercase tracking-wider hover:underline cursor-pointer">
            Lijst &rarr;
          </button>
        </div>
        <div className="divide-y divide-surface-100">
          {interventions.length > 0 ? (
            interventions.map((i) => (
              <div key={i.id} onClick={() => navigate('/interventions')} className="p-4 hover:bg-surface-50 transition-colors flex items-center justify-between gap-4 cursor-pointer">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-brand-50 text-brand-600 rounded-md flex items-center justify-center shrink-0">
                     <Wrench className="w-5 h-5" />
                  </div>
                  <div className="text-left">
                    <h4 className="text-sm font-semibold text-surface-900">{customers.find(c => c.id === i.customerId)?.name || 'Onbekend'}</h4>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-xs font-medium text-surface-500">{i.date}</span>
                      <span className="w-1.5 h-1.5 rounded-full bg-surface-300"></span>
                      <span className="text-xs font-medium text-surface-500">{i.type}</span>
                    </div>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-surface-400" />
              </div>
            ))
          ) : (
            <div className="p-5 text-center text-surface-400 text-sm font-medium">Alle klussen zijn klaar!</div>
          )}
        </div>
      </section>
    </div>
  );
};

export default DashboardLists;
