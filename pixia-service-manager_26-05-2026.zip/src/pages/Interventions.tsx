import { useSearchParams } from 'react-router-dom';
import React, { useEffect, useState, useMemo, useRef } from 'react';
import { format } from 'date-fns';
import { nl } from 'date-fns/locale';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, Search, Filter, History, Calendar, FileText, Briefcase, 
  MapPin, User, Clock, AlertCircle, CheckCircle2, ChevronRight, X,
  Trash2, Mail, Edit, PlayCircle, ExternalLink, Package, Minus,
  Edit3, Wrench, MoreVertical, ClipboardList, Printer, Sparkles, Download
} from 'lucide-react';

import { useInterventions } from '../hooks/useInterventions';
import { interventionService } from '../services/interventionService';
import { 
  Intervention, Customer, Machine, InterventionStatus, 
  InterventionType, InventoryItem, WorkOrder, AuditLog, 
  AlertPriority, ReminderPriority 
} from '../types';

import { 
  handleFirestoreError, OperationType, cn,
  calculateNextMaintenanceDate, generateSequenceNumber 
} from '../lib/utils';
import { logAction } from '../lib/audit';
import { emailService } from '../lib/emailService';
import { aiService } from '../services/aiService';

import ConfirmDialog from '../components/ConfirmDialog';
import DocumentSection from '../components/DocumentSection';
import AppointmentModal from '../components/AppointmentModal';
import InterventionTable from '../components/interventions/InterventionTable';
import InterventionFilters from '../components/interventions/InterventionFilters';
import { COLLECTIONS } from '../constants/collections';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

const Interventions: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const { 
    interventions, 
    customers, 
    machines, 
    inventory, 
    loading, 
    refreshData 
  } = useInterventions();
  
  const pdfTemplateRef = useRef<HTMLDivElement>(null);
  
  // Filters
  const [search, setSearch] = useState('');
  const [filterCustomer, setFilterCustomer] = useState('');
  const [filterMachine, setFilterMachine] = useState('');
  const [filterType, setFilterType] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterPriority, setFilterPriority] = useState('');
  const [filterDate, setFilterDate] = useState('');

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isAppointmentModalOpen, setIsAppointmentModalOpen] = useState(false);
  const [isSendingEmail, setIsSendingEmail] = useState(false);
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const [aiDraft, setAiDraft] = useState<string | null>(null);
  const [appointmentInitialData, setAppointmentInitialData] = useState<any>({});
  const [selectedIntervention, setSelectedIntervention] = useState<Intervention | null>(null);
  const [isDetailView, setIsDetailView] = useState(false);
  const [interventionWorkOrder, setInterventionWorkOrder] = useState<WorkOrder | null>(null);
  const [interventionWorkOrders, setInterventionWorkOrders] = useState<WorkOrder[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [deleteConfirm, setDeleteConfirm] = useState<{ isOpen: boolean; id: string | null }>({ isOpen: false, id: null });
  const [isSaving, setIsSaving] = useState(false);
  const [duplicateWarning, setDuplicateWarning] = useState<{ isOpen: boolean; matches: Intervention[] }>({ isOpen: false, matches: [] });

  const interventionTotals = useMemo(() => {
    let totalHours = 0;
    let totalTravelTime = 0;
    let totalPartsCost = 0;
    const partsUsedMap: { [key: string]: { name: string; quantity: number; cost: number } } = {};

    interventionWorkOrders.forEach(wo => {
      totalHours += wo.hoursWorked || 0;
      totalTravelTime += wo.travelTime || 0;
      if (wo.partsUsed) {
        wo.partsUsed.forEach(part => {
          const qty = part.quantity || 0;
          const price = part.unitPrice || 0;
          const cost = qty * price;
          totalPartsCost += cost;

          const key = part.itemId || part.name;
          if (partsUsedMap[key]) {
            partsUsedMap[key].quantity += qty;
            partsUsedMap[key].cost += cost;
          } else {
            partsUsedMap[key] = {
              name: part.name,
              quantity: qty,
              cost: cost
            };
          }
        });
      }
    });

    return {
      totalHours,
      totalTravelTime,
      totalPartsCost,
      combinedParts: Object.values(partsUsedMap)
    };
  }, [interventionWorkOrders]);

  // Form State
  const [isDirty, setIsDirty] = useState(false);
  const [isCancelConfirmOpen, setIsCancelConfirmOpen] = useState(false);
  const [formData, setFormData] = useState({
    interventionNumber: '',
    date: format(new Date(), 'yyyy-MM-dd'),
    endDate: '',
    time: format(new Date(), 'HH:mm'),
    startTime: format(new Date(), 'HH:mm'),
    endTime: format(new Date(new Date().getTime() + 60 * 60 * 1000), 'HH:mm'),
    customerId: '',
    machineId: '',
    location: '',
    technicianName: '',
    type: 'onderhoud' as InterventionType,
    status: 'gepland' as InterventionStatus,
    priority: 'normal' as AlertPriority,
    problemDescription: '',
    workPerformed: '',
    hoursWorked: 0,
    travelTime: 0,
    followUpAction: '',
    nextMaintenanceDate: '',
    internalNotes: '',
    customerNotes: '',
    workOrderId: '',
    partsUsed: [] as { itemId?: string; quantity: number; name: string; unitPrice?: number }[]
  });

  useEffect(() => {
    // Handle URL parameters for pre-filling new intervention
    const params = new URLSearchParams(window.location.search);
    const machineId = params.get('machine');
    const customerId = params.get('customer');
    const interventionId = params.get('id');
    const shouldOpenNew = params.get('new') === 'true';

    if (machineId || customerId || shouldOpenNew) {
      setFormData(prev => ({
        ...prev,
        machineId: machineId || prev.machineId,
        customerId: customerId || prev.customerId,
        interventionNumber: generateSequenceNumber('INT')
      }));
      setIsAddModalOpen(true);
    } else if (interventionId) {
      const searchAndOpen = async () => {
        const interv = await interventionService.getById(interventionId);
        if (interv) {
          handleOpenEditModal(interv);
        }
      };
      searchAndOpen();
    }
  }, []);

  const getCustomerName = (id: string) => customers.find(c => c.id === id)?.name || 'Onbekende Klant';
  const getMachineSimpleInfo = (id: string) => {
    const m = machines.find(m => m.id === id);
    return m ? `${m.brand} ${m.model}` : 'Onbekende Machine';
  };
  const getMachineInfo = (id: string) => {
    const m = machines.find(mac => mac.id === id);
    return m ? `${m.brand} ${m.model} (${m.serialNumber})` : 'Onbekende machine';
  };

  
  const updateFormData = (updates: any) => {
    setFormData((prev: any) => ({ ...prev, ...updates }));
    setIsDirty(true);
  };

  const handleCloseModal = () => {
    if (isDirty && !isDetailView) {
      setIsCancelConfirmOpen(true);
    } else {
      closeModal();
    }
  };

  const closeModal = () => {
    setIsCancelConfirmOpen(false);
    setIsAddModalOpen(false);
    setIsDirty(false);
  };

  const handleOpenAddModal = () => {
    setSelectedIntervention(null);
    setIsDetailView(false);
    setDuplicateWarning({ isOpen: false, matches: [] });
    setFormData({
      interventionNumber: generateSequenceNumber('INT'),
      date: format(new Date(), 'yyyy-MM-dd'),
      endDate: '',
      time: format(new Date(), 'HH:mm'),
      startTime: format(new Date(), 'HH:mm'),
      endTime: format(new Date(new Date().getTime() + 60 * 60 * 1000), 'HH:mm'),
      customerId: '',
      machineId: '',
      location: '',
      technicianName: '',
      type: 'onderhoud',
      status: 'gepland',
      priority: 'normal',
      problemDescription: '',
      workPerformed: '',
      hoursWorked: 0,
      travelTime: 0,
      followUpAction: '',
      nextMaintenanceDate: '',
      internalNotes: '',
      customerNotes: '',
      workOrderId: '',
      partsUsed: []
    });
    setIsAddModalOpen(true);
  };

  const fetchInterventionDetails = async (intervention: Intervention) => {
    if (!intervention.id) return;
    const [wo, wos, logs] = await Promise.all([
      interventionService.getLinkedWorkOrder(intervention.id),
      interventionService.getLinkedWorkOrders(intervention.id),
      interventionService.getAuditLogs(intervention.id)
    ]);
    setInterventionWorkOrder(wo);
    setInterventionWorkOrders(wos);
    setAuditLogs(logs);
  };

  const handleOpenDetails = (intervention: Intervention) => {
    setSelectedIntervention(intervention);
    setIsDetailView(true);
    setAiDraft(null); // Reset AI draft
    setDuplicateWarning({ isOpen: false, matches: [] });
    // Fill formData for detail view if needed by components
    handleOpenEditModal(intervention, true);
    setIsDetailView(true);
  };

  const handleOpenEditModal = (intervention: Intervention, detailsOnly = false) => {
    setSelectedIntervention(intervention);
    if (!detailsOnly) setIsDetailView(false);
    setDuplicateWarning({ isOpen: false, matches: [] });
    
    setFormData({
      interventionNumber: intervention.interventionNumber || '',
      date: intervention.date,
      endDate: intervention.endDate || '',
      time: intervention.time || '',
      startTime: intervention.startTime || '',
      endTime: intervention.endTime || '',
      customerId: intervention.customerId,
      machineId: intervention.machineId,
      location: intervention.location || '',
      technicianName: intervention.technicianName || '',
      type: intervention.type,
      status: intervention.status,
      priority: intervention.priority,
      problemDescription: intervention.problemDescription || '',
      workPerformed: intervention.workPerformed || '',
      hoursWorked: intervention.hoursWorked || 0,
      travelTime: intervention.travelTime || 0,
      followUpAction: intervention.followUpAction || '',
      nextMaintenanceDate: intervention.nextMaintenanceDate || '',
      internalNotes: intervention.internalNotes || '',
      customerNotes: intervention.customerNotes || '',
      workOrderId: intervention.workOrderId || '',
      partsUsed: intervention.partsUsed || []
    });
    fetchInterventionDetails(intervention);
    setIsAddModalOpen(true);
  };

  const handleSave = async (e?: React.FormEvent, bypassDuplicateCheck = false) => {
    if (e) e.preventDefault();
    
    if (isSaving) return;

    if (!bypassDuplicateCheck) {
      setIsSaving(true);
      const matches = await interventionService.findPotentialDuplicates(formData as any, selectedIntervention?.id);
      setIsSaving(false);
      
      if (matches.length > 0) {
        setDuplicateWarning({ isOpen: true, matches });
        return;
      }
    }

    setIsSaving(true);
    const successId = await interventionService.save(formData, selectedIntervention);
    setIsSaving(false);
    
    if (successId) {
      setIsAddModalOpen(false);
      refreshData();
    }
  };

  const handleDelete = async () => {
    if (deleteConfirm.id) {
      const success = await interventionService.delete(deleteConfirm.id);
      if (success) {
        setDeleteConfirm({ isOpen: false, id: null });
        refreshData();
      }
    }
  };

  const handleCreateWorkOrder = async () => {
    if (!selectedIntervention) return;
    
    setIsSaving(true);
    const customer = customers.find(c => c.id === selectedIntervention.customerId);
    const machine = machines.find(m => m.id === selectedIntervention.machineId);
    
    try {
      const woId = await interventionService.createWorkOrderFromIntervention(
        selectedIntervention, customer, machine, formData
      );
      
      if (woId) {
        alert('Werkbon succesvol aangemaakt.');
        // Refresh state
        const updatedInterv = {
          ...selectedIntervention,
          workOrderCount: (selectedIntervention.workOrderCount || 0) + 1
        };
        setSelectedIntervention(updatedInterv);
        await fetchInterventionDetails(updatedInterv);
        refreshData();
      } else {
        alert('Fout bij maken werkbon.');
      }
    } finally {
      setIsSaving(false);
    }
  };

  const [isFollowUpConfirmOpen, setIsFollowUpConfirmOpen] = useState(false);
  const [isCompleteConfirmOpen, setIsCompleteConfirmOpen] = useState(false);

  const handleCreateFollowUpWorkOrder = async () => {
    if (!selectedIntervention) return;
    setIsFollowUpConfirmOpen(true);
  };

  const confirmFollowUpWorkOrder = async () => {
    setIsFollowUpConfirmOpen(false);
    
    setIsSaving(true);
    const customer = customers.find(c => c.id === selectedIntervention!.customerId);
    const machine = machines.find(m => m.id === selectedIntervention!.machineId);
    
    try {
      // Create high quality follow-up work order
      const woId = await interventionService.createWorkOrderFromIntervention(
        selectedIntervention!, 
        customer, 
        machine, 
        formData,
        true // isFollowUp
      );
      
      if (woId) {
        alert('Vervolgwerkbon succesvol aangemaakt. Status van de interventie is gewijzigd naar "Gepland vervolgbezoek".');
        
        const updatedInterv = {
          ...selectedIntervention!,
          status: 'Gepland vervolgbezoek' as InterventionStatus,
          workOrderCount: (selectedIntervention!.workOrderCount || 0) + 1
        };
        setSelectedIntervention(updatedInterv);
        setFormData(prev => ({ ...prev, status: 'Gepland vervolgbezoek' }));
        await fetchInterventionDetails(updatedInterv);
        refreshData();
      } else {
        alert('Fout bij maken vervolgwerkbon.');
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handleCompleteIntervention = async () => {
    if (!selectedIntervention) return;
    setIsCompleteConfirmOpen(true);
  };

  const confirmCompleteIntervention = async () => {
    setIsCompleteConfirmOpen(false);
    
    setIsSaving(true);
    try {
      const updated = {
        ...formData,
        status: 'Afgerond' as InterventionStatus,
        endDate: format(new Date(), 'yyyy-MM-dd')
      };
      
      await interventionService.save(updated as any, selectedIntervention!);
      
      alert('Interventie succesvol afgerond.');
      setSelectedIntervention({
        ...selectedIntervention!,
        status: 'Afgerond',
        endDate: updated.endDate
      });
      setFormData(prev => ({
        ...prev,
        status: 'Afgerond',
        endDate: updated.endDate
      }));
      refreshData();
    } finally {
      setIsSaving(false);
    }
  };

  const exportInterventionPDF = async () => {
    if (!selectedIntervention) return;
    const customer = customers.find(c => c.id === selectedIntervention.customerId);
    const machine = machines.find(m => m.id === selectedIntervention.machineId);

    alert("Bezig met genereren van het interventiedossier... Een moment geduld.");

    const doc = new jsPDF('p', 'mm', 'a4');
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    let currentY = 20;

    const addText = (text: string, x: number, y: number, options?: { fontSize?: number, fontStyle?: string, textColor?: [number, number, number] }) => {
      if (options?.fontSize) doc.setFontSize(options.fontSize);
      if (options?.fontStyle) doc.setFont("helvetica", options.fontStyle);
      if (options?.textColor) doc.setTextColor(options.textColor[0], options.textColor[1], options.textColor[2]);
      doc.text(text, x, y);
    };

    // Header strip
    doc.setFillColor(15, 23, 42);
    doc.rect(0, 0, pageWidth, 42, 'F');

    addText("INTERVENTIE DOSSIER OVERZICHT", 15, 18, { fontSize: 18, fontStyle: "bold", textColor: [255, 255, 255] });
    addText(`Dossiernummer: ${selectedIntervention.interventionNumber || 'INT-N/A'}`, 15, 26, { fontSize: 11, fontStyle: "normal", textColor: [148, 163, 184] });
    addText(`Datum: ${selectedIntervention.date ? format(new Date(selectedIntervention.date), 'dd MMMM yyyy', { locale: nl }) : 'N/A'}`, 15, 33, { fontSize: 10, fontStyle: "normal", textColor: [148, 163, 184] });

    currentY = 55;

    // Contact Grid details
    doc.setFillColor(248, 250, 252);
    doc.roundedRect(15, currentY, (pageWidth - 35) / 2, 40, 3, 3, 'F');
    doc.roundedRect(15 + (pageWidth - 35) / 2 + 5, currentY, (pageWidth - 35) / 2, 40, 3, 3, 'F');

    addText("Klantgegevens", 20, currentY + 8, { fontSize: 10, fontStyle: "bold", textColor: [37, 99, 235] });
    addText(`Naam: ${customer?.name || 'Onbekend'}`, 20, currentY + 16, { fontSize: 9, fontStyle: "normal", textColor: [15, 23, 42] });
    addText(`Adres: ${customer?.address || 'N/A'}`, 20, currentY + 23, { fontSize: 9, fontStyle: "normal", textColor: [71, 85, 105] });
    addText(`Contactpersoon: ${customer?.contactPerson || 'N/A'}`, 20, currentY + 30, { fontSize: 9, fontStyle: "normal", textColor: [71, 85, 105] });

    addText("Machine details", 15 + (pageWidth - 35) / 2 + 10, currentY + 8, { fontSize: 10, fontStyle: "bold", textColor: [37, 99, 235] });
    addText(`Model: ${machine ? `${machine.brand} ${machine.model}` : 'Onbekend'}`, 15 + (pageWidth - 35) / 2 + 10, currentY + 16, { fontSize: 9, fontStyle: "normal", textColor: [15, 23, 42] });
    addText(`Serienummer: ${machine?.serialNumber || 'N/A'}`, 15 + (pageWidth - 35) / 2 + 10, currentY + 23, { fontSize: 9, fontStyle: "normal", textColor: [71, 85, 105] });
    addText(`Locatie: ${selectedIntervention.location || 'Standaard'}`, 15 + (pageWidth - 35) / 2 + 10, currentY + 30, { fontSize: 9, fontStyle: "normal", textColor: [71, 85, 105] });

    currentY += 48;

    addText("Probleemomschrijving", 15, currentY, { fontSize: 11, fontStyle: "bold", textColor: [15, 23, 42] });
    currentY += 5;
    doc.setFillColor(254, 243, 199);
    doc.rect(15, currentY, pageWidth - 30, 18, 'F');
    addText(selectedIntervention.problemDescription || 'Geen omschrijving ingevoerd.', 20, currentY + 11, { fontSize: 9.5, fontStyle: "italic", textColor: [120, 53, 4] });

    currentY += 28;

    addText("Overzicht Dossier Totale Cijfers", 15, currentY, { fontSize: 11, fontStyle: "bold", textColor: [15, 23, 42] });
    currentY += 5;
    doc.setFillColor(241, 245, 249);
    doc.rect(15, currentY, pageWidth - 30, 20, 'F');

    addText(`Aantal bezoeken: ${interventionWorkOrders.length}`, 20, currentY + 12, { fontSize: 10, fontStyle: "bold", textColor: [15, 23, 42] });
    addText(`Totale werktijd: ${interventionTotals.totalHours.toFixed(1)} u`, 90, currentY + 12, { fontSize: 10, fontStyle: "bold", textColor: [15, 23, 42] });
    addText(`Totale reistijd: ${interventionTotals.totalTravelTime} min`, pageWidth - 80, currentY + 12, { fontSize: 10, fontStyle: "bold", textColor: [15, 23, 42] });

    currentY += 28;

    addText("Historie van Bezoeken (Gekoppelde Werkbonnen)", 15, currentY, { fontSize: 12, fontStyle: "bold", textColor: [15, 23, 42] });
    currentY += 6;

    interventionWorkOrders.forEach((wo, idx) => {
      if (currentY > pageHeight - 45) {
        doc.addPage();
        currentY = 20;
      }

      const boxHeight = 24;
      doc.setFillColor(248, 250, 252);
      doc.setDrawColor(226, 232, 240);
      doc.rect(15, currentY, pageWidth - 30, boxHeight, 'FD');

      addText(`Bezoek #${wo.visitNumber || (idx + 1)} - Werkbon ${wo.orderNumber}`, 20, currentY + 7, { fontSize: 10, fontStyle: "bold", textColor: [37, 99, 235] });
      addText(`Status: ${wo.status || 'Concept'}`, pageWidth - 65, currentY + 7, { fontSize: 9, fontStyle: "bold", textColor: [15, 23, 42] });

      addText(`Technicus: ${wo.technicianName || 'N/A'}`, 25, currentY + 14, { fontSize: 9, fontStyle: "normal", textColor: [71, 85, 105] });
      addText(`Datum: ${wo.date ? format(new Date(wo.date), 'dd MMMM yyyy', { locale: nl }) : 'N/A'}`, 100, currentY + 14, { fontSize: 9, fontStyle: "normal", textColor: [71, 85, 105] });
      
      const completedTxt = wo.workDescription ? (wo.workDescription.length > 50 ? wo.workDescription.substring(0, 50) + "..." : wo.workDescription) : "Geen opgave van werkzaamheden.";
      addText(`Gewerkt: ${wo.hoursWorked || 0}u | Reistijd: ${wo.travelTime || 0}m`, 25, currentY + 20, { fontSize: 8.5, fontStyle: "normal", textColor: [100, 116, 139] });
      addText(`Werk: ${completedTxt}`, 100, currentY + 20, { fontSize: 8.5, fontStyle: "normal", textColor: [100, 116, 139] });

      currentY += boxHeight + 4;
    });

    if (interventionTotals.combinedParts.length > 0) {
      if (currentY > pageHeight - 50) {
        doc.addPage();
        currentY = 20;
      }

      currentY += 5;
      addText("Consolidatie Verbruikte Onderdelen", 15, currentY, { fontSize: 11, fontStyle: "bold", textColor: [15, 23, 42] });
      currentY += 6;

      doc.setFillColor(241, 245, 249);
      doc.rect(15, currentY, pageWidth - 30, 8, 'F');
      addText("Onderdeel", 20, currentY + 5.5, { fontSize: 8.5, fontStyle: "bold", textColor: [71, 85, 105] });
      addText("Aantal", pageWidth - 50, currentY + 5.5, { fontSize: 8.5, fontStyle: "bold", textColor: [71, 85, 105] });

      currentY += 8;

      interventionTotals.combinedParts.forEach(p => {
        if (currentY > pageHeight - 15) {
          doc.addPage();
          currentY = 20;
        }

        addText(p.name, 20, currentY + 6, { fontSize: 9, fontStyle: "normal", textColor: [15, 23, 42] });
        addText(`${p.quantity}x`, pageWidth - 50, currentY + 6, { fontSize: 9, fontStyle: "bold", textColor: [37, 99, 235] });
        currentY += 10;
      });
    }

    doc.save(`Interventie_Dossier_${selectedIntervention.interventionNumber || 'INT'}.pdf`);
  };

  const handleGenerateAIDraft = async () => {
    if (!selectedIntervention) return;
    setIsGeneratingAI(true);
    try {
      const customer = customers.find(c => c.id === selectedIntervention.customerId);
      const machine = machines.find(m => m.id === selectedIntervention.machineId);
      
      if (customer && machine) {
        const draft = await aiService.generateEmailDraft({
          intervention: selectedIntervention,
          customer,
          machine
        });
        setAiDraft(draft || 'Geen concept gegenereerd.');
      }
    } catch (err) {
      console.error('AI Draft failed:', err);
    } finally {
      setIsGeneratingAI(false);
    }
  };
  const handleSendConfirmation = async () => {
    if (!selectedIntervention) return;
    setIsSendingEmail(true);
    try {
      const customer = customers.find(c => c.id === selectedIntervention.customerId);
      const machine = machines.find(m => m.id === selectedIntervention.machineId);
      
      if (!customer?.email) {
        alert('Klant heeft geen e-mailadres ingesteld.');
        return;
      }

      await emailService.triggerAutomation('appointment_confirmation', {
        customer,
        machine,
        intervention: selectedIntervention,
        appointment: {
          date: selectedIntervention.date,
          startTime: selectedIntervention.time,
          location: customer.address
        }
      });
      
      alert('Bevestigingsmail is verzonden naar ' + customer.email);
    } catch (err) {
      console.error('Email sending failed:', err);
      alert('Fout bij het verzenden van de e-mail.');
    } finally {
      setIsSendingEmail(false);
    }
  };

  const filteredInterventions = useMemo(() => interventions.filter(i => {
    const matchesSearch = 
      getCustomerName(i.customerId).toLowerCase().includes(search.toLowerCase()) ||
      getMachineInfo(i.machineId).toLowerCase().includes(search.toLowerCase()) ||
      (i.problemDescription || '').toLowerCase().includes(search.toLowerCase()) ||
      (i.technicianName || '').toLowerCase().includes(search.toLowerCase());
    
    const matchesCustomer = !filterCustomer || i.customerId === filterCustomer;
    const matchesMachine = !filterMachine || i.machineId === filterMachine;
    const matchesType = !filterType || i.type === filterType;
    const matchesStatus = !filterStatus || i.status === filterStatus;
    const matchesPriority = !filterPriority || i.priority === filterPriority;
    const matchesDate = !filterDate || i.date === filterDate;

    return matchesSearch && matchesCustomer && matchesMachine && matchesType && matchesStatus && matchesPriority && matchesDate;
  }), [interventions, search, filterCustomer, filterMachine, filterType, filterStatus, filterPriority, filterDate, customers, machines]);

  const getStatusStyle = (status: InterventionStatus) => {
    switch (status) {
      case 'Nieuw':
      case 'to-be-scheduled': return 'bg-purple-50 text-purple-700 border-purple-100';
      case 'In behandeling':
      case 'in-progress':
      case 'bezig': return 'bg-brand-50 text-blue-700 border-brand-200';
      case 'Wachten onderdelen':
      case 'waiting-parts':
      case 'wacht op onderdelen': return 'bg-orange-50 text-orange-700 border-orange-100';
      case 'Gepland vervolgbezoek': return 'bg-brand-50 text-indigo-700 border-indigo-100';
      case 'Tijdelijk opgelost': return 'bg-cyan-50 text-cyan-700 border-cyan-100';
      case 'Afgerond':
      case 'completed':
      case 'afgerond': return 'bg-green-50 text-green-700 border-green-100';
      case 'Geannuleerd':
      case 'cancelled':
      case 'geannuleerd': return 'bg-surface-100 text-surface-500 border-surface-200';
      case 'planned':
      case 'gepland': return 'bg-amber-50 text-amber-700 border-amber-100';
      case 'on-route':
      case 'onderweg': return 'bg-brand-50 text-indigo-700 border-indigo-100';
      case 'gefactureerd':
      case 'invoiced': return 'bg-emerald-50 text-emerald-700 border-emerald-100';
      default: return 'bg-surface-50 text-surface-700 border-surface-100';
    }
  };

  const getStatusLabel = (status: InterventionStatus) => {
    switch (status) {
      case 'Nieuw': return 'Nieuw';
      case 'In behandeling': return 'In behandeling';
      case 'Wachten onderdelen': return 'Wachten onderdelen';
      case 'Gepland vervolgbezoek': return 'Gepland vervolgbezoek';
      case 'Tijdelijk opgelost': return 'Tijdelijk opgelost';
      case 'Afgerond': return 'Afgerond';
      case 'Geannuleerd': return 'Geannuleerd';
      
      case 'completed':
      case 'afgerond': return 'Afgerond';
      case 'in-progress':
      case 'bezig': return 'Bezig';
      case 'on-route':
      case 'onderweg': return 'Onderweg';
      case 'waiting-parts':
      case 'wacht op onderdelen': return 'Wacht op onderdelen';
      case 'planned':
      case 'gepland': return 'Gepland';
      case 'cancelled':
      case 'geannuleerd': return 'Geannuleerd';
      case 'to-be-scheduled': return 'Nog te plannen';
      case 'gefactureerd':
      case 'invoiced': return 'Gefactureerd';
      default: return status;
    }
  };

  const getPriorityStyle = (priority: ReminderPriority) => {
    switch (priority) {
      case 'urgent': return 'text-red-600 bg-red-50 border-red-100';
      case 'high': return 'text-amber-600 bg-amber-50 border-amber-100';
      case 'normal': return 'text-brand-500 bg-brand-50 border-brand-200';
      case 'low': return 'text-surface-500 bg-surface-50 border-surface-100';
      default: return 'text-surface-500 bg-surface-50 border-surface-100';
    }
  };



  useEffect(() => {
    const id = searchParams.get('id');
    if (id && interventions.length > 0) {
      const item = interventions.find(x => x.id === id);
      if (item) {
        handleOpenDetails(item);
        const newParams = new URLSearchParams(searchParams);
        newParams.delete('id');
        setSearchParams(newParams, { replace: true });
      }
    }
  }, [searchParams, interventions, setSearchParams]);

  return (
    <div className="space-y-4 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-surface-200 pb-6">
        <div>
          <h1 className="text-2xl font-bold text-surface-900 leading-tight">Interventies & Onderhoud</h1>
          <p className="text-sm text-surface-500 mt-1">Beheer servicebezoeken en reparaties.</p>
        </div>
        <button 
          onClick={handleOpenAddModal}
          className="btn-primary"
        >
          <Plus className="w-4 h-4" />
          <span>Nieuwe Interventie</span>
        </button>
      </div>

      <InterventionFilters 
        search={search} setSearch={setSearch}
        filterCustomer={filterCustomer} setFilterCustomer={setFilterCustomer}
        filterMachine={filterMachine} setFilterMachine={setFilterMachine}
        filterType={filterType} setFilterType={setFilterType}
        filterStatus={filterStatus} setFilterStatus={setFilterStatus}
        filterPriority={filterPriority} setFilterPriority={setFilterPriority}
        filterDate={filterDate} setFilterDate={setFilterDate}
        customers={customers}
        machines={machines}
      />

      {loading ? (
        <div className="flex justify-center p-24">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-surface-200 border-t-blue-600"></div>
        </div>
      ) : (
        <InterventionTable 
          interventions={filteredInterventions}
          customers={customers}
          machines={machines}
          onOpenDetails={handleOpenDetails}
          onOpenEdit={handleOpenEditModal}
          onPlanAppointment={(i) => {
            setAppointmentInitialData({
              date: i.date,
              interventionId: i.id,
              customerId: i.customerId,
              machineId: i.machineId,
              title: `Interventie: ${getCustomerName(i.customerId)}`
            });
            setIsAppointmentModalOpen(true);
          }}
          onCreateWorkOrder={(i) => {
            setSelectedIntervention(i);
            handleCreateWorkOrder();
          }}
          onDelete={(id) => setDeleteConfirm({ isOpen: true, id })}
          getStatusLabel={getStatusLabel}
          getStatusStyle={getStatusStyle}
          getPriorityStyle={getPriorityStyle}
        />
      )}

      {/* Add/Edit Modal */}
      <AnimatePresence>
        {isAddModalOpen && (
          <motion.div 
            key="intervention-modal-container"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center p-4"
          >
            <motion.div
              key="backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-surface-900/60 backdrop-blur-sm"

            />
            <motion.div
              key="modal-content"
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-4xl rounded-lg shadow-2xl p-5 overflow-y-auto max-h-[95vh] focus:outline-none"
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-8 pb-6 border-b border-surface-100">
                <div className="flex flex-col flex-1 min-w-0">
                  <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                    <h2 className="text-xl font-bold text-surface-900 flex items-center gap-3 flex-wrap">
                      <div className="p-2.5 bg-brand-500 text-white rounded-md shadow-lg shadow-blue-500/20 shrink-0">
                        <ClipboardList className="w-5 h-5" />
                      </div>
                      <span className="truncate">
                      {isDetailView ? `Interventie: ${formData.interventionNumber || 'Nieuw'}` : (selectedIntervention ? 'Interventie Aanpassen' : 'Nieuwe Interventie')}
                      </span>
                    </h2>
                    <select 
                      className={cn(
                        "text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full border outline-none shrink-0",
                        getStatusStyle(formData.status)
                      )}
                      value={formData.status}
                      onChange={(e) => updateFormData({ status: e.target.value as InterventionStatus})}
                    >
                      <option value="Nieuw">Nieuw</option>
                      <option value="In behandeling">In behandeling</option>
                      <option value="Wachten onderdelen">Wachten onderdelen</option>
                      <option value="Gepland vervolgbezoek">Gepland vervolgbezoek</option>
                      <option value="Tijdelijk opgelost">Tijdelijk opgelost</option>
                      <option value="Afgerond">Afgerond</option>
                      <option value="Geannuleerd">Geannuleerd</option>
                    </select>
                  </div>
                  {isDetailView && (
                    <p className="text-[11px] font-medium text-surface-500 mt-2 sm:ml-14 truncate">
                      Klant: {getCustomerName(formData.customerId)} • Machine: {getMachineSimpleInfo(formData.machineId)}
                    </p>
                  )}
                </div>
                
                <div className="flex items-center flex-wrap gap-2 shrink-0">
                  {isDetailView && (
                    <button 
                       onClick={handleGenerateAIDraft}
                       disabled={isGeneratingAI}
                       className="btn-ghost !bg-amber-50 !text-amber-700 hover:!bg-amber-100 border border-amber-200"
                       title="Genereer AI E-mail concept"
                    >
                       <Sparkles className={cn("w-4 h-4", isGeneratingAI && "animate-spin")} />
                       <span className="hidden sm:inline">{isGeneratingAI ? 'AI Schrijft...' : 'AI Concept'}</span>
                    </button>
                  )}
                  {isDetailView && (
                    <button 
                      onClick={() => setIsDetailView(false)}
                      className="btn-ghost !bg-surface-100 !text-surface-700 hover:!bg-surface-200"
                    >
                      <Edit className="w-4 h-4" />
                      <span className="hidden sm:inline">Bewerken</span>
                    </button>
                  )}
                  {selectedIntervention && (
                    <>
                      <button 
                        type="button"
                        onClick={handleSendConfirmation}
                        disabled={isSendingEmail}
                        className="btn-ghost !p-2 text-surface-400 hover:text-brand-600"
                        title="Verstuur Bevestiging"
                      >
                        <Mail className={cn("w-5 h-5", isSendingEmail && "animate-pulse")} />
                      </button>
                      <button 
                        type="button"
                        onClick={() => window.print()}
                        className="btn-ghost !p-2 text-surface-400 hover:text-brand-500"
                        title="Afdrukken / PDF"
                      >
                        <Printer className="w-5 h-5" />
                      </button>
                    </>
                  )}
                  <button 
                    onClick={handleCloseModal}
                    className="p-2 hover:bg-surface-100 rounded-lg text-surface-400 shrink-0"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>
              </div>              {isDetailView ? (
                <div className="space-y-5 font-[Inter]">
                  {/* Action Buttons for Details View */}
                  <div className="flex flex-wrap gap-4 p-5 bg-surface-50 rounded-lg border border-surface-100">
                    <button 
                       onClick={handleCreateWorkOrder}
                       disabled={isSaving}
                       className="flex-1 min-w-[140px] sm:min-w-[140px] sm:min-w-[170px] btn-primary !py-3.5 !bg-brand-500 hover:!bg-blue-700 font-bold disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <FileText className="w-5 h-5" /> 
                      <span>Nieuwe Werkbon</span>
                    </button>
                    
                    <button 
                       onClick={handleCreateFollowUpWorkOrder}
                       disabled={isSaving}
                       className="flex-1 min-w-[140px] sm:min-w-[140px] sm:min-w-[170px] btn-secondary !py-3.5 border border-surface-300 bg-white text-surface-700 hover:bg-surface-50 font-bold disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Plus className="w-5 h-5" />
                      <span>Vervolgwerkbon</span>
                    </button>

                    {formData.status !== 'Afgerond' && formData.status !== 'completed' && (
                      <button 
                         onClick={handleCompleteIntervention}
                         disabled={isSaving}
                         className="flex-1 min-w-[140px] sm:min-w-[140px] sm:min-w-[170px] btn-primary !py-3.5 !bg-emerald-600 hover:!bg-emerald-700 font-bold disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <CheckCircle2 className="w-5 h-5" />
                        <span>Afronden Interventie</span>
                      </button>
                    )}

                    <button 
                       onClick={exportInterventionPDF}
                       disabled={isSaving}
                       className="flex-1 min-w-[140px] sm:min-w-[140px] sm:min-w-[170px] btn-secondary !py-3.5 bg-surface-900 border-surface-900 text-white hover:bg-surface-800 font-bold disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Download className="w-5 h-5" />
                      <span>Interventie PDF</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="md:col-span-2 space-y-4">
                      {/* Detailed Info Sections */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="p-5 bg-white border border-surface-100 rounded-lg shadow-sm">
                          <h4 className="text-[10px] font-bold uppercase tracking-wider text-surface-400 mb-3 flex items-center gap-2">
                             <User className="w-3.5 h-3.5" /> Klant Informatie
                          </h4>
                          <div className="space-y-1">
                             <p className="text-sm font-bold text-surface-900">{getCustomerName(formData.customerId)}</p>
                             <p className="text-xs text-surface-500 font-medium">{customers.find(c => c.id === formData.customerId)?.address}</p>
                             <p className="text-xs text-brand-500 font-bold mt-2">{customers.find(c => c.id === formData.customerId)?.contactPerson}</p>
                          </div>
                        </div>
                        <div className="p-5 bg-white border border-surface-100 rounded-lg shadow-sm">
                          <h4 className="text-[10px] font-bold uppercase tracking-wider text-surface-400 mb-3 flex items-center gap-2">
                             <Printer className="w-3.5 h-3.5" /> Machine Details
                          </h4>
                          <div className="space-y-1">
                             <p className="text-sm font-bold text-surface-900">{getMachineSimpleInfo(formData.machineId)}</p>
                             <p className="text-xs text-surface-500 font-medium">Serienummer: <span className="font-mono font-bold text-surface-700">{machines.find(m => m.id === formData.machineId)?.serialNumber || 'N/A'}</span></p>
                             <p className="text-xs text-surface-500 font-medium">Locatie: {formData.location || machines.find(m => m.id === formData.machineId)?.location || 'Standaard'}</p>
                          </div>
                        </div>
                      </div>

                      <div className="p-5 bg-white border border-surface-100 rounded-lg shadow-sm space-y-5">
                        <div className="flex items-center justify-between border-b border-surface-50 pb-4">
                           <h4 className="text-xs font-bold uppercase tracking-wider text-surface-900">Werkzaamheden & Bevindingen</h4>
                           <span className="px-2 py-0.5 rounded-full bg-surface-100 text-[10px] font-bold uppercase tracking-wider text-surface-600">
                             {formData.type}
                           </span>
                        </div>
                        <div className="space-y-3">
                           <div>
                              <p className="text-[10px] font-bold text-surface-400 uppercase tracking-wider mb-2">Probleemomschrijving</p>
                              <div className="text-sm text-surface-600 leading-relaxed bg-surface-50 p-4 rounded-md italic">
                                {formData.problemDescription || 'Geen omschrijving ingevoerd.'}
                              </div>
                           </div>
                           <div>
                              <p className="text-[10px] font-bold text-surface-400 uppercase tracking-wider mb-2">Uitgevoerde Werkzaamheden</p>
                              <div className="space-y-4">
                                <div className="text-sm text-surface-900 leading-relaxed bg-brand-50/30 p-4 rounded-md font-medium border border-blue-50">
                                  {formData.workPerformed || 'Nog geen werkzaamheden geregistreerd.'}
                                </div>
                                
                                {aiDraft && (
                                  <motion.div 
                                    initial={{ opacity: 0, scale: 0.98 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    className="p-5 bg-amber-50/50 border border-amber-100 rounded-md space-y-4"
                                  >
                                     <div className="flex items-center gap-2 text-amber-700">
                                        <Sparkles className="w-4 h-4" />
                                        <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800">AI Gegenereerd Concept Mail</span>
                                     </div>
                                     <div className="text-sm text-surface-700 whitespace-pre-wrap leading-relaxed italic">
                                        {aiDraft}
                                     </div>
                                     <div className="flex justify-end gap-2 pt-4 border-t border-amber-100">
                                        <button 
                                          onClick={() => {
                                            navigator.clipboard.writeText(aiDraft);
                                          }}
                                          className="btn-secondary !text-[10px] !py-2 !px-4"
                                        >
                                          Kopiëren
                                        </button>
                                     </div>
                                  </motion.div>
                                )}
                              </div>
                           </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="p-5 bg-white border border-surface-100 rounded-lg shadow-sm">
                           <h4 className="text-[10px] font-bold uppercase tracking-wider text-surface-400 mb-4 flex items-center gap-2">
                              <Clock className="w-3.5 h-3.5" /> Uren & Tijden
                           </h4>
                           <div className="grid grid-cols-2 gap-4">
                              <div>
                                 <p className="text-[9px] font-bold text-surface-400 uppercase">Werktijd</p>
                                 <p className="text-base font-bold text-surface-900">{formData.hoursWorked}<span className="text-xs text-surface-400 ml-1">u</span></p>
                              </div>
                              <div>
                                 <p className="text-[9px] font-bold text-surface-400 uppercase">Reistijd</p>
                                 <p className="text-base font-bold text-surface-900">{formData.travelTime}<span className="text-xs text-surface-400 ml-1">min</span></p>
                              </div>
                              <div className="col-span-2 grid grid-cols-2 gap-2 pt-3 border-t border-surface-50">
                                 <div>
                                    <p className="text-[9px] font-bold text-surface-400 uppercase">Start</p>
                                    <p className="text-xs font-bold text-surface-600">{formData.startTime || '--:--'}</p>
                                 </div>
                                 <div>
                                    <p className="text-[9px] font-bold text-surface-400 uppercase">Eind</p>
                                    <p className="text-xs font-bold text-surface-600">{formData.endTime || '--:--'}</p>
                                 </div>
                              </div>
                           </div>
                        </div>

                        <div className="p-5 bg-white border border-surface-100 rounded-lg shadow-sm">
                           <h4 className="text-[10px] font-bold uppercase tracking-wider text-surface-400 mb-4 flex items-center gap-2">
                              <Package className="w-3.5 h-3.5" /> Onderdelen
                           </h4>
                           <div className="space-y-2 max-h-[140px] overflow-y-auto pr-2 custom-scrollbar">
                              {formData.partsUsed.map((p, idx) => (
                                 <div key={idx} className="flex justify-between items-center text-xs font-bold bg-surface-50 p-2.5 rounded-lg border border-surface-100">
                                    <span className="text-surface-700 truncate">{p.name}</span>
                                    <span className="text-brand-500 shrink-0 ml-2 bg-white px-2 py-0.5 rounded border border-brand-200">{p.quantity}x</span>
                                 </div>
                              ))}
                              {formData.partsUsed.length === 0 && (
                                 <div className="flex flex-col items-center justify-center py-6 text-surface-300">
                                   <Package className="w-6 h-6 mb-1 opacity-20" />
                                   <p className="text-[10px] font-bold uppercase tracking-wider">Geen onderdelen</p>
                                 </div>
                              )}
                           </div>
                        </div>
                      </div>

                      {/* Linked Work Orders Dossier Component */}
                      <div className="p-5 bg-white border border-surface-100 rounded-lg shadow-sm space-y-3">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-surface-50 pb-4">
                          <div>
                            <h4 className="text-sm font-bold text-surface-900 uppercase tracking-wide">Bezoeken & Werkbonnen Dossier ({interventionWorkOrders.length})</h4>
                            <p className="text-xs text-surface-400 mt-0.5">Volledige servicehistorie en geregistreerde bezoeken.</p>
                          </div>
                          <div className="flex items-center gap-3 bg-brand-50/50 border border-brand-200 px-4 py-2.5 rounded-md">
                             <div className="text-center shrink-0 border-r border-brand-200 pr-3">
                                <p className="text-[9px] font-bold text-surface-400 uppercase font-mono">Totale Tijd</p>
                                <p className="text-xs font-bold text-surface-800">{interventionTotals.totalHours.toFixed(1)} u</p>
                             </div>
                             <div className="text-center shrink-0 pr-3 border-r border-brand-200 pl-1">
                                <p className="text-[9px] font-bold text-surface-400 uppercase font-mono">Reistijd</p>
                                <p className="text-xs font-bold text-surface-800">{interventionTotals.totalTravelTime} m</p>
                             </div>
                             <div className="text-center shrink-0 pl-1 font-mono">
                                <p className="text-[9px] font-bold text-surface-400 uppercase">Materiaalkosten</p>
                                <p className="text-xs font-bold text-brand-500">€{interventionTotals.totalPartsCost.toFixed(2)}</p>
                             </div>
                          </div>
                        </div>

                        <div className="space-y-4">
                          {interventionWorkOrders.length === 0 ? (
                            <div className="flex flex-col items-center justify-center py-6 bg-surface-50 rounded-md border border-dashed border-surface-200">
                               <FileText className="w-8 h-8 text-surface-300 mb-2" />
                               <p className="text-xs font-bold text-surface-400 uppercase tracking-wider">Nog geen bezoeken geregistreerd</p>
                               <p className="text-[11px] text-surface-500 mt-1">Klik hierboven op "Nieuwe Werkbon" om de eerste werkbon aan te maken.</p>
                            </div>
                          ) : (
                            <div className="divide-y divide-surface-100 border border-surface-100 rounded-md overflow-hidden bg-surface-50/10">
                               {interventionWorkOrders.map((wo, index) => (
                                  <div key={wo.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-surface-50 transition-colors">
                                     <div className="space-y-1.5 flex-1 min-w-0">
                                        <div className="flex flex-wrap items-center gap-2">
                                           <span className="px-2 py-0.5 rounded bg-brand-500 text-white text-[10px] font-bold font-mono">
                                             Bezoek #{wo.visitNumber || (index + 1)}
                                           </span>
                                           <span className="text-xs font-bold text-surface-900 font-mono">
                                             {wo.orderNumber}
                                           </span>
                                           <span className={cn(
                                              "text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border",
                                              wo.status === 'Afgerond' || wo.status === 'Gefactureerd' ? "bg-green-50 text-green-700 border-green-100" :
                                              wo.status === 'Bezig' || wo.status === 'Onderweg' ? "bg-brand-50 text-blue-700 border-brand-200" :
                                              "bg-surface-50 text-surface-600 border-surface-200"
                                           )}>
                                              {wo.status || 'Concept'}
                                           </span>
                                        </div>
                                        <p className="text-xs text-surface-600 italic font-medium max-w-xl line-clamp-2">
                                           {wo.workDescription || "Geen opgave van werkzaamheden ingevoerd."}
                                        </p>
                                        <div className="flex flex-wrap gap-x-4 gap-y-1 text-[10px] font-medium text-surface-400">
                                           <span className="flex items-center gap-1">
                                              <User className="w-3.5 h-3.5" /> Technicus: <strong className="text-surface-600">{wo.technicianName || 'Onbekend'}</strong>
                                           </span>
                                           <span className="flex items-center gap-1">
                                              <Calendar className="w-3.5 h-3.5" /> Datum: <strong className="text-surface-600">{wo.date ? format(new Date(wo.date), 'dd MMM yyyy', { locale: nl }) : 'N/A'}</strong>
                                           </span>
                                           <span className="flex items-center gap-1">
                                              <Clock className="w-3.5 h-3.5" /> Tijd: <strong className="text-surface-600">{wo.hoursWorked || 0}u werk • {wo.travelTime || 0}m reis</strong>
                                           </span>
                                        </div>
                                     </div>

                                     <div className="flex items-center gap-2 shrink-0">
                                        <button
                                           onClick={() => window.location.href = `/work-orders?id=${wo.id}`}
                                           className="btn-secondary !py-2 !px-3.5 !text-[11px] gap-1.5 hover:!bg-surface-900 hover:!text-white border-surface-200"
                                        >
                                           <ExternalLink className="w-3.5 h-3.5" />
                                           <span>Openen</span>
                                        </button>
                                     </div>
                                  </div>
                               ))}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                       {/* Timeline / Audit Log */}
                       <div className="p-5 bg-surface-900 text-white rounded-lg shadow-xl space-y-3 h-full min-h-[400px] flex flex-col">
                          <h4 className="text-xs font-bold uppercase tracking-wider flex items-center gap-3 border-b border-surface-800 pb-4">
                             <History className="w-4 h-4 text-blue-400" />
                             Status Verloop
                          </h4>
                          <div className="flex-1 overflow-y-auto space-y-3 pr-2 custom-scrollbar py-2">
                             {auditLogs.map((log, idx) => (
                                <div key={log.id} className="relative pl-6 pb-2">
                                   {idx !== auditLogs.length - 1 && (
                                      <div className="absolute left-[3px] top-4 bottom-0 w-px bg-surface-800" />
                                   )}
                                   <div className="absolute left-0 top-1.5 w-1.5 h-1.5 rounded-full bg-brand-500 shadow-[0_0_8px_rgba(59,130,246,0.5)]" />
                                   <div className="space-y-1">
                                      <div className="flex justify-between items-start">
                                         <p className="text-[10px] font-bold uppercase text-blue-400 leading-none">{log.action}</p>
                                         <span className="text-[9px] font-medium text-surface-500 uppercase">{format(new Date(log.timestamp), 'HH:mm')}</span>
                                      </div>
                                      <p className="text-[11px] text-surface-300 leading-relaxed">
                                         {log.details}
                                      </p>
                                      <p className="text-[9px] font-bold text-surface-500 uppercase flex items-center gap-1.5 mt-1">
                                         <User className="w-2.5 h-2.5" /> {log.userName || log.userEmail.split('@')[0]} 
                                         <span className="text-surface-700 mx-1">•</span> 
                                         {format(new Date(log.timestamp), 'dd MMM')}
                                      </p>
                                   </div>
                                </div>
                             ))}
                             {auditLogs.length === 0 && (
                                <div className="flex flex-col items-center justify-center py-6 text-surface-600 opacity-50">
                                   <History className="w-8 h-8 mb-2" />
                                   <p className="text-[10px] font-bold uppercase tracking-widest">Geen acties gevonden</p>
                                </div>
                             )}
                          </div>
                       </div>
                    </div>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSave} className="space-y-4">
                  {formData.status === 'waiting-parts' && (
                    <motion.div 
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex items-center gap-4 p-5 bg-orange-50 border border-orange-200 rounded-lg text-orange-800"
                    >
                      <AlertCircle className="w-6 h-6 text-orange-500 shrink-0" />
                      <div>
                        <p className="text-xs font-bold uppercase tracking-wider">Wacht op onderdelen</p>
                        <p className="text-[11px] font-medium opacity-80 mt-0.5">Zorg dat de benodigde onderdelen zijn besteld en vermeld de vervolgactie onderaan.</p>
                      </div>
                    </motion.div>
                  )}

                  {formData.status === 'completed' && (
                    <motion.div 
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex flex-col md:flex-row md:items-center gap-4 p-5 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-800"
                    >
                      <div className="flex items-center gap-4 flex-1">
                        <CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0" />
                        <div>
                          <p className="text-xs font-bold uppercase tracking-wider">Interventie Afgerond</p>
                          <p className="text-[11px] font-medium opacity-80 mt-0.5">Zorg dat de klant de werkbon tekent voor akkoord.</p>
                        </div>
                      </div>
                      {selectedIntervention && (
                        <button 
                          type="button"
                          onClick={() => window.location.href = `/work-orders?interventionId=${selectedIntervention.id}`}
                          className="btn-primary !bg-emerald-600 !py-2 !px-4 text-[11px]"
                        >
                          Maak Werkbon
                        </button>
                      )}
                    </motion.div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    {/* Basic Info */}
                    <div>
                      <label className="label">Klant *</label>
                      <select 
                        required
                        className="input-field"
                        value={formData.customerId}
                        onChange={(e) => updateFormData({ customerId: e.target.value, machineId: ''})}
                      >
                        <option value="">Selecteer klant...</option>
                        {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                      </select>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="label">Begindatum *</label>
                        <input 
                          required type="date" 
                          className="input-field" 
                          value={formData.date}
                          onChange={(e) => updateFormData({ date: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="label">Einddatum (optioneel)</label>
                        <input 
                          type="date" 
                          className="input-field" 
                          value={formData.endDate}
                          min={formData.date}
                          onChange={(e) => updateFormData({ endDate: e.target.value})}
                        />
                      </div>
                    </div>
                    <div>
                      <label className="label">Tijd</label>
                      <input 
                        type="time" 
                        className="input-field" 
                        value={formData.time}
                        onChange={(e) => updateFormData({ time: e.target.value})}
                      />
                    </div>

                    <div className="md:col-span-2">
                      <label className="label">Machine *</label>
                      <select 
                        required
                        className="input-field"
                        value={formData.machineId}
                        onChange={(e) => updateFormData({ machineId: e.target.value})}
                      >
                        <option value="">{formData.customerId ? 'Selecteer machine...' : 'Kies eerst een klant'}</option>
                        {machines.filter(m => m.customerId === formData.customerId).map(m => (
                          <option key={m.id} value={m.id}>{m.brand} {m.model} ({m.serialNumber})</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="label">Technicus</label>
                      <input 
                        type="text" 
                        placeholder="Naam technicus"
                        className="input-field" 
                        value={formData.technicianName}
                        onChange={(e) => updateFormData({ technicianName: e.target.value})}
                      />
                    </div>

                    <div>
                      <label className="label">Type *</label>
                      <select 
                        required
                        className="input-field"
                        value={formData.type}
                        onChange={(e) => updateFormData({ type: e.target.value as InterventionType})}
                      >
                        <option value="onderhoud">Onderhoud</option>
                        <option value="storing">Storing</option>
                        <option value="installatie">Installatie</option>
                        <option value="inspectie">Inspectie</option>
                        <option value="garantie">Garantie</option>
                        <option value="training">Training</option>
                        <option value="anders">Overig</option>
                      </select>
                    </div>
                    <div>
                      <label className="label">Prioriteit</label>
                      <select 
                        className="input-field"
                        value={formData.priority}
                        onChange={(e) => updateFormData({ priority: e.target.value as ReminderPriority})}
                      >
                        <option value="low">Laag</option>
                        <option value="normal">Normaal</option>
                        <option value="high">Hoog</option>
                        <option value="urgent">Urgent</option>
                      </select>
                    </div>
                    <div>
                      <label className="label">Status</label>
                      <select 
                        className={cn("input-field font-bold", getStatusStyle(formData.status))}
                        value={formData.status}
                        onChange={(e) => updateFormData({ status: e.target.value as InterventionStatus})}
                      >
                        <option value="Nieuw">Nieuw</option>
                        <option value="In behandeling">In behandeling</option>
                        <option value="Wachten onderdelen">Wachten onderdelen</option>
                        <option value="Gepland vervolgbezoek">Gepland vervolgbezoek</option>
                        <option value="Tijdelijk opgelost">Tijdelijk opgelost</option>
                        <option value="Afgerond">Afgerond</option>
                        <option value="Geannuleerd">Geannuleerd</option>
                      </select>
                    </div>

                    <div className="md:col-span-3 pt-4 border-t border-surface-100">
                      <div className="flex items-center justify-between mb-3">
                        <label className="text-xs font-bold uppercase tracking-wider text-surface-500">Onderdelen & Verbruik</label>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-bold text-surface-400 uppercase">Snel Toevoegen:</span>
                          <select 
                            className="text-xs font-bold bg-surface-50 border border-surface-200 rounded-lg px-2 py-1 outline-none"
                            onChange={(e) => {
                              const item = inventory.find(i => i.id === e.target.value);
                              if (item) {
                                if (!formData.partsUsed.find(p => p.itemId === item.id)) {
                                  updateFormData({ partsUsed: [...formData.partsUsed, { 
                                      itemId: item.id, 
                                      quantity: 1, 
                                      name: item.name,
                                      unitPrice: item.sellingPrice
                                    }]
                                  });
                                }
                              }
                              e.target.value = '';
                            }}
                          >
                            <option value="">Kies onderdeel...</option>
                            {inventory.filter(i => i.status === 'active').map(i => (
                              <option key={i.id} value={i.id}>
                                {i.name} (€{i.sellingPrice?.toFixed(2)})
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {formData.partsUsed.map((part, idx) => (
                          <div key={part.itemId} className="flex items-center gap-3 p-3 bg-surface-50 border border-surface-200 rounded-md group transition-all hover:border-surface-300">
                            <div className="p-2 bg-white rounded-lg text-brand-500 shadow-sm border border-surface-100 italic">
                              <Package className="w-3.5 h-3.5" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-bold text-surface-900 truncate">{part.name}</p>
                              <div className="flex items-center gap-2 mt-0.5">
                                <p className="text-[9px] text-surface-400 font-bold uppercase">
                                   Stock: {inventory.find(i => i.id === part.itemId)?.stockCount || 0}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center gap-1 bg-white border border-surface-200 rounded-lg p-0.5 shadow-sm">
                              <button 
                                type="button"
                                onClick={() => {
                                  const newParts = [...formData.partsUsed];
                                  if (newParts[idx].quantity > 1) {
                                    newParts[idx].quantity -= 1;
                                    updateFormData({ partsUsed: newParts });
                                  }
                                }}
                                className="w-7 h-7 flex items-center justify-center text-surface-400 hover:text-brand-500 hover:bg-surface-50 rounded"
                              >
                                <Minus className="w-3.5 h-3.5" />
                              </button>
                              <span className="w-6 text-center text-xs font-bold">{part.quantity}</span>
                              <button 
                                type="button"
                                onClick={() => {
                                  const newParts = [...formData.partsUsed];
                                  newParts[idx].quantity += 1;
                                  updateFormData({ partsUsed: newParts });
                                }}
                                className="w-7 h-7 flex items-center justify-center text-surface-400 hover:text-brand-500 hover:bg-surface-50 rounded"
                              >
                                <Plus className="w-3.5 h-3.5" />
                              </button>
                            </div>
                            <button 
                              type="button"
                              onClick={() => {
                                updateFormData({ partsUsed: formData.partsUsed.filter((_, i) => i !== idx)
                                });
                              }}
                              className="p-2 text-surface-300 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-all"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                        {formData.partsUsed.length === 0 && (
                          <div className="md:col-span-2 py-6 border border-dashed border-surface-200 rounded-md flex flex-col items-center justify-center bg-surface-50/50">
                             <Package className="w-5 h-5 mb-1 text-surface-300" />
                             <p className="text-[10px] font-bold uppercase tracking-wider text-surface-400">Geen onderdelen geselecteerd</p>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Problem & Solution */}
                    <div className="md:col-span-3 grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div>
                        <label className="label">Omschrijving probleem</label>
                        <textarea 
                          rows={3}
                          placeholder="Wat was de klacht?"
                          className="input-field resize-none" 
                          value={formData.problemDescription}
                          onChange={(e) => updateFormData({ problemDescription: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="label">Uitgevoerde Werkzaamheden</label>
                        <textarea 
                          rows={3}
                          placeholder="Wat heeft u gedaan?"
                          className="input-field resize-none" 
                          value={formData.workPerformed}
                          onChange={(e) => updateFormData({ workPerformed: e.target.value})}
                        />
                      </div>
                    </div>

                    {/* Time Tracking */}
                    <div>
                      <label className="label">Gewerkte Uren</label>
                      <div className="relative">
                         <Clock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
                         <input 
                          type="number" step="0.25"
                          className="input-field pl-10" 
                          value={formData.hoursWorked}
                          onChange={(e) => updateFormData({ hoursWorked: parseFloat(e.target.value)})}
                        />
                      </div>
                    </div>
                    <div>
                      <label className="label">Reistijd (minuten)</label>
                      <input 
                        type="number" 
                        className="input-field" 
                        value={formData.travelTime}
                        onChange={(e) => updateFormData({ travelTime: parseInt(e.target.value)})}
                      />
                    </div>
                    <div className="md:col-span-1">
                       {/* Space filler or extra field */}
                    </div>

                    {/* Planning & Follow up */}
                    <div className="md:col-span-3 grid grid-cols-1 md:grid-cols-2 gap-3 bg-surface-50 p-5 rounded-lg border border-surface-200">
                      <div>
                        <label className="label">Vervolgactie</label>
                        <input 
                          type="text" 
                          placeholder="Nabestellen, herhaalbezoek, etc."
                          className="input-field underline-offset-4" 
                          value={formData.followUpAction}
                          onChange={(e) => updateFormData({ followUpAction: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="label">Volgende Onderhoudsdatum</label>
                        <input 
                          type="date" 
                          className="input-field" 
                          value={formData.nextMaintenanceDate}
                          onChange={(e) => updateFormData({ nextMaintenanceDate: e.target.value})}
                        />
                      </div>
                    </div>

                    {/* Notes */}
                    <div className="md:col-span-3 grid grid-cols-1 md:grid-cols-2 gap-3 pt-4 border-t border-surface-100">
                      <div>
                        <label className="label">Interne Opmerkingen</label>
                        <textarea 
                          rows={2}
                          className="input-field resize-none" 
                          value={formData.internalNotes}
                          onChange={(e) => updateFormData({ internalNotes: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="label">Publieke Opmerkingen (op werkbon)</label>
                        <textarea 
                          rows={2}
                          className="input-field resize-none" 
                          value={formData.customerNotes}
                          onChange={(e) => updateFormData({ customerNotes: e.target.value})}
                        />
                      </div>
                    </div>
                  </div>

                  <AnimatePresence>
                    {duplicateWarning.isOpen && (
                      <motion.div 
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="bg-amber-50 border border-amber-100 rounded-md p-4 overflow-hidden mb-6"
                      >
                        <div className="flex items-start gap-3">
                          <div className="p-2 bg-amber-100 text-amber-600 rounded-lg shrink-0">
                            <Trash2 className="w-5 h-5" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-bold text-amber-900">Mogelijke dubbele interventie gevonden</p>
                            <p className="text-xs text-amber-700 mt-1">
                              Er zijn al interventies geregistreerd voor deze machine/klant die mogelijk hetzelfde zijn.
                            </p>
                            <div className="mt-3 space-y-2">
                              {duplicateWarning.matches.map(m => (
                                <div key={m.id} className="flex items-center justify-between p-2 bg-white/50 rounded-lg border border-amber-200/50">
                                  <span className="text-[11px] font-bold text-surface-700">{m.date} - {m.type} ({m.status})</span>
                                  <button 
                                    type="button"
                                    onClick={(e) => {
                                      e.preventDefault();
                                      handleOpenDetails(m);
                                    }}
                                    className="text-[10px] font-black uppercase text-amber-600 hover:text-amber-700"
                                  >
                                    Bekijken
                                  </button>
                                </div>
                              ))}
                            </div>
                            <div className="mt-4 flex items-center gap-3">
                               <button
                                 type="button"
                                 onClick={() => setDuplicateWarning({ isOpen: false, matches: [] })}
                                 className="text-xs font-bold text-surface-500 hover:text-surface-700"
                                >
                                 Aanpassen
                               </button>
                               <button
                                 type="button"
                                 onClick={() => handleSave(undefined, true)}
                                 className="text-xs font-bold text-amber-600 hover:text-amber-700 underline underline-offset-2"
                               >
                                 Toch opslaan als nieuwe interventie
                               </button>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <div className="flex items-center justify-end gap-3 pt-8 border-t border-surface-100">
                    <button 
                      type="button" 
                      disabled={isSaving}
                      onClick={handleCloseModal}
                      className="btn-ghost"
                    >
                      Annuleren
                    </button>
                    <button 
                      type="submit" 
                      disabled={isSaving}
                      className="btn-primary w-full sm:w-auto sm:min-w-[200px]"
                    >
                      {isSaving ? (
                        <div className="flex items-center gap-2">
                          <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          <span>Verwerken...</span>
                        </div>
                      ) : (
                        <span>{selectedIntervention ? 'Wijzigingen Opslaan' : 'Interventie Registreren'}</span>
                      )}
                    </button>
                  </div>
                </form>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <ConfirmDialog
        isOpen={deleteConfirm.isOpen}
        title="Interventie Verwijderen"
        message="Weet u zeker dat u deze interventie wilt verwijderen? Dit kan niet ongedaan worden gemaakt."
        onConfirm={handleDelete}
        onCancel={() => setDeleteConfirm({ isOpen: false, id: null })}
      />

      <AppointmentModal 
        isOpen={isAppointmentModalOpen}
        onClose={() => setIsAppointmentModalOpen(false)}
        appointment={null}
        initialData={appointmentInitialData}
        onSave={() => {
          setIsAppointmentModalOpen(false);
          refreshData();
        }}
        customers={customers}
        machines={machines}
        reminders={[]}
        interventions={interventions}
      />

      <ConfirmDialog
        isOpen={isFollowUpConfirmOpen}
        title="Vervolgwerkbon Aanmaken"
        message="Weet je zeker dat je een vervolgwerkbon wilt aanmaken? Recente actieve werkbonnen worden afgerond en de status van deze interventie wordt 'Gepland vervolgbezoek'."
        onConfirm={confirmFollowUpWorkOrder}
        onCancel={() => setIsFollowUpConfirmOpen(false)}
        confirmText="Aanmaken"
      />

      <ConfirmDialog
        isOpen={isCompleteConfirmOpen}
        title="Interventie Afronden"
        message="Weet je zeker dat je deze gehele interventie wilt afronden? De status van de interventie wordt op 'Afgerond' ingesteld."
        onConfirm={confirmCompleteIntervention}
        onCancel={() => setIsCompleteConfirmOpen(false)}
        confirmText="Afronden"
      />
      <ConfirmDialog
        isOpen={isCancelConfirmOpen}
        title="Onopgeslagen Wijzigingen"
        message="Je hebt onopgeslagen wijzigingen. Weet je zeker dat je wilt annuleren? Al je werk gaat verloren."
        onConfirm={closeModal}
        onCancel={() => setIsCancelConfirmOpen(false)}
        variant="danger"
        confirmText="Ja, werk weggooien"
        cancelText="Terug"
      />
    </div>
  );
};

export default Interventions;
