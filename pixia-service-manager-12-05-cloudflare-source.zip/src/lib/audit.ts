import { collection, addDoc } from 'firebase/firestore';
import { db, auth } from './firebase';
import { AuditLog } from '../types';
import { COLLECTIONS } from '../constants/collections';

export async function logAction(
  action: string, 
  entityType: AuditLog['entityType'], 
  entityId: string, 
  details: string = '',
  module: string = 'general'
) {
  const user = auth.currentUser;
  if (!user) return;

  try {
    const logData: Omit<AuditLog, 'id'> = {
      userId: user.uid,
      userEmail: user.email || 'unknown',
      userName: user.displayName || null,
      action,
      module,
      entityType,
      entityId: entityId || null,
      details,
      timestamp: new Date().toISOString()
    };

    await addDoc(collection(db, COLLECTIONS.AUDIT_LOGS), logData);
  } catch (error) {
    console.error('Failed to create audit log:', error);
  }
}
