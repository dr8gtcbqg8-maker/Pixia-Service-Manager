import { CommunicationTemplate, CommunicationTemplateType } from '../types';

export interface PlaceholderDefinition {
  key: string;
  label: string;
  description: string;
  exampleValue: string;
}

export const SUPPORTED_PLACEHOLDERS: PlaceholderDefinition[] = [
  { key: 'customer_name', label: 'Klant Naam', description: 'De volledige naam van de klant', exampleValue: 'J. Jansen' },
  { key: 'contact_person', label: 'Contactpersoon', description: 'Naam van de contactpersoon', exampleValue: 'Jan Pietersen' },
  { key: 'customer_email', label: 'E-mail Klant', description: 'E-mailadres van de klant', exampleValue: 'klant@voorbeeld.nl' },
  { key: 'customer_phone', label: 'Telefoon Klant', description: 'Telefoonnummer van de klant', exampleValue: '06-12345678' },
  { key: 'machine_brand', label: 'Machine Merk', description: 'Merk van de machine', exampleValue: 'Epson' },
  { key: 'machine_model', label: 'Machine Model', description: 'Model van de machine', exampleValue: 'SureColor SC-F2100' },
  { key: 'serial_number', label: 'Serienummer', description: 'Serienummer van de machine', exampleValue: 'EPS12345678' },
  { key: 'appointment_date', label: 'Afspraak Datum', description: 'Datum van de afspraak', exampleValue: '12 mei 2026' },
  { key: 'appointment_time', label: 'Afspraak Tijd', description: 'Tijd van de afspraak', exampleValue: '14:30' },
  { key: 'appointment_location', label: 'Locatie', description: 'Locatie van de afspraak', exampleValue: 'Kantoor Utrecht' },
  { key: 'technician_name', label: 'Technicus', description: 'Naam van de toegewezen technicus', exampleValue: 'Marco Technisch' },
  { key: 'intervention_type', label: 'Type Interventie', description: 'Soort werkzaamheden', exampleValue: 'Periodiek Onderhoud' },
  { key: 'intervention_status', label: 'Status', description: 'Huidige status van de interventie', exampleValue: 'Afgerond' },
  { key: 'work_order_number', label: 'Werkbon Nummer', description: 'Het unieke nummer van de werkbon', exampleValue: 'WB-2026-001' },
  { key: 'company_name', label: 'Eigen Bedrijfsnaam', description: 'Naam van Pixia', exampleValue: 'Pixia Service Manager' },
  { key: 'company_phone', label: 'Eigen Telefoon', description: 'Contacttelefoon Pixia', exampleValue: '030-1234567' },
  { key: 'company_email', label: 'Eigen E-mail', description: 'Contact e-mail Pixia', exampleValue: 'service@pixia.nl' }
];

export const PIXIA_DEFAULT_TEMPLATES: Omit<CommunicationTemplate, 'id' | 'updatedAt' | 'createdAt'>[] = [
  {
    type: 'appointment_confirmation',
    name: 'Afspraakbevestiging',
    description: 'Verzonden zodra een afspraak definitief is ingepland.',
    category: 'appointments',
    subject: 'Bevestiging van uw afspraak - {{company_name}}',
    body: 'Beste {{customer_name}},\n\nHierbij bevestigen wij uw afspraak op {{appointment_date}} om {{appointment_time}}.\n\nLocatie: {{appointment_location}}\nMachine: {{machine_model}}\n\nMet vriendelijke groet,\nHet team van {{company_name}}',
    placeholders: ['customer_name', 'appointment_date', 'appointment_time', 'appointment_location', 'machine_model', 'company_name'],
    active: true,
    isSystemTemplate: true
  },
  {
    type: 'appointment_reminder_24h',
    name: 'Afspraakherinnering (24u)',
    description: 'Automatische herinnering 24 uur voor de afspraak.',
    category: 'appointments',
    subject: 'Herinnering: Uw afspraak voor morgen bij {{company_name}}',
    body: 'Beste {{customer_name}},\n\nDit is een vriendelijke herinnering aan onze afspraak van morgen op {{appointment_date}} om {{appointment_time}}.\n\nWij kijken uit naar ons bezoek.\n\nMet vriendelijke groet,\n{{company_name}}',
    placeholders: ['customer_name', 'appointment_date', 'appointment_time', 'company_name'],
    active: true,
    isSystemTemplate: true
  },
  {
    type: 'maintenance_reminder',
    name: 'Onderhoudsherinnering',
    description: 'Herinnering dat een machine toe is aan periodiek onderhoud.',
    category: 'maintenance',
    subject: 'Herinnering: Periodiek onderhoud voor uw {{machine_brand}} {{machine_model}}',
    body: 'Beste {{customer_name}},\n\nUw {{machine_brand}} {{machine_model}} (SN: {{serial_number}}) is volgens onze gegevens toe aan periodiek onderhoud.\n\nOm een optimale werking te garanderen, raden wij aan dit binnenkort in te plannen. Neem contact met ons op om een afspraak te maken.\n\nMet vriendelijke groet,\n{{company_name}}',
    placeholders: ['customer_name', 'machine_brand', 'machine_model', 'serial_number', 'company_name'],
    active: true,
    isSystemTemplate: true
  },
  {
    type: 'intervention_completed',
    name: 'Interventie Afgerond',
    description: 'Bevestiging dat de werkzaamheden zijn voltooid.',
    category: 'interventions',
    subject: 'Service voltooid aan uw {{machine_model}}',
    body: 'Beste {{customer_name}},\n\nOnze technicus {{technician_name}} heeft de werkzaamheden ({{intervention_type}}) aan uw {{machine_model}} zojuist afgerond.\n\nWij hopen dat alles naar wens is verlopen.\n\nMet vriendelijke groet,\n{{company_name}}',
    placeholders: ['customer_name', 'technician_name', 'intervention_type', 'machine_model', 'company_name'],
    active: true,
    isSystemTemplate: true
  },
  {
    type: 'work_order_sent',
    name: 'Digitale Werkbon',
    description: 'Verzonden wanneer de digitale werkbon wordt gemaild.',
    category: 'work_orders',
    subject: 'Digitale Werkbon - {{work_order_number}}',
    body: 'Beste {{customer_name}},\n\nIn de bijlage vindt u de digitale werkbon van de werkzaamheden die wij hebben uitgevoerd op {{appointment_date}}.\n\nBedankt voor uw vertrouwen.\n\nMet vriendelijke groet,\n{{company_name}}',
    placeholders: ['customer_name', 'work_order_number', 'appointment_date', 'company_name'],
    active: true,
    isSystemTemplate: true
  },
  {
    type: 'follow_up',
    name: 'Klanttevredenheid Follow-up',
    description: 'Vraag om feedback enkele dagen na een interventie.',
    category: 'interventions',
    subject: 'Hoe verliep uw recente servicebezoek van {{company_name}}?',
    body: 'Beste {{customer_name}},\n\nOnlangs hebben wij een interventie uitgevoerd aan uw {{machine_model}}.\n\nWij hopen dat alles naar wens is verlopen. Indien u nog vragen heeft of er zijn problemen, laat het ons dan direct weten.\n\nMet vriendelijke groet,\nHet service team van {{company_name}}',
    placeholders: ['customer_name', 'machine_model', 'company_name'],
    active: true,
    isSystemTemplate: true
  }
];
