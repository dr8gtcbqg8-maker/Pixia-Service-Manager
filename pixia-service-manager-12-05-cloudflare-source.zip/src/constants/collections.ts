export const COLLECTIONS = {
  USERS: 'users',
  CUSTOMERS: 'customers',
  MACHINES: 'machines',
  INTERVENTIONS: 'interventions',
  WORK_ORDERS: 'work_orders',
  APPOINTMENTS: 'appointments',
  INVENTORY: 'inventory',
  INVENTORY_MUTATIONS: 'inventory_mutations',
  ALERTS: 'alerts',
  SMART_ALERTS: 'smart_alerts',
  REMINDERS: 'reminders',
  EMAIL_LOGS: 'email_logs',
  OUTLOOK_CONNECTIONS: 'outlook_connections',
  AUDIT_LOGS: 'audit_logs',
  COMMUNICATION_TEMPLATES: 'communication_templates',
  AUTOMATION_RULES: 'automation_rules',
  NOTIFICATIONS: 'notifications',
  SETTINGS: 'settings',
} as const;

export type CollectionName = typeof COLLECTIONS[keyof typeof COLLECTIONS];
