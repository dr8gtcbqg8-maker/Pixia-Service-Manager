import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Globe, Mail, ChevronRight, UserPlus, Printer, 
  Wrench, ClipboardList, Bell, Package 
} from 'lucide-react';
import { cn } from '../../lib/utils';
import { OutlookConnection, EmailLog } from '../../types';

interface DashboardQuickActionsProps {
  outlookConnection: OutlookConnection | null;
  emailLogs: EmailLog[];
}

const DashboardQuickActions: React.FC<DashboardQuickActionsProps> = ({ outlookConnection, emailLogs }) => {
  const navigate = useNavigate();

  return (
    <div className="space-y-8">
      {/* Automatisering & Koppelingen */}
      <section className="bg-white border border-slate-100 rounded-[2.5rem] p-8 shadow-sm">
        <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-6 flex items-center gap-2">
          Automatisering & Koppelingen
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
           <div 
             onClick={() => navigate('/settings?tab=outlook')}
             className="p-6 bg-slate-900 border border-slate-800 rounded-[2rem] text-white flex items-center justify-between cursor-pointer group shadow-xl"
           >
              <div className="flex items-center gap-4">
                 <div className={cn(
                   "w-12 h-12 rounded-2xl flex items-center justify-center transition-all",
                   outlookConnection ? "bg-blue-600 shadow-lg shadow-blue-900/50" : "bg-slate-800"
                 )}>
                    <Globe className={cn("w-6 h-6", outlookConnection ? "text-white" : "text-slate-500")} />
                 </div>
                 <div className="text-left">
                    <p className="text-[10px] font-black uppercase text-slate-500 tracking-widest mb-1">Outlook Status</p>
                    <p className="text-sm font-black italic">{outlookConnection ? 'Verbonden' : 'Niet Gekoppeld'}</p>
                 </div>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-600 group-hover:text-blue-400 transition-colors" />
           </div>

           <div 
             onClick={() => navigate('/email-log')}
             className="p-6 bg-white border border-slate-100 rounded-[2rem] flex items-center justify-between cursor-pointer group hover:border-indigo-100 hover:shadow-lg transition-all"
           >
              <div className="flex items-center gap-4">
                 <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center border border-indigo-100">
                    <Mail className="w-6 h-6 text-indigo-600" />
                 </div>
                 <div className="text-left">
                    <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-1">E-mail Activiteit</p>
                    <p className="text-sm font-black italic">
                      {emailLogs.filter(l => l.status === 'sent').length} verzonden
                      {emailLogs.filter(l => l.status === 'failed').length > 0 && 
                        <span className="text-rose-500 ml-2">({emailLogs.filter(l => l.status === 'failed').length} fouten)</span>
                      }
                    </p>
                 </div>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-indigo-600 transition-colors" />
           </div>
        </div>
      </section>

      {/* Snelkoppelingen */}
      <section className="bg-white border border-slate-100 rounded-[2.5rem] p-8 shadow-sm">
        <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-6 flex items-center gap-2 text-left">
          Snelkoppelingen
        </h3>
        <div className="flex overflow-x-auto pb-4 -mx-4 px-4 md:grid md:grid-cols-6 md:pb-0 md:mx-0 md:px-0 gap-4 no-scrollbar">
          {[
            { label: 'Klant', icon: UserPlus, color: 'text-blue-600', bg: 'bg-blue-50', path: '/customers' },
            { label: 'Machine', icon: Printer, color: 'text-indigo-600', bg: 'bg-indigo-50', path: '/machines' },
            { label: 'Service', icon: Wrench, color: 'text-amber-600', bg: 'bg-amber-50', path: '/interventions' },
            { label: 'Werkbon', icon: ClipboardList, color: 'text-green-600', bg: 'bg-green-50', path: '/work-orders' },
            { label: 'Taken', icon: Bell, color: 'text-rose-600', bg: 'bg-rose-50', path: '/reminders' },
            { label: 'Stock', icon: Package, color: 'text-slate-600', bg: 'bg-slate-50', path: '/inventory' },
          ].map((action, i) => (
            <button
              key={i}
              onClick={() => navigate(action.path)}
              className="flex flex-col items-center gap-3 p-5 min-w-[100px] rounded-[2rem] border border-slate-50 hover:border-blue-200 hover:shadow-xl hover:shadow-slate-100 transition-all group cursor-pointer bg-slate-50/10"
            >
              <div className={`p-4 ${action.bg} ${action.color} rounded-2xl group-hover:scale-110 transition-transform shadow-sm`}>
                <action.icon className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-black text-slate-900 uppercase tracking-widest text-center whitespace-nowrap">{action.label}</span>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
};

export default DashboardQuickActions;
