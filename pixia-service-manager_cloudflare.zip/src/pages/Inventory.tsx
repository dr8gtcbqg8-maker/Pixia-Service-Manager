import React, { useEffect, useState, useMemo } from 'react';
import { InventoryItem, InventoryMutation, MutationType } from '../types';
import { 
  Plus, Package, AlertTriangle, ArrowUpRight, ArrowDownRight, 
  History, CheckCircle2, Tag, MapPin, Hash, DollarSign,
  X, Trash2, Printer, Search
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ConfirmDialog from '../components/ConfirmDialog';
import { format } from 'date-fns';
import { useInventory } from '../hooks/useInventory';
import { inventoryService } from '../services/inventoryService';
import InventoryTable from '../components/inventory/InventoryTable';
import InventoryFilters from '../components/inventory/InventoryFilters';
import { cn } from '../lib/utils';

const Inventory: React.FC = () => {
  const { items, loading, refreshData, fetchMutations } = useInventory();
  const [mutations, setMutations] = useState<InventoryMutation[]>([]);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [isMutationModalOpen, setIsMutationModalOpen] = useState(false);
  
  // Print & Low Stock per supplier states
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [selectedPrintItems, setSelectedPrintItems] = useState<string[]>([]);
  const [manuallyAddedPrintItemIds, setManuallyAddedPrintItemIds] = useState<string[]>([]);
  const [printSearch, setPrintSearch] = useState('');
  
  const [search, setSearch] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterSupplier, setFilterSupplier] = useState('all');
  const [filterStatus, setFilterStatus] = useState('active');
  const [filterLowStock, setFilterLowStock] = useState(false);
  
  const [deleteConfirm, setDeleteConfirm] = useState<{ isOpen: boolean; id: string | null }>({ isOpen: false, id: null });
  const [isSaving, setIsSaving] = useState(false);
  const [duplicateWarning, setDuplicateWarning] = useState<{ isOpen: boolean; matches: InventoryItem[] }>({ isOpen: false, matches: [] });

  const [isDirty, setIsDirty] = useState(false);
  const [isCancelConfirmOpen, setIsCancelConfirmOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    category: '',
    sku: '',
    supplier: '',
    stockCount: 0,
    minStock: 5,
    brand: '',
    location: '',
    purchasePrice: 0,
    sellingPrice: 0,
    notes: '',
    status: 'active' as 'active' | 'inactive'
  });

  const [mutationData, setMutationData] = useState({
    type: 'increase' as MutationType,
    quantity: 0,
    reason: ''
  });

  // Memoized print grouping calculations
  const lowStockItems = useMemo(() => {
    return items.filter(item => item.stockCount < item.minStock || manuallyAddedPrintItemIds.includes(item.id));
  }, [items, manuallyAddedPrintItemIds]);

  const lowStockItemsBySupplier = useMemo(() => {
    const grouped: Record<string, InventoryItem[]> = {};
    lowStockItems.forEach(item => {
      const s = (item.supplier || 'Onbekende leverancier').trim();
      if (!grouped[s]) {
        grouped[s] = [];
      }
      grouped[s].push(item);
    });
    return Object.entries(grouped)
      .map(([supplierName, items]) => ({
        supplierName,
        items
      }))
      .sort((a, b) => a.supplierName.localeCompare(b.supplierName));
  }, [lowStockItems]);

  const printSearchCandidates = useMemo(() => {
    if (!printSearch.trim()) return [];
    const term = printSearch.toLowerCase();
    return items.filter(item => 
      !manuallyAddedPrintItemIds.includes(item.id) &&
      item.stockCount >= item.minStock && 
      (item.name.toLowerCase().includes(term) || item.sku?.toLowerCase().includes(term))
    ).slice(0, 5);
  }, [items, printSearch, manuallyAddedPrintItemIds]);

  const handleAddManualPrintItem = (item: InventoryItem) => {
    setManuallyAddedPrintItemIds(prev => [...prev, item.id]);
    setSelectedPrintItems(prev => [...prev, item.id]);
    setPrintSearch('');
  };

  const handleOpenPrintModal = () => {
    const allLowStockIds = items.filter(item => item.stockCount < item.minStock).map(i => i.id);
    setSelectedPrintItems(allLowStockIds);
    setManuallyAddedPrintItemIds([]);
    setPrintSearch('');
    setIsPrintModalOpen(true);
  };

  const togglePrintItem = (id: string) => {
    setSelectedPrintItems(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const toggleSupplierItems = (supplierName: string, supplierItems: InventoryItem[]) => {
    const itemIds = supplierItems.map(i => i.id);
    const allSelected = itemIds.every(id => selectedPrintItems.includes(id));
    if (allSelected) {
      setSelectedPrintItems(prev => prev.filter(id => !itemIds.includes(id)));
    } else {
      setSelectedPrintItems(prev => {
        const otherIds = prev.filter(id => !itemIds.includes(id));
        return [...otherIds, ...itemIds];
      });
    }
  };

  const categories = useMemo(() => Array.from(new Set(items.map(i => i.category))).filter(Boolean), [items]);
  const suppliers = useMemo(() => Array.from(new Set(items.map(i => i.supplier))).filter(Boolean), [items]);

  
  const updateFormData = (updates: any) => {
    setFormData((prev: any) => ({ ...prev, ...updates }));
    setIsDirty(true);
  };

  const handleCloseModal = () => {
    if (isDirty ) {
      setIsCancelConfirmOpen(true);
    } else {
      closeModal();
    }
  };

  const closeModal = () => {
    setIsCancelConfirmOpen(false);
    setIsAddModalOpen(false);
    setIsDirty(false);
  };

  const handleOpenAddModal = () => {
    setSelectedItem(null);
    setDuplicateWarning({ isOpen: false, matches: [] });
    setFormData({
      name: '', category: '', sku: '', supplier: '', 
      stockCount: 0, minStock: 5, brand: '', location: '', 
      purchasePrice: 0, sellingPrice: 0, notes: '', status: 'active'
    });
    setIsAddModalOpen(true);
  };

  const handleOpenEditModal = (item: InventoryItem) => {
    setSelectedItem(item);
    setDuplicateWarning({ isOpen: false, matches: [] });
    setFormData({
      name: item.name,
      category: item.category || '',
      sku: item.sku || item.partNumber || '',
      supplier: item.supplier || '',
      brand: item.brand || '',
      stockCount: item.stockCount,
      minStock: item.minStock,
      location: item.location || '',
      purchasePrice: item.purchasePrice,
      sellingPrice: item.sellingPrice,
      notes: item.notes || '',
      status: item.status
    });
    setIsAddModalOpen(true);
  };

  const handleOpenDetails = async (item: InventoryItem) => {
    setSelectedItem(item);
    setDuplicateWarning({ isOpen: false, matches: [] });
    const itemMutations = await fetchMutations(item.id);
    setMutations(itemMutations);
    setIsDetailsModalOpen(true);
  };

  const handleOpenMutationModal = (item: InventoryItem, type: MutationType) => {
    setSelectedItem(item);
    setMutationData({ type, quantity: 0, reason: '' });
    setIsMutationModalOpen(true);
  };

  const handleSaveItem = async (e?: React.FormEvent, bypassDuplicateCheck = false) => {
    if (e) e.preventDefault();
    
    if (isSaving) return;

    if (!bypassDuplicateCheck) {
      setIsSaving(true);
      const matches = await inventoryService.findPotentialDuplicates(formData, selectedItem?.id);
      setIsSaving(false);

      if (matches.length > 0) {
        setDuplicateWarning({ isOpen: true, matches });
        return;
      }
    }

    setIsSaving(true);
    const successId = await inventoryService.save(formData, selectedItem);
    setIsSaving(false);

    if (successId) {
      setIsAddModalOpen(false);
      refreshData();
    }
  };

  const handleSaveMutation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedItem) return;
    if (mutationData.quantity <= 0 && mutationData.type !== 'correction') {
      alert('Voer een aantal groter dan 0 in.');
      return;
    }

    const success = await inventoryService.saveMutation(
      selectedItem.id,
      selectedItem.stockCount,
      mutationData.type,
      mutationData.quantity,
      mutationData.reason
    );

    if (success) {
      setIsMutationModalOpen(false);
      refreshData();
      if (isDetailsModalOpen) {
        const itemMutations = await fetchMutations(selectedItem.id);
        setMutations(itemMutations);
      }
    }
  };

  const handleDeleteClick = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setDeleteConfirm({ isOpen: true, id });
  };

  const confirmDelete = async () => {
    if (!deleteConfirm.id) return;
    const success = await inventoryService.delete(deleteConfirm.id);
    if (success) {
      setDeleteConfirm({ isOpen: false, id: null });
      refreshData();
    }
  };

  const filteredItems = useMemo(() => items.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(search.toLowerCase()) || 
                          item.partNumber?.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = filterCategory === 'all' || item.category === filterCategory;
    const matchesSupplier = filterSupplier === 'all' || item.supplier === filterSupplier;
    const matchesStatus = filterStatus === 'all' || item.status === filterStatus;
    const isLowStock = item.stockCount < item.minStock;
    const matchesLowStock = !filterLowStock || isLowStock;
    
    return matchesSearch && matchesCategory && matchesSupplier && matchesStatus && matchesLowStock;
  }), [items, search, filterCategory, filterSupplier, filterStatus, filterLowStock]);

  return (
    <div>
      {/* SCREEN CONTAINER - Verborgen tijdens het printen */}
      <div className="print:hidden space-y-4 pb-12">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold text-surface-900 tracking-tight">Voorraadbeheer</h1>
            <p className="text-surface-500 mt-1 text-sm">Beheer onderdelen en verbruiksartikelen in de centrale voorraad.</p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button 
              onClick={handleOpenPrintModal}
              className="flex items-center gap-2 bg-white hover:bg-surface-50 border border-surface-200 text-surface-700 px-4 py-2.5 rounded-md text-sm font-semibold shadow-sm transition-all active:scale-95"
            >
              <Printer className="w-4 h-4 text-brand-500" />
              <span>Besteladvies printen</span>
            </button>
            <button 
              onClick={handleOpenAddModal}
              className="btn-primary"
            >
              <Plus className="w-5 h-5" />
              <span>Nieuw Artikel</span>
            </button>
          </div>
        </div>

      <InventoryFilters 
        search={search} setSearch={setSearch}
        filterCategory={filterCategory} setFilterCategory={setFilterCategory} categories={categories}
        filterSupplier={filterSupplier} setFilterSupplier={setFilterSupplier} suppliers={suppliers}
        filterStatus={filterStatus} setFilterStatus={setFilterStatus}
        filterLowStock={filterLowStock} setFilterLowStock={setFilterLowStock}
      />

      {loading ? (
        <div className="flex justify-center p-24">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-surface-200 border-t-blue-600"></div>
        </div>
      ) : (
        <InventoryTable 
          items={filteredItems}
          onDetails={handleOpenDetails}
          onEdit={handleOpenEditModal}
          onDelete={handleDeleteClick}
          onMutation={handleOpenMutationModal}
        />
      )}

      <ConfirmDialog
        isOpen={deleteConfirm.isOpen}
        title="Artikel verwijderen"
        message="Weet u zeker dat u dit artikel wilt verwijderen uit de voorraad? Deze actie kan niet ongedaan worden gemaakt."
        onConfirm={confirmDelete}
        onCancel={() => setDeleteConfirm({ isOpen: false, id: null })}
      />

      {/* Add/Edit Modal */}
      <AnimatePresence>
        {isAddModalOpen && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-surface-900/40 backdrop-blur-sm"

            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative bg-white w-full max-w-2xl rounded-lg shadow-xl overflow-hidden flex flex-col max-h-[95vh]"
            >
              <div className="px-5 py-6 border-b border-surface-100 flex items-center justify-between shrink-0 bg-white z-10">
                <h2 className="text-xl font-bold text-surface-900">
                  {selectedItem ? 'Artikel bewerken' : 'Nieuw artikel toevoegen'}
                </h2>
                <button 
                  onClick={handleCloseModal}
                  className="p-2 hover:bg-surface-100 rounded-lg text-surface-400 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveItem} className="flex-1 overflow-y-auto p-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="md:col-span-2">
                    <label className="label">Artikelnaam *</label>
                    <input 
                      required 
                      type="text" 
                      className="input-field"
                      value={formData.name}
                      onChange={(e) => updateFormData({ name: e.target.value})}
                    />
                  </div>

                  <div>
                    <label className="label">Artikelnummer</label>
                    <div className="relative">
                      <Hash className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
                      <input 
                        type="text" 
                        className="input-field pl-10"
                        placeholder="VB: 12345-AB"
                        value={formData.sku}
                        onChange={(e) => updateFormData({ sku: e.target.value})}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="label">Merk</label>
                    <input 
                      type="text" 
                      className="input-field"
                      placeholder="VB: Samsung, Canon..."
                      value={formData.brand}
                      onChange={(e) => updateFormData({ brand: e.target.value})}
                    />
                  </div>

                  <div>
                    <label className="label">Leverancier</label>
                    <input 
                      type="text" 
                      className="input-field"
                      placeholder="Naam leverancier"
                      value={formData.supplier}
                      onChange={(e) => updateFormData({ supplier: e.target.value})}
                    />
                  </div>

                  <div>
                    <label className="label">Categorie</label>
                    <div className="relative">
                      <Tag className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
                      <input 
                        type="text" 
                        className="input-field pl-10"
                        placeholder="VB: Onderdelen"
                        value={formData.category}
                        onChange={(e) => updateFormData({ category: e.target.value})}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="label">Status</label>
                    <select 
                      className="input-field"
                      value={formData.status}
                      onChange={(e) => updateFormData({ status: e.target.value as any})}
                    >
                      <option value="active">Actief</option>
                      <option value="inactive">Inactief</option>
                    </select>
                  </div>

                  <div className="md:col-span-2 grid grid-cols-2 gap-4">
                    <div>
                      <label className="label">Voorraad</label>
                      <input 
                        disabled={!!selectedItem}
                        type="number" 
                        className="input-field disabled:bg-surface-50 disabled:text-surface-500"
                        value={formData.stockCount}
                        onChange={(e) => updateFormData({ stockCount: parseInt(e.target.value) || 0})}
                      />
                    </div>
                    <div>
                      <label className="label">Minimale voorraad</label>
                      <input 
                        type="number" 
                        className="input-field"
                        value={formData.minStock}
                        onChange={(e) => updateFormData({ minStock: parseInt(e.target.value) || 0})}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="label">Locatie</label>
                    <div className="relative">
                      <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
                      <input 
                        type="text" 
                        className="input-field pl-10"
                        placeholder="VB: Kast A-12"
                        value={formData.location}
                        onChange={(e) => updateFormData({ location: e.target.value})}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="label">Inkoopprijs (€)</label>
                    <div className="relative">
                      <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
                      <input 
                        type="number" step="0.01"
                        className="input-field pl-10"
                        value={formData.purchasePrice}
                        onChange={(e) => updateFormData({ purchasePrice: parseFloat(e.target.value) || 0})}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="label">Verkoopprijs (€)</label>
                    <div className="relative">
                      <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
                      <input 
                        type="number" step="0.01"
                        className="input-field pl-10"
                        value={formData.sellingPrice}
                        onChange={(e) => updateFormData({ sellingPrice: parseFloat(e.target.value) || 0})}
                      />
                    </div>
                  </div>

                  <div className="md:col-span-2">
                    <label className="label">Interne notities</label>
                    <textarea 
                      className="input-field py-3 min-h-[100px] resize-none"
                      rows={3}
                      placeholder="Optionele extra informatie..."
                      value={formData.notes}
                      onChange={(e) => updateFormData({ notes: e.target.value})}
                    />
                  </div>
                </div>

                <AnimatePresence>
                  {duplicateWarning.isOpen && (
                    <motion.div 
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="bg-amber-50 border border-amber-100 rounded-md p-4 overflow-hidden mt-6"
                    >
                      <div className="flex items-start gap-3">
                        <div className="p-2 bg-amber-100 text-amber-600 rounded-lg shrink-0">
                          <Trash2 className="w-5 h-5" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-bold text-amber-900">Mogelijk dubbel artikel gevonden</p>
                          <p className="text-xs text-amber-700 mt-1">
                            Er bestaat al een artikel met dezelfde SKU of Naam/Merk/Leverancier combinatie.
                          </p>
                          <div className="mt-3 space-y-2">
                            {duplicateWarning.matches.map(m => (
                              <div key={m.id} className="flex items-center justify-between p-2 bg-white/50 rounded-lg border border-amber-200/50">
                                <span className="text-[11px] font-bold text-surface-700">{m.name} ({m.sku || 'Geen SKU'})</span>
                                <button 
                                  type="button"
                                  onClick={(e) => {
                                    e.preventDefault();
                                    handleOpenDetails(m);
                                  }}
                                  className="text-[10px] font-black uppercase text-amber-600 hover:text-amber-700"
                                >
                                  Bekijken
                                </button>
                              </div>
                            ))}
                          </div>
                          <div className="mt-4 flex items-center gap-3">
                             <button
                               type="button"
                               onClick={() => setDuplicateWarning({ isOpen: false, matches: [] })}
                               className="text-xs font-bold text-surface-500 hover:text-surface-700"
                             >
                               Aanpassen
                             </button>
                             <button
                               type="button"
                               onClick={() => handleSaveItem(undefined, true)}
                               className="text-xs font-bold text-amber-600 hover:text-amber-700 underline underline-offset-2"
                             >
                               Toch opslaan
                             </button>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <div className="mt-8 flex items-center justify-end gap-3 pt-6 border-t border-surface-100 sticky bottom-0 bg-white">
                  <button 
                    type="button" 
                    disabled={isSaving}
                    onClick={handleCloseModal}
                    className="btn-ghost"
                  >
                    Annuleren
                  </button>
                  <button 
                    type="submit" 
                    disabled={isSaving}
                    className="btn-primary min-w-[140px]"
                  >
                    {isSaving ? (
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        <span>Laden...</span>
                      </div>
                    ) : (
                      <span>{selectedItem ? 'Opslaan' : 'Toevoegen'}</span>
                    )}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Mutation Modal */}
      <AnimatePresence>
        {isMutationModalOpen && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-surface-900/40 backdrop-blur-sm"

            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative bg-white w-full max-w-md rounded-lg shadow-xl p-5"
            >
              <h2 className="text-xl font-bold text-surface-900 mb-6 flex items-center gap-2">
                <Package className="w-5 h-5 text-brand-500" />
                <span className="capitalize">Voorraad {mutationData.type}</span>
              </h2>
              
              <form onSubmit={handleSaveMutation} className="space-y-3">
                <div>
                  <label className="label">
                    {mutationData.type === 'correction' ? 'Nieuwe voorraad stand' : 'Aantal stuks'}
                  </label>
                  <input 
                    required 
                    type="number" 
                    className="w-full px-5 py-2 bg-surface-50 border border-surface-200 rounded-md font-bold text-2xl text-center focus:ring-2 focus:ring-blue-500 outline-none"
                    value={mutationData.quantity}
                    onChange={(e) => setMutationData({...mutationData, quantity: parseInt(e.target.value) || 0})}
                  />
                  {mutationData.type !== 'correction' && (
                    <div className="flex justify-center mt-3">
                      <div className="px-3 py-1 bg-surface-100 rounded-full text-[10px] font-bold text-surface-500 uppercase tracking-wider">
                         Huidig: {selectedItem?.stockCount} → Nieuw: {
                            mutationData.type === 'increase' 
                            ? (selectedItem?.stockCount || 0) + mutationData.quantity 
                            : (selectedItem?.stockCount || 0) - mutationData.quantity
                        }
                      </div>
                    </div>
                  )}
                </div>

                <div>
                  <label className="label">Reden / Notitie</label>
                  <input 
                    type="text" 
                    className="input-field"
                    placeholder="Bijv. Inventaris, Nieuwe levering..."
                    value={mutationData.reason}
                    onChange={(e) => setMutationData({...mutationData, reason: e.target.value})}
                  />
                </div>

                <div className="flex items-center gap-3 pt-6 border-t border-surface-100">
                  <button 
                    type="button" 
                    onClick={() => setIsMutationModalOpen(false)}
                    className="btn-ghost flex-1"
                  >
                    Annuleren
                  </button>
                  <button 
                    type="submit" 
                    className={cn(
                        "btn-primary flex-1",
                        mutationData.type === 'increase' ? 'bg-emerald-600 hover:bg-emerald-700' : 
                        mutationData.type === 'decrease' ? 'bg-rose-600 hover:bg-rose-700' : ''
                    )}
                  >
                    Bevestigen
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Details Modal */}
      <AnimatePresence>
        {isDetailsModalOpen && selectedItem && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-surface-900/40 backdrop-blur-sm"

            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative bg-white w-full max-w-4xl rounded-lg shadow-xl overflow-hidden flex flex-col max-h-[90vh]"
            >
              <div className="px-5 py-6 bg-surface-50 border-b border-surface-200 flex items-center justify-between">
                <div className="flex items-center gap-4">
                   <div className={cn(
                     "w-12 h-12 rounded-md flex items-center justify-center border shadow-sm",
                     selectedItem.stockCount < selectedItem.minStock ? 'bg-rose-50 text-rose-600 border-rose-100' : 'bg-white text-brand-500 border-surface-200'
                   )}>
                      <Package className="w-6 h-6" />
                   </div>
                   <div>
                      <h2 className="text-xl font-bold text-surface-900">{selectedItem.name}</h2>
                      <p className="text-xs font-mono text-surface-500">PN: {selectedItem.partNumber || 'Geen nummer'}</p>
                   </div>
                </div>
                <button 
                  onClick={() => setIsDetailsModalOpen(false)}
                  className="p-2 hover:bg-white rounded-lg text-surface-400 transition-colors border border-transparent hover:border-surface-200"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-5 lg:p-5">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                  <div className="space-y-4">
                     <div className="grid grid-cols-2 gap-4">
                        <div className="p-5 bg-surface-50 border border-surface-200 rounded-md">
                           <span className="block text-[10px] font-bold text-surface-400 uppercase tracking-wider mb-1">Leverancier</span>
                           <p className="text-sm font-bold text-surface-700">{selectedItem.supplier || 'Niet bekend'}</p>
                        </div>
                        <div className="p-5 bg-surface-50 border border-surface-200 rounded-md">
                           <span className="block text-[10px] font-bold text-surface-400 uppercase tracking-wider mb-1">Magazijnlocatie</span>
                           <p className="text-sm font-bold text-surface-700">{selectedItem.location || 'Niet bekend'}</p>
                        </div>
                     </div>

                     <div className="bg-surface-900 text-white rounded-lg p-5 shadow-xl">
                        <div className="flex items-center justify-between mb-8">
                           <div>
                              <span className="text-[11px] font-bold text-surface-400 uppercase tracking-widest block mb-1">Huidige Voorraad</span>
                              <div className="flex items-baseline gap-2">
                                <span className={cn(
                                  "text-4xl font-bold",
                                  selectedItem.stockCount < selectedItem.minStock ? 'text-rose-400' : 'text-white'
                                )}>{selectedItem.stockCount}</span>
                                <span className="text-surface-400 text-sm">stuks</span>
                              </div>
                           </div>
                           <div className="text-right">
                              <span className="text-[11px] font-bold text-surface-400 uppercase tracking-widest block mb-1">Minimum niveau</span>
                              <p className="text-base font-bold text-white/90">{selectedItem.minStock} stuks</p>
                           </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4 pt-8 border-t border-white/10">
                           <div>
                              <span className="text-[10px] font-bold text-surface-400 uppercase tracking-widest block mb-1">Verkoopprijs</span>
                              <p className="text-xl font-bold">€ {selectedItem.sellingPrice.toFixed(2)}</p>
                           </div>
                           <div className="text-right">
                              <span className="text-[10px] font-bold text-surface-400 uppercase tracking-widest block mb-1">Inkoopprijs</span>
                              <p className="text-xl font-bold text-white/60">€ {selectedItem.purchasePrice.toFixed(2)}</p>
                           </div>
                        </div>
                     </div>

                     <div className="space-y-4">
                        <h4 className="text-sm font-bold text-surface-900">Snelle handelingen</h4>
                        <div className="grid grid-cols-2 gap-3">
                           <button 
                              onClick={() => handleOpenMutationModal(selectedItem, 'increase')}
                              className="btn-ghost !bg-surface-50 hover:!bg-emerald-50 !border-surface-200 hover:!border-emerald-200 !text-surface-700 hover:!text-emerald-700 !py-2"
                           >
                              <Plus className="w-5 h-5" />
                              <span>Inboeken</span>
                           </button>
                           <button 
                              onClick={() => handleOpenMutationModal(selectedItem, 'decrease')}
                              className="btn-ghost !bg-surface-50 hover:!bg-rose-50 !border-surface-200 hover:!border-rose-200 !text-surface-700 hover:!text-rose-700 !py-2"
                           >
                              <ArrowDownRight className="w-5 h-5" />
                              <span>Uitboeken</span>
                           </button>
                        </div>
                     </div>
                  </div>

                  <div className="flex flex-col h-full bg-surface-50 border border-surface-200 rounded-lg overflow-hidden">
                     <div className="px-6 py-2 border-b border-surface-200 flex items-center justify-between bg-white">
                        <h3 className="text-sm font-bold text-surface-900 flex items-center gap-2">
                           <History className="w-4 h-4 text-brand-500" />
                           Mutatiehistorie
                        </h3>
                     </div>
                     
                     <div className="flex-1 overflow-y-auto p-4 space-y-3 min-h-[400px]">
                        {mutations.length > 0 ? (
                          mutations.map(m => (
                            <div key={m.id} className="p-4 bg-white border border-surface-200 rounded-md shadow-sm flex items-center justify-between">
                               <div className="flex items-center gap-3">
                                  <div className={cn(
                                    "w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border",
                                    m.type === 'increase' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-rose-50 text-rose-600 border-rose-100'
                                  )}>
                                     {m.type === 'increase' ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
                                  </div>
                                  <div>
                                     <div className="flex items-center gap-2">
                                        <span className="text-xs font-bold text-surface-900 capitalize">{m.type}</span>
                                        <span className="text-[10px] text-surface-400">{format(new Date(m.timestamp), 'dd/MM/yy HH:mm')}</span>
                                     </div>
                                     <p className="text-[11px] text-surface-500 line-clamp-1">{m.reason || 'Geen reden opgegeven'}</p>
                                  </div>
                               </div>
                               <div className="text-right">
                                  <span className={cn(
                                    "text-sm font-bold",
                                    m.type === 'increase' ? 'text-emerald-600' : 'text-rose-600'
                                  )}>
                                     {m.type === 'increase' ? '+' : '-'}{m.quantity}
                                  </span>
                               </div>
                            </div>
                          ))
                        ) : (
                          <div className="h-full flex flex-col items-center justify-center text-center p-5 opacity-30">
                             <History className="w-10 h-10 mb-4" />
                             <p className="text-xs font-bold uppercase tracking-widest">Geen mutaties</p>
                          </div>
                        )}
                     </div>
                  </div>
                </div>
              </div>

              <div className="px-5 py-3 bg-surface-50 border-t border-surface-200 flex items-center justify-between">
                 <button 
                    onClick={() => { setDeleteConfirm({ isOpen: true, id: selectedItem.id }); setIsDetailsModalOpen(false); }}
                    className="flex items-center gap-2 text-surface-400 hover:text-rose-600 text-xs font-medium transition-colors"
                 >
                    <Trash2 className="w-4 h-4" />
                    <span>Artikel verwijderen</span>
                 </button>
                 <button 
                  onClick={() => setIsDetailsModalOpen(false)}
                  className="btn-primary min-w-[120px]"
                >
                  Sluiten
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      <ConfirmDialog
        isOpen={isCancelConfirmOpen}
        title="Onopgeslagen Wijzigingen"
        message="Je hebt onopgeslagen wijzigingen. Weet je zeker dat je wilt annuleren? Al je werk gaat verloren."
        onConfirm={closeModal}
        onCancel={() => setIsCancelConfirmOpen(false)}
        variant="danger"
        confirmText="Ja, werk weggooien"
        cancelText="Terug"
      />
    </div> {/* --- EINDE SCREEN:PRINT-HIDDEN WRAPPER --- */}

    {/* Print Selection Modal */}
    <AnimatePresence>
      {isPrintModalOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 print:hidden">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsPrintModalOpen(false)}
            className="absolute inset-0 bg-surface-900/40 backdrop-blur-sm print:hidden"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 10 }}
            className="relative bg-white w-full max-w-3xl rounded-lg shadow-xl overflow-hidden flex flex-col max-h-[90vh] print:hidden"
          >
            <div className="px-5 py-6 border-b border-surface-100 flex items-center justify-between shrink-0 bg-white z-10">
              <div className="flex items-center gap-2">
                <Printer className="w-5 h-5 text-brand-500" />
                <h2 className="text-xl font-bold text-surface-900">
                  Besteladvies genereren & printen
                </h2>
              </div>
              <button 
                onClick={() => setIsPrintModalOpen(false)}
                className="p-2 hover:bg-surface-100 rounded-lg text-surface-400 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 bg-surface-50 space-y-4">
              <div className="p-4 bg-blue-50 border border-blue-100 rounded-md text-sm text-blue-800 flex items-start gap-2.5">
                <AlertTriangle className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold">Selecteer artikelen voor het besteladvies</span>
                  <p className="text-xs text-blue-700 mt-1">
                    De lijst toont onderstaande onderdelen waarvan de actuele voorraad lager is dan de minimale voorraad, gegroepeerd per leverancier. 
                    Vink de producten aan die je op het geprinte inkooplijst-advies wilt opnemen.
                  </p>
                </div>
              </div>

              <div className="relative z-20">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
                  <input
                    type="text"
                    value={printSearch}
                    onChange={(e) => setPrintSearch(e.target.value)}
                    placeholder="Zoek en voeg ander artikel toe uit voorraad..."
                    className="w-full pl-9 pr-4 py-2 border border-surface-200 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500 text-sm"
                  />
                </div>
                {printSearchCandidates.length > 0 && (
                  <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-surface-200 rounded-md shadow-lg overflow-hidden py-1 z-30">
                    {printSearchCandidates.map(candidate => (
                      <button
                        key={candidate.id}
                        onClick={() => handleAddManualPrintItem(candidate)}
                        className="w-full text-left px-4 py-2 hover:bg-surface-50 flex items-center justify-between text-sm"
                      >
                        <div className="flex-1 min-w-0 pr-2">
                          <p className="font-medium text-surface-900 truncate">{candidate.name}</p>
                          <p className="text-xs text-surface-500 truncate">
                            {candidate.supplier || 'Geen leverancier'} {candidate.sku ? `• ${candidate.sku}` : ''}
                          </p>
                        </div>
                        <span className="text-xs font-semibold text-brand-600 bg-brand-50 px-2 py-0.5 rounded">Toevoegen</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {lowStockItems.length === 0 ? (
                <div className="text-center py-12 bg-white rounded-lg border border-surface-200">
                  <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
                  <h3 className="font-bold text-surface-900">Voorraad is op peil!</h3>
                  <p className="text-sm text-surface-500 mt-1">Geen artikelen met een lage voorraad. Gebruik de zoekbalk hierboven om handmatig artikelen toe te voegen.</p>
                </div>
              ) : (
                <div className="space-y-6">
                  {lowStockItemsBySupplier.map(({ supplierName, items: supplierItems }) => {
                    const allSelected = supplierItems.every(i => selectedPrintItems.includes(i.id));
                    const someSelected = supplierItems.some(i => selectedPrintItems.includes(i.id)) && !allSelected;

                    return (
                      <div key={supplierName} className="bg-white rounded-lg border border-surface-200 overflow-hidden shadow-sm">
                        {/* Supplier Header */}
                        <div className="p-4 bg-surface-50 border-b border-surface-100 flex items-center justify-between">
                          <label className="flex items-center gap-3 font-semibold text-surface-800 text-sm cursor-pointer select-none">
                            <input 
                              type="checkbox"
                              checked={allSelected}
                              ref={(el) => {
                                if (el) {
                                  el.indeterminate = someSelected;
                                }
                              }}
                              onChange={() => toggleSupplierItems(supplierName, supplierItems)}
                              className="w-4 h-4 rounded text-brand-600 focus:ring-brand-500 border-surface-300"
                            />
                            <span>Leverancier: <span className="font-bold">{supplierName || 'Onbekend'}</span></span>
                          </label>
                          <span className="text-[11px] bg-surface-200 text-surface-700 px-2 py-0.5 rounded font-bold">
                            {supplierItems.length} {supplierItems.length === 1 ? 'artikel' : 'artikelen'} in lijst
                          </span>
                        </div>

                        {/* Items Grid List */}
                        <div className="divide-y divide-surface-100">
                          {supplierItems.map((item) => {
                            const isChecked = selectedPrintItems.includes(item.id);
                            return (
                              <div key={item.id} className="p-3 hover:bg-surface-50/50 flex items-center gap-4 text-xs transition-colors">
                                <input 
                                  type="checkbox"
                                  checked={isChecked}
                                  onChange={() => togglePrintItem(item.id)}
                                  className="w-4 h-4 rounded text-brand-600 focus:ring-brand-500 border-surface-300 shrink-0 cursor-pointer"
                                />
                                <div className="flex-1 min-w-0 pr-4">
                                  <div className="flex items-center gap-2">
                                    <p className="font-bold text-surface-900 truncate">{item.name}</p>
                                    {item.sku && (
                                      <span className="font-mono text-[10px] text-surface-500 bg-surface-100 px-1.5 py-0.5 rounded">
                                        {item.sku}
                                      </span>
                                    )}
                                  </div>
                                  <p className="text-[11px] text-surface-500 mt-0.5 font-medium">Locatie: {item.location || 'Onbekend'}</p>
                                </div>
                                <div className="flex items-center gap-6 shrink-0 font-medium text-right pr-2">
                                  <div>
                                    <p className="text-surface-400 font-normal uppercase text-[9px] tracking-wider">Huidig / Min</p>
                                    <p className="text-surface-800">
                                      <span className="text-red-600 font-bold">{item.stockCount}</span> / <span className="text-surface-500">{item.minStock}</span>
                                    </p>
                                  </div>
                                  <div className="bg-red-50 text-red-700 border border-red-100 rounded px-2.5 py-1 text-center font-bold">
                                    <p className="text-[9px] uppercase tracking-wider font-normal leading-tight text-red-500">Advies</p>
                                    <p className="text-xs leading-none mt-0.5">+{Math.max(1, item.minStock - item.stockCount)}</p>
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="px-5 py-4 border-t border-surface-100 shrink-0 bg-white flex items-center justify-between">
              <span className="text-xs font-semibold text-surface-500">
                {selectedPrintItems.length} van de {lowStockItems.length} geselecteerd voor print
              </span>
              <div className="flex items-center gap-3">
                <button 
                  type="button" 
                  onClick={() => setIsPrintModalOpen(false)}
                  className="btn-ghost"
                >
                  Annuleren
                </button>
                <button 
                  type="button" 
                  disabled={selectedPrintItems.length === 0}
                  onClick={() => {
                    window.print();
                  }}
                  className="btn-primary flex items-center gap-2 disabled:bg-surface-200 disabled:text-surface-400 disabled:cursor-not-allowed"
                >
                  <Printer className="w-4 h-4" />
                  <span>Lijst afdrukken</span>
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>

    {/* PRINT-ONLY BESTELLIJST VAN LAGE VOORRAAD PER LEVERANCIER */}
    <div className="hidden print:block font-sans text-black w-full bg-white leading-relaxed">
      {(() => {
        // Filter suppliers to only those that have selected print items
        const activeSuppliers = lowStockItemsBySupplier
          .map(group => ({
            ...group,
            activeItems: group.items.filter(item => selectedPrintItems.includes(item.id))
          }))
          .filter(group => group.activeItems.length > 0);

        if (activeSuppliers.length === 0) {
          return (
            <div className="p-8 text-center py-10 font-medium">
              Er zijn momenteel geen geselecteerde artikelen die besteld hoeven te worden.
            </div>
          );
        }

        return activeSuppliers.map((group, index) => (
          <div 
            key={group.supplierName} 
            className="p-8 bg-white min-h-[95vh] flex flex-col justify-between"
            style={{ 
              pageBreakAfter: index === activeSuppliers.length - 1 ? 'auto' : 'always',
              breakAfter: index === activeSuppliers.length - 1 ? 'auto' : 'page'
            }}
          >
            <div>
              {/* Header on every single supplier's page */}
              <div className="flex justify-between items-start border-b-2 border-black pb-4 mb-6">
                <div>
                  <h1 className="text-2xl font-black uppercase tracking-tight">Besteladvies Pixia Service Manager</h1>
                  <p className="text-xs text-gray-600 mt-1">Interne bestellijst voor kritieke voorraadartikelen (per leverancier)</p>
                </div>
                <div className="text-right text-xs">
                  <p className="text-sm font-bold">Datum: {format(new Date(), 'dd-MM-yyyy')}</p>
                  <p className="text-gray-500">Gemaakt om {format(new Date(), 'HH:mm')} uur</p>
                </div>
              </div>

              {/* Supplier Info Block */}
              <div className="mb-6 p-4 bg-gray-50 rounded border border-gray-200">
                <p className="text-[10px] uppercase tracking-wider font-bold text-gray-500">Bestelling voorleverancier</p>
                <p className="text-base font-extrabold text-gray-900 mt-0.5">{group.supplierName || 'Onbekende leverancier'}</p>
                <p className="text-xs text-gray-600 mt-1">Deze pagina bevat {group.activeItems.length} geselecteerde artikelen die onder hun gewenste minimumvoorraad zijn gezakt.</p>
              </div>

              {/* Items Table */}
              <table className="w-full border-collapse text-[11px] text-left">
                <thead>
                  <tr className="border-b-2 border-black font-extrabold uppercase tracking-wide text-gray-800">
                    <th className="py-2 pr-2 w-[15%]">SKU / Code</th>
                    <th className="py-2 pr-2 w-[15%]">Merk / Model</th>
                    <th className="py-2 pr-2 w-[30%]">Artikelnaam</th>
                    <th className="py-2 pr-2 w-[15%]">Locatie</th>
                    <th className="py-2 pr-2 text-center w-[8%]">Huidig</th>
                    <th className="py-2 pr-2 text-center w-[8%]">Minimaal</th>
                    <th className="py-2 pr-2 text-center w-[9%] bg-gray-100 font-black">Advies</th>
                    <th className="py-2 pl-4 border-l border-gray-300 w-[20%]">Bestelaantal / Notitie</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {group.activeItems.map((item) => (
                    <tr key={item.id} className="align-middle">
                      <td className="py-2.5 pr-2 font-mono text-[10px] text-gray-700">{item.sku || item.partNumber || '-'}</td>
                      <td className="py-2.5 pr-2 text-gray-800">{item.brand || '-'}</td>
                      <td className="py-2.5 pr-2 font-semibold text-gray-900">{item.name}</td>
                      <td className="py-2.5 pr-2 text-gray-600">{item.location || '-'}</td>
                      <td className="py-2.5 pr-2 text-center text-red-600 font-bold">{item.stockCount} st.</td>
                      <td className="py-2.5 pr-2 text-center text-gray-650">{item.minStock} st.</td>
                      <td className="py-2.5 pr-2 text-center font-extrabold bg-gray-50 border border-gray-100">
                        {Math.max(1, item.minStock - item.stockCount)} st.
                      </td>
                      <td className="py-2.5 pl-4 border-l border-gray-300">
                        <div className="h-5 border border-gray-300 bg-white rounded-sm w-[90%]"></div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Authorisation Footer on each page */}
            <div className="mt-8 pt-4 border-t border-gray-300 flex justify-between items-end text-[10px] text-gray-400">
              <div>
                <p className="mt-0.5">Pagina {index + 1} van {activeSuppliers.length}</p>
              </div>
              <div className="text-right">
                <p className="text-gray-800 mb-4">Handtekening Inkoop ({group.supplierName || 'Leverancier'}):</p>
                <div className="border-b border-gray-400 w-52 inline-block"></div>
              </div>
            </div>
          </div>
        ));
      })()}
    </div>

  </div>
);
};

export default Inventory;
