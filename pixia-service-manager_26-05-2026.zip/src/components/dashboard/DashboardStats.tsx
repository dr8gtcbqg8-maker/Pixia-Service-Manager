import React from 'react';
import { motion } from 'motion/react';
import { Wrench, ClipboardList, Package, Bell } from 'lucide-react';
import { LucideIcon } from 'lucide-react';
import { cn } from '../../lib/utils';
import { Link } from 'react-router-dom';

interface StatProps {
  label: string;
  value: number;
  icon: LucideIcon;
  color: string;
  bg: string;
  trend?: string;
  up?: boolean;
  to?: string;
}

const StatCard: React.FC<StatProps & { index: number }> = ({ label, value, icon: Icon, color, bg, index, to }) => {
  const content = (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      className={cn(
        "bg-surface-900 px-5 py-5 rounded-md border border-white/5 shadow-sm hover:shadow-md hover:border-brand-500/30 transition-all group",
        to && "cursor-pointer"
      )}
    >
      <div className="flex items-center gap-4">
        <div className={cn("p-3 rounded-md shrink-0 transition-transform group-hover:scale-105", bg, color)}>
          <Icon className="w-5 h-5" />
        </div>
        <div>
          <p className="text-[13px] font-medium text-surface-400 mb-0.5 tracking-wide">{label}</p>
          <p className="text-3xl font-display font-bold text-white tracking-tight leading-none">{value}</p>
        </div>
      </div>
    </motion.div>
  );

  if (to) {
    return <Link to={to}>{content}</Link>;
  }

  return content;
};

interface DashboardStatsProps {
  totalInterventions: number;
  closedInterventions: number;
  lowStockCount: number;
  openReminders: number;
}

const DashboardStats: React.FC<DashboardStatsProps> = ({ 
  totalInterventions, 
  closedInterventions, 
  lowStockCount, 
  openReminders 
}) => {
  const stats = [
    { label: 'Open Interventies', value: totalInterventions - closedInterventions, icon: Wrench, color: 'text-brand-400', bg: 'bg-brand-500/10', to: '/interventions' },
    { label: 'Vandaag Afgerond', value: closedInterventions, icon: ClipboardList, color: 'text-accent-400', bg: 'bg-accent-500/10', to: '/interventions' },
    { label: 'Lage Voorraad', value: lowStockCount, icon: Package, color: 'text-rose-400', bg: 'bg-rose-500/10', to: '/inventory' },
    { label: 'Opstaande Taken', value: openReminders, icon: Bell, color: 'text-amber-400', bg: 'bg-amber-500/10', to: '/actions' },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat, i) => (
        <StatCard key={stat.label} {...stat} index={i} />
      ))}
    </div>
  );
};

export default DashboardStats;
