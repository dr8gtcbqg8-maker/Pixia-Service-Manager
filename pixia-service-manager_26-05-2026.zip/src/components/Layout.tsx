import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  Printer, 
  Wrench, 
  Package, 
  Bell, 
  Menu, 
  X,
  LogOut,
  Settings,
  Plus,
  ClipboardList,
  FileText,
  Calendar,
  Briefcase,
  ShieldCheck,
  Clock,
  Headphones
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { BusinessSettings } from '../types';
import { GlobalSearch } from './GlobalSearch';

const navItems = [
  { name: 'Dashboard', icon: LayoutDashboard, path: '/', roles: ['admin', 'planner'] },
  { name: 'Vandaag', icon: Clock, path: '/vandaag', roles: ['technician'] },
  { name: 'Planning', icon: Calendar, path: '/calendar', roles: ['admin', 'planner'] },
  { name: 'Interventies', icon: Wrench, path: '/interventions', roles: ['admin', 'planner'] },
  { name: 'Support Logs', icon: Headphones, path: '/support-logs', roles: ['admin', 'planner', 'technician'] },
  { name: 'Werkbonnen', icon: ClipboardList, path: '/work-orders', roles: ['admin', 'planner', 'technician'] },
  { name: 'Klanten', icon: Users, path: '/customers', roles: ['admin', 'planner', 'technician'] },
  { name: 'Machines', icon: Printer, path: '/machines', roles: ['admin', 'planner', 'technician'] },
  { name: 'Voorraad', icon: Package, path: '/inventory', roles: ['admin', 'planner', 'technician'] },
  { name: 'Acties', icon: Bell, path: '/actions', roles: ['admin', 'planner', 'technician'] },
  { name: 'Audit Logs', icon: ShieldCheck, path: '/audit-logs', roles: ['admin'] },
  { name: 'Instellingen', icon: Settings, path: '/settings', roles: ['admin', 'planner'] },
];

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [businessSettings, setBusinessSettings] = useState<BusinessSettings | null>(null);
  const location = useLocation();
  const { profile, logout } = useAuth();

  useEffect(() => {
    const fetchBusiness = async () => {
      try {
        const docSnap = await getDoc(doc(db, 'settings', 'business'));
        if (docSnap.exists()) {
          setBusinessSettings(docSnap.data() as BusinessSettings);
        }
      } catch (err) {
        console.error('Error fetching business settings for layout:', err);
      }
    };
    fetchBusiness();
  }, []);

  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);

  const filteredNavItems = navItems.filter(item => {
    if (!item.roles) return true;
    const role = profile?.role || 'technician';
    return item.roles.includes(role);
  });

  return (
    <div className="min-h-screen flex bg-surface-50">
      {/* Mobile Backdrop */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={toggleSidebar}
            className="fixed inset-0 bg-surface-900/40 z-40 lg:hidden backdrop-blur-sm"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside
        className={cn(
          "print:hidden fixed inset-y-0 left-0 z-50 w-64 bg-surface-900 text-white flex flex-col transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0 shadow-2xl lg:shadow-none",
          isSidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="h-full flex flex-col">
          <div className="p-5 border-b border-white/5 flex items-center justify-between">
            <Link to="/" className="flex items-center space-x-3 group">
              <div className="shrink-0">
                {businessSettings?.iconUrl || businessSettings?.logoUrl ? (
                  <img src={businessSettings?.iconUrl || businessSettings?.logoUrl} alt="Company Logo" className="w-9 h-9 object-contain" />
                ) : (
                  <div className="w-9 h-9 bg-brand-500 rounded-md flex items-center justify-center group-hover:bg-brand-400 transition-colors duration-200">
                    <Printer className="text-white w-5 h-5" />
                  </div>
                )}
              </div>
              <div className="flex flex-col min-w-0">
                <span className="font-bold text-base tracking-tight text-white truncate leading-none">
                  {businessSettings?.name || 'Pixia'}
                </span>
                <span className="text-[10px] font-medium text-surface-400 uppercase tracking-widest mt-1">
                  Serviceplatform
                </span>
              </div>
            </Link>
            <button 
              onClick={toggleSidebar} 
              className="lg:hidden p-2 text-surface-400 hover:text-white transition-colors"
              aria-label="Sluit menu"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto custom-scrollbar">
            {filteredNavItems.map((item) => {
              const isActive = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setIsSidebarOpen(false)}
                  className={cn(
                    "flex items-center space-x-3 px-3 py-2 rounded-md transition-all duration-200 text-sm font-medium",
                    isActive 
                      ? "bg-brand-500/10 text-brand-400" 
                      : "text-surface-400 hover:bg-surface-800 hover:text-surface-100"
                  )}
                >
                  <div className={cn("w-1 h-1 rounded-full", isActive ? "bg-brand-400" : "bg-transparent")}></div>
                  <item.icon className={cn(
                    "w-4 h-4 transition-colors",
                    isActive ? "text-brand-400" : "text-surface-400 group-hover:text-surface-300"
                  )} />
                  <span>{item.name}</span>
                </Link>
              );
            })}
          </nav>

          {/* User Section */}
          <div className="p-4 border-t border-white/5">
            <div className="flex items-center space-x-3 px-2 mb-4">
              <div className="w-9 h-9 bg-surface-800 rounded-md flex items-center justify-center text-sm font-bold text-brand-400 border border-white/5 shadow-inner">
                {profile?.displayName?.charAt(0) || 'U'}
              </div>
              <div className="flex flex-col min-w-0">
                <span className="text-sm font-semibold text-white truncate">
                  {profile?.displayName || 'Gebruiker'}
                </span>
                <span className="text-[11px] text-surface-400 font-medium capitalize mt-0.5">
                  {profile?.role === 'admin' ? 'Admin' : profile?.role === 'customer' ? 'Klant' : 'Technicus'}
                </span>
              </div>
            </div>
            <button 
              onClick={logout}
              className="w-full flex items-center space-x-3 px-3 py-2 text-surface-400 hover:bg-red-500/10 hover:text-red-400 rounded-md transition-all text-sm font-medium"
            >
              <LogOut className="w-4 h-4" />
              <span>Uitloggen</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden print:h-auto print:overflow-visible print:bg-white print:block">
        <header className="h-16 bg-white border-b border-surface-200 flex items-center px-4 lg:px-5 shrink-0 z-30 lg:hidden print:hidden">
          <button 
            onClick={toggleSidebar} 
            className="p-2 text-surface-500 hover:bg-surface-50 rounded-lg transition-colors"
            aria-label="Open menu"
          >
            <Menu className="w-6 h-6" />
          </button>
        </header>

        <main className="flex-1 overflow-y-auto bg-surface-50 print:bg-white print:overflow-visible print:block print:p-0">
          <div className="p-4 lg:p-5 max-w-[1600px] mx-auto print:p-0 print:max-w-full">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};
