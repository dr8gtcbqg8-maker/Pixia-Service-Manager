const fs = require('fs');

function fixBadge(file) {
  let content = fs.readFileSync(file, 'utf8');
  content = content.replace(
    /className=\{\`text-\[8px\] font-black uppercase tracking-widest px-2 py-0\.5 rounded-lg border /g,
    'className={`shrink-0 text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded-lg border '
  );
  content = content.replace(
    /className=\"text-\[8px\] font-black uppercase tracking-widest px-2 py-0\.5 rounded-lg border /g,
    'className="shrink-0 text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded-lg border '
  );
  fs.writeFileSync(file, content);
}

fixBadge('src/components/machines/MachineTable.tsx');
fixBadge('src/components/customers/CustomerTable.tsx');
fixBadge('src/components/inventory/InventoryTable.tsx');
fixBadge('src/components/interventions/InterventionTable.tsx');
fixBadge('src/components/work-orders/WorkOrderTable.tsx');
console.log('Done fixing badges');
