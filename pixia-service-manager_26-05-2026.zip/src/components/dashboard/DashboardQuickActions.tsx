import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Globe, Mail, ChevronRight, UserPlus, Printer, 
  Wrench, ClipboardList, Bell, Package 
} from 'lucide-react';
import { cn } from '../../lib/utils';
import { OutlookConnection, EmailLog } from '../../types';

interface DashboardQuickActionsProps {
  outlookConnection: OutlookConnection | null;
  emailLogs: EmailLog[];
}

const DashboardQuickActions: React.FC<DashboardQuickActionsProps> = ({ outlookConnection, emailLogs }) => {
  const navigate = useNavigate();

  return (
    <div className="space-y-4">
      {/* Automatisering & Koppelingen */}
      <section className="card p-5">
        <h3 className="text-[13px] font-bold text-surface-900 uppercase tracking-wide mb-5 flex items-center gap-2">
          Automatisering & Koppelingen
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
           <div 
             onClick={() => navigate('/settings?tab=outlook')}
             className="p-4 bg-surface-900 border border-white/5 rounded-md text-white flex items-center justify-between cursor-pointer group hover:border-brand-500/50 transition-all shadow-sm"
           >
              <div className="flex items-center gap-4">
                 <div className={cn(
                   "w-10 h-10 rounded-md flex items-center justify-center transition-all",
                   outlookConnection ? "bg-brand-500 shadow-md shadow-brand-500/20" : "bg-white/5"
                 )}>
                    <Globe className={cn("w-5 h-5", outlookConnection ? "text-white" : "text-surface-500")} />
                 </div>
                 <div className="text-left">
                    <p className="text-[11px] font-semibold uppercase text-surface-400 tracking-wide mb-0.5">Outlook Status</p>
                    <p className="text-base font-display font-bold">{outlookConnection ? 'Verbonden' : 'Niet Gekoppeld'}</p>
                 </div>
              </div>
              <ChevronRight className="w-5 h-5 text-surface-500 group-hover:text-brand-400 transition-colors" />
           </div>

           <div 
             onClick={() => navigate('/settings?tab=email')}
             className="p-4 bg-surface-50 border border-surface-200 rounded-md flex items-center justify-between cursor-pointer group hover:border-brand-300 hover:shadow-sm transition-all"
           >
              <div className="flex items-center gap-4">
                 <div className="w-10 h-10 bg-white border border-surface-200 shadow-sm rounded-md flex items-center justify-center">
                    <Mail className="w-5 h-5 text-brand-500" />
                 </div>
                 <div className="text-left">
                    <p className="text-[11px] font-semibold uppercase text-surface-500 tracking-wide mb-0.5">E-mail Activiteit</p>
                    <p className="text-base font-display font-bold text-surface-900">
                      {emailLogs.filter(l => l.status === 'sent').length} verzonden
                      {emailLogs.filter(l => l.status === 'failed').length > 0 && 
                        <span className="text-red-500 ml-2">({emailLogs.filter(l => l.status === 'failed').length} fouten)</span>
                      }
                    </p>
                 </div>
              </div>
              <ChevronRight className="w-5 h-5 text-surface-400 group-hover:text-brand-500 transition-colors" />
           </div>
        </div>
      </section>
    </div>
  );
};

export default DashboardQuickActions;
