import React, { useState, useEffect } from 'react';
import { collection, addDoc, updateDoc, doc, deleteDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Appointment, Customer, Machine, Reminder, Intervention, UserProfile } from '../types';
import { 
  X, Calendar, Clock, MapPin, AlignLeft, 
  User, Printer, AlertCircle, CheckCircle2,
  Trash2, Mail, Info, Sparkles, Wand2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { handleFirestoreError, OperationType } from '../lib/utils';
import { schedulingService } from '../services/schedulingService';
import { notificationService } from '../services/notificationService';
import { logAction } from '../lib/audit';
import ConfirmDialog from './ConfirmDialog';

interface AppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  appointment: Appointment | null;
  initialData: {
    date?: string;
    reminderId?: string;
    interventionId?: string;
    customerId?: string;
    machineId?: string;
  };
  onSave: () => void;
  customers: Customer[];
  machines: Machine[];
  reminders: Reminder[];
  interventions: Intervention[];
}

const AppointmentModal: React.FC<AppointmentModalProps> = ({
  isOpen, onClose, appointment, initialData, onSave,
  customers, machines, reminders, interventions
}) => {
  const [formData, setFormData] = useState<Partial<Appointment>>({
    title: '',
    customerId: '',
    machineId: '',
    date: '',
    endDate: '',
    startTime: '09:00',
    endTime: '10:00',
    type: 'general',
    priority: 'normal',
    location: '',
    description: '',
    internalNotes: '',
    status: 'planned',
    reminderId: '',
    interventionId: '',
    technicianId: '',
    technicianName: ''
  });

  const [isDirty, setIsDirty] = useState(false);

  const updateFormData = (updates: Partial<Appointment>) => {
    setIsDirty(true);
    setFormData(prev => ({ ...prev, ...updates }));
  };

  const handleClose = () => {
    if (isDirty) {
      setIsCancelConfirmOpen(true);
    } else {
      onClose();
    }
  };

  const confirmCancel = () => {
    setIsCancelConfirmOpen(false);
    setIsDirty(false);
    onClose();
  };

  const [technicians, setTechnicians] = useState<UserProfile[]>([]);
  const [suggestions, setSuggestions] = useState<{ startTime: string; endTime: string; technicianId: string }[]>([]);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [isInterventionDeleteConfirmOpen, setIsInterventionDeleteConfirmOpen] = useState(false);
  const [isCancelConfirmOpen, setIsCancelConfirmOpen] = useState(false);

  useEffect(() => {
    const fetchTechs = async () => {
      try {
        const techs = await schedulingService.getTechnicians();
        setTechnicians(techs);
      } catch (err) {
        console.warn('Fout bij ophalen technici:', err);
      }
    };
    if (isOpen) fetchTechs();
  }, [isOpen]);

  useEffect(() => {
    if (appointment) {
      setFormData(appointment);
    } else {
      setFormData({
        title: initialData.interventionId ? `Interventie: ${customers.find(c => c.id === initialData.customerId)?.name || 'Nieuw'}` : '',
        customerId: initialData.customerId || '',
        machineId: initialData.machineId || '',
        date: initialData.date || new Date().toISOString().split('T')[0],
        endDate: '',
        startTime: '09:00',
        endTime: '10:00',
        type: 'general',
        priority: 'normal',
        location: '',
        description: '',
        internalNotes: '',
        status: 'planned',
        reminderId: initialData.reminderId || '',
        interventionId: initialData.interventionId || '',
        technicianId: '',
        technicianName: ''
      });
    }
    setIsDirty(false);
  }, [appointment, initialData, isOpen, customers]);

  const handleAutoPlan = async () => {
    if (!formData.date) {
      alert('Kies eerst een datum');
      return;
    }
    setLoadingSuggestions(true);
    try {
      const res = await schedulingService.suggestSlots({
        date: formData.date,
        durationHours: 1
      });
      setSuggestions(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingSuggestions(false);
    }
  };

  const applySuggestion = (s: { startTime: string; endTime: string; technicianId: string }) => {
    const tech = technicians.find(t => t.uid === s.technicianId);
    setFormData({
      ...formData,
      startTime: s.startTime,
      endTime: s.endTime,
      technicianId: s.technicianId,
      technicianName: tech?.displayName || tech?.email || ''
    });
    setSuggestions([]);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = {
        ...formData,
        updatedAt: new Date().toISOString()
      };

      let appointmentId = appointment?.id || '';
      let finalInterventionId = formData.interventionId || '';

      // 1. Als er geen interventie is maar wel een type dat er een vereist, maak er een aan
      if (!finalInterventionId && (formData.type === 'maintenance' || formData.type === 'fault' || formData.type === 'installation')) {
        const intRef = await addDoc(collection(db, 'interventions'), {
          customerId: formData.customerId,
          machineId: formData.machineId,
          date: formData.date,
          endDate: formData.endDate || '',
          type: formData.type === 'maintenance' ? 'onderhoud' : formData.type === 'fault' ? 'storing' : 'installatie',
          status: 'planned',
          problemDescription: formData.description || formData.title,
          technicianId: formData.technicianId,
          technicianName: formData.technicianName,
          interventionNumber: `INT-${Math.floor(1000 + Math.random() * 9000)}`,
          createdAt: new Date().toISOString()
        });
        finalInterventionId = intRef.id;
        data.interventionId = finalInterventionId;
      }

      // 2. Synchroniseer technicus & datum naar bestaande interventie
      if (finalInterventionId) {
        await updateDoc(doc(db, 'interventions', finalInterventionId), {
          date: formData.date,
          endDate: formData.endDate || '',
          technicianId: formData.technicianId,
          technicianName: formData.technicianName,
          status: 'planned'
        });
      }

      // 3. Opslaan afspraak
      if (appointment) {
        await updateDoc(doc(db, 'appointments', appointment.id), data);
      } else {
        const docRef = await addDoc(collection(db, 'appointments'), {
          ...data,
          createdAt: new Date().toISOString()
        });
        appointmentId = docRef.id;

        // Trigger notification & email
        const customer = customers.find(c => c.id === formData.customerId);
        if (customer) {
          await notificationService.handleNewAppointment({ id: appointmentId, ...data } as Appointment, customer);
        }
      }
      onSave();
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'appointments');
    }
  };

  const handleDelete = async () => {
    if (!appointment) return;
    
    try {
      if (appointment.interventionId) {
        setIsInterventionDeleteConfirmOpen(true);
      } else {
        setIsDeleteConfirmOpen(true);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const confirmDelete = async (deleteIntervention: boolean = false) => {
    if (!appointment) return;
    try {
      if (deleteIntervention && appointment.interventionId) {
        await deleteDoc(doc(db, 'interventions', appointment.interventionId));
        await logAction('Interventie verwijderd via afspraak', 'intervention', appointment.interventionId, `Gekoppeld aan afspraak ${appointment.id}`, 'calendar');
      }

      await deleteDoc(doc(db, 'appointments', appointment.id));
      await logAction('Afspraak verwijderd', 'appointment', appointment.id, `Titel: ${appointment.title}`, 'calendar');
      
      setIsDeleteConfirmOpen(false);
      setIsInterventionDeleteConfirmOpen(false);
      onSave();
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `appointments/${appointment.id}`);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
          key="appointment-modal-wrapper"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-4"
        >
          <motion.div
            key="backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-surface-900/60 backdrop-blur-md"
          />
          <motion.div
            key="modal"
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative bg-white w-full max-w-2xl max-h-[90vh] rounded-lg shadow-2xl overflow-y-auto"
          >
          <div className="p-5 md:p-5">
            <div className="flex items-center justify-between mb-10">
              <div className="space-y-1">
                <h2 className="text-2xl font-black text-surface-900 tracking-tight italic">
                  {appointment ? 'Afspraak Aanpassen' : 'Nieuwe Afspraak'}
                </h2>
                <p className="text-surface-400 text-[10px] font-black uppercase tracking-widest">Inplannen in de centrale agenda</p>
              </div>
              <div className="flex items-center gap-2">
                {appointment && (
                  <button onClick={handleDelete} className="p-3 text-red-400 hover:bg-red-50 rounded-md transition-all">
                    <Trash2 className="w-5 h-5" />
                  </button>
                )}
                <button onClick={handleClose} className="p-3 hover:bg-surface-50 rounded-md text-surface-400">
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Basic Info */}
                <div className="md:col-span-2 space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-surface-400 ml-1">Onderwerp / Titel</label>
                  <input 
                    type="text"
                    required
                    placeholder="Bijv. Jaarlijks onderhoud bij Klant X"
                    className="w-full px-6 py-2 bg-surface-50 border border-surface-200 rounded-md font-bold text-sm focus:ring-4 focus:ring-blue-100 outline-none transition-all"
                    value={formData.title ?? ''}
                    onChange={(e) => updateFormData({ title: e.target.value })}
                  />
                </div>
 
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-surface-400 ml-1">Type Activiteit</label>
                  <select 
                    required
                    className="w-full px-6 py-2 bg-surface-50 border border-surface-200 rounded-md font-bold text-sm focus:ring-4 focus:ring-blue-100 outline-none transition-all"
                    value={formData.type ?? 'general'}
                    onChange={(e) => updateFormData({ type: e.target.value as any })}
                  >
                    <option value="general">Algemene Afspraak</option>
                    <option value="maintenance">Periodiek Onderhoud</option>
                    <option value="fault">Storing / Reparatie</option>
                    <option value="installation">Installatie</option>
                    <option value="follow-up">Follow-up / Controle</option>
                    <option value="warranty">Garantiebepaling</option>
                  </select>
                </div>
 
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-surface-400 ml-1">Prioriteit</label>
                  <select 
                    required
                    className="w-full px-6 py-2 bg-surface-50 border border-surface-200 rounded-md font-bold text-sm focus:ring-4 focus:ring-blue-100 outline-none transition-all"
                    value={formData.priority ?? 'normal'}
                    onChange={(e) => updateFormData({ priority: e.target.value as any })}
                  >
                    <option value="low">Laag</option>
                    <option value="normal">Normaal</option>
                    <option value="high">Hoog</option>
                    <option value="urgent">Urgent</option>
                  </select>
                </div>
 
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-surface-400 ml-1">Klant</label>
                  <select 
                    required
                    className="w-full px-6 py-2 bg-surface-50 border border-surface-200 rounded-md font-bold text-sm focus:ring-4 focus:ring-blue-100 outline-none transition-all"
                    value={formData.customerId ?? ''}
                    onChange={(e) => updateFormData({ customerId: e.target.value, machineId: '' })}
                  >
                    <option value="">Selecteer klant...</option>
                    {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
 
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-surface-400 ml-1">Machine (optioneel)</label>
                  <select 
                    className="w-full px-6 py-2 bg-surface-50 border border-surface-200 rounded-md font-bold text-sm focus:ring-4 focus:ring-blue-100 outline-none transition-all"
                    value={formData.machineId ?? ''}
                    onChange={(e) => updateFormData({ machineId: e.target.value })}
                  >
                    <option value="">Geen specifieke machine</option>
                    {machines.filter(m => m.customerId === formData.customerId).map(m => (
                      <option key={m.id} value={m.id}>{m.brand} {m.model} ({m.serialNumber})</option>
                    ))}
                  </select>
                </div>
 
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-surface-400 ml-1">Begindatum</label>
                    <div className="relative">
                      <Calendar className="absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
                      <input 
                        type="date"
                        required
                        className="w-full pl-14 pr-6 py-2 bg-surface-50 border border-surface-200 rounded-md font-bold text-sm focus:ring-4 focus:ring-blue-100 outline-none transition-all"
                        value={formData.date ?? ''}
                        onChange={(e) => updateFormData({ date: e.target.value })}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-surface-400 ml-1">Einddatum</label>
                    <div className="relative">
                      <Calendar className="absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
                      <input 
                        type="date"
                        className="w-full pl-14 pr-6 py-2 bg-surface-50 border border-surface-200 rounded-md font-bold text-sm focus:ring-4 focus:ring-blue-100 outline-none transition-all"
                        value={formData.endDate ?? ''}
                        min={formData.date}
                        onChange={(e) => updateFormData({ endDate: e.target.value })}
                      />
                    </div>
                  </div>
                </div>
 
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-surface-400 ml-1">Starttijd</label>
                    <div className="relative">
                      <Clock className="absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
                      <input 
                        type="time"
                        required
                        className="w-full pl-14 pr-4 py-2 bg-surface-50 border border-surface-200 rounded-md font-bold text-sm focus:ring-4 focus:ring-blue-100 outline-none transition-all"
                        value={formData.startTime ?? '09:00'}
                        onChange={(e) => updateFormData({ startTime: e.target.value })}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-surface-400 ml-1">Eindtijd</label>
                    <div className="relative">
                      <Clock className="absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
                      <input 
                        type="time"
                        required
                        className="w-full pl-14 pr-4 py-2 bg-surface-50 border border-surface-200 rounded-md font-bold text-sm focus:ring-4 focus:ring-blue-100 outline-none transition-all"
                        value={formData.endTime ?? '10:00'}
                        onChange={(e) => updateFormData({ endTime: e.target.value })}
                      />
                    </div>
                  </div>
                </div>
 
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-surface-400 ml-1">Toegewezen Technicus</label>
                  <select 
                    className="w-full px-6 py-2 bg-surface-50 border border-surface-200 rounded-md font-bold text-sm focus:ring-4 focus:ring-blue-100 outline-none transition-all"
                    value={formData.technicianId ?? ''}
                    onChange={(e) => {
                      const tech = technicians.find(t => t.uid === e.target.value);
                      updateFormData({technicianId: e.target.value,
                        technicianName: tech?.displayName || tech?.email || ''
                      });
                    }}
                  >
                    <option value="">Nog niet toegewezen</option>
                    {technicians.map(t => (
                      <option key={t.uid} value={t.uid}>{t.displayName || t.email}</option>
                    ))}
                  </select>
                </div>
 
                <div className="space-y-2 md:col-span-2">
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-surface-400 ml-1">Slimme Suggesties</label>
                    <button 
                      type="button"
                      onClick={handleAutoPlan}
                      disabled={loadingSuggestions}
                      className="flex items-center gap-2 text-[9px] font-black uppercase tracking-widest text-brand-500 hover:text-blue-700 disabled:opacity-50"
                    >
                      {loadingSuggestions ? 'Zoeken...' : (
                        <><Sparkles className="w-3.5 h-3.5" /> Vind vrij slot</>
                      )}
                    </button>
                  </div>
                  
                  {suggestions.length > 0 && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="grid grid-cols-2 sm:grid-cols-3 gap-2 p-4 bg-brand-50/50 rounded-lg border border-brand-200"
                    >
                      {suggestions.map((s, idx) => {
                        const techName = technicians.find(t => t.uid === s.technicianId)?.displayName?.split(' ')[0] || 'Tech';
                        return (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => applySuggestion(s)}
                      className="bg-white p-3 rounded-md border border-brand-200 text-[10px] font-black text-brand-500 hover:bg-brand-500 hover:text-white transition-all text-center flex flex-col items-center"
                          >
                            <span className="opacity-60">{techName}</span>
                            <span>{s.startTime} - {s.endTime}</span>
                          </button>
                        );
                      })}
                      <button 
                        type="button"
                        onClick={() => setSuggestions([])}
                        className="col-span-full text-center py-2 text-[8px] font-black uppercase text-surface-400 hover:text-surface-600"
                      >
                        Annuleren
                      </button>
                    </motion.div>
                  )}
                </div>
 
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-surface-400 ml-1">Status</label>
                    <select 
                      required
                      className="w-full px-6 py-2 bg-surface-50 border border-surface-200 rounded-md font-bold text-sm focus:ring-4 focus:ring-blue-100 outline-none transition-all"
                      value={formData.status ?? 'planned'}
                      onChange={(e) => updateFormData({ status: e.target.value as any })}
                    >
                      <option value="planned">Ingepland</option>
                      <option value="confirmed">Bevestigd door klant</option>
                      <option value="on-route">Onderweg</option>
                      <option value="in-progress">In uitvoering / Bezig</option>
                      <option value="waiting-parts">Wacht op onderdelen</option>
                      <option value="waiting">Wachtend op klant</option>
                      <option value="completed">Afgerond</option>
                      <option value="cancelled">Geannuleerd</option>
                    </select>
                </div>
 
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-surface-400 ml-1">Locatie</label>
                  <div className="relative">
                    <MapPin className="absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
                    <input 
                      type="text"
                      placeholder="Adres of werkplaats"
                      className="w-full pl-14 pr-6 py-2 bg-surface-50 border border-surface-200 rounded-md font-bold text-sm focus:ring-4 focus:ring-blue-100 outline-none transition-all"
                      value={formData.location ?? ''}
                      onChange={(e) => updateFormData({ location: e.target.value })}
                    />
                  </div>
                </div>
 
                <div className="md:col-span-2 space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-surface-400 ml-1">Omschrijving / Details</label>
                  <textarea 
                    rows={3}
                    placeholder="Bijkomende details over de afspraak..."
                    className="w-full px-6 py-2 bg-surface-50 border border-surface-200 rounded-md font-bold text-sm focus:ring-4 focus:ring-blue-100 outline-none transition-all resize-none"
                    value={formData.description ?? ''}
                    onChange={(e) => updateFormData({ description: e.target.value })}
                  />
                </div>
 
                <div className="md:col-span-2 space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-surface-400 ml-1">Interne Notities (niet zichtbaar voor klant)</label>
                  <textarea 
                    rows={2}
                    placeholder="Interne instructies, pincodes, etc..."
                    className="w-full px-6 py-2 bg-amber-50/50 border border-amber-100 rounded-md font-bold text-sm focus:ring-4 focus:ring-amber-100 outline-none transition-all resize-none italic"
                    value={formData.internalNotes ?? ''}
                    onChange={(e) => updateFormData({ internalNotes: e.target.value })}
                  />
                </div>
              </div>

              <div className="flex items-center gap-3 pt-6 animate-in slide-in-from-bottom-2 duration-700">
                <button 
                  type="button" 
                  onClick={handleClose}
                  className="flex-1 py-3 text-surface-400 font-black text-[10px] uppercase tracking-[0.3em] hover:bg-surface-50 rounded-md transition-all"
                >
                  Annuleren
                </button>
                <button 
                  type="submit" 
                  className="flex-[2] py-3 bg-surface-900 text-white font-black text-[10px] uppercase tracking-[0.4em] rounded-md hover:bg-brand-500 transition-all shadow-2xl shadow-surface-200 active:scale-95 flex items-center justify-center gap-3"
                >
                  <Calendar className="w-5 h-5" />
                  {appointment ? 'Afspraak Bijwerken' : 'Afspraak Bevestigen'}
                </button>
              </div>
            </form>
          </div>
      </motion.div>

      <ConfirmDialog
        isOpen={isDeleteConfirmOpen}
        title="Afspraak verwijderen"
        message="Weet u zeker dat u deze afspraak wilt verwijderen?"
        confirmText="Verwijderen"
        onConfirm={() => confirmDelete(false)}
        onCancel={() => setIsDeleteConfirmOpen(false)}
      />

      <ConfirmDialog
        isOpen={isInterventionDeleteConfirmOpen}
        title="Gekoppelde interventie"
        message="Er is een gekoppelde interventie. Wilt u deze ook verwijderen?"
        variant="warning"
        confirmText="Verwijder Beide"
        cancelText="Alleen Afspraak"
        onConfirm={() => confirmDelete(true)}
        onCancel={() => confirmDelete(false)} /* Als ze annuleren in de interventie-vraag, verwijderen we alleen de afspraak? Of helemaal niks? Meestal is annuleren = stop actie. Maar hier wil ik misschien "alleen afspraak" knop. */
      />

      <ConfirmDialog
        isOpen={isCancelConfirmOpen}
        title="Onopgeslagen Wijzigingen"
        message="Je hebt onopgeslagen wijzigingen. Weet je zeker dat je wilt annuleren? Al je werk gaat verloren."
        variant="danger"
        confirmText="Ja, werk weggooien"
        cancelText="Terug"
        onConfirm={confirmCancel}
        onCancel={() => setIsCancelConfirmOpen(false)}
      />
    </motion.div>
  )}
</AnimatePresence>
  );
};

export default AppointmentModal;
