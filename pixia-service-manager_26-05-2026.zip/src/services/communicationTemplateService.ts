import { 
  collection, doc, getDocs, setDoc, updateDoc, 
  query, where, writeBatch, getDoc, addDoc, deleteDoc
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { CommunicationTemplate, CommunicationTemplateType } from '../types';
import { PIXIA_DEFAULT_TEMPLATES, SUPPORTED_PLACEHOLDERS } from '../constants/emailTemplates';
import { COLLECTIONS } from '../constants/collections';

export const communicationTemplateService = {
  /**
   * Syncs the default system templates with Firestore.
   */
  async syncDefaultTemplates() {
    const batch = writeBatch(db);
    const now = new Date().toISOString();

    for (const def of PIXIA_DEFAULT_TEMPLATES) {
      const docRef = doc(db, COLLECTIONS.COMMUNICATION_TEMPLATES, def.type);
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        batch.set(docRef, {
          ...def,
          id: def.type,
          createdAt: now,
          updatedAt: now
        });
      } else {
        batch.update(docRef, {
          name: def.name,
          description: def.description,
          category: def.category,
          placeholders: def.placeholders,
          isSystemTemplate: true,
          updatedAt: now
        });
      }
    }

    await batch.commit();
  },

  /**
   * Finds potential duplicate templates.
   */
  async findPotentialDuplicates(templateData: any, excludeId?: string): Promise<CommunicationTemplate[]> {
    try {
      const snap = await getDocs(collection(db, COLLECTIONS.COMMUNICATION_TEMPLATES));
      const templates = snap.docs.map(d => ({ id: d.id, ...d.data() } as CommunicationTemplate));
      
      const normalizedName = (templateData.name || '').toLowerCase().trim();
      const normalizedSubject = (templateData.subject || '').toLowerCase().trim();
      
      return templates.filter(t => {
        if (excludeId && t.id === excludeId) return false;
        if (t.archived) return false;
        
        const isSameType = t.type === templateData.type;
        const isSameName = (t.name || '').toLowerCase().trim() === normalizedName;
        const isSameSubject = (t.subject || '').toLowerCase().trim() === normalizedSubject;
        
        return (isSameType && isSameName) || isSameSubject;
      });
    } catch (err) {
      console.error('Error finding duplicate templates:', err);
      return [];
    }
  },

  /**
   * Identifies and cleans up duplicate templates.
   */
  async resolveDuplicates() {
    const snap = await getDocs(collection(db, COLLECTIONS.COMMUNICATION_TEMPLATES));
    const templates = snap.docs.map(d => ({ id: d.id, ...d.data() } as CommunicationTemplate));
    
    const byType: Record<string, CommunicationTemplate[]> = {};
    templates.forEach(t => {
      if (!byType[t.type]) byType[t.type] = [];
      byType[t.type].push(t);
    });

    const batch = writeBatch(db);
    let resolvedCount = 0;

    for (const [type, group] of Object.entries(byType)) {
      if (group.length > 1) {
        const primary = group.find(t => t.id === type) || 
                        group.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))[0];
        
        for (const item of group) {
          if (item.id !== primary.id) {
            batch.update(doc(db, COLLECTIONS.COMMUNICATION_TEMPLATES, item.id), {
              active: false,
              archived: true,
              name: `${item.name} (DUPLICAAT)`,
              updatedAt: new Date().toISOString()
            });
            resolvedCount++;
          }
        }
      }
    }

    if (resolvedCount > 0) {
      await batch.commit();
    }
    
    return resolvedCount;
  },

  /**
   * CRUD Operations
   */
  async createTemplate(template: Omit<CommunicationTemplate, 'id' | 'createdAt' | 'updatedAt'>) {
    const now = new Date().toISOString();
    const docRef = await addDoc(collection(db, COLLECTIONS.COMMUNICATION_TEMPLATES), {
      ...template,
      createdAt: now,
      updatedAt: now
    });
    return docRef.id;
  },

  async updateTemplate(id: string, updates: Partial<CommunicationTemplate>) {
    const docRef = doc(db, COLLECTIONS.COMMUNICATION_TEMPLATES, id);
    await updateDoc(docRef, {
      ...updates,
      updatedAt: new Date().toISOString()
    });
  },

  async deleteTemplate(id: string) {
    await deleteDoc(doc(db, COLLECTIONS.COMMUNICATION_TEMPLATES, id));
  },

  async duplicateTemplate(template: CommunicationTemplate) {
    const { id, createdAt, updatedAt, ...rest } = template;
    return await this.createTemplate({
      ...rest,
      name: `${template.name} (Kopie)`,
      isSystemTemplate: false,
      active: false
    });
  },

  /**
   * Resets a specific template back to its default state.
   */
  async resetToDefault(type: CommunicationTemplateType | string) {
    const def = PIXIA_DEFAULT_TEMPLATES.find(t => t.type === type);
    if (!def) throw new Error(`Geen standaardtemplate gevonden voor type: ${type}`);

    const docRef = doc(db, COLLECTIONS.COMMUNICATION_TEMPLATES, type);
    await setDoc(docRef, {
      ...def,
      id: type,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  },

  /**
   * Generates a preview string.
   */
  preview(content: string): string {
    let result = content;
    SUPPORTED_PLACEHOLDERS.forEach(placeholder => {
      const regex = new RegExp(`{{${placeholder.key}}}`, 'g');
      result = result.replace(regex, placeholder.exampleValue);
    });
    return result;
  },

  /**
   * Validates placeholders.
   */
  validatePlaceholders(content: string): { unknownPlaceholders: string[] } {
    const regex = /{{(.*?)}}/g;
    const matches = content.matchAll(regex);
    const unknown: string[] = [];
    
    for (const match of matches) {
      const key = match[1];
      if (!SUPPORTED_PLACEHOLDERS.find(p => p.key === key)) {
        unknown.push(key);
      }
    }
    
    return { unknownPlaceholders: [...new Set(unknown)] };
  }
};
