import React from 'react';
import { Search, Filter } from 'lucide-react';

interface InventoryFiltersProps {
  search: string;
  setSearch: (s: string) => void;
  filterCategory: string;
  setFilterCategory: (c: string) => void;
  categories: string[];
  filterSupplier: string;
  setFilterSupplier: (s: string) => void;
  suppliers: string[];
  filterStatus: string;
  setFilterStatus: (s: string) => void;
  filterLowStock: boolean;
  setFilterLowStock: (l: boolean) => void;
}

const InventoryFilters: React.FC<InventoryFiltersProps> = ({
  search, setSearch,
  filterCategory, setFilterCategory, categories,
  filterSupplier, setFilterSupplier, suppliers,
  filterStatus, setFilterStatus,
  filterLowStock, setFilterLowStock
}) => {
  return (
    <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        <div className="md:col-span-4 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Zoek op naam of artikelnummer..." 
            className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div className="md:col-span-2">
          <select 
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20"
          >
            <option value="all">Alle Categorieën</option>
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>

        <div className="md:col-span-2">
          <select 
            value={filterSupplier}
            onChange={(e) => setFilterSupplier(e.target.value)}
            className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20"
          >
            <option value="all">Alle Leveranciers</option>
            {suppliers.map(sup => (
              <option key={sup} value={sup}>{sup}</option>
            ))}
          </select>
        </div>

        <div className="md:col-span-2">
          <select 
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20"
          >
            <option value="all">Alle Status</option>
            <option value="active">Actief</option>
            <option value="inactive">Inactief</option>
          </select>
        </div>

        <div className="md:col-span-2 flex items-center justify-end">
          <label className="flex items-center gap-2 cursor-pointer select-none">
            <input 
              type="checkbox" 
              checked={filterLowStock}
              onChange={(e) => setFilterLowStock(e.target.checked)}
              className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
            />
            <span className="text-sm font-medium text-slate-700">Lage voorraad</span>
          </label>
        </div>
      </div>
    </div>
  );
};

export default InventoryFilters;
