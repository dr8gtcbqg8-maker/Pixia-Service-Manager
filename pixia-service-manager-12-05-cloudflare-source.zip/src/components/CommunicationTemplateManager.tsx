import React, { useState, useEffect, useMemo } from 'react';
import { collection, query, getDocs, updateDoc, doc, deleteDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { CommunicationTemplate, CommunicationTemplateType } from '../types';
import { 
  Mail, Save, RotateCcw, Info, CheckCircle2, 
  Search, Filter, RefreshCw, Eye, Code, 
  AlertTriangle, Trash2, Check, X, Plus, 
  Copy, LayoutGrid, List, FileText, ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { handleFirestoreError, OperationType, cn } from '../lib/utils';
import { communicationTemplateService } from '../services/communicationTemplateService';
import { SUPPORTED_PLACEHOLDERS } from '../constants/emailTemplates';
import { logAction } from '../lib/audit';
import { COLLECTIONS } from '../constants/collections';

const CATEGORIES = [
  { id: 'all', label: 'Alle' },
  { id: 'appointments', label: 'Afspraken' },
  { id: 'interventions', label: 'Interventies' },
  { id: 'work_orders', label: 'Werkbonnen' },
  { id: 'maintenance', label: 'Onderhoud' },
  { id: 'system', label: 'Systeem' },
  { id: 'custom', label: 'Aangepast' }
];

const CommunicationTemplateManager: React.FC = () => {
  const [templates, setTemplates] = useState<CommunicationTemplate[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<CommunicationTemplate | null>(null);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [showSavedMsg, setShowSavedMsg] = useState(false);
  
  // UI State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [viewMode, setViewMode] = useState<'edit' | 'preview'>('edit');
  const [displayMode, setDisplayMode] = useState<'grid' | 'list'>('list');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'create' | 'edit-meta'>('create');
  
  // Form State for Modal
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: 'custom' as CommunicationTemplate['category'],
    type: 'custom'
  });

  const fetchTemplates = async () => {
    setLoading(true);
    try {
      const snap = await getDocs(collection(db, COLLECTIONS.COMMUNICATION_TEMPLATES));
      if (snap.empty) {
        await communicationTemplateService.syncDefaultTemplates();
        const retrySnap = await getDocs(collection(db, COLLECTIONS.COMMUNICATION_TEMPLATES));
        const fetched = retrySnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as CommunicationTemplate));
        setTemplates(fetched);
        if (fetched.length > 0) setSelectedTemplate(fetched[0]);
      } else {
        const fetched = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as CommunicationTemplate));
        const sorted = fetched.sort((a, b) => {
          if (a.active !== b.active) return a.active ? -1 : 1;
          if (a.isSystemTemplate !== b.isSystemTemplate) return a.isSystemTemplate ? -1 : 1;
          return a.name.localeCompare(b.name);
        });
        setTemplates(sorted);
        if (!selectedTemplate && sorted.length > 0) setSelectedTemplate(sorted[0]);
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'communication_templates');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTemplates();
  }, []);

  const filteredTemplates = useMemo(() => {
    return templates.filter(t => {
      const matchesSearch = t.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           t.subject.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === 'all' || t.category === selectedCategory;
      const isNotArchived = !t.archived;
      return matchesSearch && matchesCategory && isNotArchived;
    });
  }, [templates, searchQuery, selectedCategory]);

  const handleSave = async () => {
    if (!selectedTemplate) return;
    setSaving(true);
    try {
      await communicationTemplateService.updateTemplate(selectedTemplate.id, {
        subject: selectedTemplate.subject,
        body: selectedTemplate.body,
        active: selectedTemplate.active,
        name: selectedTemplate.name,
        description: selectedTemplate.description,
        category: selectedTemplate.category
      });
      
      await logAction('Template bijgewerkt', 'settings', selectedTemplate.id, `Type: ${selectedTemplate.type}`, 'settings');
      
      setShowSavedMsg(true);
      setTimeout(() => setShowSavedMsg(false), 3000);
      setTemplates(templates.map(t => t.id === selectedTemplate.id ? selectedTemplate : t));
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `communication_templates/${selectedTemplate.id}`);
    } finally {
      setSaving(false);
    }
  };

  const handleCreateOrUpdateMeta = async () => {
    setSaving(true);
    try {
      if (modalMode === 'create') {
        const newTemplate: Omit<CommunicationTemplate, 'id' | 'createdAt' | 'updatedAt'> = {
          ...formData,
          subject: 'Nieuw Bericht',
          body: 'Beste {{customer_name}},\n\n...',
          placeholders: ['customer_name'],
          active: true,
          isSystemTemplate: false
        };
        const id = await communicationTemplateService.createTemplate(newTemplate);
        await logAction('Template aangemaakt', 'settings', id, `Naam: ${formData.name}`, 'settings');
        await fetchTemplates();
      } else if (selectedTemplate) {
        await communicationTemplateService.updateTemplate(selectedTemplate.id, {
          name: formData.name,
          description: formData.description,
          category: formData.category
        });
        await fetchTemplates();
      }
      setIsModalOpen(false);
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  const handleDuplicate = async (template: CommunicationTemplate) => {
    try {
      setSaving(true);
      const id = await communicationTemplateService.duplicateTemplate(template);
      await logAction('Template gedupliceerd', 'settings', id, `Origineel: ${template.name}`, 'settings');
      await fetchTemplates();
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (!confirm(`Weet u zeker dat u "${name}" wilt verwijderen? Dit kan niet ongedaan worden gemaakt.`)) return;
    try {
      setSaving(true);
      await communicationTemplateService.deleteTemplate(id);
      await logAction('Template verwijderd', 'settings', id, `Naam: ${name}`, 'settings');
      if (selectedTemplate?.id === id) setSelectedTemplate(null);
      await fetchTemplates();
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  const handleSync = async () => {
    if (!confirm('Dit synchroniseert alle standaardtemplates. Bestaande inhoud blijft behouden, maar metadata wordt ververst. Doorgaan?')) return;
    setSyncing(true);
    try {
      await communicationTemplateService.syncDefaultTemplates();
      await fetchTemplates();
      alert('Synchronisatie voltooid.');
    } catch (err) {
      console.error(err);
      alert('Fout bij synchroniseren.');
    } finally {
      setSyncing(false);
    }
  };

  const handleReset = async () => {
    if (!selectedTemplate) return;
    if (!confirm(`Weet u zeker dat u "${selectedTemplate.name}" wilt resetten naar de standaard Pixia instellingen?`)) return;
    setSaving(true);
    try {
      await communicationTemplateService.resetToDefault(selectedTemplate.type);
      await fetchTemplates();
      alert('Template gereset.');
    } catch (err) {
      console.error(err);
      alert('Fout bij resetten.');
    } finally {
      setSaving(false);
    }
  };

  const unknownPlaceholders = useMemo(() => {
    if (!selectedTemplate) return [];
    const bodyRes = communicationTemplateService.validatePlaceholders(selectedTemplate.body);
    const subjectRes = communicationTemplateService.validatePlaceholders(selectedTemplate.subject);
    return [...new Set([...bodyRes.unknownPlaceholders, ...subjectRes.unknownPlaceholders])];
  }, [selectedTemplate]);

  if (loading) {
     return (
       <div className="p-12 flex flex-col items-center justify-center space-y-4">
         <div className="animate-spin rounded-full h-10 w-10 border-4 border-slate-200 border-t-blue-600"></div>
         <p className="text-xs font-black uppercase tracking-widest text-slate-400">Templates laden...</p>
       </div>
     );
  }

  return (
    <div className="space-y-8">
      {/* Header Actions */}
      <div className="flex flex-wrap items-center justify-between gap-6 bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
        <div className="flex items-center gap-6 flex-1 min-w-[300px]">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Zoek templates..."
              className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-sm outline-none focus:ring-4 focus:ring-blue-100 transition-all font-bold"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-3">
             <div className="flex p-1 bg-slate-50 rounded-xl border border-slate-100">
                <button 
                  onClick={() => setDisplayMode('list')}
                  className={cn(
                    "p-2 rounded-lg transition-all",
                    displayMode === 'list' ? "bg-white shadow-sm text-blue-600" : "text-slate-400 hover:text-slate-600"
                  )}
                >
                  <List className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => setDisplayMode('grid')}
                  className={cn(
                    "p-2 rounded-lg transition-all",
                    displayMode === 'grid' ? "bg-white shadow-sm text-blue-600" : "text-slate-400 hover:text-slate-600"
                  )}
                >
                  <LayoutGrid className="w-4 h-4" />
                </button>
             </div>
          </div>
        </div>
        <div className="flex gap-3">
           <button 
            onClick={handleSync}
            disabled={syncing}
            className="flex items-center gap-2 px-6 py-4 bg-blue-50 text-blue-600 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-blue-100 transition-all"
          >
            <RefreshCw className={cn("w-4 h-4", syncing && "animate-spin")} />
            Sync Systeem
          </button>
          <button 
            onClick={() => {
              setModalMode('create');
              setFormData({ name: '', description: '', category: 'custom', type: 'custom' });
              setIsModalOpen(true);
            }}
            className="flex items-center gap-2 px-8 py-4 bg-slate-900 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-blue-600 transition-all shadow-xl active:scale-95"
          >
            <Plus className="w-4 h-4" />
            Nieuwe Template
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Sidebar / List */}
        <div className={cn(
          "space-y-4",
          displayMode === 'list' ? "lg:col-span-12" : "lg:col-span-4"
        )}>
           <div className="flex items-center justify-between px-2">
              <h3 className="text-[10px] font-black uppercase tracking-widest text-slate-400">Templates ({filteredTemplates.length})</h3>
              <div className="flex gap-2">
                 {CATEGORIES.map(c => (
                   <button
                    key={c.id}
                    onClick={() => setSelectedCategory(c.id)}
                    className={cn(
                      "px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest transition-all",
                      selectedCategory === c.id ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-400 hover:bg-slate-200"
                    )}
                   >
                     {c.label}
                   </button>
                 ))}
              </div>
           </div>

           {displayMode === 'grid' ? (
             <div className="grid grid-cols-1 gap-3 max-h-[700px] overflow-y-auto pr-2 custom-scrollbar">
               {filteredTemplates.map(t => (
                  <div
                    key={t.id}
                    onClick={() => setSelectedTemplate(t)}
                    className={cn(
                      "w-full text-left p-5 rounded-3xl border transition-all group relative overflow-hidden cursor-pointer",
                      selectedTemplate?.id === t.id 
                      ? "bg-slate-900 border-slate-900 text-white shadow-2xl translate-x-2" 
                      : "bg-white border-slate-100 text-slate-600 hover:border-slate-300"
                    )}
                  >
                    <div className="flex items-center justify-between mb-2">
                       <div className="flex items-center gap-2">
                          <span className={cn(
                            "w-2 h-2 rounded-full",
                            t.active ? "bg-green-500" : "bg-slate-300"
                          )} />
                          <p className="text-xs font-black tracking-tight truncate max-w-[150px]">{t.name}</p>
                       </div>
                       {t.isSystemTemplate && (
                         <span className="text-[8px] font-black uppercase px-2 py-0.5 bg-blue-500 text-white rounded-full">System</span>
                       )}
                    </div>
                    <p className={cn(
                      "text-[10px] font-medium line-clamp-1 mb-3",
                      selectedTemplate?.id === t.id ? "text-slate-400" : "text-slate-500"
                    )}>
                      {t.subject}
                    </p>
                    <div className="flex items-center justify-between">
                       <span className="text-[9px] font-black uppercase tracking-widest opacity-60">{t.category}</span>
                       <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                         <button onClick={(e) => { e.stopPropagation(); handleDuplicate(t); }} className="p-1 hover:text-blue-400"><Copy className="w-3.5 h-3.5" /></button>
                         {!t.isSystemTemplate && (
                           <button onClick={(e) => { e.stopPropagation(); handleDelete(t.id, t.name); }} className="p-1 hover:text-red-400"><Trash2 className="w-3.5 h-3.5" /></button>
                         )}
                       </div>
                    </div>
                  </div>
               ))}
             </div>
           ) : (
             <div className="bg-white border border-slate-100 rounded-[2.5rem] overflow-hidden shadow-sm">
                <table className="w-full">
                  <thead className="bg-slate-50 border-b border-slate-100">
                    <tr>
                      <th className="px-8 py-5 text-left text-[10px] font-black uppercase tracking-widest text-slate-400 w-12">Status</th>
                      <th className="px-8 py-5 text-left text-[10px] font-black uppercase tracking-widest text-slate-400">Naam</th>
                      <th className="px-8 py-5 text-left text-[10px] font-black uppercase tracking-widest text-slate-400">Onderwerp</th>
                      <th className="px-8 py-5 text-left text-[10px] font-black uppercase tracking-widest text-slate-400">Categorie</th>
                      <th className="px-8 py-5 text-center text-[10px] font-black uppercase tracking-widest text-slate-400">Acties</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {filteredTemplates.map(t => (
                      <tr 
                        key={t.id} 
                        onClick={() => { setSelectedTemplate(t); setDisplayMode('grid'); }}
                        className={cn(
                          "group hover:bg-slate-50/50 cursor-pointer transition-colors",
                          selectedTemplate?.id === t.id && "bg-blue-50/30"
                        )}
                      >
                        <td className="px-8 py-5">
                           <div className={cn(
                             "w-3 h-3 rounded-full mx-auto",
                             t.active ? "bg-green-500 shadow-lg shadow-green-100" : "bg-slate-200"
                           )} />
                        </td>
                        <td className="px-8 py-5">
                          <div className="flex items-center gap-3">
                            <p className="text-sm font-black text-slate-900 italic tracking-tight">{t.name}</p>
                            {t.isSystemTemplate && <span className="text-[8px] font-black uppercase px-2 py-0.5 bg-slate-100 text-slate-400 rounded-full">System</span>}
                          </div>
                          <p className="text-[10px] text-slate-400 font-medium">{t.description || 'Geen omschrijving'}</p>
                        </td>
                        <td className="px-8 py-5">
                           <p className="text-sm font-bold text-slate-500 line-clamp-1">{t.subject}</p>
                        </td>
                        <td className="px-8 py-5">
                           <span className="text-[9px] font-black uppercase tracking-widest px-3 py-1 bg-slate-100 text-slate-500 rounded-lg">{t.category}</span>
                        </td>
                        <td className="px-8 py-5">
                           <div className="flex items-center justify-center gap-4">
                              <button 
                                onClick={(e) => { e.stopPropagation(); handleDuplicate(t); }}
                                className="p-2 hover:bg-blue-50 text-slate-400 hover:text-blue-600 rounded-xl transition-all"
                                title="Dupliceren"
                              >
                                <Copy className="w-4 h-4" />
                              </button>
                              {!t.isSystemTemplate && (
                                <button 
                                  onClick={(e) => { e.stopPropagation(); handleDelete(t.id, t.name); }}
                                  className="p-2 hover:bg-red-50 text-slate-400 hover:text-red-600 rounded-xl transition-all"
                                  title="Verwijderen"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              )}
                              <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-blue-500 transition-all opacity-0 group-hover:opacity-100" />
                           </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
             </div>
           )}
        </div>

        {/* Editor Area */}
        {displayMode === 'grid' && (
          <div className="lg:col-span-8">
            <AnimatePresence mode="wait">
              {selectedTemplate ? (
                <motion.div
                  key={selectedTemplate.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="bg-white border border-slate-100 rounded-[3rem] shadow-2xl overflow-hidden"
                >
                  <div className="p-10 border-b border-slate-50 flex items-center justify-between bg-slate-50/30">
                    <div className="flex items-center gap-6">
                      <div className="w-16 h-16 bg-white rounded-3xl shadow-lg flex items-center justify-center text-slate-900 border border-slate-100 shrink-0">
                        <FileText className="w-8 h-8" />
                      </div>
                      <div>
                        <div className="flex items-center gap-3 mb-1">
                          <h2 className="text-2xl font-black italic tracking-tighter text-slate-900">{selectedTemplate.name}</h2>
                          <button 
                            onClick={() => {
                              setModalMode('edit-meta');
                              setFormData({
                                name: selectedTemplate.name,
                                description: selectedTemplate.description || '',
                                category: selectedTemplate.category,
                                type: selectedTemplate.type
                              });
                              setIsModalOpen(true);
                            }}
                            className="p-2 bg-slate-100 text-slate-400 hover:text-slate-900 rounded-xl transition-all"
                          >
                            <Code className="w-4 h-4" />
                          </button>
                        </div>
                        <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest">{selectedTemplate.description || 'Standaard communictie template'}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 p-1.5 bg-white rounded-2xl border border-slate-200">
                      <button 
                        onClick={() => setViewMode('edit')}
                        className={cn(
                          "px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all",
                          viewMode === 'edit' ? "bg-slate-900 text-white shadow-xl" : "text-slate-400"
                        )}
                      >
                        Editor
                      </button>
                      <button 
                        onClick={() => setViewMode('preview')}
                        className={cn(
                          "px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all",
                          viewMode === 'preview' ? "bg-slate-900 text-white shadow-xl" : "text-slate-400"
                        )}
                      >
                        Preview
                      </button>
                    </div>
                  </div>

                  <div className="p-10">
                    {viewMode === 'edit' ? (
                       <div className="space-y-10">
                          <div className="grid grid-cols-1 xl:grid-cols-2 gap-12">
                             <div className="space-y-8">
                                <div className="space-y-3">
                                   <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">E-mail Onderwerp</label>
                                   <input 
                                     type="text"
                                     className="w-full input-field !py-5 !px-8 text-base shadow-sm"
                                     placeholder="Bijv: Bevestiging van uw afspraak"
                                     value={selectedTemplate.subject}
                                     onChange={(e) => setSelectedTemplate({ ...selectedTemplate, subject: e.target.value })}
                                   />
                                </div>
                                <div className="space-y-3">
                                   <div className="flex items-center justify-between mb-1">
                                      <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">Inhoud Bericht</label>
                                      <div className="flex items-center gap-3">
                                         <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Actief</span>
                                         <button 
                                           onClick={() => setSelectedTemplate({ ...selectedTemplate, active: !selectedTemplate.active })}
                                           className={cn(
                                             "w-12 h-6 rounded-full transition-all relative ring-4 ring-white shadow-sm",
                                             selectedTemplate.active ? "bg-green-500" : "bg-slate-200"
                                           )}
                                         >
                                            <div className={cn(
                                              "absolute top-1 w-4 h-4 rounded-full bg-white transition-all shadow-sm",
                                              selectedTemplate.active ? "left-7" : "left-1"
                                            )} />
                                         </button>
                                      </div>
                                   </div>
                                   <textarea 
                                      rows={15}
                                      className="w-full input-field !py-8 !px-10 text-base leading-relaxed resize-none font-sans"
                                      value={selectedTemplate.body}
                                      onChange={(e) => setSelectedTemplate({ ...selectedTemplate, body: e.target.value })}
                                   />
                                   <div className="flex justify-between items-center px-2">
                                      <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 italic">
                                        Type {"{{"} om een variabele te starten
                                      </p>
                                      {selectedTemplate.isSystemTemplate && (
                                         <button onClick={handleReset} className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-blue-500 hover:text-blue-700 transition-all">
                                            <RotateCcw className="w-3.5 h-3.5" />
                                            Herstel naar Standaard
                                         </button>
                                      )}
                                   </div>
                                </div>
                             </div>

                             <div className="space-y-8">
                                <div className="p-8 bg-blue-50/50 rounded-[2.5rem] border border-blue-100/50 space-y-6">
                                   <div className="flex items-center justify-between">
                                      <h4 className="text-[11px] font-black uppercase tracking-widest text-blue-600 flex items-center gap-2 italic">
                                        <Info className="w-4 h-4" />
                                        Dynamische Variabelen
                                      </h4>
                                   </div>
                                   <div className="grid grid-cols-1 gap-3 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
                                      {SUPPORTED_PLACEHOLDERS.map(p => (
                                         <button
                                          key={p.key}
                                          onClick={() => setSelectedTemplate({ ...selectedTemplate, body: selectedTemplate.body + `{{${p.key}}}` })}
                                          className="group p-5 bg-white border border-blue-100 rounded-2xl hover:border-blue-400 hover:shadow-xl transition-all text-left relative overflow-hidden"
                                         >
                                            <div className="flex items-center justify-between mb-2">
                                               <code className="text-[11px] font-black text-blue-600 bg-blue-50 px-2.5 py-1 rounded-lg">{"{{"}{p.key}{"}}"}</code>
                                               <Plus className="w-4 h-4 text-slate-200 group-hover:text-blue-400 transition-all" />
                                            </div>
                                            <p className="text-[10px] font-bold text-slate-500 mb-1">{p.label}</p>
                                            <p className="text-[9px] text-slate-400 italic">{p.description}</p>
                                         </button>
                                      ))}
                                   </div>
                                </div>

                                {unknownPlaceholders.length > 0 && (
                                   <div className="p-6 bg-red-50 border border-red-100 rounded-3xl flex items-start gap-4">
                                      <AlertTriangle className="w-6 h-6 text-red-500 mt-1 shrink-0" />
                                      <div>
                                         <p className="text-[11px] font-black uppercase tracking-widest text-red-600 mb-1">Onbekende Codes!</p>
                                         <p className="text-xs text-red-700/70 leading-relaxed font-medium">
                                           De volgende codes worden niet herkend door het systeem: 
                                           <span className="font-mono block mt-2 p-3 bg-white/50 rounded-xl border border-red-100">{unknownPlaceholders.map(u => `{{${u}}}`).join(', ')}</span>
                                         </p>
                                      </div>
                                   </div>
                                )}
                             </div>
                          </div>

                          <div className="flex justify-end items-center gap-6 pt-10 border-t border-slate-50">
                             {showSavedMsg && (
                               <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} className="flex items-center gap-2 text-green-600 text-[11px] font-black uppercase tracking-widest italic">
                                 <CheckCircle2 className="w-5 h-5" />
                                 Wijzigingen opgeslagen
                               </motion.div>
                             )}
                             <button 
                               onClick={handleSave}
                               disabled={saving}
                               className="px-14 py-5 bg-slate-900 text-white rounded-3xl text-[11px] font-black uppercase tracking-widest hover:bg-blue-600 transition-all shadow-2xl active:scale-95 flex items-center gap-4"
                             >
                               <Save className="w-5 h-5" />
                               Layout Opslaan
                             </button>
                          </div>
                       </div>
                    ) : (
                       <div className="max-w-3xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-5 duration-500">
                          <div className="bg-slate-900 rounded-[2.5rem] overflow-hidden shadow-2xl">
                             <div className="px-8 py-5 border-b border-white/10 flex items-center gap-4">
                                <div className="flex gap-2">
                                   <div className="w-3 h-3 rounded-full bg-red-500" />
                                   <div className="w-3 h-3 rounded-full bg-amber-500" />
                                   <div className="w-3 h-3 rounded-full bg-green-500" />
                                </div>
                                <div className="flex-1 text-center">
                                   <p className="text-[10px] font-black text-white/40 uppercase tracking-widest">Nieuw Bericht</p>
                                </div>
                             </div>
                             <div className="p-10 space-y-8">
                                <div className="space-y-3">
                                   <div className="flex items-center gap-4 text-white/50 text-xs font-bold border-b border-white/5 pb-3">
                                      <span className="w-16 uppercase text-[9px] tracking-widest font-black">Aan:</span>
                                      <span>klant@voorbeeld.nl</span>
                                   </div>
                                   <div className="flex items-center gap-4 text-white/50 text-xs font-bold border-b border-white/5 pb-3">
                                      <span className="w-16 uppercase text-[9px] tracking-widest font-black">Van:</span>
                                      <span>service@pixia.nl</span>
                                   </div>
                                   <div className="flex items-center gap-4 text-white text-sm font-black italic">
                                      <span className="w-16 uppercase text-[9px] tracking-widest font-black text-white/50 not-italic">Onderwerp:</span>
                                      <span>{communicationTemplateService.preview(selectedTemplate.subject)}</span>
                                   </div>
                                </div>
                                <div className="bg-white rounded-[2rem] p-10 shadow-inner">
                                   <pre className="text-sm text-slate-700 whitespace-pre-wrap font-sans leading-loose italic">
                                     {communicationTemplateService.preview(selectedTemplate.body)}
                                   </pre>
                                </div>
                             </div>
                          </div>
                          <div className="text-center p-8 bg-slate-50 rounded-[2rem] border border-slate-100">
                             <p className="text-[9px] font-black uppercase tracking-widest text-slate-400 italic">
                               Let op: Dit is een gesimuleerd voorbeeld met fictieve data. 
                               Echte data wordt dynamisch geladen bij verzending.
                             </p>
                          </div>
                       </div>
                    )}
                  </div>
                </motion.div>
              ) : (
                <div className="h-full min-h-[600px] flex flex-col items-center justify-center bg-slate-50 border-4 border-dashed border-slate-200 rounded-[3rem] p-20 text-center">
                  <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center text-slate-200 shadow-xl mb-8">
                    <Mail className="w-12 h-12" />
                  </div>
                  <h3 className="text-xl font-black text-slate-900 italic tracking-tight mb-2">Configureer Communicatie</h3>
                  <p className="text-sm font-medium text-slate-400 max-w-sm mb-10">Selecteer een template uit de lijst om de inhoud aan te passen of een preview te bekijken.</p>
                  <button 
                    onClick={() => setDisplayMode('list')}
                    className="flex items-center gap-3 px-10 py-5 bg-white border border-slate-200 text-slate-900 rounded-3xl text-[11px] font-black uppercase tracking-widest hover:bg-slate-50 transition-all shadow-sm"
                  >
                    Terug naar Overzicht
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              )}
            </AnimatePresence>
          </div>
        )}
      </div>

      {/* Modal Tool */}
      <AnimatePresence>
         {isModalOpen && (
           <div className="fixed inset-0 z-[60] flex items-center justify-center p-6">
              <motion.div 
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }} 
                exit={{ opacity: 0 }}
                onClick={() => setIsModalOpen(false)}
                className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" 
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="relative w-full max-w-xl bg-white rounded-[2.5rem] shadow-2xl overflow-hidden"
              >
                 <div className="p-10 border-b border-slate-50">
                    <h3 className="text-xl font-black italic tracking-tight text-slate-900">
                      {modalMode === 'create' ? 'Nieuwe Template' : 'Template Informatie Wijzigen'}
                    </h3>
                    <p className="text-xs font-medium text-slate-400 mt-1">Configuratie van de metadata en categorie.</p>
                 </div>
                 <div className="p-10 space-y-6">
                    <div className="space-y-2">
                       <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">Naam</label>
                       <input 
                         type="text" 
                         className="w-full input-field !py-4 !px-6"
                         placeholder="Bijv: Factuur Herinnering"
                         value={formData.name}
                         onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                       />
                    </div>
                    <div className="space-y-2">
                       <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">Omschrijving</label>
                       <textarea 
                         className="w-full input-field !py-4 !px-6 !h-24 resize-none"
                         placeholder="Waar wordt deze template voor gebruikt?"
                         value={formData.description}
                         onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                       />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                       <div className="space-y-2">
                          <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">Categorie</label>
                          <select 
                            className="w-full input-field !py-4 !px-6 !h-auto text-xs uppercase font-black"
                            value={formData.category}
                            onChange={(e) => setFormData({ ...formData, category: e.target.value as any })}
                          >
                             {CATEGORIES.filter(c => c.id !== 'all').map(c => <option key={c.id} value={c.id}>{c.label}</option>)}
                          </select>
                       </div>
                       {modalMode === 'create' && (
                         <div className="space-y-2">
                            <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">Type ID</label>
                            <input 
                              type="text" 
                              className="w-full input-field !py-4 !px-6 placeholder:lowercase"
                              placeholder="unieke_id"
                              value={formData.type}
                              onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                            />
                         </div>
                       )}
                    </div>
                 </div>
                 <div className="p-8 bg-slate-50 border-t border-slate-100 flex justify-end gap-4">
                    <button onClick={() => setIsModalOpen(false)} className="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-slate-900 transition-all">Annuleren</button>
                    <button 
                      onClick={handleCreateOrUpdateMeta}
                      className="px-10 py-4 bg-slate-900 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-blue-600 transition-all shadow-xl shadow-blue-100"
                    >
                      Bevestigen
                    </button>
                 </div>
              </motion.div>
           </div>
         )}
      </AnimatePresence>
    </div>
  );
};

export default CommunicationTemplateManager;
