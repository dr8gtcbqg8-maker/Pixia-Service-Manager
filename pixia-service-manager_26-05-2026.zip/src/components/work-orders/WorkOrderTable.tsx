import React from 'react';
import { ClipboardList, ChevronRight, Trash2, X } from 'lucide-react';
import { motion } from 'motion/react';
import { WorkOrder, Customer, Machine, WorkOrderStatus } from '../../types';
import { format } from 'date-fns';
import { nl } from 'date-fns/locale';

interface WorkOrderTableProps {
  workOrders: WorkOrder[];
  customers: Customer[];
  machines: Machine[];
  onSelect: (order: WorkOrder) => void;
  onDelete: (order: WorkOrder) => void;
  deleteId: string | null;
  setDeleteId: (id: string | null) => void;
  isDeleting: boolean;
  profile: any;
  getStatusStyle: (status: WorkOrderStatus) => string;
  getStatusLabelText: (status: WorkOrderStatus) => string;
}

const WorkOrderTable: React.FC<WorkOrderTableProps> = ({
  workOrders,
  customers,
  machines,
  onSelect,
  onDelete,
  deleteId,
  setDeleteId,
  isDeleting,
  profile,
  getStatusStyle,
  getStatusLabelText
}) => {
  const getCustomer = (id: string) => customers.find(c => c.id === id);
  const getMachine = (id: string) => machines.find(m => m.id === id);

  if (workOrders.length === 0) {
    return (
    <div className="bg-white px-5 py-4 rounded-lg border border-surface-200 text-center flex flex-col items-center gap-4">
      <div className="w-16 h-16 bg-surface-50 rounded-full flex items-center justify-center text-surface-300">
        <ClipboardList className="w-8 h-8" />
      </div>
      <div>
        <h3 className="text-base font-bold text-surface-900">Geen werkbonnen gevonden</h3>
        <p className="text-sm text-surface-500 max-w-xs mx-auto">Start met het aanmaken van een nieuwe werkbon of pas de filters aan.</p>
      </div>
    </div>
    );
  }

  return (
    <div className="bg-white rounded-lg border border-surface-200 overflow-hidden shadow-sm">
      {/* Desktop Header */}
      <div className="hidden md:grid grid-cols-12 gap-4 px-6 py-3 bg-surface-50 border-b border-surface-200 text-[10px] font-bold uppercase tracking-wider text-surface-500">
        <div className="col-span-2">Nummer</div>
        <div className="col-span-3">Klant / Machine</div>
        <div className="col-span-2">Datum</div>
        <div className="col-span-1 text-center">Uren</div>
        <div className="col-span-2">Status</div>
        <div className="col-span-2 text-right">Acties</div>
      </div>

      <div className="divide-y divide-surface-100">
        {workOrders.map(order => (
          <motion.div
            layout
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            key={order.id}
            onClick={() => onSelect(order)}
            className="group hover:bg-surface-50/50 transition-all cursor-pointer"
          >
            {/* Desktop Row */}
            <div className="hidden md:grid grid-cols-12 gap-4 items-center px-6 py-2">
              <div className="col-span-2 flex items-center gap-1.5">
                <span className="text-[10px] font-bold text-surface-400 font-mono tracking-wider uppercase">{order.orderNumber}</span>
                {order.visitNumber && (
                  <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-brand-50 text-[8px] font-bold text-blue-700 font-mono" title={`Bezoek #${order.visitNumber}`}>
                    #{order.visitNumber}
                  </span>
                )}
              </div>
              <div className="col-span-3 min-w-0">
                <div className="text-sm font-bold text-surface-900 truncate">{getCustomer(order.customerId)?.name || 'Onbekend'}</div>
                <div className="text-[10px] text-brand-500 font-bold truncate mt-0.5 uppercase tracking-wide">{getMachine(order.machineId)?.model || 'Machine'}</div>
              </div>
              <div className="col-span-2 text-xs font-bold text-surface-700">
                {format(new Date(order.date), 'dd MMM yyyy', { locale: nl })}
              </div>
              <div className="col-span-1 text-center text-xs font-bold text-surface-600">
                {order.hoursWorked}u
              </div>
              <div className="col-span-2">
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider border ${getStatusStyle(order.status)}`}>
                  {getStatusLabelText(order.status)}
                </span>
              </div>
              <div className="col-span-2 flex justify-end gap-1.5 px-2 opacity-100 md:opacity-0 group-hover:opacity-100 transition-all">
                {profile?.role === 'admin' && (
                  deleteId === order.id ? (
                    <div className="flex items-center gap-1 bg-red-50 p-1 rounded-lg border border-red-100">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onDelete(order);
                        }}
                        className="px-2 py-1 bg-red-600 text-white text-[8px] font-bold uppercase rounded shadow-sm hover:bg-red-700"
                      >
                        OK
                      </button>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setDeleteId(null);
                        }}
                        className="p-1 text-surface-400 hover:text-surface-600"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setDeleteId(order.id);
                      }}
                      disabled={isDeleting}
                      className="p-1.5 text-surface-400 hover:text-red-600 hover:bg-white rounded-md border border-transparent hover:border-surface-200 transition-all shadow-sm disabled:opacity-50"
                      title="Verwijderen"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )
                )}
                <div className="h-8 flex items-center px-3 bg-surface-900 text-white rounded-lg text-[10px] font-bold uppercase tracking-wider gap-1.5 shadow-sm active:scale-95 transition-all">
                  Details <ChevronRight className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>

            {/* Mobile View */}
            <div className="md:hidden p-4 space-y-3">
              <div className="flex justify-between items-start gap-2">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5 mb-0.5">
                    <span className="text-[9px] font-black font-mono text-surface-400 tracking-widest">{order.orderNumber}</span>
                    {order.visitNumber && (
                      <span className="inline-flex items-center px-1.5 py-0.2 rounded bg-brand-50 text-[7px] font-bold text-blue-700 font-mono">
                        #{order.visitNumber}
                      </span>
                    )}
                  </div>
                  <div className="text-sm font-bold text-surface-900 truncate">{getCustomer(order.customerId)?.name || 'Onbekend'}</div>
                </div>
                <span className={`shrink-0 text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded-lg border ${getStatusStyle(order.status)}`}>
                  {getStatusLabelText(order.status)}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-4 text-[10px] bg-surface-50 p-3 rounded-md border border-surface-100">
                <div>
                  <span className="block text-surface-400 uppercase font-black mb-0.5 tracking-tighter">Machine</span>
                  <span className="font-bold text-brand-500 truncate block">{getMachine(order.machineId)?.model || 'Machine'}</span>
                </div>
                <div>
                  <span className="block text-surface-400 uppercase font-black mb-0.5 tracking-tighter">Datum / Uren</span>
                  <span className="font-bold text-surface-700">{format(new Date(order.date), 'dd/MM/yy')} • {order.hoursWorked}u</span>
                </div>
              </div>

              {profile?.role === 'admin' && (
                deleteId === order.id ? (
                  <div className="flex flex-col gap-2 p-4 bg-red-50 rounded-lg border border-red-100">
                    <p className="text-[10px] font-black text-red-700 uppercase text-center">Zeker weten?</p>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onDelete(order);
                        }}
                        className="flex-1 py-3 bg-red-600 text-white rounded-md text-[10px] font-black uppercase shadow-sm"
                      >
                        Ja, Verwijderen
                      </button>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setDeleteId(null);
                        }}
                        className="flex-1 py-3 bg-white text-surface-500 border border-red-100 rounded-md text-[10px] font-black uppercase"
                      >
                        Annuleren
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setDeleteId(order.id);
                    }}
                    disabled={isDeleting}
                    className="w-full py-2 bg-red-50 text-red-600 border border-red-100 rounded-lg text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-all shadow-sm"
                  >
                    <Trash2 className="w-4 h-4" /> Werkbon Verwijderen
                  </button>
                )
              )}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default WorkOrderTable;
