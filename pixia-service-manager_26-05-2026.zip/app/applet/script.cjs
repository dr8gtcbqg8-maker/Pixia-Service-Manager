const fs = require('fs');
const file = 'src/components/AppointmentModal.tsx';
let content = fs.readFileSync(file, 'utf8');

content = content.replace(/onChange=\{\(e\) => setFormData\(\{ \.\.\.formData, /g, 'onChange={(e) => updateFormData({ ');

content = content.replace(/setFormData\(\{([\s]+)\.\.\.formData,([\s]+)technicianId:/g, 'updateFormData({$1technicianId:');

fs.writeFileSync(file, content);
console.log('Replaced setFormData to updateFormData');
