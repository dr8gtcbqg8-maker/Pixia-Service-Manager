const fs = require('fs');
const file = 'src/components/AppointmentModal.tsx';
let content = fs.readFileSync(file, 'utf8');

// replace standard inputs
content = content.replace(/onChange\{\(e\) => setFormData\(\{ \.\.\.formData, /g, 'onChange={(e) => updateFormData({ ');

// replace technicianId dropdown (which has a multi-line onChange)
// Find this block:
/*
                    onChange={(e) => {
                      const tech = technicians.find(t => t.uid === e.target.value);
                      setFormData({ 
                        ...formData, 
                        technicianId: e.target.value,
*/
content = content.replace(/setFormData\(\{([\s]+)\.\.\.formData,([\s]+)technicianId:/g, 'updateFormData({$1technicianId:');

fs.writeFileSync(file, content);
console.log('Replaced setFormData to updateFormData');
