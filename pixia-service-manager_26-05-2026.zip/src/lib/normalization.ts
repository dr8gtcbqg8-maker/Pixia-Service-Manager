/**
 * Utility functions for data normalization to prevent duplicates
 */

/**
 * Basic text normalization: trim, lowercase, remove double spaces
 */
export const normalizeText = (value: string | undefined | null): string => {
  if (!value) return '';
  return value
    .trim()
    .toLowerCase()
    .replace(/\s+/g, ' ');
};

/**
 * Normalizes company names: removes dots, common suffixes, and multiple spaces
 */
export const normalizeCompanyName = (value: string | undefined | null): string => {
  if (!value) return '';
  return value
    .trim()
    .toLowerCase()
    .replace(/\./g, '') // remove dots (B.V. -> BV)
    .replace(/\s+/g, ' ') // normalize spaces
    .replace(/\bbv\b/g, 'bv') // normalize BV
    .replace(/\bnv\b/g, 'nv') // normalize NV
    .replace(/\bvof\b/g, 'vof') // normalize VOF
    .trim();
};

/**
 * Normalizes email addresses
 */
export const normalizeEmail = (value: string | undefined | null): string => {
  if (!value) return '';
  return value.trim().toLowerCase();
};

/**
 * Normalizes phone numbers: removes non-digit characters
 */
export const normalizePhone = (value: string | undefined | null): string => {
  if (!value) return '';
  // Keep only digits and maybe the leading + for international comparison
  const digits = value.replace(/\D/g, '');
  // If it starts with 00, replace with +
  if (value.startsWith('00')) return '+' + digits.substring(2);
  // If it starts with 0 and has 10 digits total (standard NL), maybe prepend +31
  // However, simple digit comparison is usually safest for duplicates
  return digits;
};

/**
 * Normalizes serial numbers or machine IDs
 */
export const normalizeSerialNumber = (value: string | undefined | null): string => {
  if (!value) return '';
  return value.trim().toUpperCase().replace(/\s+/g, '');
};

/**
 * Normalizes SKUs or Part Numbers
 */
export const normalizeSku = (value: string | undefined | null): string => {
  if (!value) return '';
  return value.trim().toUpperCase().replace(/[-\s._]+/g, '');
};

/**
 * Normalizes names (like person names)
 */
export const normalizeName = (value: string | undefined | null): string => {
  if (!value) return '';
  return value.trim().toLowerCase();
};
