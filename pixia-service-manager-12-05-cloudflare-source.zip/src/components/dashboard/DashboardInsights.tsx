import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { ShieldAlert, Calendar, TrendingUp, Printer } from 'lucide-react';
import { InventoryItem, Machine, Customer } from '../../types';
import { format } from 'date-fns';

interface DashboardInsightsProps {
  lowStockItems: InventoryItem[];
  expiringWarrantyCount: number;
  faultyMachinesCount: number;
  upcomingMaintenance: Machine[];
  customers: Customer[];
}

const DashboardInsights: React.FC<DashboardInsightsProps> = ({
  lowStockItems,
  expiringWarrantyCount,
  faultyMachinesCount,
  upcomingMaintenance,
  customers
}) => {
  const navigate = useNavigate();
  const getCustomer = (id: string) => customers.find(c => c.id === id);

  return (
    <div className="space-y-8">
      <section className="bg-slate-900 text-white rounded-[2.5rem] p-8 shadow-2xl relative overflow-hidden">
         <div className="relative z-10 space-y-8">
            <div className="flex items-center gap-2 text-rose-400 border-b border-white/10 pb-4">
               <ShieldAlert className="w-6 h-6" />
               <h2 className="text-[11px] font-black uppercase tracking-[0.3em]">Business Alerts</h2>
            </div>
            
            <div className="space-y-5">
               {lowStockItems.length > 0 && (
                  <motion.div 
                    whileHover={{ scale: 1.02 }}
                    onClick={() => navigate('/inventory')}
                    className="bg-rose-500/20 backdrop-blur-md rounded-3xl p-5 border border-rose-500/30 ring-1 ring-rose-500/50 cursor-pointer"
                  >
                     <p className="text-[10px] font-black text-rose-200 uppercase tracking-widest mb-1">Kritieke Voorraad</p>
                     <p className="text-3xl font-black italic text-white leading-none text-left">{lowStockItems.length} Artikelen</p>
                     <div className="mt-4 space-y-2">
                        {lowStockItems.slice(0, 3).map(item => (
                           <div key={item.id} className="text-[9px] font-bold text-rose-100 flex justify-between items-center bg-white/5 p-2 rounded-lg">
                              <span>{item.name}</span>
                              <span className="bg-rose-500 px-2 py-0.5 rounded text-white font-mono">{item.stockCount} st.</span>
                           </div>
                        ))}
                     </div>
                  </motion.div>
               )}

               <div 
                onClick={() => navigate('/machines')}
                className="bg-white/5 backdrop-blur-md rounded-2xl p-5 border border-white/5 cursor-pointer hover:bg-white/10 transition-colors text-left"
               >
                  <p className="text-[10px] font-black text-white/50 uppercase tracking-widest mb-1">Garantie verlopen (30d)</p>
                  <p className="text-2xl font-black italic">{expiringWarrantyCount} Machines</p>
               </div>
               
               <div 
                onClick={() => navigate('/machines')}
                className="bg-white/5 backdrop-blur-md rounded-2xl p-5 border border-white/5 cursor-pointer hover:bg-white/10 transition-colors text-left"
               >
                  <p className="text-[10px] font-black text-white/50 uppercase tracking-widest mb-1">Defect gemeld</p>
                  <p className="text-2xl font-black italic text-rose-400">{faultyMachinesCount} Machines</p>
               </div>
            </div>

            <div className="pt-6 border-t border-white/10 text-left">
               <p className="text-[10px] text-white/40 font-bold italic">Rapportage gegenereerd op {format(new Date(), 'HH:mm')}</p>
            </div>
         </div>
         <div className="absolute top-0 right-0 w-64 h-64 bg-blue-600/10 rounded-full blur-[100px] pointer-events-none"></div>
         <div className="absolute bottom-0 left-0 w-32 h-32 bg-rose-600/10 rounded-full blur-[60px] pointer-events-none"></div>
      </section>

      <section className="bg-white rounded-[2rem] border border-slate-200 overflow-hidden shadow-sm">
         <div className="p-6 bg-amber-50/50 border-b border-amber-100">
            <h3 className="text-[10px] font-black text-amber-900 uppercase tracking-[0.2em] flex items-center gap-2">
               <Calendar className="w-4 h-4 text-amber-600" />
               Komend Onderhoud
            </h3>
         </div>
         <div className="divide-y divide-slate-50">
            {upcomingMaintenance.length > 0 ? (
              upcomingMaintenance.slice(0, 5).map(m => (
                <div 
                  key={m.id} 
                  onClick={() => navigate('/machines')}
                  className="p-5 hover:bg-slate-50 transition-colors cursor-pointer text-left"
                >
                   <div className="flex items-center justify-between mb-1">
                      <p className="text-xs font-black text-slate-900 truncate">{m.brand} {m.model}</p>
                      <span className="text-[8px] font-black text-amber-600 uppercase bg-amber-50 px-2 py-0.5 rounded-lg">Gepland</span>
                   </div>
                   <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{m.nextMaintenanceDate}</p>
                   <p className="text-[9px] text-slate-500 font-medium truncate mt-1 italic">{getCustomer(m.customerId)?.name}</p>
                </div>
              ))
            ) : (
              <div className="p-10 text-center text-[10px] font-black text-slate-300 uppercase tracking-widest italic">Geen onderhoud gepland</div>
            )}
         </div>
      </section>

      <section className="bg-indigo-600 text-white rounded-[2rem] p-8 shadow-xl relative overflow-hidden group">
         <div className="relative z-10 text-left">
            <h3 className="text-[10px] font-black uppercase tracking-[0.3em] mb-4 opacity-70">Systeem Status</h3>
            <div className="flex items-center gap-4 mb-6">
               <div className="h-12 w-12 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-md">
                  <TrendingUp className="w-6 h-6" />
               </div>
               <div>
                  <p className="text-2xl font-black tracking-tighter">98.5%</p>
                  <p className="text-[9px] font-black uppercase tracking-widest opacity-60">Gemiddelde Uptime</p>
               </div>
            </div>
            <button 
              onClick={() => navigate('/machines')}
              className="w-full bg-white text-indigo-600 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-indigo-50 transition-all shadow-lg active:scale-95"
            >
              Machinepark Beheer
            </button>
         </div>
         <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:rotate-12 transition-transform duration-500">
            <Printer className="w-32 h-32" />
         </div>
      </section>
    </div>
  );
};

export default DashboardInsights;
