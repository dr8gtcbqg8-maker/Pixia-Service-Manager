import React, { useEffect, useRef } from 'react';
import SignaturePadBase from 'signature_pad';
import { RotateCcw, Check, X } from 'lucide-react';

interface SignaturePadProps {
  onSave: (signatureData: string) => void;
  onClear?: () => void;
  title: string;
}

const SignaturePad: React.FC<SignaturePadProps> = ({ onSave, onClear, title }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const signaturePadRef = useRef<SignaturePadBase | null>(null);

  useEffect(() => {
    if (canvasRef.current) {
      const canvas = canvasRef.current;
      signaturePadRef.current = new SignaturePadBase(canvas, {
        backgroundColor: 'rgba(0,0,0,0)',
        penColor: 'rgb(0,0,0)'
      });

      // Handle window resize properly
      const resizeCanvas = () => {
        const ratio = Math.max(window.devicePixelRatio || 1, 1);
        canvas.width = canvas.offsetWidth * ratio;
        canvas.height = canvas.offsetHeight * ratio;
        canvas.getContext("2d")?.scale(ratio, ratio);
        signaturePadRef.current?.clear();
      };

      window.addEventListener("resize", resizeCanvas);
      resizeCanvas();

      return () => {
        window.removeEventListener("resize", resizeCanvas);
        signaturePadRef.current?.off();
      };
    }
  }, []);

  const clear = () => {
    signaturePadRef.current?.clear();
    onClear?.();
  };

  const save = () => {
    if (!signaturePadRef.current || signaturePadRef.current.isEmpty()) return;
    
    // We want to trim the signature like react-signature-canvas did
    // This is a manual implementation of trimming
    const canvas = canvasRef.current!;
    const trimmedCanvas = getTrimmedCanvas(canvas);
    const data = trimmedCanvas.toDataURL('image/png');
    
    if (data) {
      onSave(data);
    }
  };

  // Helper to trim white space from canvas
  const getTrimmedCanvas = (canvas: HTMLCanvasElement) => {
    const ctx = canvas.getContext('2d')!;
    const width = canvas.width;
    const height = canvas.height;
    const pixels = ctx.getImageData(0, 0, width, height);
    const l = pixels.data.length;
    let bound: any = {
      top: null,
      left: null,
      right: null,
      bottom: null
    };
    let x, y;

    for (let i = 0; i < l; i += 4) {
      if (pixels.data[i + 3] !== 0) {
        x = (i / 4) % width;
        y = Math.floor((i / 4) / width);

        if (bound.top === null) {
          bound.top = y;
        }

        if (bound.left === null) {
          bound.left = x;
        } else if (x < bound.left) {
          bound.left = x;
        }

        if (bound.right === null) {
          bound.right = x;
        } else if (bound.right < x) {
          bound.right = x;
        }

        if (bound.bottom === null) {
          bound.bottom = y;
        } else if (bound.bottom < y) {
          bound.bottom = y;
        }
      }
    }

    const trimHeight = bound.bottom - bound.top + 1;
    const trimWidth = bound.right - bound.left + 1;
    if (trimWidth <= 0 || trimHeight <= 0) return canvas;

    const trimmed = ctx.getImageData(bound.left, bound.top, trimWidth, trimHeight);

    const copy = document.createElement('canvas');
    copy.width = trimWidth;
    copy.height = trimHeight;
    const copyCtx = copy.getContext('2d')!;
    copyCtx.putImageData(trimmed, 0, 0);

    return copy;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 ml-1">{title}</label>
        <button 
          type="button"
          onClick={clear}
          className="text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-red-500 transition-all flex items-center gap-1.5"
        >
          <RotateCcw className="w-3" />
          Wissen
        </button>
      </div>
      
      <div className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl overflow-hidden touch-none relative h-48">
        <canvas 
          ref={canvasRef}
          className="w-full h-full cursor-crosshair"
          style={{ width: '100%', height: '100%' }}
        />
      </div>

      <div className="flex justify-end">
         <button 
          type="button"
          onClick={save}
          className="bg-blue-600 text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-blue-100 flex items-center gap-2 hover:bg-blue-700 transition-all"
        >
          <Check className="w-3 h-3" />
          Bevestigen
        </button>
      </div>
    </div>
  );
};

export default SignaturePad;
