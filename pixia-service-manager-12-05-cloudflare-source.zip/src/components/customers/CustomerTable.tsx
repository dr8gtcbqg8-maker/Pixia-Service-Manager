import React from 'react';
import { Mail, Phone, MapPin, Edit3, Trash2, User } from 'lucide-react';
import { motion } from 'motion/react';
import { Customer } from '../../types';

interface CustomerTableProps {
  customers: Customer[];
  onSelect: (customer: Customer) => void;
  onEdit: (customer: Customer) => void;
  onDelete: (id: string, e: React.MouseEvent) => void;
}

const CustomerTable: React.FC<CustomerTableProps> = ({ customers, onSelect, onEdit, onDelete }) => {
  if (customers.length === 0) {
    return (
    <div className="bg-white p-16 rounded-2xl border border-slate-200 text-center flex flex-col items-center gap-4">
      <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center text-slate-300">
        <User className="w-8 h-8" />
      </div>
      <div>
        <h3 className="text-base font-bold text-slate-900">Geen klanten gevonden</h3>
        <p className="text-sm text-slate-500 max-w-xs mx-auto">Pas de zoekterm aan of voeg een nieuwe klant toe aan het systeem.</p>
      </div>
    </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
      {/* Desktop Header */}
      <div className="hidden md:grid grid-cols-12 gap-4 px-6 py-3 bg-slate-50 border-b border-slate-200 text-[10px] font-bold uppercase tracking-wider text-slate-500">
        <div className="col-span-4">Klant / Contactpersoon</div>
        <div className="col-span-3">Contactgegevens</div>
        <div className="col-span-3">Adres</div>
        <div className="col-span-1">Status</div>
        <div className="col-span-1 text-right">Acties</div>
      </div>

      <div className="divide-y divide-slate-100">
        {customers.map((customer) => (
          <motion.div
            layout
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            key={customer.id}
            className="group hover:bg-slate-50/50 transition-all cursor-pointer"
            onClick={() => onSelect(customer)}
          >
            {/* Desktop Row */}
            <div className="hidden md:grid grid-cols-12 gap-4 items-center px-6 py-4">
              <div className="col-span-4 flex items-center gap-3">
                <div className="w-10 h-10 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-center text-slate-400 font-bold group-hover:bg-blue-600 group-hover:text-white group-hover:border-blue-600 transition-all uppercase shrink-0 shadow-sm">
                  {customer.name.charAt(0)}
                </div>
                <div className="min-w-0">
                  <div className="text-sm font-bold text-slate-900 truncate group-hover:text-blue-600 transition-colors leading-tight">{customer.name}</div>
                  <div className="text-[10px] uppercase tracking-wider font-bold text-slate-400 mt-0.5 truncate">{customer.contactPerson || '-'}</div>
                </div>
              </div>
              <div className="col-span-3 space-y-1">
                {customer.email && (
                  <div className="flex items-center gap-2 text-xs text-slate-600 truncate">
                    <Mail className="w-3.5 h-3.5 text-slate-400" />
                    <span className="truncate">{customer.email}</span>
                  </div>
                )}
                {customer.phone && (
                  <div className="flex items-center gap-2 text-xs text-slate-600">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    <span>{customer.phone}</span>
                  </div>
                )}
              </div>
              <div className="col-span-3 min-w-0">
                {customer.address ? (
                  <div className="flex items-center gap-2 text-xs text-slate-600">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate leading-tight inline-block max-w-full">{customer.address}</span>
                  </div>
                ) : (
                  <span className="text-xs text-slate-400 italic">Geen adres</span>
                )}
              </div>
              <div className="col-span-1">
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border ${
                  customer.status === 'active' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 
                  customer.status === 'inactive' ? 'bg-slate-100 text-slate-500 border-slate-200' :
                  customer.status === 'lead' ? 'bg-blue-50 text-blue-700 border-blue-100' :
                  'bg-amber-50 text-amber-600 border-amber-100'
                }`}>
                  {customer.status}
                </span>
              </div>
              <div className="col-span-1 flex justify-end gap-1 px-2 opacity-100 md:opacity-0 group-hover:opacity-100 transition-all">
                <button 
                  onClick={(e) => { e.stopPropagation(); onEdit(customer); }}
                  className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-white rounded-md border border-transparent hover:border-slate-200 transition-all shadow-sm"
                  title="Bewerken"
                >
                  <Edit3 className="w-4 h-4" />
                </button>
                <button 
                  onClick={(e) => { e.stopPropagation(); onDelete(customer.id, e); }}
                  className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-white rounded-md border border-transparent hover:border-slate-200 transition-all shadow-sm"
                  title="Verwijderen"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Mobile View */}
            <div className="md:hidden p-5 space-y-4">
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-center text-slate-400 font-bold uppercase shrink-0">
                    {customer.name.charAt(0)}
                  </div>
                  <div>
                    <div className="text-base font-bold text-slate-900 leading-tight">{customer.name}</div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider border ${
                        customer.status === 'active' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 'bg-slate-100 text-slate-500 border-slate-200'
                      }`}>
                        {customer.status}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex gap-1.5">
                  <button 
                    onClick={(e) => { e.stopPropagation(); onEdit(customer); }}
                    className="p-2.5 text-slate-500 bg-white border border-slate-200 rounded-xl shadow-sm"
                  >
                    <Edit3 className="w-4.5 h-4.5" />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-2 bg-slate-50/50 p-3 rounded-xl border border-slate-100">
                <div className="flex items-center gap-2 text-xs font-medium text-slate-600">
                   <User className="w-3.5 h-3.5 text-slate-400" />
                   {customer.contactPerson || '-'}
                </div>
                <div className="flex items-center gap-2 text-xs font-medium text-slate-600">
                   <Phone className="w-3.5 h-3.5 text-slate-400" />
                   {customer.phone || '-'}
                </div>
                {customer.email && (
                  <div className="flex items-center gap-2 text-xs font-medium text-slate-600">
                    <Mail className="w-3.5 h-3.5 text-slate-400" />
                    <span className="truncate">{customer.email}</span>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default CustomerTable;
