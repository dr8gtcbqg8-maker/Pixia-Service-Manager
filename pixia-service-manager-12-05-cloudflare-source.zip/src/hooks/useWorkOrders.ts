import { useState, useEffect, useCallback } from 'react';
import { collection, getDocs, query, orderBy, limit, doc, getDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { WorkOrder, Customer, Machine } from '../types';
import { COLLECTIONS } from '../constants/collections';

export const useWorkOrders = () => {
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [machines, setMachines] = useState<Machine[]>([]);
  const [inventory, setInventory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [settings, setSettings] = useState<any>(null);
  const [businessSettings, setBusinessSettings] = useState<any>(null);
  const [pdfLayoutSettings, setPdfLayoutSettings] = useState<any>(null);

  const refreshData = useCallback(async () => {
    setLoading(true);
    try {
      const [woSnap, cSnap, mSnap, invSnap, appSnap, busSnap, pdfSnap] = await Promise.all([
        getDocs(query(collection(db, COLLECTIONS.WORK_ORDERS), orderBy('createdAt', 'desc'), limit(50))),
        getDocs(collection(db, COLLECTIONS.CUSTOMERS)),
        getDocs(collection(db, COLLECTIONS.MACHINES)),
        getDocs(collection(db, COLLECTIONS.INVENTORY)),
        getDoc(doc(db, COLLECTIONS.SETTINGS, 'app')),
        getDoc(doc(db, COLLECTIONS.SETTINGS, 'business')),
        getDoc(doc(db, COLLECTIONS.SETTINGS, 'pdf-layout'))
      ]);
      
      setWorkOrders(woSnap.docs.map(d => ({ id: d.id, ...d.data() } as WorkOrder)));
      setCustomers(cSnap.docs.map(d => ({ id: d.id, ...d.data() } as Customer)));
      setMachines(mSnap.docs.map(d => ({ id: d.id, ...d.data() } as Machine)));
      setInventory(invSnap.docs.map(d => ({ id: d.id, ...d.data() } as any)));
      
      if (appSnap.exists()) {
        setSettings(appSnap.data());
      }
      if (busSnap.exists()) {
        setBusinessSettings(busSnap.data());
      }
      if (pdfSnap.exists()) {
        setPdfLayoutSettings(pdfSnap.data());
      }
    } catch (err) {
      console.error('Error fetching work orders data:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  return {
    workOrders,
    customers,
    machines,
    inventory,
    loading,
    settings,
    businessSettings,
    pdfLayoutSettings,
    refreshData
  };
};
