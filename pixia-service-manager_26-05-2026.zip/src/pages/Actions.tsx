import React, { useEffect, useState } from 'react';
import { collection, query, getDocs, orderBy, updateDoc, doc, where, deleteDoc, addDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { SmartAlert, AlertStatus, AlertPriority, Reminder, Customer, Machine, ReminderPriority, ReminderType } from '../types';
import { 
  Bell, CheckCircle, Eye, Trash2, Package, Wrench, 
  ShieldAlert, Activity, AlertTriangle, ChevronRight,
  Filter, Search, X, Plus, Calendar, CheckCircle2, Phone, Edit3, User, Printer, Clock
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format } from 'date-fns';
import { nl } from 'date-fns/locale';
import { handleFirestoreError, OperationType, cn } from '../lib/utils';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { COLLECTIONS } from '../constants/collections';
import ConfirmDialog from '../components/ConfirmDialog';
import AppointmentModal from '../components/AppointmentModal';
import { reminderService } from '../services/reminderService';

const Actions: React.FC = () => {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'alerts' | 'reminders'>('alerts');
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  // Alerts states
  const [alerts, setAlerts] = useState<SmartAlert[]>([]);
  const [alertsFilter, setAlertsFilter] = useState<AlertStatus | 'all'>('all');

  // Reminders states
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [machines, setMachines] = useState<Machine[]>([]);
  const [remindersFilterStatus, setRemindersFilterStatus] = useState('');
  
  // Modal states
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedReminder, setSelectedReminder] = useState<Reminder | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [duplicateWarning, setDuplicateWarning] = useState<{ isOpen: boolean; matches: Reminder[] }>({ isOpen: false, matches: [] });
  const [deleteConfirm, setDeleteConfirm] = useState<{ isOpen: boolean; id: string | null; type: 'alert' | 'reminder' }>({ 
    isOpen: false, 
    id: null, 
    type: 'alert' 
  });
  const [isAppointmentModalOpen, setIsAppointmentModalOpen] = useState(false);
  const [appointmentInitialData, setAppointmentInitialData] = useState<any>({});

  const [newReminder, setNewReminder] = useState({
    title: '',
    description: '',
    customerId: '',
    machineId: '',
    dueDate: format(new Date(), 'yyyy-MM-dd'),
    priority: 'normal' as ReminderPriority,
    status: 'open' as Reminder['status'],
    type: 'other' as ReminderType,
    internalNotes: ''
  });

  const fetchData = async () => {
    setLoading(true);
    try {
      const [aSnap, rSnap, cSnap, mSnap] = await Promise.all([
        getDocs(query(collection(db, 'smart_alerts'), orderBy('createdAt', 'desc'))),
        getDocs(query(collection(db, COLLECTIONS.REMINDERS), orderBy('dueDate', 'asc'))),
        getDocs(collection(db, COLLECTIONS.CUSTOMERS)),
        getDocs(collection(db, COLLECTIONS.MACHINES))
      ]);
      
      setAlerts(aSnap.docs.map(d => ({ id: d.id, ...d.data() } as SmartAlert)));
      setReminders(rSnap.docs.map(d => ({ id: d.id, ...d.data() } as Reminder)));
      setCustomers(cSnap.docs.map(d => ({ id: d.id, ...d.data() } as Customer)));
      setMachines(mSnap.docs.map(d => ({ id: d.id, ...d.data() } as Machine)));
    } catch (err) {
      console.error('Error fetching data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Alert Actions
  const handleUpdateAlertStatus = async (id: string, status: AlertStatus) => {
    try {
      await updateDoc(doc(db, 'smart_alerts', id), {
        status,
        updatedAt: new Date().toISOString()
      });
      setAlerts(prev => prev.map(a => a.id === id ? { ...a, status, updatedAt: new Date().toISOString() } : a));
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `smart_alerts/${id}`);
    }
  };

  const deleteAlert = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'smart_alerts', id));
      setAlerts(prev => prev.filter(a => a.id !== id));
      setDeleteConfirm({ isOpen: false, id: null, type: 'alert' });
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `smart_alerts/${id}`);
    }
  };

  // Reminder Actions
  const handleSaveReminder = async (e?: React.FormEvent, bypassDuplicateCheck = false) => {
    if (e) e.preventDefault();
    
    if (isSaving) return;

    if (!bypassDuplicateCheck) {
      setIsSaving(true);
      const matches = await reminderService.findPotentialDuplicates(newReminder, selectedReminder?.id);
      setIsSaving(false);

      if (matches.length > 0) {
        setDuplicateWarning({ isOpen: true, matches });
        return;
      }
    }

    setIsSaving(true);
    const successId = await reminderService.save(newReminder, selectedReminder);
    setIsSaving(false);

    if (successId) {
      setIsAddModalOpen(false);
      fetchData();
    }
  };

  const handleUpdateReminderStatus = async (id: string, status: Reminder['status']) => {
    try {
      await updateDoc(doc(db, COLLECTIONS.REMINDERS, id), { status, updatedAt: new Date().toISOString() });
      fetchData();
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `${COLLECTIONS.REMINDERS}/${id}`);
    }
  };

  const deleteReminder = async (id: string) => {
    try {
      await deleteDoc(doc(db, COLLECTIONS.REMINDERS, id));
      setReminders(prev => prev.filter(r => r.id !== id));
      setDeleteConfirm({ isOpen: false, id: null, type: 'reminder' });
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `${COLLECTIONS.REMINDERS}/${id}`);
    }
  };

  const handleConfirmDelete = () => {
    if (!deleteConfirm.id) return;
    if (deleteConfirm.type === 'alert') {
      deleteAlert(deleteConfirm.id);
    } else {
      deleteReminder(deleteConfirm.id);
    }
  };

  // UI Helpers
  const getAlertPriorityColor = (priority: AlertPriority) => {
    switch (priority) {
      case 'urgent': return 'bg-rose-500 text-white';
      case 'high': return 'bg-amber-500 text-white';
      case 'normal': return 'bg-brand-500 text-white';
      case 'low': return 'bg-surface-400 text-white';
      default: return 'bg-surface-500 text-white';
    }
  };

  const getReminderPriorityColor = (priority: ReminderPriority) => {
    switch (priority) {
      case 'urgent': return 'bg-red-500 text-white';
      case 'high': return 'bg-amber-500 text-white';
      case 'normal': return 'bg-brand-500 text-white';
      case 'low': return 'bg-surface-400 text-white';
      default: return 'bg-surface-500 text-white';
    }
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'stock': return <Package className="w-5 h-5" />;
      case 'maintenance': return <Wrench className="w-5 h-5" />;
      case 'warranty': return <ShieldAlert className="w-5 h-5" />;
      case 'failure': return <AlertTriangle className="w-5 h-5" />;
      case 'inactivity': return <Activity className="w-5 h-5" />;
      default: return <Bell className="w-5 h-5" />;
    }
  };

  const getReminderIcon = (type: ReminderType) => {
    switch (type) {
      case 'maintenance': return <Wrench className="w-4 h-4" />;
      case 'warranty': return <ShieldAlert className="w-4 h-4" />;
      case 'contract': return <ShieldAlert className="w-4 h-4" />;
      case 'call': return <Phone className="w-4 h-4" />;
      case 'follow-up': return <ChevronRight className="w-4 h-4" />;
      case 'stock': return <Package className="w-4 h-4" />;
      default: return <Bell className="w-4 h-4" />;
    }
  };

  const getCustomerName = (id?: string) => customers.find(c => c.id === id)?.name || 'Geen klant';
  const getMachineInfo = (id?: string) => {
    const m = machines.find(mac => mac.id === id);
    return m ? `${m.brand} ${m.model}` : 'Geen machine';
  };

  // Filtered Lists
  const filteredAlerts = alerts.filter(a => {
    const matchesFilter = alertsFilter === 'all' || a.status === alertsFilter;
    const matchesSearch = a.title.toLowerCase().includes(search.toLowerCase()) || 
                          a.description.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const filteredReminders = reminders.filter(r => {
    const matchesSearch = 
      (r.title || '').toLowerCase().includes(search.toLowerCase()) || 
      (r.description || '').toLowerCase().includes(search.toLowerCase()) ||
      getCustomerName(r.customerId).toLowerCase().includes(search.toLowerCase());
    const matchesStatus = !remindersFilterStatus || r.status === remindersFilterStatus;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-4 pb-20">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        <div>
          <h1 className="text-4xl font-black text-surface-900 tracking-tight italic flex items-center gap-4">
            Acties
            <Bell className="w-8 h-8 text-brand-500" />
          </h1>
          <p className="text-surface-500 font-medium italic text-sm mt-1">Wat vraagt vandaag je aandacht?</p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-surface-400" />
            <input 
              type="text"
              placeholder="Zoeken..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-11 pr-4 py-3 bg-white border border-surface-200 rounded-lg text-xs font-bold outline-none focus:ring-4 focus:ring-blue-100 transition-all w-64 shadow-sm"
            />
          </div>
          {activeTab === 'reminders' && (
            <button 
              onClick={() => {
                setSelectedReminder(null);
                setNewReminder({
                  title: '',
                  description: '',
                  customerId: '',
                  machineId: '',
                  dueDate: format(new Date(), 'yyyy-MM-dd'),
                  priority: 'normal',
                  status: 'open',
                  type: 'other',
                  internalNotes: ''
                });
                setIsAddModalOpen(true);
              }}
              className="bg-brand-500 text-white px-6 py-3 rounded-lg font-black text-xs uppercase tracking-[0.2em] shadow-xl shadow-blue-100 flex items-center gap-2 hover:bg-blue-700 transition-all active:scale-95"
            >
              <Plus className="w-5 h-5" />
              Nieuw
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 p-1.5 bg-surface-100 rounded-md w-fit shadow-inner">
        <button
          onClick={() => setActiveTab('alerts')}
          className={cn(
            "px-5 py-3 rounded-md text-xs font-black uppercase tracking-[0.2em] transition-all flex items-center gap-2",
            activeTab === 'alerts' ? "bg-white text-brand-500 shadow-sm" : "text-surface-500 hover:text-surface-700"
          )}
        >
          Systeem Meldingen
          {alerts.filter(a => a.status === 'open').length > 0 && (
            <span className="w-5 h-5 bg-brand-500 text-white text-[10px] rounded-full flex items-center justify-center font-bold">
              {alerts.filter(a => a.status === 'open').length}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('reminders')}
          className={cn(
            "px-5 py-3 rounded-md text-xs font-black uppercase tracking-[0.2em] transition-all flex items-center gap-2",
            activeTab === 'reminders' ? "bg-white text-brand-500 shadow-sm" : "text-surface-500 hover:text-surface-700"
          )}
        >
          Herinneringen
          {reminders.filter(r => r.status === 'open').length > 0 && (
            <span className="w-5 h-5 bg-brand-500 text-white text-[10px] rounded-full flex items-center justify-center font-bold">
              {reminders.filter(r => r.status === 'open').length}
            </span>
          )}
        </button>
      </div>

      {/* Content Area */}
      <div className="grid grid-cols-1 gap-3">
        {loading ? (
          <div className="flex items-center justify-center p-20">
            <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600"></div>
          </div>
        ) : (
          <AnimatePresence mode="wait">
            {activeTab === 'alerts' ? (
              <motion.div
                key="alerts-view"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-4"
              >
                {/* Alerts Filters */}
                <div className="flex gap-2">
                  {(['all', 'open', 'resolved'] as const).map((f) => (
                    <button
                      key={f}
                      onClick={() => setAlertsFilter(f)}
                      className={cn(
                        "px-4 py-2 rounded-md text-[10px] font-black uppercase tracking-widest transition-all border",
                        alertsFilter === f 
                          ? "bg-white border-brand-200 text-brand-500 shadow-sm" 
                          : "bg-surface-50 border-surface-100 text-surface-500 hover:text-surface-700"
                      )}
                    >
                      {f === 'all' ? 'Alle' : f === 'open' ? 'Open' : 'Opgelost'}
                    </button>
                  ))}
                </div>

                <div className="grid grid-cols-1 gap-4">
                  {filteredAlerts.length > 0 ? (
                    filteredAlerts.map((alert) => (
                      <div
                        key={alert.id}
                        className={cn(
                          "bg-white border rounded-lg p-5 shadow-sm hover:shadow-xl hover:shadow-surface-100 transition-all group flex flex-col md:flex-row items-stretch md:items-center gap-3",
                          alert.status === 'open' ? "border-surface-200" : "border-surface-100 opacity-60"
                        )}
                      >
                        <div className={cn(
                          "w-12 h-12 md:w-14 md:h-14 rounded-lg flex items-center justify-center shrink-0 shadow-lg",
                          getAlertPriorityColor(alert.priority)
                        )}>
                          {getAlertIcon(alert.type)}
                        </div>

                        <div className="flex-1 space-y-1 min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <h3 className="text-base md:text-base font-black text-surface-900 leading-tight truncate">{alert.title}</h3>
                            <span className={cn(
                              "text-[8px] md:text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded-lg border",
                              alert.status === 'open' ? "bg-brand-50 text-brand-500 border-brand-200" : "bg-surface-50 text-surface-400 border-surface-100"
                            )}>
                              {alert.status}
                            </span>
                          </div>
                          <p className="text-xs md:text-sm font-medium text-surface-500 leading-relaxed max-w-2xl">{alert.description}</p>
                          <div className="text-[10px] font-bold text-surface-400 uppercase tracking-widest pt-1">
                            {format(new Date(alert.createdAt), 'dd MMM yyyy HH:mm', { locale: nl })}
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          {alert.status === 'open' && (
                            <>
                              <button
                                onClick={() => handleUpdateAlertStatus(alert.id, 'seen')}
                                className="p-3 bg-surface-50 text-surface-400 hover:text-brand-500 hover:bg-white hover:border-surface-200 border border-transparent hover:shadow-md rounded-md transition-all"
                                title="Markeren als gezien"
                              >
                                <Eye className="w-5 h-5" />
                              </button>
                              <button
                                onClick={() => handleUpdateAlertStatus(alert.id, 'resolved')}
                                className="p-3 bg-surface-50 text-surface-400 hover:text-green-600 hover:bg-white hover:border-surface-200 border border-transparent hover:shadow-md rounded-md transition-all"
                                title="Markeren als opgelost"
                              >
                                <CheckCircle className="w-5 h-5" />
                              </button>
                            </>
                          )}
                          <button
                            onClick={() => setDeleteConfirm({ isOpen: true, id: alert.id, type: 'alert' })}
                            className="p-3 bg-surface-50 text-surface-400 hover:text-red-500 hover:bg-white hover:border-surface-200 border border-transparent hover:shadow-md rounded-md transition-all"
                            title="Verwijderen"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="bg-white border border-dashed border-surface-200 rounded-lg p-20 flex flex-col items-center justify-center text-center">
                      <div className="w-16 h-16 bg-surface-50 rounded-lg flex items-center justify-center text-surface-200 mb-4">
                        <Bell className="w-8 h-8" />
                      </div>
                      <h3 className="text-base font-black text-surface-900">Geen meldingen</h3>
                      <p className="text-surface-400 font-medium text-sm">Alles loopt op rolletjes!</p>
                    </div>
                  )}
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="reminders-view"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-4"
              >
                {/* Reminders Filters */}
                <div className="flex gap-2">
                  {(['all', 'open', 'planned', 'executed'] as const).map((s) => (
                    <button
                      key={s}
                      onClick={() => setRemindersFilterStatus(s === 'all' ? '' : s)}
                      className={cn(
                        "px-4 py-2 rounded-md text-[10px] font-black uppercase tracking-widest transition-all border",
                        (remindersFilterStatus === s || (s === 'all' && !remindersFilterStatus))
                          ? "bg-white border-brand-200 text-brand-500 shadow-sm" 
                          : "bg-surface-50 border-surface-100 text-surface-500 hover:text-surface-700"
                      )}
                    >
                      {s === 'all' ? 'Alle' : s.charAt(0).toUpperCase() + s.slice(1)}
                    </button>
                  ))}
                </div>

                <div className="grid grid-cols-1 gap-4">
                  {filteredReminders.length > 0 ? (
                    filteredReminders.map((reminder) => (
                      <div
                        key={reminder.id}
                        onClick={() => {
                          setSelectedReminder(reminder);
                          setNewReminder({
                            title: reminder.title,
                            description: reminder.description,
                            customerId: reminder.customerId || '',
                            machineId: reminder.machineId || '',
                            dueDate: reminder.dueDate,
                            priority: reminder.priority,
                            status: reminder.status,
                            type: reminder.type,
                            internalNotes: reminder.internalNotes || ''
                          });
                          setIsAddModalOpen(true);
                        }}
                        className={cn(
                          "bg-white border rounded-lg p-5 shadow-sm hover:shadow-xl hover:shadow-surface-100 transition-all group flex flex-col md:flex-row items-stretch md:items-center gap-3 cursor-pointer",
                          reminder.status === 'open' ? "border-surface-200" : "border-surface-100 opacity-60"
                        )}
                      >
                        <div className={cn(
                          "w-12 h-12 md:w-14 md:h-14 rounded-lg flex items-center justify-center shrink-0 shadow-lg",
                          getReminderPriorityColor(reminder.priority)
                        )}>
                          {getReminderIcon(reminder.type)}
                        </div>

                        <div className="flex-1 space-y-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <h3 className="text-base font-black text-surface-900 truncate">{reminder.title}</h3>
                            {reminder.count && reminder.count > 1 && (
                              <span className="px-1.5 py-0.5 bg-blue-100 text-blue-700 text-[10px] font-black rounded-lg">
                                {reminder.count}x
                              </span>
                            )}
                            <span className="text-[10px] font-black text-brand-500 uppercase tracking-widest ml-auto">
                              {reminder.dueDate}
                            </span>
                          </div>
                          <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
                             <div className="flex items-center gap-1.5 text-[11px] font-bold text-surface-500">
                               <User className="w-3.5 h-3.5" />
                               {getCustomerName(reminder.customerId)}
                             </div>
                             <div className="flex items-center gap-1.5 text-[11px] font-bold text-surface-400">
                               <Printer className="w-3.5 h-3.5" />
                               {getMachineInfo(reminder.machineId)}
                             </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                          {reminder.status === 'open' && (
                            <>
                              <button 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setAppointmentInitialData({
                                    date: reminder.dueDate,
                                    reminderId: reminder.id,
                                    customerId: reminder.customerId,
                                    machineId: reminder.machineId,
                                    title: reminder.title
                                  });
                                  setIsAppointmentModalOpen(true);
                                }}
                                className="p-3 bg-surface-50 text-surface-400 hover:text-brand-600 hover:bg-white hover:border-surface-200 border border-transparent shadow-sm rounded-md transition-all"
                                title="Plan Afspraak"
                              >
                                <Calendar className="w-5 h-5" />
                              </button>
                              <button 
                                onClick={(e) => { e.stopPropagation(); handleUpdateReminderStatus(reminder.id, 'executed'); }}
                                className="p-3 bg-surface-50 text-surface-400 hover:text-green-600 hover:bg-white hover:border-surface-200 border border-transparent shadow-sm rounded-md transition-all"
                                title="Voltooien"
                              >
                                <CheckCircle2 className="w-5 h-5" />
                              </button>
                            </>
                          )}
                          <button 
                            onClick={(e) => { e.stopPropagation(); setDeleteConfirm({ isOpen: true, id: reminder.id, type: 'reminder' }); }}
                            className="p-3 bg-surface-50 text-surface-400 hover:text-red-500 hover:bg-white hover:border-surface-200 border border-transparent shadow-sm rounded-md transition-all"
                            title="Verwijderen"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="bg-white border border-dashed border-surface-200 rounded-lg p-20 flex flex-col items-center justify-center text-center">
                      <div className="w-16 h-16 bg-surface-50 rounded-lg flex items-center justify-center text-surface-200 mb-4">
                        <Clock className="w-8 h-8" />
                      </div>
                      <h3 className="text-base font-black text-surface-900">Geen herinneringen</h3>
                      <p className="text-surface-400 font-medium text-sm">Plan een actie in om te beginnen.</p>
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        )}
      </div>

      {/* Add/Edit Reminder Modal */}
      <AnimatePresence>
        {isAddModalOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center p-4"
          >
            <div className="absolute inset-0 bg-surface-900/60 backdrop-blur-sm" />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-2xl rounded-lg shadow-2xl p-5 overflow-y-auto max-h-[90vh]"
            >
              <h2 className="text-xl font-black text-surface-900 mb-8 border-b border-surface-100 pb-6 flex items-center gap-3 italic">
                <Bell className="w-6 h-6 text-brand-500" />
                {selectedReminder ? 'Herinnering Bewerken' : 'Nieuwe Herinnering'}
              </h2>
              <form onSubmit={handleSaveReminder} className="space-y-3">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="md:col-span-2 space-y-1">
                    <label className="text-[10px] font-black uppercase tracking-widest text-surface-400 ml-1">Titel *</label>
                    <input 
                      required 
                      type="text" 
                      placeholder="bijv. Klant bellen voor afspraak"
                      className="w-full px-4 py-3 bg-surface-50 border border-surface-200 rounded-md font-bold text-sm focus:ring-2 focus:ring-blue-500 outline-none" 
                      value={newReminder.title}
                      onChange={(e) => setNewReminder({...newReminder, title: e.target.value})}
                    />
                  </div>

                  <div className="md:col-span-2 space-y-1">
                    <label className="text-[10px] font-black uppercase tracking-widest text-surface-400 ml-1">Omschrijving</label>
                    <textarea 
                      rows={3}
                      className="w-full px-4 py-3 bg-surface-50 border border-surface-200 rounded-md font-bold text-sm focus:ring-2 focus:ring-blue-500 outline-none resize-none" 
                      value={newReminder.description}
                      onChange={(e) => setNewReminder({...newReminder, description: e.target.value})}
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-black uppercase tracking-widest text-surface-400 ml-1">Klant</label>
                    <select 
                      className="w-full px-4 py-3 bg-surface-50 border border-surface-200 rounded-md font-bold text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                      value={newReminder.customerId}
                      onChange={(e) => setNewReminder({...newReminder, customerId: e.target.value})}
                    >
                      <option value="">Koppel aan klant...</option>
                      {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-black uppercase tracking-widest text-surface-400 ml-1">Machine</label>
                    <select 
                      className="w-full px-4 py-3 bg-surface-50 border border-surface-200 rounded-md font-bold text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                      value={newReminder.machineId}
                      onChange={(e) => setNewReminder({...newReminder, machineId: e.target.value})}
                    >
                      <option value="">Koppel aan machine...</option>
                      {machines.filter(m => !newReminder.customerId || m.customerId === newReminder.customerId).map(m => (
                        <option key={m.id} value={m.id}>{m.brand} {m.model} ({m.serialNumber})</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-black uppercase tracking-widest text-surface-400 ml-1">Datum</label>
                    <input 
                      type="date" 
                      className="w-full px-4 py-3 bg-surface-50 border border-surface-200 rounded-md font-bold text-sm focus:ring-2 focus:ring-blue-500 outline-none" 
                      value={newReminder.dueDate}
                      onChange={(e) => setNewReminder({...newReminder, dueDate: e.target.value})}
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-black uppercase tracking-widest text-surface-400 ml-1">Prioriteit</label>
                    <select 
                      className="w-full px-4 py-3 bg-surface-50 border border-surface-200 rounded-md font-bold text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                      value={newReminder.priority}
                      onChange={(e) => setNewReminder({...newReminder, priority: e.target.value as ReminderPriority})}
                    >
                      <option value="low">Laag</option>
                      <option value="normal">Normaal</option>
                      <option value="high">Hoog</option>
                      <option value="urgent">Urgent / Nu</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-black uppercase tracking-widest text-surface-400 ml-1">Type Herinnering</label>
                    <select 
                      className="w-full px-4 py-3 bg-surface-50 border border-surface-200 rounded-md font-bold text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                      value={newReminder.type}
                      onChange={(e) => setNewReminder({...newReminder, type: e.target.value as ReminderType})}
                    >
                      <option value="maintenance">Onderhoud</option>
                      <option value="warranty">Garantie</option>
                      <option value="contract">Onderhoudscontract</option>
                      <option value="call">Afspraak / Tel.</option>
                      <option value="follow-up">Follow-up</option>
                      <option value="stock">Voorraad</option>
                      <option value="other">Overig</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                     <label className="text-[10px] font-black uppercase tracking-widest text-surface-400 ml-1">Status</label>
                     <select 
                       className="w-full px-4 py-3 bg-surface-50 border border-surface-200 rounded-md font-bold text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                       value={newReminder.status}
                       onChange={(e) => setNewReminder({...newReminder, status: e.target.value as any})}
                    >
                      <option value="open">Open</option>
                      <option value="planned">Ingepland</option>
                      <option value="postponed">Doorgeschoven</option>
                      <option value="executed">Uitgevoerd</option>
                      <option value="completed">Afgerond</option>
                      <option value="expired">Verlopen</option>
                      <option value="cancelled">Geannuleerd</option>
                      <option value="ignored">Genegeerd</option>
                    </select>
                  </div>
                </div>

                <AnimatePresence>
                  {duplicateWarning.isOpen && (
                    <motion.div 
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="bg-amber-50 border border-amber-100 rounded-md p-4 overflow-hidden mt-6"
                    >
                      <div className="flex items-start gap-3">
                        <div className="p-2 bg-amber-100 text-amber-600 rounded-lg shrink-0">
                          <AlertTriangle className="w-5 h-5" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-bold text-amber-900">Mogelijke dubbele herinnering gevonden</p>
                          <p className="text-xs text-amber-700 mt-1">
                            Er bestaat al een open herinnering voor deze machine/klant die mogelijk hetzelfde is.
                          </p>
                          <div className="mt-3 space-y-2">
                            {duplicateWarning.matches.map(m => (
                              <div key={m.id} className="flex items-center justify-between p-2 bg-white/50 rounded-lg border border-amber-200/50">
                                <span className="text-[11px] font-bold text-surface-700">{m.title} ({m.dueDate})</span>
                                <div className="flex gap-2">
                                  <button 
                                    type="button"
                                    onClick={() => {
                                      setDuplicateWarning({ isOpen: false, matches: [] });
                                      setSelectedReminder(m);
                                      setNewReminder({
                                        title: m.title,
                                        description: m.description,
                                        customerId: m.customerId || '',
                                        machineId: m.machineId || '',
                                        dueDate: m.dueDate,
                                        priority: m.priority,
                                        status: m.status,
                                        type: m.type,
                                        internalNotes: m.internalNotes || ''
                                      });
                                    }}
                                    className="text-[10px] font-black uppercase text-amber-600 hover:text-amber-700"
                                  >
                                    Bewerken
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                          <div className="mt-4 flex items-center gap-3">
                             <button
                               type="button"
                               onClick={() => setDuplicateWarning({ isOpen: false, matches: [] })}
                               className="text-xs font-bold text-surface-500 hover:text-surface-700"
                             >
                               Aanpassen
                             </button>
                             <button
                               type="button"
                               onClick={() => handleSaveReminder(undefined, true)}
                               className="text-xs font-bold text-amber-600 hover:text-amber-700 underline underline-offset-2"
                             >
                               Toch opslaan
                             </button>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <div className="flex items-center gap-4 pt-8 shrink-0 pb-2">
                  <button 
                    type="button" 
                    disabled={isSaving}
                    onClick={() => setIsAddModalOpen(false)}
                    className="flex-1 py-2 text-surface-600 font-black text-xs uppercase tracking-[0.2em] hover:bg-surface-50 rounded-lg transition-all border border-surface-100"
                  >
                    Annuleren
                  </button>
                  <button 
                    type="submit" 
                    disabled={isSaving}
                    className="flex-1 py-2 bg-brand-500 text-white font-black text-xs uppercase tracking-[0.2em] rounded-lg shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all active:scale-[0.98]"
                  >
                    {isSaving ? (
                      <div className="flex items-center justify-center gap-2">
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        <span>Laden...</span>
                      </div>
                    ) : (
                      <span>{selectedReminder ? 'Opslaan' : 'Toevoegen'}</span>
                    )}
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <ConfirmDialog
        isOpen={deleteConfirm.isOpen}
        title={`${deleteConfirm.type === 'alert' ? 'Melding' : 'Herinnering'} Verwijderen`}
        message="Weet u zeker dat u dit wilt verwijderen? Deze actie kan niet ongedaan worden gemaakt."
        onConfirm={handleConfirmDelete}
        onCancel={() => setDeleteConfirm({ ...deleteConfirm, isOpen: false })}
      />

      <AppointmentModal 
        isOpen={isAppointmentModalOpen}
        onClose={() => setIsAppointmentModalOpen(false)}
        appointment={null}
        initialData={appointmentInitialData}
        onSave={() => {
          setIsAppointmentModalOpen(false);
          fetchData();
        }}
        customers={customers}
        machines={machines}
        reminders={reminders}
        interventions={[]}
      />
    </div>
  );
};

export default Actions;
