import React, { useEffect, useState, useMemo } from 'react';
import { InventoryItem, InventoryMutation, MutationType } from '../types';
import { 
  Plus, Package, AlertTriangle, ArrowUpRight, ArrowDownRight, 
  History, CheckCircle2, Tag, MapPin, Hash, DollarSign,
  X, Trash2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ConfirmDialog from '../components/ConfirmDialog';
import { format } from 'date-fns';
import { useInventory } from '../hooks/useInventory';
import { inventoryService } from '../services/inventoryService';
import InventoryTable from '../components/inventory/InventoryTable';
import InventoryFilters from '../components/inventory/InventoryFilters';
import { cn } from '../lib/utils';

const Inventory: React.FC = () => {
  const { items, loading, refreshData, fetchMutations } = useInventory();
  const [mutations, setMutations] = useState<InventoryMutation[]>([]);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [isMutationModalOpen, setIsMutationModalOpen] = useState(false);
  
  const [search, setSearch] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterSupplier, setFilterSupplier] = useState('all');
  const [filterStatus, setFilterStatus] = useState('active');
  const [filterLowStock, setFilterLowStock] = useState(false);
  
  const [deleteConfirm, setDeleteConfirm] = useState<{ isOpen: boolean; id: string | null }>({ isOpen: false, id: null });

  const [formData, setFormData] = useState({
    name: '',
    category: '',
    partNumber: '',
    supplier: '',
    stockCount: 0,
    minStock: 5,
    location: '',
    purchasePrice: 0,
    sellingPrice: 0,
    notes: '',
    status: 'active' as 'active' | 'inactive'
  });

  const [mutationData, setMutationData] = useState({
    type: 'increase' as MutationType,
    quantity: 0,
    reason: ''
  });

  const categories = useMemo(() => Array.from(new Set(items.map(i => i.category))).filter(Boolean), [items]);
  const suppliers = useMemo(() => Array.from(new Set(items.map(i => i.supplier))).filter(Boolean), [items]);

  const handleOpenAddModal = () => {
    setSelectedItem(null);
    setFormData({
      name: '', category: '', partNumber: '', supplier: '', 
      stockCount: 0, minStock: 5, location: '', 
      purchasePrice: 0, sellingPrice: 0, notes: '', status: 'active'
    });
    setIsAddModalOpen(true);
  };

  const handleOpenEditModal = (item: InventoryItem) => {
    setSelectedItem(item);
    setFormData({
      name: item.name,
      category: item.category,
      partNumber: item.partNumber,
      supplier: item.supplier,
      stockCount: item.stockCount,
      minStock: item.minStock,
      location: item.location,
      purchasePrice: item.purchasePrice,
      sellingPrice: item.sellingPrice,
      notes: item.notes,
      status: item.status
    });
    setIsAddModalOpen(true);
  };

  const handleOpenDetails = async (item: InventoryItem) => {
    setSelectedItem(item);
    const itemMutations = await fetchMutations(item.id);
    setMutations(itemMutations);
    setIsDetailsModalOpen(true);
  };

  const handleOpenMutationModal = (item: InventoryItem, type: MutationType) => {
    setSelectedItem(item);
    setMutationData({ type, quantity: 0, reason: '' });
    setIsMutationModalOpen(true);
  };

  const handleSaveItem = async (e: React.FormEvent) => {
    e.preventDefault();
    const success = await inventoryService.save(formData, selectedItem);
    if (success) {
      setIsAddModalOpen(false);
      refreshData();
    }
  };

  const handleSaveMutation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedItem) return;
    if (mutationData.quantity <= 0 && mutationData.type !== 'correction') {
      alert('Voer een aantal groter dan 0 in.');
      return;
    }

    const success = await inventoryService.saveMutation(
      selectedItem.id,
      selectedItem.stockCount,
      mutationData.type,
      mutationData.quantity,
      mutationData.reason
    );

    if (success) {
      setIsMutationModalOpen(false);
      refreshData();
      if (isDetailsModalOpen) {
        const itemMutations = await fetchMutations(selectedItem.id);
        setMutations(itemMutations);
      }
    }
  };

  const handleDeleteClick = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setDeleteConfirm({ isOpen: true, id });
  };

  const confirmDelete = async () => {
    if (!deleteConfirm.id) return;
    const success = await inventoryService.delete(deleteConfirm.id);
    if (success) {
      setDeleteConfirm({ isOpen: false, id: null });
      refreshData();
    }
  };

  const filteredItems = useMemo(() => items.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(search.toLowerCase()) || 
                          item.partNumber?.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = filterCategory === 'all' || item.category === filterCategory;
    const matchesSupplier = filterSupplier === 'all' || item.supplier === filterSupplier;
    const matchesStatus = filterStatus === 'all' || item.status === filterStatus;
    const isLowStock = item.stockCount <= item.minStock;
    const matchesLowStock = !filterLowStock || isLowStock;
    
    return matchesSearch && matchesCategory && matchesSupplier && matchesStatus && matchesLowStock;
  }), [items, search, filterCategory, filterSupplier, filterStatus, filterLowStock]);

  return (
    <div className="space-y-8 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Voorraadbeheer</h1>
          <p className="text-slate-500 mt-1 text-sm">Beheer onderdelen en verbruiksartikelen in de centrale voorraad.</p>
        </div>
        <button 
          onClick={handleOpenAddModal}
          className="btn-primary"
        >
          <Plus className="w-5 h-5" />
          <span>Nieuw Artikel</span>
        </button>
      </div>

      <InventoryFilters 
        search={search} setSearch={setSearch}
        filterCategory={filterCategory} setFilterCategory={setFilterCategory} categories={categories}
        filterSupplier={filterSupplier} setFilterSupplier={setFilterSupplier} suppliers={suppliers}
        filterStatus={filterStatus} setFilterStatus={setFilterStatus}
        filterLowStock={filterLowStock} setFilterLowStock={setFilterLowStock}
      />

      {loading ? (
        <div className="flex justify-center p-24">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-slate-200 border-t-blue-600"></div>
        </div>
      ) : (
        <InventoryTable 
          items={filteredItems}
          onDetails={handleOpenDetails}
          onEdit={handleOpenEditModal}
          onDelete={handleDeleteClick}
          onMutation={handleOpenMutationModal}
        />
      )}

      <ConfirmDialog
        isOpen={deleteConfirm.isOpen}
        title="Artikel verwijderen"
        message="Weet u zeker dat u dit artikel wilt verwijderen uit de voorraad? Deze actie kan niet ongedaan worden gemaakt."
        onConfirm={confirmDelete}
        onCancel={() => setDeleteConfirm({ isOpen: false, id: null })}
      />

      {/* Add/Edit Modal */}
      <AnimatePresence>
        {isAddModalOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
              onClick={() => setIsAddModalOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative bg-white w-full max-w-2xl rounded-2xl shadow-xl overflow-hidden"
            >
              <div className="px-8 py-6 border-b border-slate-100 flex items-center justify-between">
                <h2 className="text-xl font-bold text-slate-900">
                  {selectedItem ? 'Artikel bewerken' : 'Nieuw artikel toevoegen'}
                </h2>
                <button 
                  onClick={() => setIsAddModalOpen(false)}
                  className="p-2 hover:bg-slate-100 rounded-lg text-slate-400 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveItem} className="p-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="md:col-span-2">
                    <label className="label">Artikelnaam *</label>
                    <input 
                      required 
                      type="text" 
                      className="input-field"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                    />
                  </div>

                  <div>
                    <label className="label">Artikelnummer</label>
                    <div className="relative">
                      <Hash className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type="text" 
                        className="input-field pl-10"
                        placeholder="VB: 12345-AB"
                        value={formData.partNumber}
                        onChange={(e) => setFormData({...formData, partNumber: e.target.value})}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="label">Categorie</label>
                    <div className="relative">
                      <Tag className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type="text" 
                        className="input-field pl-10"
                        placeholder="VB: Onderdelen"
                        value={formData.category}
                        onChange={(e) => setFormData({...formData, category: e.target.value})}
                      />
                    </div>
                  </div>

                  <div className="md:col-span-2 grid grid-cols-2 gap-4">
                    <div>
                      <label className="label">Voorraad</label>
                      <input 
                        disabled={!!selectedItem}
                        type="number" 
                        className="input-field disabled:bg-slate-50 disabled:text-slate-500"
                        value={formData.stockCount}
                        onChange={(e) => setFormData({...formData, stockCount: parseInt(e.target.value) || 0})}
                      />
                    </div>
                    <div>
                      <label className="label">Minimale voorraad</label>
                      <input 
                        type="number" 
                        className="input-field"
                        value={formData.minStock}
                        onChange={(e) => setFormData({...formData, minStock: parseInt(e.target.value) || 0})}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="label">Locatie</label>
                    <div className="relative">
                      <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type="text" 
                        className="input-field pl-10"
                        placeholder="VB: Kast A-12"
                        value={formData.location}
                        onChange={(e) => setFormData({...formData, location: e.target.value})}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="label">Status</label>
                    <select 
                      className="input-field"
                      value={formData.status}
                      onChange={(e) => setFormData({...formData, status: e.target.value as any})}
                    >
                      <option value="active">Actief</option>
                      <option value="inactive">Inactief</option>
                    </select>
                  </div>

                  <div>
                    <label className="label">Inkoopprijs (€)</label>
                    <div className="relative">
                      <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type="number" step="0.01"
                        className="input-field pl-10"
                        value={formData.purchasePrice}
                        onChange={(e) => setFormData({...formData, purchasePrice: parseFloat(e.target.value) || 0})}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="label">Verkoopprijs (€)</label>
                    <div className="relative">
                      <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type="number" step="0.01"
                        className="input-field pl-10"
                        value={formData.sellingPrice}
                        onChange={(e) => setFormData({...formData, sellingPrice: parseFloat(e.target.value) || 0})}
                      />
                    </div>
                  </div>

                  <div className="md:col-span-2">
                    <label className="label">Interne notities</label>
                    <textarea 
                      className="input-field py-3 min-h-[100px] resize-none"
                      rows={3}
                      placeholder="Optionele extra informatie..."
                      value={formData.notes}
                      onChange={(e) => setFormData({...formData, notes: e.target.value})}
                    />
                  </div>
                </div>

                <div className="mt-8 flex items-center justify-end gap-3 pt-6 border-t border-slate-100">
                  <button 
                    type="button" 
                    onClick={() => setIsAddModalOpen(false)}
                    className="btn-ghost"
                  >
                    Annuleren
                  </button>
                  <button 
                    type="submit" 
                    className="btn-primary min-w-[140px]"
                  >
                    {selectedItem ? 'Opslaan' : 'Toevoegen'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Mutation Modal */}
      <AnimatePresence>
        {isMutationModalOpen && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
              onClick={() => setIsMutationModalOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative bg-white w-full max-w-md rounded-2xl shadow-xl p-8"
            >
              <h2 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-2">
                <Package className="w-5 h-5 text-blue-600" />
                <span className="capitalize">Voorraad {mutationData.type}</span>
              </h2>
              
              <form onSubmit={handleSaveMutation} className="space-y-6">
                <div>
                  <label className="label">
                    {mutationData.type === 'correction' ? 'Nieuwe voorraad stand' : 'Aantal stuks'}
                  </label>
                  <input 
                    required 
                    type="number" 
                    className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-xl font-bold text-2xl text-center focus:ring-2 focus:ring-blue-500 outline-none"
                    value={mutationData.quantity}
                    onChange={(e) => setMutationData({...mutationData, quantity: parseInt(e.target.value) || 0})}
                  />
                  {mutationData.type !== 'correction' && (
                    <div className="flex justify-center mt-3">
                      <div className="px-3 py-1 bg-slate-100 rounded-full text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                         Huidig: {selectedItem?.stockCount} → Nieuw: {
                            mutationData.type === 'increase' 
                            ? (selectedItem?.stockCount || 0) + mutationData.quantity 
                            : (selectedItem?.stockCount || 0) - mutationData.quantity
                        }
                      </div>
                    </div>
                  )}
                </div>

                <div>
                  <label className="label">Reden / Notitie</label>
                  <input 
                    type="text" 
                    className="input-field"
                    placeholder="Bijv. Inventaris, Nieuwe levering..."
                    value={mutationData.reason}
                    onChange={(e) => setMutationData({...mutationData, reason: e.target.value})}
                  />
                </div>

                <div className="flex items-center gap-3 pt-6 border-t border-slate-100">
                  <button 
                    type="button" 
                    onClick={() => setIsMutationModalOpen(false)}
                    className="btn-ghost flex-1"
                  >
                    Annuleren
                  </button>
                  <button 
                    type="submit" 
                    className={cn(
                        "btn-primary flex-1",
                        mutationData.type === 'increase' ? 'bg-emerald-600 hover:bg-emerald-700' : 
                        mutationData.type === 'decrease' ? 'bg-rose-600 hover:bg-rose-700' : ''
                    )}
                  >
                    Bevestigen
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Details Modal */}
      <AnimatePresence>
        {isDetailsModalOpen && selectedItem && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
              onClick={() => setIsDetailsModalOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative bg-white w-full max-w-4xl rounded-2xl shadow-xl overflow-hidden flex flex-col max-h-[90vh]"
            >
              <div className="px-8 py-6 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-4">
                   <div className={cn(
                     "w-12 h-12 rounded-xl flex items-center justify-center border shadow-sm",
                     selectedItem.stockCount <= selectedItem.minStock ? 'bg-rose-50 text-rose-600 border-rose-100' : 'bg-white text-blue-600 border-slate-200'
                   )}>
                      <Package className="w-6 h-6" />
                   </div>
                   <div>
                      <h2 className="text-xl font-bold text-slate-900">{selectedItem.name}</h2>
                      <p className="text-xs font-mono text-slate-500">PN: {selectedItem.partNumber || 'Geen nummer'}</p>
                   </div>
                </div>
                <button 
                  onClick={() => setIsDetailsModalOpen(false)}
                  className="p-2 hover:bg-white rounded-lg text-slate-400 transition-colors border border-transparent hover:border-slate-200"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-8 lg:p-12">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                  <div className="space-y-8">
                     <div className="grid grid-cols-2 gap-4">
                        <div className="p-5 bg-slate-50 border border-slate-200 rounded-xl">
                           <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Leverancier</span>
                           <p className="text-sm font-bold text-slate-700">{selectedItem.supplier || 'Niet bekend'}</p>
                        </div>
                        <div className="p-5 bg-slate-50 border border-slate-200 rounded-xl">
                           <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Magazijnlocatie</span>
                           <p className="text-sm font-bold text-slate-700">{selectedItem.location || 'Niet bekend'}</p>
                        </div>
                     </div>

                     <div className="bg-slate-900 text-white rounded-2xl p-8 shadow-xl">
                        <div className="flex items-center justify-between mb-8">
                           <div>
                              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Huidige Voorraad</span>
                              <div className="flex items-baseline gap-2">
                                <span className={cn(
                                  "text-4xl font-bold",
                                  selectedItem.stockCount <= selectedItem.minStock ? 'text-rose-400' : 'text-white'
                                )}>{selectedItem.stockCount}</span>
                                <span className="text-slate-400 text-sm">stuks</span>
                              </div>
                           </div>
                           <div className="text-right">
                              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Minimum niveau</span>
                              <p className="text-lg font-bold text-white/90">{selectedItem.minStock} stuks</p>
                           </div>
                        </div>
                        <div className="grid grid-cols-2 gap-8 pt-8 border-t border-white/10">
                           <div>
                              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Verkoopprijs</span>
                              <p className="text-xl font-bold">€ {selectedItem.sellingPrice.toFixed(2)}</p>
                           </div>
                           <div className="text-right">
                              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Inkoopprijs</span>
                              <p className="text-xl font-bold text-white/60">€ {selectedItem.purchasePrice.toFixed(2)}</p>
                           </div>
                        </div>
                     </div>

                     <div className="space-y-4">
                        <h4 className="text-sm font-bold text-slate-900">Snelle handelingen</h4>
                        <div className="grid grid-cols-2 gap-3">
                           <button 
                              onClick={() => handleOpenMutationModal(selectedItem, 'increase')}
                              className="btn-ghost !bg-slate-50 hover:!bg-emerald-50 !border-slate-200 hover:!border-emerald-200 !text-slate-700 hover:!text-emerald-700 !py-4"
                           >
                              <Plus className="w-5 h-5" />
                              <span>Inboeken</span>
                           </button>
                           <button 
                              onClick={() => handleOpenMutationModal(selectedItem, 'decrease')}
                              className="btn-ghost !bg-slate-50 hover:!bg-rose-50 !border-slate-200 hover:!border-rose-200 !text-slate-700 hover:!text-rose-700 !py-4"
                           >
                              <ArrowDownRight className="w-5 h-5" />
                              <span>Uitboeken</span>
                           </button>
                        </div>
                     </div>
                  </div>

                  <div className="flex flex-col h-full bg-slate-50 border border-slate-200 rounded-2xl overflow-hidden">
                     <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-white">
                        <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                           <History className="w-4 h-4 text-blue-600" />
                           Mutatiehistorie
                        </h3>
                     </div>
                     
                     <div className="flex-1 overflow-y-auto p-4 space-y-3 min-h-[400px]">
                        {mutations.length > 0 ? (
                          mutations.map(m => (
                            <div key={m.id} className="p-4 bg-white border border-slate-200 rounded-xl shadow-sm flex items-center justify-between">
                               <div className="flex items-center gap-3">
                                  <div className={cn(
                                    "w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border",
                                    m.type === 'increase' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-rose-50 text-rose-600 border-rose-100'
                                  )}>
                                     {m.type === 'increase' ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
                                  </div>
                                  <div>
                                     <div className="flex items-center gap-2">
                                        <span className="text-xs font-bold text-slate-900 capitalize">{m.type}</span>
                                        <span className="text-[10px] text-slate-400">{format(new Date(m.timestamp), 'dd/MM/yy HH:mm')}</span>
                                     </div>
                                     <p className="text-[11px] text-slate-500 line-clamp-1">{m.reason || 'Geen reden opgegeven'}</p>
                                  </div>
                               </div>
                               <div className="text-right">
                                  <span className={cn(
                                    "text-sm font-bold",
                                    m.type === 'increase' ? 'text-emerald-600' : 'text-rose-600'
                                  )}>
                                     {m.type === 'increase' ? '+' : '-'}{m.quantity}
                                  </span>
                               </div>
                            </div>
                          ))
                        ) : (
                          <div className="h-full flex flex-col items-center justify-center text-center p-12 opacity-30">
                             <History className="w-10 h-10 mb-4" />
                             <p className="text-xs font-bold uppercase tracking-widest">Geen mutaties</p>
                          </div>
                        )}
                     </div>
                  </div>
                </div>
              </div>

              <div className="px-8 py-5 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
                 <button 
                    onClick={() => { setDeleteConfirm({ isOpen: true, id: selectedItem.id }); setIsDetailsModalOpen(false); }}
                    className="flex items-center gap-2 text-slate-400 hover:text-rose-600 text-xs font-medium transition-colors"
                 >
                    <Trash2 className="w-4 h-4" />
                    <span>Artikel verwijderen</span>
                 </button>
                 <button 
                  onClick={() => setIsDetailsModalOpen(false)}
                  className="btn-primary min-w-[120px]"
                >
                  Sluiten
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Inventory;
