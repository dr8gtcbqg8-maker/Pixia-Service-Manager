import fs from 'fs';
import path from 'path';

function walkDir(dir: string, callback: (path: string) => void) {
  fs.readdirSync(dir).forEach(f => {
    const dirPath = path.join(dir, f);
    if (fs.statSync(dirPath).isDirectory()) {
      walkDir(dirPath, callback);
    } else {
      callback(path.join(dir, f));
    }
  });
}

function processFile(filePath: string) {
  if (!filePath.endsWith('.tsx')) return;
  let content = fs.readFileSync(filePath, 'utf8');
  let original = content;
  
  // Single line replacement: <div ... className="...backdrop..."... onClick={...} ... >
  content = content.replace(/(className="[^"]*backdrop[^"]*"[^>]*?)\s*onClick=\{[^}]+\}/g, '$1');
  
  // Wait, sometimes onClick spans multiple lines or has inner curlies like onClick={(e) => { e.stopPropagation(); }}
  // It's safer to just split by line and if a line contains backdrop and onClick, replace it.
  
  let lines = content.split('\n');
  let modified = false;
  for (let i = 0; i < lines.length; i++) {
     if (lines[i].includes('backdrop') && lines[i].includes('onClick={')) {
        lines[i] = lines[i].replace(/onClick=\{.*?\}/, '');
        // handle outer curlies if any
        lines[i] = lines[i].replace(/onClick=\{\(.*?\}\}/, '');
        modified = true;
     }
  }
  
  // multi-line
  for (let i = 0; i < lines.length - 1; i++) {
     if (lines[i].includes('backdrop') && lines[i].match(/<div [^>]*$/) && lines[i+1].includes('onClick={')) {
        let replaceMatched = lines[i+1].replace(/onClick=\{.*?\}/, '');
        replaceMatched = replaceMatched.replace(/onClick=\{\(.*?\}\}/, '');
        if (replaceMatched !== lines[i+1]) {
           lines[i+1] = replaceMatched;
           modified = true;
        }
     }
  }

  if (modified) {
     fs.writeFileSync(filePath, lines.join('\n'));
     console.log('Modified ' + filePath);
  }
}

walkDir('src', processFile);
